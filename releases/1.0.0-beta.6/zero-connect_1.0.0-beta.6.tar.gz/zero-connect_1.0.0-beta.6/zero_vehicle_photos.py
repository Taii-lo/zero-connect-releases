"""Vehicle photos that are not shipped with the app.

Manufacturer pictures are downloaded from the manufacturer's own image server the
first time a model/color is shown and then kept in this device's data directory.
The URL always comes from the bundled catalogue (`vehicle-sources.json`), never
from a request, and only hosts named there are contacted. Owners can also upload
a photo of their own bike; it stays on the device.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from zero_paths import PATHS

MAX_PHOTO_BYTES = 6 * 1024 * 1024
MAX_UPLOAD_BYTES = 6 * 1024 * 1024
RETRY_AFTER_SECONDS = 600
NAME = re.compile(r"^zero-[a-z0-9]+-[a-z0-9]+\.webp$")
CUSTOM_NAME = "custom"
_MAGIC = ((b"\xff\xd8\xff", "jpg", "image/jpeg"), (b"\x89PNG\r\n\x1a\n", "png", "image/png"))
_lock = threading.Lock()
_failed: dict[str, float] = {}


def cache_dir() -> Path:
    return PATHS.data_dir / "vehicle-photos"


def _catalogue() -> dict[str, Any]:
    try:
        value = json.loads((PATHS.web_assets_dir / "vehicle-sources.json").read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def source_for(name: str) -> str | None:
    """Download URL for a cache file name, or None when it is not in the catalogue."""
    if not NAME.match(name):
        return None
    catalogue = _catalogue()
    entry = (catalogue.get("photos") or {}).get(name)
    url = entry.get("url") if isinstance(entry, dict) else None
    parsed = urllib.parse.urlparse(str(url or ""))
    if parsed.scheme != "https" or parsed.hostname not in set(catalogue.get("hosts") or []):
        return None
    return str(url)


def version_for(name: str) -> str | None:
    """Stable cache-busting token: changes when the catalogue points to another image."""
    if name == CUSTOM_NAME:
        path = custom_path()
        try:
            return f"c{int(path.stat().st_mtime)}" if path else None
        except OSError:
            return None
    url = source_for(name)
    return hashlib.sha256(url.encode()).hexdigest()[:12] if url else None


def _is_webp(data: bytes) -> bool:
    return data[:4] == b"RIFF" and data[8:12] == b"WEBP"


def fetch(name: str, *, opener=None) -> Path | None:
    """Return the cached photo, downloading it once. None means: use the neutral drawing."""
    url = source_for(name)
    if url is None:
        return None
    target = cache_dir() / name
    if target.is_file():
        return target
    with _lock:
        if target.is_file():
            return target
        if time.monotonic() - _failed.get(name, -RETRY_AFTER_SECONDS) < RETRY_AFTER_SECONDS:
            return None
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "ZeroConnect (personal dashboard)"})
            with (opener or urllib.request.urlopen)(request, timeout=20) as response:
                data = response.read(MAX_PHOTO_BYTES + 1)
        except (urllib.error.URLError, OSError, TimeoutError, ValueError):
            _failed[name] = time.monotonic()
            return None
        if len(data) > MAX_PHOTO_BYTES or not _is_webp(data):
            _failed[name] = time.monotonic()
            return None
        cache_dir().mkdir(parents=True, exist_ok=True)
        handle, temporary = tempfile.mkstemp(prefix=".photo-", dir=cache_dir())
        try:
            with os.fdopen(handle, "wb") as stream:
                stream.write(data)
            os.chmod(temporary, 0o640)
            os.replace(temporary, target)
        finally:
            try:
                os.unlink(temporary)
            except OSError:
                pass
        _failed.pop(name, None)
        return target


# ---------------------------------------------------------------- the owner's own photo
def custom_path() -> Path | None:
    for _magic, extension, _mime in _MAGIC:
        candidate = PATHS.data_dir / f"vehicle-photo-custom.{extension}"
        if candidate.is_file():
            return candidate
    return None


def content_type(path: Path) -> str:
    return {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(path.suffix.lower(), "application/octet-stream")


def save_custom(data: bytes) -> None:
    if not data or len(data) > MAX_UPLOAD_BYTES:
        raise ValueError("Das Foto ist leer oder zu groß (maximal 6 MB).")
    extension = next((ext for magic, ext, _mime in _MAGIC if data.startswith(magic)), None)
    if extension is None:
        raise ValueError("Bitte ein JPEG- oder PNG-Foto wählen.")
    PATHS.data_dir.mkdir(parents=True, exist_ok=True)
    remove_custom()
    handle, temporary = tempfile.mkstemp(prefix=".custom-", dir=PATHS.data_dir)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
        os.chmod(temporary, 0o600)
        os.replace(temporary, PATHS.data_dir / f"vehicle-photo-custom.{extension}")
    finally:
        try:
            os.unlink(temporary)
        except OSError:
            pass


def remove_custom() -> bool:
    removed = False
    for _magic, extension, _mime in _MAGIC:
        try:
            (PATHS.data_dir / f"vehicle-photo-custom.{extension}").unlink()
            removed = True
        except OSError:
            pass
    return removed


def has_custom() -> bool:
    return custom_path() is not None
