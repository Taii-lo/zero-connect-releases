"""In-app software updates: signed channel manifest, invite-only beta, staged install.

The owner signs `channels.json`, `release.json` and `beta-access.json` on their
own machine (tools/publish.py). The device only ever trusts documents whose
Ed25519 signature verifies against the release public key, downloads the bundle
over HTTPS, checks its SHA-256 and then hands it to the root-only appliance
updater by writing it into the staging directory. Nothing here installs code.
"""
from __future__ import annotations

import base64
import functools
import hashlib
import json
import os
import re
import datetime as dt
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable

import zero_release_verify as verify
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from zero_paths import PATHS

CHANNELS = ("stable", "beta")
CHECK_INTERVAL_SECONDS = 24 * 3600
BETA_GRACE_SECONDS = 14 * 24 * 3600
NIGHT_HOUR = 3  # local time of a planned overnight install
SCHEDULE_GRACE_SECONDS = 5 * 3600  # a busy vehicle is waited out this long, then the plan moves to the next night
RETRY_AFTER_ERROR_SECONDS = 3600
MAX_JSON_BYTES = 256 * 1024
MAX_BUNDLE_BYTES = 200 * 1024 * 1024
DEFAULT_SOURCE = "https://taii-lo.github.io/zero-connect-releases"  # signed channel files (GitHub Pages)
INVITE_PREFIX = "zero-connect-beta-v2:"
KDF_PARAMS = {"n": 2 ** 14, "r": 8, "p": 1}
_VERSION = re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class UpdateError(RuntimeError):
    """Raised with a stable, machine-readable `code` for the UI."""

    def __init__(self, code: str, message: str = "") -> None:
        super().__init__(message or code)
        self.code = code


# ---------------------------------------------------------------- versions
def parse_version(text: str) -> tuple[tuple[int, int, int], tuple[Any, ...] | None]:
    match = _VERSION.match(str(text).strip())
    if not match:
        raise ValueError(f"ungültige Version: {text!r}")
    core = (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    pre = match.group(4)
    if pre is None:
        return core, None
    return core, tuple((0, int(part), "") if part.isdigit() else (1, 0, part) for part in pre.split("."))


def compare_versions(left: str, right: str) -> int:
    """-1, 0, 1 following SemVer: 0.9.0-beta.45 < 1.0.0-beta.1 < 1.0.0."""
    (core_l, pre_l), (core_r, pre_r) = parse_version(left), parse_version(right)
    if core_l != core_r:
        return -1 if core_l < core_r else 1
    if pre_l == pre_r:
        return 0
    if pre_l is None:
        return 1
    if pre_r is None:
        return -1
    return -1 if pre_l < pre_r else 1


def is_prerelease(version: str) -> bool:
    return parse_version(version)[1] is not None


# ---------------------------------------------------------------- local state
def _version_file() -> dict[str, Any]:
    try:
        return json.loads((PATHS.program_dir / "VERSION.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def current_version() -> str:
    return str(_version_file().get("public_version") or "0.0.0")


def current_config_schema() -> int:
    try:
        return int(_version_file().get("config_schema") or 0)
    except (TypeError, ValueError):
        return 0


def state_path() -> Path:
    return PATHS.data_dir / "updates.json"


def staging_dir() -> Path:
    return Path(os.environ.get("ZERO_CONNECT_UPDATE_STAGING", "/var/lib/zero-connect/update-staging"))


def _default_state() -> dict[str, Any]:
    # A device that came with a pre-release version (a friend's first image) follows the beta until the user
    # decides otherwise; with only betas around, "stable" would never offer it an update. Once a channel is stored
    # (the switch in Settings), that choice wins.
    try:
        channel = "beta" if is_prerelease(current_version()) else "stable"
    except ValueError:
        channel = "stable"
    return {"channel": channel, "beta": None, "last_check_ts": 0, "last_error": None,
            "available": None, "held_back": False, "notice": None, "staged_version": None,
            "scheduled_at": None, "auto_install": False, "return_to_stable": False, "downgrade_blocked": None,
            "staged_downgrade": False}


def load_state() -> dict[str, Any]:
    try:
        value = json.loads(state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        value = {}
    state = _default_state()
    if isinstance(value, dict):
        state.update({key: value[key] for key in state if key in value})
    # A damaged value falls back to its default instead of breaking the update page.
    kinds = {"beta": (dict,), "available": (dict,), "notice": (str,), "last_error": (str,), "staged_version": (str,),
             "scheduled_at": (int, float, str), "last_check_ts": (int, float), "held_back": (bool,), "auto_install": (bool,),
             "return_to_stable": (bool,), "downgrade_blocked": (str,), "staged_downgrade": (bool,)}
    defaults = _default_state()
    for key, allowed in kinds.items():
        value_ = state[key]
        if value_ is not None and (not isinstance(value_, allowed) or (bool not in allowed and isinstance(value_, bool))):
            state[key] = defaults[key]
    for key, version in (("staged_version", state["staged_version"]), ("available", (state["available"] or {}).get("version", ""))):
        if state[key] is not None:
            try:
                parse_version(str(version))
            except ValueError:
                state[key] = None
    if state["channel"] not in CHANNELS:
        state["channel"] = defaults["channel"]
    return state


def save_state(state: dict[str, Any]) -> None:
    path = state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix=".updates-", dir=path.parent)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(state, stream, ensure_ascii=False, indent=1)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


# ---------------------------------------------------------------- source + key
def source_url() -> str:
    value = os.environ.get("ZERO_CONNECT_UPDATE_URL", "").strip()
    if not value:
        try:
            value = str(json.loads(PATHS.config_file.read_text(encoding="utf-8")).get("update_source") or "").strip()
        except (OSError, ValueError, AttributeError):
            value = ""
    return (value or DEFAULT_SOURCE).rstrip("/")


def public_key() -> str | None:
    for candidate in (PATHS.config_dir / "release-public-key", PATHS.program_dir / "release-public-key.pub"):
        try:
            for line in candidate.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    if len(base64.b64decode(line, validate=True)) == 32:
                        return line
                    break
        except (OSError, ValueError):
            continue
    return None


def _allowed_url(url: str) -> bool:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme == "https" and parsed.hostname:
        return True
    return (parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "localhost"}
            and os.environ.get("ZERO_CONNECT_UPDATE_ALLOW_LOCAL_HTTP") == "1")


def _open(url: str, timeout: float = 20):
    if not _allowed_url(url):
        raise UpdateError("insecure_url", "Nur HTTPS-Quellen sind erlaubt.")
    request = urllib.request.Request(url, headers={"User-Agent": f"ZeroConnect/{current_version()}"})
    return urllib.request.urlopen(request, timeout=timeout)  # noqa: S310 (scheme checked above)


def fetch_json(url: str, *, optional: bool = False) -> dict[str, Any] | None:
    try:
        with _open(url) as response:
            raw = response.read(MAX_JSON_BYTES + 1)
    except urllib.error.HTTPError as exc:
        if optional and exc.code == 404:
            return None
        raise UpdateError("unreachable", str(exc)) from exc
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise UpdateError("unreachable", str(exc)) from exc
    if len(raw) > MAX_JSON_BYTES:
        raise UpdateError("bad_document", "Dokument zu groß.")
    try:
        value = json.loads(raw)
    except ValueError as exc:
        raise UpdateError("bad_document", "Kein gültiges JSON.") from exc
    if not isinstance(value, dict):
        raise UpdateError("bad_document", "Unerwartetes Dokument.")
    return value


def _verified(document: dict[str, Any], key: str | None) -> dict[str, Any]:
    if not key:
        raise UpdateError("no_public_key", "Kein Release-Schlüssel hinterlegt.")
    if not verify.verify_release_metadata(document, key):
        raise UpdateError("bad_signature", "Signatur ungültig.")
    return document


# ---------------------------------------------------------------- crypto helpers (shared with tools/publish.py)
def b64e(raw: bytes) -> str:
    return base64.b64encode(raw).decode()


def b64d(text: str) -> bytes:
    try:
        return base64.b64decode(text, validate=True)
    except (ValueError, TypeError) as exc:
        raise UpdateError("bad_document", "Ungültige Kodierung.") from exc


def seal(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
    nonce = os.urandom(12)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def unseal(key: bytes, blob: bytes, aad: bytes = b"") -> bytes:
    try:
        return AESGCM(key).decrypt(blob[:12], blob[12:], aad)
    except (InvalidTag, ValueError) as exc:
        raise UpdateError("bad_decrypt", "Entschlüsselung fehlgeschlagen.") from exc


def derive_kek(secret: str, salt: bytes, params: dict[str, Any] | None = None) -> bytes:
    p = {**KDF_PARAMS, **(params or {})}
    return Scrypt(salt=salt, length=32, n=int(p["n"]), r=int(p["r"]), p=int(p["p"])).derive((INVITE_PREFIX + secret).encode())


# ---------------------------------------------------------------- beta access
def normalize_code(code: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(code).upper())


def split_code(code: str) -> tuple[str, str]:
    """A code is 4 public id characters plus a 12 character secret (XXXX-XXXX-XXXX-XXXX)."""
    normalized = normalize_code(code)
    if len(normalized) != 16:
        raise UpdateError("invalid_code", "Code ungültig.")
    return normalized[:4], normalized[4:]


def _entry_by_id(access: dict[str, Any], entry_id: str) -> dict[str, Any] | None:
    for entry in access.get("codes", []):
        if isinstance(entry, dict) and entry.get("id") == entry_id:
            return entry
    return None


def _entry_problem(entry: dict[str, Any] | None, now: float) -> str | None:
    if entry is None:
        return "invalid_code"
    if entry.get("revoked"):
        return "code_revoked"
    expires = entry.get("expires_at")
    if expires:
        try:
            if now > _timestamp(str(expires)):
                return "code_expired"
        except ValueError:
            return "invalid_code"
    return None


def _timestamp(text: str) -> float:
    from datetime import datetime, timezone
    value = datetime.fromisoformat(text.strip().replace("Z", "+00:00"))
    return (value if value.tzinfo else value.replace(tzinfo=timezone.utc)).timestamp()


def _fetch_access(base: str, key: str | None) -> dict[str, Any]:
    return _verified(fetch_json(f"{base}/beta-access.json"), key)


def _epoch_aad(entry_id: str, epoch: int) -> bytes:
    return f"zero-connect-epoch:{entry_id}:{epoch}".encode()


def _unwrap_epoch_key(entry: dict[str, Any], kek: bytes) -> bytes:
    try:
        return unseal(kek, b64d(str(entry.get("wrapped") or "")), _epoch_aad(str(entry.get("id")), int(entry.get("epoch") or 0)))
    except (UpdateError, TypeError, ValueError):
        raise UpdateError("invalid_code", "Code ungültig.") from None


def redeem_beta_code(code: str, *, now: float | None = None) -> dict[str, Any]:
    now = time.time() if now is None else now
    base = source_url()
    if not base:
        raise UpdateError("not_configured", "Keine Update-Quelle konfiguriert.")
    entry_id, secret = split_code(code)
    access = _fetch_access(base, public_key())
    entry = _entry_by_id(access, entry_id)
    problem = _entry_problem(entry, now)
    if problem:
        raise UpdateError(problem, "Code nicht gültig.")
    try:
        salt = b64d(str(entry.get("salt") or ""))
    except UpdateError:
        raise UpdateError("bad_document", "Zugangsdatei fehlerhaft.") from None
    kek = derive_kek(secret, salt, entry.get("kdf"))
    epoch_key = _unwrap_epoch_key(entry, kek)  # a wrong secret fails authentication here
    state = load_state()
    state["beta"] = {"id": entry_id, "kek": b64e(kek), "epoch": int(entry.get("epoch") or 0),
                     "epoch_key": b64e(epoch_key), "verified_ts": now}
    state["channel"] = "beta"
    state["notice"] = None
    save_state(state)
    return status()


def set_channel(channel: str, *, return_to_stable: bool = False) -> dict[str, Any]:
    """Choose stable or beta. The beta is open (no code); private invite betas are separate (`redeem_beta_code`).

    ``return_to_stable`` is the explicit "leave the beta and go back" action: the next check may then offer the
    current stable release even though it is older than the installed beta, if its data are compatible.
    """
    if channel not in CHANNELS:
        raise UpdateError("bad_channel", "Unbekannter Kanal.")
    state = load_state()
    state["channel"] = channel
    state["available"] = None
    state["notice"] = None
    state["return_to_stable"] = bool(return_to_stable and channel == "stable")
    state["downgrade_blocked"] = None
    save_state(state)
    return status()


def _refresh_beta_access(state: dict[str, Any], base: str, key: str | None, now: float) -> bytes | None:
    """Re-verify the invite and return the current epoch key; None when beta must be left."""
    beta = state.get("beta")
    if not beta:
        return None  # no invite: the open beta (if chosen) needs none
    try:
        access = _fetch_access(base, key)
    except UpdateError as exc:
        if exc.code == "unreachable":
            if now - float(beta.get("verified_ts") or 0) < BETA_GRACE_SECONDS and beta.get("epoch_key"):
                return b64d(beta["epoch_key"])
            state["channel"], state["notice"] = "stable", "beta_unverified"
        return None
    entry = _entry_by_id(access, str(beta.get("id")))
    if _entry_problem(entry, now):
        state["beta"], state["channel"], state["notice"] = None, "stable", "beta_access_ended"
        return None
    try:
        epoch_key = _unwrap_epoch_key(entry, b64d(beta["kek"]))
    except UpdateError:
        state["beta"], state["channel"], state["notice"] = None, "stable", "beta_access_ended"
        return None
    beta.update(verified_ts=now, epoch=int(entry.get("epoch") or 0), epoch_key=b64e(epoch_key))
    return epoch_key


# ---------------------------------------------------------------- checking
def _release_ok(release: dict[str, Any], expected_version: str, channel: str) -> None:
    asset = release.get("asset") or {}
    if release.get("public_version") != expected_version or release.get("channel") != channel:
        raise UpdateError("bad_document", "Release passt nicht zum Kanal-Eintrag.")
    if not (isinstance(asset.get("url"), str) and _allowed_url(asset["url"]) and _SHA256.match(str(asset.get("sha256", "")))):
        raise UpdateError("bad_document", "Release-Asset unvollständig.")
    encrypted = asset.get("encrypted")
    if encrypted is not None and not (isinstance(encrypted, dict) and _SHA256.match(str(encrypted.get("ciphertext_sha256", "")))):
        raise UpdateError("bad_document", "Verschlüsseltes Asset unvollständig.")
    platforms = release.get("supported_platforms") or []
    if platforms and "raspios-trixie-arm64" not in platforms:
        raise UpdateError("platform_incompatible", "Plattform nicht unterstützt.")


def _available_from(release: dict[str, Any], channel: str, bundle_key: str | None = None, *, downgrade: bool = False) -> dict[str, Any]:
    minimum = int(release.get("minimum_config_schema") or 0)
    return {"version": release["public_version"], "channel": channel,
            "summary": str(release.get("changelog_summary") or ""),
            "notes": [str(item) for item in (release.get("notes") or [])][:20],
            "published": str(release.get("release_timestamp") or ""),
            "size": int((release.get("asset") or {}).get("size") or 0),
            "needs_newer_app": minimum > current_config_schema() + 1,
            "downgrade": downgrade, "release": release, "bundle_key": bundle_key}


def _downgrade_blocker(entry: dict[str, Any], release: dict[str, Any], current: str) -> str | None:
    """Why the device must not go back to this (older) release, or None. The publisher's signed statement says up to
    which version the older code reads the newer data; the config schema must be identical."""
    declared = str(entry.get("downgrade_from") or "")
    try:
        parse_version(declared)
    except ValueError:
        return "not_declared"
    if compare_versions(current, declared) > 0:
        return "data_newer"
    if int(release.get("minimum_config_schema") or 0) != current_config_schema():
        return "schema_differs"
    return None


def _channel_candidate(channels: dict[str, Any], channel: str, key: str | None, current: str, state: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """(entry, candidate) for an open channel of channels.json: a newer release, or, when the user asked to
    return to stable, an older one that is declared data-compatible."""
    entry = channels.get(channel)
    if isinstance(entry, dict):
        try:
            parse_version(entry.get("version", ""))
        except ValueError:
            entry = None
    else:
        entry = None
    if not entry:
        return None, None
    release_url = str(entry.get("release_url") or "")
    order = compare_versions(entry["version"], current)
    if order > 0:
        if not _allowed_url(release_url):
            raise UpdateError("bad_document", "Release-URL ungültig.")
        release = _verified(fetch_json(release_url), key)
        _release_ok(release, entry["version"], channel)
        return entry, _available_from(release, channel)
    if order < 0 and channel == "stable" and state.get("return_to_stable"):
        if not _allowed_url(release_url):
            raise UpdateError("bad_document", "Release-URL ungültig.")
        release = _verified(fetch_json(release_url), key)
        _release_ok(release, entry["version"], channel)
        blocker = _downgrade_blocker(entry, release, current)
        state["downgrade_blocked"] = blocker
        return entry, (None if blocker else _available_from(release, channel, downgrade=True))
    return entry, None


def _beta_candidate(base: str, key: str | None, epoch: int, epoch_key: bytes) -> dict[str, Any] | None:
    document = fetch_json(f"{base}/beta.json", optional=True)
    if document is None:
        return None
    _verified(document, key)
    if int(document.get("epoch") or 0) != epoch:
        return None  # published for another key generation; wait for the owner's refresh
    try:
        payload = json.loads(unseal(epoch_key, b64d(str(document.get("payload") or "")), f"zero-connect-beta:{epoch}".encode()))
        release = _verified(payload["release"], key)
        _release_ok(release, str(payload["version"]), "beta")
        parse_version(payload["version"])
        return _available_from(release, "beta", str(payload.get("bundle_key") or ""))
    except (KeyError, TypeError, ValueError):
        raise UpdateError("bad_document", "Beta-Dokument fehlerhaft.") from None


def check(*, force: bool = False, now: float | None = None) -> dict[str, Any]:
    """Refresh what is available. Never raises for network trouble; it records it."""
    now = time.time() if now is None else now
    state = load_state()
    if not force and now - float(state.get("last_check_ts") or 0) < CHECK_INTERVAL_SECONDS and not state.get("last_error"):
        return status()
    base = source_url()
    state["last_check_ts"] = now
    state["last_error"] = None
    if not base:
        state["last_error"] = "not_configured"
        save_state(state)
        return status()
    try:
        key = public_key()
        epoch_key = _refresh_beta_access(state, base, key, now)
        current = current_version()
        candidates: list[dict[str, Any]] = []
        channels = _verified(fetch_json(f"{base}/channels.json"), key).get("channels") or {}
        state["downgrade_blocked"] = None
        entry, stable_candidate = _channel_candidate(channels, "stable", key, current, state)
        if stable_candidate:
            candidates.append(stable_candidate)
        if state["channel"] == "beta":
            _, open_candidate = _channel_candidate(channels, "beta", key, current, state)
            if open_candidate:
                candidates.append(open_candidate)
            if epoch_key is not None:  # a private invite beta (encrypted) next to the open one
                beta = state["beta"]
                candidate = _beta_candidate(base, key, int(beta.get("epoch") or 0), epoch_key)
                if candidate and compare_versions(candidate["version"], current) > 0:
                    candidates.append(candidate)
        state["available"], state["held_back"] = None, False
        if candidates:
            state["available"] = max(candidates, key=functools.cmp_to_key(lambda a, b: compare_versions(a["version"], b["version"])))
        elif state["channel"] == "stable" and entry and is_prerelease(current) and compare_versions(current, entry["version"]) > 0:
            state["held_back"] = True  # running a newer beta than stable; wait for the next stable
        if state.get("return_to_stable") and (not entry or compare_versions(current, entry["version"]) <= 0):
            state["return_to_stable"] = False  # arrived (or stable has caught up)
    except UpdateError as exc:
        state["last_error"] = exc.code
    save_state(state)
    return status()


# ---------------------------------------------------------------- installing
def _repair_staging(stage: Path) -> bool:
    """Baseline images created the staging directory as root:root; the web user owns its parent and can swap it.

    Only an existing directory that rmdir accepts (= empty) is replaced; a root-owned one cannot even be listed here; a missing one is not created,
    so a host without the root updater (the development Pi) keeps reporting the blocker.
    """
    try:
        stage.rmdir()  # the kernel refuses a non-empty directory, so nothing staged can be lost
        stage.mkdir(mode=0o750)
        return os.access(stage, os.W_OK)
    except OSError:
        return False


def install_blockers(*, vehicle_busy: Callable[[], bool] | None = None) -> list[str]:
    blockers: list[str] = []
    if PATHS.mode != "appliance":
        blockers.append("not_appliance")
    if not source_url():
        blockers.append("not_configured")
    if not public_key():
        blockers.append("no_public_key")
    stage = staging_dir()
    try:
        writable = stage.is_dir() and os.access(stage, os.W_OK)
        if stage.is_dir() and not writable:
            writable = _repair_staging(stage)
    except OSError:  # e.g. the parent directory is not traversable for this user
        writable = False
    if not writable:
        blockers.append("staging_not_writable")
    if vehicle_busy is not None and vehicle_busy():
        blockers.append("vehicle_busy")
    return blockers


def _download(url: str, expected_sha: str, expected_size: int, target: Path) -> None:
    digest = hashlib.sha256()
    total = 0
    try:
        with _open(url, timeout=60) as response, target.open("wb") as out:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_BUNDLE_BYTES or (expected_size and total > expected_size):
                    raise UpdateError("bad_asset", "Paket größer als angekündigt.")
                digest.update(chunk)
                out.write(chunk)
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise UpdateError("unreachable", str(exc)) from exc
    if expected_size and total != expected_size:
        raise UpdateError("bad_asset", "Paketgröße stimmt nicht.")
    if digest.hexdigest() != expected_sha:
        raise UpdateError("bad_asset", "Prüfsumme stimmt nicht.")


def _fetch_bundle(asset: dict[str, Any], bundle_key: str | None, target: Path) -> None:
    """Download the package into `target`; encrypted (beta) packages are decrypted here."""
    encrypted = asset.get("encrypted")
    if not encrypted:
        _download(asset["url"], asset["sha256"], int(asset.get("size") or 0), target)
        return
    if not bundle_key:
        raise UpdateError("bad_asset", "Paketschlüssel fehlt.")
    ciphertext = target.with_name(target.name + ".enc")
    try:
        _download(asset["url"], encrypted["ciphertext_sha256"], int(encrypted.get("ciphertext_size") or 0), ciphertext)
        plain = unseal(b64d(bundle_key), ciphertext.read_bytes(), str(asset.get("aad") or "").encode())
    except OSError as exc:
        raise UpdateError("bad_asset", str(exc)) from exc
    finally:
        try:
            ciphertext.unlink()
        except OSError:
            pass
    if hashlib.sha256(plain).hexdigest() != asset["sha256"] or (asset.get("size") and len(plain) != int(asset["size"])):
        raise UpdateError("bad_asset", "Prüfsumme des entschlüsselten Pakets stimmt nicht.")
    target.write_bytes(plain)


def stage_install(*, vehicle_busy: Callable[[], bool] | None = None) -> dict[str, Any]:
    """Download + verify the available release and drop it where the root updater looks."""
    state = load_state()
    available = state.get("available")
    if not available:
        raise UpdateError("nothing_available", "Kein Update verfügbar.")
    blockers = install_blockers(vehicle_busy=vehicle_busy)
    if blockers:
        raise UpdateError(blockers[0], "Installation derzeit nicht möglich.")
    release = available["release"]
    key = public_key()
    _verified(release, key)  # the stored copy is re-verified, never trusted blindly
    if compare_versions(release["public_version"], current_version()) <= 0 and not available.get("downgrade"):
        raise UpdateError("nothing_available", "Kein Update verfügbar.")
    asset = release["asset"]
    stage = staging_dir()
    handle, temporary = tempfile.mkstemp(prefix=".incoming-", suffix=".part", dir=stage)
    os.close(handle)
    meta_handle, meta_temporary = tempfile.mkstemp(prefix=".release-", suffix=".part", dir=stage)
    os.close(meta_handle)
    try:
        _fetch_bundle(asset, available.get("bundle_key"), Path(temporary))
        Path(meta_temporary).write_text(json.dumps(_for_root_updater(release), ensure_ascii=False), encoding="utf-8")
        os.chmod(temporary, 0o640)
        os.chmod(meta_temporary, 0o640)
        # Metadata first: the root updater is triggered by the bundle changing.
        os.replace(meta_temporary, stage / "release.json")
        os.replace(temporary, stage / "incoming.tar.gz")
    finally:
        for leftover in (temporary, meta_temporary):
            try:
                os.unlink(leftover)
            except OSError:
                pass
    state["staged_version"] = available["version"]
    state["staged_downgrade"] = bool(available.get("downgrade"))
    state["scheduled_at"] = None
    save_state(state)
    return status()


def _staged_pending(state: dict[str, Any], current: str) -> str | None:
    """The staged version while it has not been installed yet (an upgrade, or the downgrade the user asked for)."""
    staged = state.get("staged_version")
    if not staged:
        return None
    order = compare_versions(staged, current)
    return staged if order > 0 or (order < 0 and state.get("staged_downgrade")) else None


def _for_root_updater(release: dict[str, Any]) -> dict[str, Any]:
    """The signed document exactly as published; its asset hash is that of the (decrypted) package."""
    return release


# ---------------------------------------------------------------- overnight install
def next_night(now: float | None = None) -> float:
    """The next NIGHT_HOUR:00 in the device's local time (tonight if it has not passed yet)."""
    moment = dt.datetime.fromtimestamp(time.time() if now is None else now)
    target = moment.replace(hour=NIGHT_HOUR, minute=0, second=0, microsecond=0)
    if target <= moment:
        target += dt.timedelta(days=1)
    return target.timestamp()


def _plan_blockers() -> list[str]:
    """Blockers that a planned install cannot wait out (a busy vehicle can)."""
    return install_blockers()


def schedule_install(enabled: bool, *, now: float | None = None) -> dict[str, Any]:
    """Plan (or cancel) installing the available update tonight."""
    state = load_state()
    if enabled:
        if not state.get("available"):
            raise UpdateError("nothing_available", "Kein Update verfügbar.")
        blockers = _plan_blockers()
        if blockers:
            raise UpdateError(blockers[0], "Installation derzeit nicht möglich.")
        state["scheduled_at"] = next_night(now)
    else:
        state["scheduled_at"] = None
    save_state(state)
    return status()


def set_auto_install(enabled: bool, *, now: float | None = None) -> dict[str, Any]:
    state = load_state()
    state["auto_install"] = bool(enabled)
    save_state(state)
    return status()


def run_background(*, vehicle_busy: Callable[[], bool] | None = None, now: float | None = None) -> str | None:
    """One tick of the background job: daily check, then the planned (or automatic) overnight install.

    Returns a short word for what happened (for logs/tests); never raises for expected update problems.
    """
    now = time.time() if now is None else now
    state = load_state()
    due = now - float(state.get("last_check_ts") or 0)
    if due >= CHECK_INTERVAL_SECONDS or (state.get("last_error") and due >= RETRY_AFTER_ERROR_SECONDS):
        try:
            check(force=False, now=now)
        except UpdateError:
            pass
        state = load_state()
    available = state.get("available")
    if not available or _staged_pending(state, current_version()):
        if state.get("scheduled_at"):
            state["scheduled_at"] = None
            save_state(state)
        return None
    if not state.get("scheduled_at") and state.get("auto_install") and not available.get("downgrade") and not _plan_blockers():
        state["scheduled_at"] = next_night(now)
        save_state(state)
    at = state.get("scheduled_at")
    if not at or now < float(at):
        return None
    if now > float(at) + SCHEDULE_GRACE_SECONDS:
        state["scheduled_at"] = next_night(now) if state.get("auto_install") else None
        save_state(state)
        return "missed"
    try:
        stage_install(vehicle_busy=vehicle_busy)
    except UpdateError as exc:
        return exc.code
    return "staged"


# ---------------------------------------------------------------- view model
def status(*, vehicle_busy: Callable[[], bool] | None = None) -> dict[str, Any]:
    state = load_state()
    available = state.get("available")
    public_available = None
    if available:
        public_available = {k: v for k, v in available.items() if k != "release"}
    current = current_version()
    return {
        "current_version": current,
        "channel": state["channel"],
        "beta_enabled": bool(state.get("beta")),
        "configured": bool(source_url()),
        "last_check_ts": state.get("last_check_ts") or 0,
        "last_error": state.get("last_error"),
        "available": public_available,
        "held_back": bool(state.get("held_back")),
        "notice": state.get("notice"),
        "install_blockers": install_blockers(vehicle_busy=vehicle_busy),
        "staged_version": _staged_pending(state, current),
        "return_to_stable": bool(state.get("return_to_stable")),
        "downgrade_blocked": state.get("downgrade_blocked"),
        "scheduled_at": state.get("scheduled_at") if public_available else None,
        "auto_install": bool(state.get("auto_install")),
    }
