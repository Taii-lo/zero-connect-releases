/* Notification-only worker. It intentionally has no fetch handler: live
   vehicle, charging, location and history responses are never cached. */
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) { data = {body: event.data?.text() || ''}; }
  const title = data.title || 'Zero Connect';
  const options = {body: data.body || '', icon: '/assets/icons/zero-connect-home-192.png?v=home-icon-v3-20261011', badge: '/assets/icons/zero-connect-home-96.png?v=home-icon-v3-20261011', data: {url: data.url || '/'}};
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = event.notification.data?.url || '/';
  event.waitUntil(clients.matchAll({type: 'window', includeUncontrolled: true}).then(list => {
    const existing = list.find(client => 'focus' in client);
    return existing ? existing.focus().then(() => existing.navigate(target)) : clients.openWindow(target);
  }));
});
