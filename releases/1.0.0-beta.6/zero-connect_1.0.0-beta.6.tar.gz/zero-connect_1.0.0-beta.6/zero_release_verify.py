"""Ed25519 verification for future signed, immutable release metadata."""
from __future__ import annotations
import base64, json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

def canonical_metadata(metadata: dict) -> bytes:
    unsigned = {key: value for key, value in metadata.items() if key != "signature"}
    return json.dumps(unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()

def verify_release_metadata(metadata: dict, public_key_b64: str) -> bool:
    signature = metadata.get("signature", {})
    if signature.get("algorithm") != "ed25519" or not isinstance(signature.get("value"), str): return False
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64, validate=True)).verify(base64.b64decode(signature["value"], validate=True), canonical_metadata(metadata))
    except (ValueError, TypeError): return False
    except Exception: return False
    return True
