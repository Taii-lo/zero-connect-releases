"""Structured release notes shared by the app, the release tooling and the Autopilot.

Every completed work item adds exactly one entry to ``release_notes.json`` in
the same commit as its code. The file therefore travels with the revision: an
entry is part of an installed release exactly when it is present in the
installed tree, and it is new in that release exactly when it was absent from
the previously installed tree. Nothing is inferred from requests or attempts
that merely exist.

The notes are channel-neutral (Owner Beta/Stable, Public Beta, GitHub release
or update hints can reuse them later); only the installation record decides
where a release was published.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import tempfile
import threading
from pathlib import Path
from typing import Any

NOTES_FILE = "release_notes.json"
SCHEMA_VERSION = 1
CATEGORIES = ("feature", "improvement", "fix", "internal")
GROUP_LABELS = {"feature": "NEU", "improvement": "VERBESSERT", "fix": "BEHOBEN", "internal": "INTERN"}
SCOPES = ("complete", "partial")
NO_VISIBLE_CHANGES = "Keine sichtbaren Änderungen in dieser Version."
LEGACY_NOTICE = "Für diese frühere Version sind keine vollständigen Release Notes vorhanden."
# A release with changes but without (all) entries is unknown, never "no visible changes".
UNDOCUMENTED_NOTICE = "Für diese Version sind keine Release Notes vorhanden."
INCOMPLETE_NOTICE = "Nicht alle Änderungen dieser Version sind beschrieben."
UNKNOWN_PREVIOUS_NOTICE = "Die vorher installierte Version ist nicht belegt; Änderungen sind nicht zuordenbar."

WORK_ITEM_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{2,80}$")
REQUEST_ID = re.compile(r"^req-[0-9a-f]{6,32}$")
_URL = re.compile(r"https?://", re.I)
_COORDINATES = re.compile(r"-?\d{1,2}\.\d{4,}\s*,\s*-?\d{1,3}\.\d{4,}")
_LIMITS = {"title": 120, "description": 600, "motivation": 600}


class ReleaseNotesError(ValueError):
    pass


def _text(entry: dict[str, Any], key: str) -> str:
    value = entry.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > _LIMITS[key]:
        raise ReleaseNotesError(f"{key} must be 1–{_LIMITS[key]} characters")
    if any(ord(char) < 32 for char in value) or _URL.search(value) or _COORDINATES.search(value):
        raise ReleaseNotesError(f"{key} must be plain text without links or coordinates")
    return value.strip()


def validate_change(entry: Any) -> dict[str, Any]:
    """Return the normalized entry or raise ReleaseNotesError."""
    if not isinstance(entry, dict):
        raise ReleaseNotesError("change entry must be an object")
    work_item = entry.get("id")
    if not isinstance(work_item, str) or not WORK_ITEM_ID.fullmatch(work_item):
        raise ReleaseNotesError("id must be the work item id")
    request_id = entry.get("request_id")
    if request_id is not None and (not isinstance(request_id, str) or not REQUEST_ID.fullmatch(request_id)):
        raise ReleaseNotesError(f"{work_item}: request_id must be a req-* id or null")
    category = entry.get("category")
    if category not in CATEGORIES:
        raise ReleaseNotesError(f"{work_item}: category must be one of {', '.join(CATEGORIES)}")
    visible = entry.get("user_visible")
    if not isinstance(visible, bool):
        raise ReleaseNotesError(f"{work_item}: user_visible must be true or false")
    # NEU/VERBESSERT/BEHOBEN list only what users can see; everything else is INTERN.
    if visible != (category != "internal"):
        raise ReleaseNotesError(f"{work_item}: internal changes are exactly the ones that are not user visible")
    scope = entry.get("scope", "complete")
    if scope not in SCOPES:
        raise ReleaseNotesError(f"{work_item}: scope must be complete or partial")
    areas = entry.get("areas")
    if (not isinstance(areas, list) or not 1 <= len(areas) <= 8
            or any(not isinstance(area, str) or not 0 < len(area.strip()) <= 40 for area in areas)):
        raise ReleaseNotesError(f"{work_item}: areas must list 1–8 short names")
    return {"id": work_item, "request_id": request_id, "scope": scope, "category": category,
            "user_visible": visible, "title": _text(entry, "title"), "description": _text(entry, "description"),
            "motivation": _text(entry, "motivation"), "areas": [area.strip() for area in areas]}


def parse_document(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, dict) or value.get("schema_version") != SCHEMA_VERSION \
            or not isinstance(value.get("changes"), list):
        raise ReleaseNotesError(f"{NOTES_FILE} schema is invalid")
    changes = [validate_change(entry) for entry in value["changes"]]
    ids = [entry["id"] for entry in changes]
    if len(ids) != len(set(ids)):
        raise ReleaseNotesError(f"{NOTES_FILE} contains a work item twice")
    return changes


def parse_text(text: str) -> list[dict[str, Any]]:
    try:
        return parse_document(json.loads(text))
    except ValueError as exc:
        raise ReleaseNotesError(str(exc)) from exc


def load_file(path: Path) -> list[dict[str, Any]] | None:
    """Entries of an installed tree, or None when that tree predates release notes."""
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    return parse_text(text)


def grouped(changes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{"category": category, "label": GROUP_LABELS[category],
             "items": [entry for entry in changes if entry.get("category") == category]}
            for category in CATEGORIES if any(entry.get("category") == category for entry in changes)]


def has_visible_changes(changes: list[dict[str, Any]]) -> bool:
    return any(entry.get("user_visible") is True for entry in changes)


def render_lines(changes: list[dict[str, Any]], *, documented: bool) -> list[str]:
    """Compact grouped notes (CLI and plain-text consumers)."""
    if not documented:
        return [LEGACY_NOTICE]
    if not changes:
        return [UNDOCUMENTED_NOTICE]
    lines: list[str] = []
    for group in grouped(changes):
        lines += ["", group["label"], *(f"- {entry['title']}" for entry in group["items"])]
    if not has_visible_changes(changes):
        lines += ["", NO_VISIBLE_CHANGES]
    return lines[1:] if lines and lines[0] == "" else lines


# ---------------------------------------------------------------- installed release (app)
HISTORY_FILE = "release_history.json"
_HISTORY_LOCK = threading.Lock()


def _installed_at(revision_file: Path) -> str | None:
    try:
        stamp = revision_file.stat().st_mtime
    except OSError:
        return None
    return dt.datetime.fromtimestamp(stamp, dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _read_history(path: Path) -> list[dict[str, Any]]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    if not isinstance(value, dict) or value.get("schema_version") != 1 or not isinstance(value.get("releases"), list):
        raise ReleaseNotesError("installed release history is unreadable")
    return [row for row in value["releases"] if isinstance(row, dict) and isinstance(row.get("revision"), str)]


def _write_history(path: Path, releases: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps({"schema_version": 1, "releases": releases}, indent=2, ensure_ascii=False) + "\n").encode()
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix="." + path.name + ".")
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def installed_release(program_dir: Path, data_dir: Path, *, version: str, internal_version: str) -> dict[str, Any]:
    """Release notes of the installed revision, as first observed on this device.

    The device remembers which entries each installed revision carried
    (``release_history.json``, its own file next to the user data). An entry is
    "new" once: when the first installed revision that contains it is observed.
    A revision installed again later (rollback) shows the notes it had first.
    """
    revision_file = program_dir / ".deploy-revision"
    try:
        revision = revision_file.read_text(encoding="utf-8").strip() or "unknown"
    except OSError:
        revision = "unknown"
    try:
        changes = load_file(program_dir / NOTES_FILE)
    except ReleaseNotesError:
        changes = None
    result: dict[str, Any] = {"version": version, "internal_version": internal_version, "revision": revision,
                              "installed_at": _installed_at(revision_file), "documented": changes is not None,
                              "groups": [], "user_visible": False, "requests": [], "notice": None}
    if changes is None:
        result["notice"] = LEGACY_NOTICE
        return result
    history_path = data_dir / HISTORY_FILE
    with _HISTORY_LOCK:
        try:
            history = _read_history(history_path)
        except (OSError, ValueError):
            history = None  # never overwrite an unreadable file; show this release unpersisted
        row = next((item for item in (history or []) if item["revision"] == revision), None)
        if row is None:
            known = {change_id for item in (history or []) for change_id in item.get("change_ids", [])}
            row = {"revision": revision, "version": version, "first_seen_at": result["installed_at"],
                   "change_ids": [entry["id"] for entry in changes],
                   "new_change_ids": [entry["id"] for entry in changes if entry["id"] not in known]}
            if history is not None and revision != "unknown":
                try:
                    _write_history(history_path, (history + [row])[-50:])
                except OSError:
                    pass
    by_id = {entry["id"]: entry for entry in changes}
    new = [by_id[change_id] for change_id in row.get("new_change_ids", []) if change_id in by_id]
    result["installed_at"] = result["installed_at"] or row.get("first_seen_at")
    result["groups"] = grouped(new)
    result["user_visible"] = has_visible_changes(new)
    result["notice"] = (UNDOCUMENTED_NOTICE if not new else None if result["user_visible"]
                        else NO_VISIBLE_CHANGES)
    requests: dict[str, str] = {}
    for entry in new:
        if entry["request_id"]:
            if entry["scope"] == "complete" or requests.get(entry["request_id"]) != "completed":
                requests[entry["request_id"]] = "completed" if entry["scope"] == "complete" else "partial"
    result["requests"] = [{"id": key, "inclusion": value} for key, value in requests.items()]
    return result
