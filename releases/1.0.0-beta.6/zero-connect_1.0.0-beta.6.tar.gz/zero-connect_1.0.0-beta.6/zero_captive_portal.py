#!/usr/bin/env python3
"""Small local-only captive portal reverse proxy, installed root-owned."""
from __future__ import annotations
import argparse, http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PROBES = {"/hotspot-detect.html", "/library/test/success.html", "/generate_204", "/gen_204", "/connecttest.txt", "/ncsi.txt"}
UPSTREAM_HOST = "127.0.0.1"
UPSTREAM_PORT = 8080
SETUP_URL = "http://10.42.0.1/"

class Portal(BaseHTTPRequestHandler):
    def log_message(self, *_: object) -> None: pass
    def redirect_to_setup(self) -> None:
        self.send_response(302)
        self.send_header("Location", SETUP_URL)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()
    def forward(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 0 or length > 128 * 1024: raise ValueError
            body = self.rfile.read(length) if length else None
        except ValueError:
            self.send_error(413); return
        try:
            upstream = http.client.HTTPConnection(UPSTREAM_HOST, UPSTREAM_PORT, timeout=8)
            headers = {"Host": "127.0.0.1:8080", "Connection": "close"}
            if self.headers.get("Content-Type"): headers["Content-Type"] = self.headers["Content-Type"]
            upstream.request("POST", self.path, body=body, headers=headers)
            response = upstream.getresponse(); data = response.read(128 * 1024)
            self.send_response(response.status)
            for key, value in response.getheaders():
                if key.lower() not in {"connection", "transfer-encoding", "content-length"}: self.send_header(key, value)
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
        except (OSError, http.client.HTTPException): self.send_error(503, "Setup wird gestartet.")
    def do_GET(self) -> None:
        path = self.path.split("?", 1)[0]
        if path in PROBES or not (path == "/" or path.startswith("/assets/") or path.startswith("/api/")):
            self.redirect_to_setup(); return
        try:
            upstream = http.client.HTTPConnection(UPSTREAM_HOST, UPSTREAM_PORT, timeout=8)
            upstream.request("GET", self.path, headers={"Host": "127.0.0.1:8080", "Connection": "close"})
            response = upstream.getresponse(); data = response.read(512 * 1024)
            self.send_response(response.status)
            for key, value in response.getheaders():
                if key.lower() not in {"connection", "transfer-encoding", "content-length"}: self.send_header(key, value)
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
        except (OSError, http.client.HTTPException):
            self.send_error(503, "Setup wird gestartet.")
    def do_HEAD(self) -> None:
        path = self.path.split("?", 1)[0]
        if path in PROBES or not (path == "/" or path.startswith("/assets/") or path.startswith("/api/")):
            self.redirect_to_setup(); return
        self.send_response(200)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()
    def do_POST(self) -> None: self.forward()

def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--host", default="10.42.0.1"); parser.add_argument("--port", type=int, default=80); args = parser.parse_args()
    ThreadingHTTPServer((args.host, args.port), Portal).serve_forever()
if __name__ == "__main__": main()
