#!/usr/bin/env python3
"""Show recent Zero Connect charging sessions."""

from __future__ import annotations

import argparse
import json
import logging
import math
from datetime import datetime
from pathlib import Path
from typing import Any

from zero_paths import PATHS
import zero_charging
PROJECT_DIR = PATHS.program_dir
SESSION_DIR = PATHS.data_dir / "sessions"
LOCAL_TZ = datetime.now().astimezone().tzinfo
EVIDENCE_UPDATE_FIELDS = (
    "shutdown_zero_pulse",
    "shutdown_zero_pulse_at_utc",
    "ended_at_utc",
    "duration_seconds",
    "completion_source",
    "end_soc",
    "end_soc_source",
)


def parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.astimezone()
    except ValueError:
        return None


def local_text(value: Any) -> str:
    parsed = parse_time(value)
    if parsed is None:
        return "?"
    return parsed.astimezone(LOCAL_TZ).strftime("%d.%m.%Y %H:%M")


def duration_text(start: Any, end: Any) -> str:
    a, b = parse_time(start), parse_time(end)
    if a is None or b is None or b < a:
        return "?"
    minutes = int(round((b - a).total_seconds() / 60))
    h, m = divmod(minutes, 60)
    return f"{h} h {m:02d} min" if h else f"{m} min"


def normalize_session(record: dict[str, Any]) -> dict[str, Any]:
    """Return the canonical session contract, including legacy durations."""
    normalized = dict(record)
    normalized["generation"] = int(record.get("generation", 0) or 0)
    for key in ("duration_seconds", "balancing_duration_seconds", "ended_epoch", "start_soc", "end_soc", "target_soc", "energy_added_kwh", "average_power_kw", "peak_power_kw"):
        if normalized.get(key) is not None:
            value = float(normalized[key])
            if not math.isfinite(value):
                raise ValueError("nonfinite session measurement")
            normalized[key] = value
    if (
        normalized.get("duration_seconds") is None
        and str(normalized.get("start_time_confidence", "")) != "uncertain"
    ):
        start = parse_time(normalized.get("started_at_utc"))
        end = parse_time(normalized.get("ended_at_utc"))
        if start is not None and end is not None and end >= start:
            normalized["duration_seconds"] = int(round((end - start).total_seconds()))
    return normalized


def result_text(record: dict[str, Any]) -> str:
    terminal = str(record.get("terminal_event", ""))
    source = str(record.get("completion_source", ""))
    confidence = str(record.get("confidence", ""))
    result = {
        "complete": "vollständig geladen",
        "ended": "beendet",
        "interrupted": "unterbrochen",
    }.get(terminal, terminal or "unbekannt")
    if source == "balancing_sleep_timeout":
        result += " · Schlaf-Fallback"
    elif confidence == "derived":
        result += " · abgeleitet"
    elif confidence == "inferred":
        result += " · von Zero Connect abgeleitet"
    return result


def load_sessions(*, include_removed: bool = False) -> list[dict[str, Any]]:
    by_generation: dict[int, dict[str, Any]] = {}
    legacy: list[dict[str, Any]] = []
    if not SESSION_DIR.exists():
        return []
    for path in sorted(SESSION_DIR.glob("session-*.jsonl")):
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except ValueError:
                continue
            if not isinstance(record, dict):
                continue
            try:
                generation = int(record.get("generation", 0) or 0)
            except (TypeError, ValueError, OverflowError):
                logging.getLogger(__name__).warning("Skipping session with invalid generation")
                continue
            if generation <= 0:
                legacy.append(record)
                continue
            if str(record.get("record_type", "session")) == "evidence_update":
                base = by_generation.setdefault(generation, {"generation": generation})
                for key in EVIDENCE_UPDATE_FIELDS:
                    if key in record:
                        base[key] = record[key]
            else:
                previous = by_generation.get(generation, {})
                merged = {**previous, **record}
                # Evidence updates can be read before the base record when files
                # are merged from older exports; never lose them.
                for key in EVIDENCE_UPDATE_FIELDS:
                    if key in previous:
                        merged[key] = previous[key]
                by_generation[generation] = merged
    records = []
    for record in [*by_generation.values(), *legacy]:
        if not (record.get("started_at_utc") or record.get("ended_at_utc")):
            continue
        try:
            records.append(normalize_session(record))
        except (ValueError, TypeError, OverflowError):
            logging.getLogger(__name__).warning("Skipping malformed session record")
    records.sort(key=lambda item: str(item.get("ended_at_utc", item.get("recorded_at_utc", ""))), reverse=True)
    if not include_removed:
        # Runtime import avoids making canonical JSONL normalization depend on
        # the optional functional store during module initialization.
        import zero_functional
        removed = set(zero_functional.session_removals())
        records = [row for row in records if int(row.get("generation", 0) or 0) not in removed]
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description="Letzte Ladesitzungen anzeigen")
    parser.add_argument("--limit", "-n", type=int, default=10, help="Anzahl Sitzungen (Standard: 10)")
    args = parser.parse_args()
    limit = max(1, args.limit)
    records = load_sessions()[:limit]
    # Import lazily to keep storage normalization independent from Observer
    # startup while avoiding display of legacy target-derived end-SOC values.
    import zero_observer
    generations = {int(record.get("generation", 0) or 0) for record in records}
    samples_by_generation = zero_observer.load_charging_sample_rows_for_generations(generations)
    projected = []
    for record in records:
        generation = int(record.get("generation", 0) or 0)
        samples = zero_charging.session_samples_for_record(
            record, samples_by_generation.get(generation, [])
        )
        projected.append({**record, "end_soc": zero_charging.session_end_soc(record, samples)})
    records = projected

    print()
    print("🔋 Zero Connect Ladehistorie")
    print("────────────────────────────────────────────────────────")
    if not records:
        print("Noch keine abgeschlossene Ladesitzung in Beta 5 aufgezeichnet.")
        print()
        return
    for record in records:
        start_soc = record.get("start_soc")
        end_soc = record.get("end_soc")
        soc_text = ""
        if start_soc is not None or end_soc is not None:
            left = "?" if start_soc is None else f"{float(start_soc):.0f}"
            right = "?" if end_soc is None else f"{float(end_soc):.0f}"
            soc_text = f" · {left}→{right} %"
        extras: list[str] = []
        if record.get("shutdown_zero_pulse"):
            extras.append("0-%-Shutdown erkannt")
        suffix = (" · " + " · ".join(extras)) if extras else ""
        print(
            f"{local_text(record.get('started_at_utc'))} · "
            f"{duration_text(record.get('started_at_utc'), record.get('ended_at_utc'))}"
            f"{soc_text} · {result_text(record)}{suffix}"
        )
    print()


if __name__ == "__main__":
    main()
