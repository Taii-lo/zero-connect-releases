#!/usr/bin/env python3
"""Root-only, fixed-path appliance updater; intentionally no CLI arguments."""
from __future__ import annotations
import hashlib, json, os, shutil, subprocess, tarfile, tempfile
from pathlib import Path
from zero_release_verify import verify_release_metadata

ROOT=Path(os.environ.get("ZERO_CONNECT_ROOT","/"))
def p(name:str)->Path: return ROOT / name.lstrip("/")
APP=p("/opt/zero-connect"); STAGE=p("/var/lib/zero-connect/update-staging"); BUNDLE=STAGE/"incoming.tar.gz"; META=STAGE/"release.json"; KEY=p("/etc/zero-connect/release-public-key"); BACKUPS=p("/opt/.zero-connect-backups")  # same mount as APP: os.replace must not cross the unit's bind mounts
class UpdateError(RuntimeError): pass
def read_key()->str:
 for line in KEY.read_text().splitlines():
  line=line.strip()
  if line and not line.startswith("#"): return line
 return ""
def digest(path:Path)->str:
 h=hashlib.sha256()
 with path.open("rb") as f:
  for c in iter(lambda:f.read(1048576),b""): h.update(c)
 return h.hexdigest()
def safe_extract(bundle:Path,dest:Path)->Path:
 with tarfile.open(bundle) as tf:
  files=tf.getmembers()
  if any(m.issym() or m.islnk() or m.name.startswith("/") or ".." in Path(m.name).parts for m in files): raise UpdateError("unsafe archive")
  roots={Path(m.name).parts[0] for m in files if m.name}
  if len(roots)!=1: raise UpdateError("invalid archive root")
  tf.extractall(dest,filter="data")
 root=dest/next(iter(roots))
 if not (root/"VERSION.json").is_file() or not (root/"MANIFEST.sha256").is_file(): raise UpdateError("bundle incomplete")
 manifest={}
 for line in (root/"MANIFEST.sha256").read_text().splitlines():
  try: h,name=line.split(maxsplit=1); manifest[name.strip()]=h
  except ValueError: raise UpdateError("invalid manifest")
 for name,h in manifest.items():
  target=(root/name).resolve()
  if not target.is_file() or root not in target.parents or digest(target)!=h: raise UpdateError("manifest validation failed")
 return root
def health()->bool:
 return subprocess.run(["/usr/bin/systemctl","restart","zero-observer.service","zero-connect-web.service"],check=False).returncode==0 and subprocess.run(["/usr/bin/systemctl","is-active","--quiet","zero-observer.service","zero-connect-web.service"],check=False).returncode==0
def run()->str:
 if os.geteuid()!=0: raise UpdateError("root required")
 if not (BUNDLE.is_file() and META.is_file() and KEY.is_file()): raise UpdateError("staged update incomplete")
 BACKUPS.mkdir(parents=True,exist_ok=True); BACKUPS.chmod(0o700)
 with tempfile.TemporaryDirectory(dir=BACKUPS,prefix="extract-") as temp:
  # Freeze unprivileged staging inputs before validation; never reopen them.
  frozen=Path(temp)/"bundle.tar.gz"; frozen_meta=Path(temp)/"release.json"
  shutil.copyfile(BUNDLE,frozen); shutil.copyfile(META,frozen_meta); frozen.chmod(0o600); frozen_meta.chmod(0o600)
  metadata=json.loads(frozen_meta.read_text()); expected=metadata.get("asset",{}).get("sha256")
  if not isinstance(expected,str) or digest(frozen)!=expected or not verify_release_metadata(metadata,read_key()): raise UpdateError("metadata validation failed")
  candidate=safe_extract(frozen,Path(temp)); version=json.loads((candidate/"VERSION.json").read_text())
  if version.get("public_version")!=metadata.get("public_version") or int(version.get("config_schema",0)) < int(metadata.get("minimum_config_schema",0)): raise UpdateError("version or schema incompatible")
  platforms=metadata.get("supported_platforms",[])
  if platforms and "raspios-trixie-arm64" not in platforms: raise UpdateError("platform incompatible")
  backup=BACKUPS/"previous"
  shutil.rmtree(backup,ignore_errors=True); os.replace(APP,backup)
  try:
   os.replace(candidate,APP)
   if not health(): raise UpdateError("health check failed")
  except Exception:
   shutil.rmtree(APP,ignore_errors=True); os.replace(backup,APP)
   if not health(): raise UpdateError("rollback health check failed")
   raise
 return "updated"
if __name__=="__main__": print(run())
