#!/usr/bin/env python3
"""Safe, hardware-gated Wi-Fi setup orchestration for first-run.

The manager only offers a hotspot when first-run is active and no network is
available. Applying a network profile is an explicit caller action; this
module never changes networking merely because it was imported or inspected.
"""

from __future__ import annotations

import json
import socket
import subprocess
from dataclasses import dataclass
from typing import Any, Callable

from zero_network_helper import normal_network_available
from zero_paths import PATHS


CommandRunner = Callable[..., Any]


@dataclass
class WifiSetupManager:
    runner: CommandRunner | None = None
    hotspot_name: str = "Zero Connect Setup"
    socket_path: str = str(PATHS.runtime_dir / "network.sock")

    def _ipc(self, action: str, **payload: str) -> dict[str, Any]:
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(50); client.connect(self.socket_path)
                client.sendall((json.dumps({"action": action, **payload}) + "\n").encode("utf-8"))
                response = json.loads(client.makefile("rb").readline(8192).decode("utf-8"))
        except (OSError, ValueError) as exc:
            raise RuntimeError("WLAN-Systemdienst ist nicht erreichbar.") from exc
        if not isinstance(response, dict) or not response.get("ok"):
            raise RuntimeError("WLAN-Aktion konnte nicht ausgeführt werden.")
        return response

    def network_available(self) -> bool:
        if self.runner is None:
            return bool(self._ipc("status").get("network_available", False))
        return normal_network_available(self.runner)

    @staticmethod
    def should_offer_hotspot(*, first_run: bool, network_available: bool) -> bool:
        return bool(first_run and not network_available)

    def plan_hotspot(self, *, first_run: bool) -> dict[str, Any]:
        status = self._ipc("status") if self.runner is None else {}
        available = bool(status.get("network_available", False)) if self.runner is None else self.network_available()
        return {
            "first_run": bool(first_run),
            "network_available": available,
            "hotspot_recommended": self.should_offer_hotspot(
                first_run=first_run, network_available=available
            ),
            "hotspot_name": self.hotspot_name,
            "hardware_validation_required": True,
            "transition": status.get("transition", {"phase": "idle", "error_code": "", "recovery_available": False}),
        }

    def ensure_hotspot_profile(self) -> bool:
        """Create the dedicated, non-autoconnecting NM profile when absent.

        This is deliberately limited to one fixed connection name; callers
        never pass arbitrary nmcli arguments.  The profile uses NetworkManager
        shared IPv4 addressing so DNS/DHCP for the local setup network are
        provided without an extra daemon.
        """
        if self.runner is None:
            return bool(self._ipc("ensure_hotspot").get("active", False))
        try:
            shown = self.runner(["nmcli", "-t", "-f", "NAME", "connection", "show"], capture_output=True, text=True, check=False, timeout=15)
            if shown.returncode == 0 and self.hotspot_name in {line.strip() for line in str(shown.stdout).splitlines()}:
                return True
            commands = (
                ["nmcli", "connection", "add", "type", "wifi", "ifname", "*", "con-name", self.hotspot_name, "ssid", self.hotspot_name],
                ["nmcli", "connection", "modify", self.hotspot_name, "802-11-wireless.mode", "ap", "ipv4.method", "shared", "ipv6.method", "disabled", "connection.autoconnect", "no"],
            )
            for command in commands:
                result = self.runner(command, capture_output=True, text=True, check=False, timeout=20)
                if result.returncode != 0:
                    return False
        except (OSError, subprocess.SubprocessError):
            return False
        return True

    def activate_hotspot(self, *, first_run: bool) -> bool:
        """Activate the temporary setup profile only after a fresh check."""
        if self.runner is None:
            if not first_run: return False
            return bool(self._ipc("ensure_hotspot").get("active", False))
        available = self.network_available()
        if not self.should_offer_hotspot(first_run=first_run, network_available=available):
            return False
        if not self.ensure_hotspot_profile():
            raise RuntimeError("Temporärer Setup-Hotspot konnte nicht vorbereitet werden.")
        try:
            result = self.runner(
                ["nmcli", "connection", "up", self.hotspot_name],
                capture_output=True,
                text=True,
                check=False,
                timeout=20,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError("Temporärer Setup-Hotspot konnte nicht aktiviert werden.") from exc
        if result.returncode != 0:
            raise RuntimeError("Temporärer Setup-Hotspot konnte nicht aktiviert werden.")
        return True

    def scan_networks(self) -> list[str]:
        """Return deduplicated visible SSIDs; never return security metadata."""
        if self.runner is None:
            return [str(x) for x in self._ipc("scan").get("networks", [])]
        try:
            result = self.runner(["nmcli", "-t", "-f", "SSID", "device", "wifi", "list", "--rescan", "yes"], capture_output=True, text=True, check=False, timeout=30)
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError("WLAN-Netze konnten nicht gesucht werden.") from exc
        if result.returncode != 0:
            raise RuntimeError("WLAN-Netze konnten nicht gesucht werden.")
        return sorted({line.strip() for line in str(result.stdout).splitlines() if line.strip()})

    def target_network_available(self) -> bool:
        """Require an active connection other than the temporary setup AP."""
        if self.runner is None:
            return bool(self._ipc("status").get("network_available", False))
        return normal_network_available(self.runner)

    def apply_network(self, ssid: str, password: str) -> bool:
        """Apply an explicitly requested profile without logging the secret.

        A failed command leaves the existing connection/hotspot untouched so a
        user can retry. Real Raspberry Pi validation remains mandatory.
        """
        ssid = str(ssid).strip()
        password = str(password)
        if not ssid or len(password) < 8:
            raise ValueError("WLAN-Name und ein WLAN-Passwort mit mindestens 8 Zeichen sind erforderlich.")
        if self.runner is None:
            return bool(self._ipc("connect", ssid=ssid, password=password).get("connected", False))
        try:
            result = self.runner(
                ["nmcli", "device", "wifi", "connect", ssid, "password", password],
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError("WLAN-Konfiguration konnte nicht angewendet werden.") from exc
        if result.returncode != 0:
            # Keep the recovery path available after bad credentials or a
            # failed association.  A successful target connection is the only
            # condition under which the setup AP may be removed.
            try:
                self.runner(["nmcli", "connection", "up", self.hotspot_name], capture_output=True, text=True, check=False, timeout=20)
            except (OSError, subprocess.SubprocessError):
                pass
            raise RuntimeError("WLAN-Konfiguration konnte nicht angewendet werden; erneut versuchen.")
        return True

    def deactivate_hotspot(self) -> bool:
        """Remove only the temporary setup connection after verified success."""
        if self.runner is None:
            self._ipc("deactivate_hotspot")
            return True
        try:
            result = self.runner(["nmcli", "connection", "down", self.hotspot_name], capture_output=True, text=True, check=False, timeout=20)
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError("Setup-Hotspot konnte nicht beendet werden.") from exc
        return result.returncode == 0
