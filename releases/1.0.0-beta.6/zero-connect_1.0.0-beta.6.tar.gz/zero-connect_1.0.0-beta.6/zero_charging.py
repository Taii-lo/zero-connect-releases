#!/usr/bin/env python3
"""Pure charging sample, rate, timeline and history-quality helpers."""
from __future__ import annotations

from datetime import datetime, timezone
from statistics import mean
import time
from typing import Any

MILESTONES = (20, 30, 40, 50, 60, 70, 80, 90, 100)
MAX_ACTIVE_GAP_SECONDS = 15 * 60


def number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def epoch(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        pass
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return (parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)).timestamp()
    except ValueError:
        return None


def valid_sample(sample: dict[str, Any]) -> bool:
    soc = number(sample.get("soc")); stamp = epoch(sample.get("timestamp"))
    return soc is not None and 0 <= soc <= 100 and stamp is not None


def ordered_samples(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: dict[tuple[int, float], dict[str, Any]] = {}
    for item in samples:
        if not valid_sample(item):
            continue
        key = (int(item.get("generation", 0) or 0), epoch(item.get("timestamp")) or 0)
        unique[key] = dict(item)
    return sorted(unique.values(), key=lambda x: epoch(x.get("timestamp")) or 0)


def observed_soc_at(samples: list[dict[str, Any]], end_epoch: float) -> float | None:
    """Return the latest valid observed SOC at or shortly before an end time.

    The charge target is not an end-SOC measurement. A sample can support the
    display only when its vehicle contact timestamp is no later than the
    selected active-end time and falls within the normal active-sample gap.
    """
    if end_epoch <= 0:
        return None
    candidates: list[tuple[float, float]] = []
    for sample in samples:
        value = number(sample.get("soc"))
        stamp = epoch(sample.get("contact_time")) or epoch(sample.get("timestamp"))
        if value is None or not 0 < value <= 100 or stamp is None:
            continue
        age = end_epoch - stamp
        if -1 <= age <= MAX_ACTIVE_GAP_SECONDS:
            candidates.append((stamp, value))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def session_end_soc(record: dict[str, Any], samples: list[dict[str, Any]]) -> float | None:
    """Return end SOC only with explicit provenance or an aligned sample.

    Legacy rows have no evidence marker and may have copied the charge target
    into `end_soc`; derive their projection from bounded, session-filtered
    samples instead of trusting the persisted scalar.
    """
    stored = number(record.get("end_soc"))
    if record.get("end_soc_source") == "observed_sample" and stored is not None and 0 < stored <= 100:
        return stored
    return observed_soc_at(samples, epoch(record.get("ended_at_utc")) or 0.0)


def session_samples_for_record(
    record: dict[str, Any], samples: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Project only samples captured when the terminal session row was written.

    `sample_sequence_watermark` is the exact generation-local watermark. Apply
    it before timestamp sorting or duplicate removal so late/out-of-order rows
    cannot displace terminal-session samples. Unsequenced legacy rows remain
    readable; `sample_count` remains the legacy normalized watermark.
    """
    watermark = record.get("sample_sequence_watermark")
    if type(watermark) is int and watermark >= 0:
        legacy = []
        sequenced = []
        for sample in samples:
            sequence = sample.get("sample_sequence")
            if "sample_sequence" not in sample:
                legacy.append(sample)
            elif type(sequence) is int and sequence <= watermark:
                sequenced.append(sample)
            # A present but invalid sequence cannot be safely positioned
            # relative to this terminal watermark. Keep it in raw storage,
            # but exclude it from derived history rather than risk admitting
            # a later plugged-idle row into a completed session.
        # Preserve latest append semantics for duplicate timestamps even when
        # wall-clock file partitioning differs from the generation sequence.
        sequenced.sort(key=lambda sample: sample["sample_sequence"])
        projected = ordered_samples(legacy + sequenced)
    else:
        count = record.get("sample_count")
        projected = ordered_samples(samples)
        if type(count) is int and count >= 0 and len(projected) > count:
            projected = projected[:count]
    # Sequence numbers are persistence metadata, not part of the History API.
    for sample in projected:
        sample.pop("sample_sequence", None)
    return projected


def rate(samples: list[dict[str, Any]], *, minimum_seconds: int = 600) -> float | None:
    rows = ordered_samples(samples)
    if len(rows) < 2:
        return None
    start, end = rows[0], rows[-1]
    elapsed = (epoch(end.get("timestamp")) or 0) - (epoch(start.get("timestamp")) or 0)
    delta = (number(end.get("soc")) or 0) - (number(start.get("soc")) or 0)
    if elapsed < minimum_seconds or delta <= 0:
        return None
    return round(delta / (elapsed / 3600), 1)


def smoothed_rate(
    samples: list[dict[str, Any]], *, window_seconds: int = 1800,
    now_epoch: float | None = None, max_age_seconds: int = 300,
) -> float | None:
    """Estimate SOC %/h from a fresh, same-generation 30 minute sample window.

    At least three samples spanning five minutes are required. Samples are
    timestamp ordered (arrival order is irrelevant); no electrical power is
    inferred and rates above 100 %/h remain valid.
    """
    rows = ordered_samples(samples)
    if len(rows) < 3:
        return None
    end_time = epoch(rows[-1].get("timestamp")) or 0
    if now_epoch is None:
        now_epoch = time.time()
    if end_time > now_epoch + 30 or now_epoch - end_time > max_age_seconds:
        return None
    window = [r for r in rows if end_time - (epoch(r.get("timestamp")) or 0) <= window_seconds]
    generations = {int(row.get("generation", 0) or 0) for row in window}
    if len(window) < 3 or len(generations) != 1:
        return None
    if any(number(row.get("charging")) != 1 for row in window):
        return None
    stamps = [epoch(row.get("timestamp")) or 0 for row in window]
    if any(later - earlier > MAX_ACTIVE_GAP_SECONDS for earlier, later in zip(stamps, stamps[1:])):
        return None
    return rate(window, minimum_seconds=300)


def session_average_rate(record: dict[str, Any], samples: list[dict[str, Any]]) -> float | None:
    """Return a session average only when active charging time is explicitly measured."""
    duration = duration_semantics(record, samples)
    active_seconds = duration["active_charging_duration_seconds"]
    start = number(record.get("start_soc")); end = number(record.get("end_soc"))
    if active_seconds is None or active_seconds <= 0 or start is None or end is None or end <= start:
        return None
    return round((end - start) / (active_seconds / 3600), 1)


def segments(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = ordered_samples(samples)
    result: list[dict[str, Any]] = []
    for low in MILESTONES[:-1]:
        high = low + 10
        start = next((r for r in rows if (number(r.get("soc")) or -1) >= low), None)
        end = next((r for r in rows if (number(r.get("soc")) or -1) >= high and start and (epoch(r.get("timestamp")) or 0) >= (epoch(start.get("timestamp")) or 0)), None)
        if start and end:
            elapsed = (epoch(end.get("timestamp")) or 0) - (epoch(start.get("timestamp")) or 0)
            if elapsed >= 0:
                result.append({"from_soc": low, "to_soc": high, "duration_seconds": round(elapsed)})
    return result


def milestones(samples: list[dict[str, Any]], target: Any = None) -> list[dict[str, Any]]:
    rows = ordered_samples(samples)
    if not rows:
        return []
    first = number(rows[0].get("soc")) or 0
    thresholds = list(MILESTONES)
    target_value = number(target)
    if target_value is not None and target_value not in thresholds:
        thresholds.append(int(round(target_value)))
    result = []
    for threshold in sorted(set(thresholds)):
        if threshold <= first:
            continue
        found = next((r for r in rows if (number(r.get("soc")) or -1) >= threshold), None)
        if found:
            result.append({"type": "charge_target_reached" if target_value == threshold else "soc_milestone", "soc": threshold, "timestamp": found.get("timestamp")})
    return result


def validate_session(record: dict[str, Any], samples: list[dict[str, Any]]) -> list[str]:
    issues: list[str] = []
    start = epoch(record.get("started_at_utc")); end = epoch(record.get("ended_at_utc"))
    if start is not None and end is not None and end < start: issues.append("end_before_start")
    duration = number(record.get("duration_seconds"))
    if duration is not None and duration < 0: issues.append("negative_duration")
    for key in ("start_soc", "end_soc", "target_soc"):
        value = number(record.get(key))
        if value is not None and not 0 <= value <= 100: issues.append(f"{key}_out_of_range")
    if number(record.get("end_soc")) is not None and number(record.get("start_soc")) is not None and number(record.get("end_soc")) < number(record.get("start_soc")): issues.append("soc_decreased")
    if any(not valid_sample(s) for s in samples): issues.append("invalid_sample")
    if ordered_samples(samples) != samples: issues.append("samples_not_normalized")
    return issues


def duration_semantics(record: dict[str, Any], samples: list[dict[str, Any]]) -> dict[str, Any]:
    """Separate physical attachment from measurable active charging time.

    A session's stored duration is retained as a session interval. Active time
    is returned only when a complete, trustworthy active interval is explicitly
    evidenced; sparse observations and telemetry gaps remain unknown.
    """
    physical = number(record.get("duration_seconds"))
    rows = ordered_samples(samples)
    active = None
    active_evidence = "unknown"
    # The observer records state observations, not energy flow. Even a dense
    # charging=1 run may be a target/balancing plateau, and it may cover only a
    # fragment of the stored session. Do not present that fragment as a total.
    explicit = number(record.get("active_charging_duration_seconds"))
    if explicit is not None and explicit >= 0 and record.get("active_charging_evidence") in {"metered", "complete_interval"}:
        active = round(explicit)
        active_evidence = str(record.get("active_charging_evidence"))
    return {
        "session_duration_seconds": round(physical) if physical is not None else None,
        "active_charging_duration_seconds": active,
        "active_charging_evidence": active_evidence,
    }


def monthly(records: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for record in records:
        stamp = str(record.get("started_at_utc") or record.get("ended_at_utc") or "")[:7]
        if len(stamp) != 7: continue
        item = result.setdefault(stamp, {"sessions": 0, "duration_seconds": 0, "delta_soc": 0.0, "start_soc": [], "end_soc": []})
        item["sessions"] += 1
        item["duration_seconds"] += int(number(record.get("duration_seconds")) or 0)
        start = number(record.get("start_soc")); end = number(record.get("end_soc"))
        if start is not None: item["start_soc"].append(start)
        if end is not None: item["end_soc"].append(end)
        if start is not None and end is not None and end >= start: item["delta_soc"] += end - start
    for item in result.values():
        item["delta_soc"] = round(item["delta_soc"], 1)
        item["average_start_soc"] = round(mean(item.pop("start_soc")), 1) if item["start_soc"] else None
        item["average_end_soc"] = round(mean(item.pop("end_soc")), 1) if item["end_soc"] else None
    return result
