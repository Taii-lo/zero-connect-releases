"""Central, explicit filesystem and service layout for Zero Connect modes."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ZeroPaths:
    mode: str
    program_dir: Path
    config_dir: Path
    data_dir: Path
    runtime_dir: Path
    service_user: str | None

    @property
    def config_file(self) -> Path: return self.config_dir / "zero_config.json"
    @property
    def secrets_file(self) -> Path: return self.config_dir / ("secrets.env" if self.mode == "appliance" else ".env")
    @property
    def web_assets_dir(self) -> Path: return self.program_dir / "web_assets"
    @property
    def service_scope(self) -> list[str]: return ["systemctl"] if self.mode == "appliance" else ["systemctl", "--user"]
    def service_command(self, *args: str) -> list[str]: return [*self.service_scope, *args]


def paths() -> ZeroPaths:
    mode = os.environ.get("ZERO_CONNECT_MODE", "user").strip().lower()
    if mode == "appliance":
        return ZeroPaths("appliance", Path(os.environ.get("ZERO_CONNECT_PROGRAM_DIR", "/opt/zero-connect")), Path(os.environ.get("ZERO_CONNECT_CONFIG_DIR", "/etc/zero-connect")), Path(os.environ.get("ZERO_CONNECT_DATA_DIR", "/var/lib/zero-connect")), Path(os.environ.get("ZERO_CONNECT_RUNTIME_DIR", "/run/zero-connect")), "zero-connect")
    program = Path(os.environ.get("ZERO_CONNECT_PROGRAM_DIR", Path(__file__).resolve().parent))
    return ZeroPaths("user", program, program, Path(os.environ.get("ZERO_CONNECT_DATA_DIR", program / "data")), Path(os.environ.get("ZERO_CONNECT_RUNTIME_DIR", "/run/zero-connect")), None)


PATHS = paths()
