#!/usr/bin/env python3
"""Synthetic Pi -> Aivi -> iPhone Live Activity test for Zero Connect."""
from __future__ import annotations

import argparse
import copy
import json
import os
import time
from pathlib import Path

from dotenv import load_dotenv

import zero_observer as observer

from zero_paths import PATHS
PROJECT_DIR = PATHS.program_dir
STATE_FILE = PATHS.data_dir / "runtime_state_v2.json"
VALID_FILE = PATHS.data_dir / "last_valid_transmit.json"


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def credentials() -> tuple[str, str, dict]:
    config = observer.load_config()
    load_dotenv(PATHS.secrets_file, override=True)
    if not bool(config.get("aivi", {}).get("enabled", False)):
        raise SystemExit("Aivi ist deaktiviert. Zuerst 'zero-connect configure aivi' ausführen.")
    token = os.getenv("AIVI_API_TOKEN", "").strip()
    slug = os.getenv("AIVI_ACTIVITY_SLUG", "").strip() or str(config["aivi"]["activity_slug"]).strip()
    if not token or not slug:
        raise SystemExit("Aivi API-Token oder Activity-Slug fehlt in .env/config.")
    return token, slug, config


def ensure_not_charging() -> None:
    state = load_json(STATE_FILE)
    phase = str(state.get("charge_phase", "unknown"))
    if bool(state.get("session_active")) or phase in {"charging", "target_reached"}:
        raise SystemExit("Test abgebrochen: Der produktive Observer sieht eine aktive Ladesitzung.")


def send(payload: dict, token: str, slug: str, config: dict, label: str) -> None:
    observer.send_aivi_activity(payload, token, slug, float(config["aivi"]["request_timeout_seconds"]))
    print(f"[{time.strftime('%H:%M:%S')}] {label}", flush=True)


def test_status(soc: int, minutes: int | None, phase: str) -> tuple[dict, dict]:
    status = observer.make_test_status(
        soc,
        1 if phase in {"charging", "target_reached"} else 0,
        1 if phase in {"target_reached", "complete"} else 0,
        1,
        time.strftime("%Y%m%d%H%M%S", time.gmtime()),
        minutes,
    )
    state = observer.default_runtime_state()
    state["initialized"] = True
    state["session_active"] = True
    state["charge_session_generation"] = 1
    state["session_started_epoch"] = time.time() - 3600
    state["session_start_soc"] = 70.0
    state["target_soc"] = 85.0
    if phase in {"target_reached", "complete"}:
        state["target_notified"] = True
    return status, state


def idle_progress_payload(status: dict, state: dict, config: dict) -> dict:
    payload = observer.build_live_update_payload("complete", status, state, config)
    payload["state"] = "IDLE"
    return payload


def reset_all(*, best_effort: bool = False, announce: bool = True) -> None:
    ensure_not_charging()
    token, progress_slug, config = credentials()
    aivi = config.get("aivi", {})
    balancing_slug = str(aivi.get("balancing_activity_slug", "")).strip()
    complete_slug = str(aivi.get("complete_activity_slug", "")).strip()
    status = load_json(VALID_FILE)
    soc = max(0, min(100, int(round(observer.to_float(status.get("soc")))))) if status else 0
    fake_status, state = test_status(soc, None, "complete")
    state["session_active"] = False
    state["session_balancing_started_epoch"] = time.time() - 300
    state["session_completed_epoch"] = time.time()

    payloads: list[tuple[str, dict, str]] = [
        (progress_slug, idle_progress_payload(fake_status, state, config), "Laden/Progress → IDLE"),
    ]
    if balancing_slug:
        payloads.append((balancing_slug, observer.build_balancing_monitor_payload(fake_status, state, "IDLE"), "Balancing → IDLE"))
    if complete_slug:
        payloads.append((complete_slug, observer.build_completion_monitor_payload(fake_status, state, "complete", "IDLE"), "Abschluss → IDLE"))

    errors: list[str] = []
    for slug, payload, label in payloads:
        try:
            send(payload, token, slug, config, label)
        except Exception as exc:  # cleanup must try every slug
            errors.append(f"{slug}: {exc}")
            if announce:
                print(f"[!] Reset fehlgeschlagen für {slug}: {exc}", flush=True)
    if errors and not best_effort:
        raise SystemExit("Aivi-Reset unvollständig: " + " | ".join(errors))
    if announce and not errors:
        print("[✓] Alle konfigurierten Aivi-Activities sind auf IDLE gesetzt.")


def run_test(interval: int, final_hold: int) -> None:
    """Exercise the same single Progress template used by production."""
    ensure_not_charging()
    token, slug, config = credentials()
    print("Aivi wird vor dem Test zurückgesetzt …")
    reset_all(announce=False)
    time.sleep(2)

    steps = [
        (70, 6, "charging"), (72, 5, "charging"),
        (75, 4, "charging"), (78, 3, "charging"),
        (81, 2, "charging"), (84, 1, "charging"),
        (85, None, "target_reached"), (85, None, "complete"),
    ]
    state = observer.default_runtime_state()
    started = time.time() - 3600
    state.update(
        initialized=True,
        session_active=True,
        charge_session_generation=1,
        session_started_epoch=started,
        session_start_soc=70.0,
        target_soc=85.0,
    )
    print(
        f"Aivi-Simulation: {len(steps)} Zustände, Abstand {interval} s, "
        f"Single-Progress-Slug {slug}"
    )
    final_payload: dict | None = None
    for index, (soc, minutes, phase) in enumerate(steps, start=1):
        now_epoch = time.time()
        state["charge_phase"] = phase
        if phase == "target_reached":
            state["target_notified"] = True
            state["session_balancing_started_epoch"] = now_epoch
        elif phase == "complete":
            state["session_active"] = False
            state["session_completed_epoch"] = now_epoch
        status = observer.make_test_status(
            soc,
            1 if phase in {"charging", "target_reached"} else 0,
            1 if phase in {"target_reached", "complete"} else 0,
            1,
            time.strftime("%Y%m%d%H%M%S", time.gmtime()),
            minutes,
        )
        payload = observer.build_live_update_payload(
            phase, status, state, config, now_epoch=now_epoch
        )
        final_payload = payload
        send(payload, token, slug, config, f"{index}/{len(steps)} · {soc}% · {phase}")
        if index < len(steps):
            time.sleep(interval)
    assert final_payload is not None
    print(f"Abschluss bleibt {final_hold} s sichtbar.")
    time.sleep(final_hold)
    idle = copy.deepcopy(final_payload)
    idle["state"] = "IDLE"
    send(idle, token, slug, config, "IDLE gesendet · Test beendet")


def main() -> None:
    parser = argparse.ArgumentParser(description="Aivi Live Activity ohne Motorrad testen")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("--interval", type=int, default=30)
    run.add_argument("--final-hold", type=int, default=5)
    sub.add_parser("reset")
    sub.add_parser("idle", help="Alias für reset")
    args = parser.parse_args()
    if args.command in {"reset", "idle"}:
        reset_all()
        return
    if args.interval < 5 or args.final_hold < 0:
        raise SystemExit("Ungültige Testzeiten.")
    try:
        run_test(args.interval, args.final_hold)
    except KeyboardInterrupt:
        print("\nTest abgebrochen. Aivi-Activities werden zurückgesetzt …", flush=True)
        try:
            reset_all(best_effort=True, announce=False)
        finally:
            raise SystemExit(130)


if __name__ == "__main__":
    main()
