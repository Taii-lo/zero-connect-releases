#!/usr/bin/env python3
"""Fixed root launcher installed with the image: the real updater travels inside the signed app bundle.

Only root may own and write the target, so a later update can replace (and fix) the updater itself.
"""
from __future__ import annotations
import os, stat, sys

TARGET = "/opt/zero-connect/zero_appliance_update.py"


def trusted(path: str = TARGET) -> bool:
    """The target and its directory must belong to root and not be group/world writable."""
    try:
        for item in (path, os.path.dirname(path)):
            info = os.stat(item)
            if info.st_uid != 0 or info.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
                return False
        return os.path.isfile(path)
    except OSError:
        return False


def main() -> int:
    if os.geteuid() != 0:
        print("root required", file=sys.stderr)
        return 1
    if not trusted():
        print("updater in /opt/zero-connect is missing or not root-owned", file=sys.stderr)
        return 1
    os.execv(sys.executable, [sys.executable, TARGET])


if __name__ == "__main__":
    sys.exit(main())
