#!/usr/bin/env python3
"""Human-friendly local status view for Zero Connect."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

import zero_observer as observer

from zero_paths import PATHS
PROJECT_DIR = PATHS.program_dir
DATA_DIR = PATHS.data_dir
STATE_FILE = DATA_DIR / "runtime_state_v2.json"
VALID_FILE = DATA_DIR / "last_valid_transmit.json"
RAW_FILE = DATA_DIR / "last_raw_transmit.json"
LOCAL_TZ = datetime.now().astimezone().tzinfo


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def parse_zero_time(value: Any) -> datetime | None:
    try:
        return datetime.strptime(str(value), "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def epoch_to_datetime(value: Any) -> datetime | None:
    number = to_float(value)
    if number is None or number <= 0:
        return None
    try:
        return datetime.fromtimestamp(number, timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


def age_seconds(value: datetime | None) -> float:
    if value is None:
        return float("inf")
    return max(0.0, time.time() - value.timestamp())


def age_text(seconds: float) -> str:
    if seconds == float("inf"):
        return "unbekannt"
    if seconds < 90:
        return f"vor {int(seconds)} s"
    minutes = int(seconds // 60)
    if minutes < 120:
        return f"vor {minutes} min"
    hours, rest = divmod(minutes, 60)
    if hours < 48:
        return f"vor {hours} h {rest:02d} min"
    return f"vor {hours // 24} Tagen"


def local_text(value: datetime | None) -> str:
    if value is None:
        return "unbekannt"
    return value.astimezone(LOCAL_TZ).strftime("%d.%m.%Y %H:%M:%S")


def service_status() -> str:
    try:
        result = subprocess.run(
            PATHS.service_command("is-active", "zero-observer.service"),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unbekannt"
    value = result.stdout.strip()
    return "aktiv" if value == "active" else value or "inaktiv"


def phase_text(phase: str) -> str:
    return {
        "charging": "Lädt",
        "target_reached": "Ladeziel erreicht · Balancing",
        "complete": "Laden abgeschlossen",
        "ended": "Bewusst beendet",
        "interrupted": "Ladeunterbrechung",
        "plugged_idle": "Angesteckt, lädt nicht",
        "unplugged": "Nicht angeschlossen",
        "other": "Unklarer Ladezustand",
        "unknown": "Noch nicht bestimmt",
    }.get(phase, "Noch nicht bestimmt")


def confidence_text(value: str) -> str:
    return {
        "confirmed": "Cloud bestätigt",
        "derived": "aus Cloud-Daten abgeleitet",
        "inferred": "von Zero Connect abgeleitet",
    }.get(value, "")


def diagnostic_text(success_epoch: Any, error: Any) -> str:
    success = epoch_to_datetime(success_epoch)
    error_text = str(error or "").strip()
    if error_text:
        return f"Fehler: {error_text}"
    if success is None:
        return "noch kein erfolgreicher Vorgang"
    return f"erfolgreich {age_text(age_seconds(success))}"


def remaining_text(value: datetime | None) -> str:
    if value is None:
        return "unbekannt"
    remaining = max(0, int(round(value.timestamp() - time.time())))
    if remaining < 90:
        return f"in {remaining} s"
    minutes, seconds = divmod(remaining, 60)
    return f"in {minutes}:{seconds:02d} min"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Aktuellen Zero-Connect-Status anzeigen",
        add_help=True,
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="zusätzliche technische Details anzeigen",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        config = observer.load_config()
    except RuntimeError:
        config = observer.DEFAULT_CONFIG

    load_dotenv(PATHS.secrets_file)
    state = load_json(STATE_FILE)
    status = load_json(VALID_FILE) or load_json(RAW_FILE)
    vehicle_label = str(config.get("vehicle_label", "Zero Motorcycle"))

    print()
    print(f"🏍️  {vehicle_label}")
    print("────────────────────────────────────────")
    print(f"Observer:          {service_status()}")

    if not status:
        print("Fahrzeugdaten:     noch keine lokalen Daten")
        print("Hinweis:           Nach der ersten erfolgreichen Zero-Cloud-Abfrage erneut prüfen.")
        print()
        return

    measurement_time = parse_zero_time(status.get("datetime_utc"))
    actual_time = parse_zero_time(status.get("datetime_actual"))
    contact_candidates = [v for v in (measurement_time, actual_time) if v is not None]
    contact_time = max(contact_candidates) if contact_candidates else None
    contact_age = age_seconds(contact_time)
    max_age = float(config.get("freshness", {}).get("max_contact_age_seconds", 900))
    fresh = contact_age <= max_age

    soc = to_float(status.get("soc"))
    soc_text = "?" if soc is None else f"{soc:.0f} %"
    phase = str(state.get("charge_phase", "unknown"))
    target_soc = to_float(state.get("target_soc"))
    target_text = ""
    if target_soc is not None and phase in {"charging", "target_reached", "complete"}:
        target_text = f" · Ziel {target_soc:.0f} %"
    confidence = confidence_text(str(state.get("charge_state_confidence", "unknown")))
    confidence_suffix = f" · {confidence}" if confidence and phase in {"target_reached", "complete"} else ""

    last_poll = epoch_to_datetime(state.get("last_poll_success_epoch"))
    print(f"Akkustand:         {soc_text}")
    print(f"Ladestatus:        {phase_text(phase)}{target_text}{confidence_suffix}")
    if fresh:
        print(f"Fahrzeugdaten:     aktuell · {age_text(contact_age)}")
    else:
        print(f"Fahrzeugdaten:     veraltet · letzter Fahrzeugkontakt {age_text(contact_age)}")
    print(f"Pi-Abfrage:        {age_text(age_seconds(last_poll))}")

    abrp_enabled = bool(config.get("abrp", {}).get("enabled", False))
    if abrp_enabled:
        print("ABRP:              " + diagnostic_text(
            state.get("last_abrp_success_epoch"), state.get("last_abrp_error")
        ))
    else:
        print("ABRP:              deaktiviert")

    aivi_enabled = bool(config.get("aivi", {}).get("enabled", False))
    if aivi_enabled:
        print("Aivi:              " + diagnostic_text(
            state.get("last_live_activity_success_epoch"), state.get("last_live_activity_error")
        ))
        live_active = bool(state.get("live_activity_active", False))
        live_phase = str(state.get("live_activity_last_phase") or "").strip()
        if state.get("last_live_activity_error"):
            live_text = "Fehler"
        elif live_active and state.get("live_activity_final_sent", False):
            idle_due = epoch_to_datetime(state.get("live_activity_idle_due_epoch"))
            live_text = "Abschluss sichtbar" + (f" · IDLE {remaining_text(idle_due)}" if idle_due else "")
        elif live_active:
            live_text = f"aktiv · {phase_text(live_phase)}" if live_phase else "aktiv"
        elif state.get("live_activity_closed_for_session", False):
            live_text = "beendet"
        else:
            live_text = "inaktiv"
        print(f"Live Activity:     {live_text}")
    else:
        print("Aivi:              deaktiviert")

    errors = int(to_float(state.get("consecutive_errors")) or 0)
    last_error = str(state.get("last_error") or "").strip()
    if errors or last_error:
        print(f"Cloud-Fehler:      {errors} in Folge · {last_error or 'unbekannt'}")

    if args.verbose:
        print("────────────────────────────────────────")
        print(f"Cloud-Kontakt:     {local_text(contact_time)} ({age_text(contact_age)})")
        print(
            f"Fahrzeugzeit:      {local_text(measurement_time)} "
            f"({age_text(age_seconds(measurement_time))})"
        )
        print(f"Letzte Pi-Abfrage: {local_text(last_poll)} ({age_text(age_seconds(last_poll))})")
        last_change = epoch_to_datetime(state.get("last_status_change_epoch"))
        print(f"Statusänderung:    {local_text(last_change)} ({age_text(age_seconds(last_change))})")
        poll_interval = int(to_float(state.get("last_poll_interval_seconds")) or 0)
        print(f"Abfrageintervall:  {poll_interval or '?'} s")
        mileage = observer.vehicle_odometer_km(status, config)
        mileage_text = "unbekannt" if mileage is None else f"{mileage:.1f} km (Cloud/Telematik)"
        print(f"Kilometerstand:    {mileage_text}")
        print(f"Konfidenz:         {confidence or 'nicht relevant'}")
        completion = str(state.get("charge_completion_source", "") or "")
        if completion:
            print(f"Abschlussquelle:   {completion}")
        if state.get("shutdown_zero_pulse_observed"):
            pulse_gen = int(to_float(state.get("shutdown_zero_pulse_generation")) or 0)
            print(f"Shutdown-Signal:   Raw-SoC 0 % erkannt · Session {pulse_gen}")
        if aivi_enabled:
            slug = os.getenv("AIVI_ACTIVITY_SLUG") or str(config.get("aivi", {}).get("activity_slug", "zero-connect"))
            mode = str(config.get("aivi", {}).get("mode", "legacy"))
            if mode == "single_progress":
                print("Aivi-Modus:        Single Progress")
                print(f"Aivi-Slug:         {slug}")
                real_updates = int(to_float(state.get("live_activity_real_update_count")) or 0)
                intermediate_updates = int(to_float(state.get("live_activity_intermediate_update_count")) or 0)
                print(f"Live-Updates:      real {real_updates} · Zwischenwerte {intermediate_updates}")
            elif mode == "three_phase":
                print("Aivi-Modus:        Dreiphasenmodus")
                print(f"Aivi Laden:        {slug}")
                print(f"Aivi Balancing:    {config.get('aivi', {}).get('balancing_activity_slug', '')}")
                print(f"Aivi Abschluss:    {config.get('aivi', {}).get('complete_activity_slug', '')}")
                active_kind = str(state.get("three_phase_active_kind", "") or "")
                if active_kind:
                    print(f"Aivi-Phase:        {active_kind}")
            else:
                print("Aivi-Modus:        Legacy-Progress")
                print(f"Aivi-Slug:         {slug}")
                real_updates = int(to_float(state.get("live_activity_real_update_count")) or 0)
                intermediate_updates = int(to_float(state.get("live_activity_intermediate_update_count")) or 0)
                print(f"Live-Updates:      real {real_updates} · Zwischenwerte {intermediate_updates}")
        diag_error = str(state.get("last_diagnostics_error", "") or "").strip()
        if diag_error:
            print(f"Diagnose-Warnung:  {diag_error}")

    print()


if __name__ == "__main__":
    main()
