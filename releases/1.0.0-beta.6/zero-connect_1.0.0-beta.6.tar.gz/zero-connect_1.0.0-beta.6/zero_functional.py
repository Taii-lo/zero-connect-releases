#!/usr/bin/env python3
"""Small, atomic, privacy-preserving functional-expansion store.

The module deliberately uses the existing JSONL history as its source of
truth.  Optional user data lives in separate files so old installations and
legacy sessions remain readable.
"""
from __future__ import annotations

import csv
import errno
import hashlib
import http.client
import io
import json
import math
import os
import re
import tempfile
import time
import zipfile
import threading
import queue
import shutil
import urllib.parse
import urllib.request
import urllib.error
from contextlib import ExitStack, contextmanager
from urllib.parse import urlparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

try:  # Appliance targets Linux; keep module importable on development Windows.
    import fcntl
except ImportError:  # pragma: no cover - Windows development fallback
    fcntl = None

import zero_remote
from zero_paths import PATHS

DATA = PATHS.data_dir
FEATURES = DATA / "functional"
SCHEMA_VERSION = 1
MAX_EVENTS = 2000
MAX_SUBSCRIPTIONS = 32
MAX_MILESTONES = 64
_LOCKS_GUARD = threading.Lock()
_LOCKS: dict[str, threading.RLock] = {}
_RESTORE_AFTER_REPLACE = None  # Test-only interruption injection point.


_RESTORE_COORDINATION = threading.RLock()
_RESTORE_DEPTH = threading.local()


@contextmanager
def _restore_barrier(*, recover: bool = True, read_only: bool = False):
    """Exclude readers/writers across processes until a published restore commits."""
    with _RESTORE_COORDINATION:
        if getattr(_RESTORE_DEPTH, "active", False):
            yield
            return
        lock_path = DATA / ".functional-restore.lock"
        if read_only:
            # Integrity measurement must not create the root or lock it needs
            # to coordinate with writers. Missing or unsafe evidence fails closed.
            if DATA.is_symlink() or not DATA.is_dir() or lock_path.is_symlink():
                raise RuntimeError("restore coordination evidence unavailable")
            lock_mode = "rb"
        else:
            DATA.mkdir(parents=True, exist_ok=True)
            lock_mode = "a+b"
        with _open_lock(lock_path, lock_mode) as handle:
            if fcntl is not None and handle is not None: fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            _RESTORE_DEPTH.active = True
            try:
                if recover and (DATA / ".functional-restore-transaction").exists():
                    _recover_restore_transaction_locked()
                yield
            finally:
                _RESTORE_DEPTH.active = False
                if fcntl is not None and handle is not None: fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


@contextmanager
def _open_lock(lock_path: Path, mode: str = "a+b"):
    """Open a lock file; on read-only storage a read handle locks just as well, and
    without the file nobody can be writing there (``None``, no lock needed)."""
    try:
        handle = lock_path.open(mode)
    except OSError as error:
        if error.errno != errno.EROFS:
            raise
        try:
            handle = lock_path.open("rb")
        except FileNotFoundError:
            handle = None
    try:
        yield handle
    finally:
        if handle is not None:
            handle.close()


@contextmanager
def _store_lock(path: Path):
    """Serialize read-modify-write operations across threads and processes."""
    key = str(path.resolve())
    with _LOCKS_GUARD:
        lock = _LOCKS.setdefault(key, threading.RLock())
    with _restore_barrier(), lock:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            if error.errno != errno.EROFS:
                raise
        lock_path = path.with_name(f".{path.name}.lock")
        with _open_lock(lock_path) as handle:
            try:
                if fcntl is not None and handle is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                yield
            finally:
                if fcntl is not None and handle is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _safe_name(value: Any, fallback: str = "") -> str:
    value = str(value or "").strip()
    if len(value) > 120:
        raise ValueError("Text ist zu lang.")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError("Ungültige Steuerzeichen.")
    return value or fallback


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.parent.chmod(0o700)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush(); os.fsync(handle.fileno())
        os.chmod(name, 0o600)
        os.replace(name, path)
        dir_fd = os.open(path.parent, os.O_RDONLY)
        try: os.fsync(dir_fd)
        finally: os.close(dir_fd)
    finally:
        try: os.unlink(name)
        except FileNotFoundError: pass


def _read(path: Path, default: Any) -> Any:
    with _restore_barrier():
        return _read_unlocked(path, default)


def _read_unlocked(path: Path, default: Any) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except (OSError, ValueError, TypeError):
        return default


def _path(name: str) -> Path: return FEATURES / name


def _now() -> str: return datetime.now(timezone.utc).isoformat()


def preferences() -> dict[str, Any]:
    value = _read(_path("preferences.json"), {})
    return value if isinstance(value, dict) else {}


def session_removals() -> dict[int, dict[str, Any]]:
    """Return reversible history-removal tombstones keyed by positive generation."""
    value = _read(_path("session-removals.json"), {})
    if not isinstance(value, dict):
        return {}
    result: dict[int, dict[str, Any]] = {}
    for key, item in value.items():
        try:
            generation = int(key)
        except (TypeError, ValueError, OverflowError):
            continue
        if generation > 0 and isinstance(item, dict):
            result[generation] = {"generation": generation, "removed_at": str(item.get("removed_at") or "")}
    return result


def set_session_removed(generation: int, removed: bool) -> bool:
    """Create or clear a generation tombstone without touching source history."""
    generation = int(generation)
    if generation <= 0:
        raise ValueError("Diese ältere Sitzung kann nicht eindeutig zugeordnet werden.")
    store = _path("session-removals.json")
    with _store_lock(store):
        value = _read_unlocked(store, {})
        if not isinstance(value, dict):
            value = {}
        key = str(generation)
        changed = (key in value) if not removed else (key not in value)
        if removed:
            value[key] = {"generation": generation, "removed_at": _now()}
        else:
            value.pop(key, None)
        if changed:
            _atomic_json(store, value)
        return changed


def _normalize_preferences(value: dict[str, Any]) -> dict[str, Any]:
    result = dict(value)
    notifications = result.get("notifications", {})
    if not isinstance(notifications, dict): raise ValueError("Ungültige Benachrichtigungseinstellungen.")
    result["notifications"] = {str(k): bool(v) for k, v in notifications.items() if len(str(k)) <= 80}
    for key, choices in (
        ("post_charge_reminder_minutes", (0, 10, 30, 60)),
        ("charging_not_started_minutes", (0, 5, 10, 15)),
    ):
        try:
            threshold = int(result.get(key, 0) or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("Ungültiger Erinnerungszeitpunkt.") from exc
        if threshold not in choices:
            raise ValueError("Ungültiger Erinnerungszeitpunkt.")
        result[key] = threshold
    for key, choices, default in (
        ("evening_reminder_soc", (0, 30, 50, 70), 0),
        ("evening_reminder_hour", (18, 19, 20, 21, 22), 20),
    ):
        try:
            value = int(result.get(key, default) if result.get(key) is not None else default)
        except (TypeError, ValueError) as exc:
            raise ValueError("Ungültige Abend-Erinnerung.") from exc
        if value not in choices:
            raise ValueError("Ungültige Abend-Erinnerung.")
        result[key] = value
    try:
        threshold = int(result.get("offline_threshold_minutes", 0) or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError("Ungültiger Offline-Schwellenwert.") from exc
    if threshold not in (0, 30, 60, 180, 360): raise ValueError("Ungültiger Offline-Schwellenwert.")
    result["offline_threshold_minutes"] = threshold
    return result


def save_preferences(value: dict[str, Any]) -> dict[str, Any]:
    allowed = {
        "notifications", "offline_threshold_minutes",
        "post_charge_reminder_minutes", "charging_not_started_minutes",
        "evening_reminder_soc", "evening_reminder_hour",
    }
    store = _path("preferences.json")
    with _store_lock(store):
        result = preferences()
        for key in allowed:
            if key in value: result[key] = value[key]
        result = _normalize_preferences(result)
        _atomic_json(store, result)
        return result


def locations() -> list[dict[str, Any]]:
    value = _read(_path("locations.json"), [])
    return value if isinstance(value, list) else []


def _legacy_custom_name(row: dict[str, Any]) -> str | None:
    """Keep old user names, but recognize the historical generated fallback."""
    custom = row.get("custom_name")
    if custom is not None:
        return str(custom).strip() or None
    name = str(row.get("name") or "").strip()
    return None if re.fullmatch(r"Ladeort\s+\d+", name, flags=re.IGNORECASE) else name or None


def location_auto_label(row: dict[str, Any], language: str = "de") -> str:
    locale = "en" if str(language).lower().startswith("en") else "de"
    labels = row.get("auto_location_labels") if isinstance(row.get("auto_location_labels"), dict) else {}
    selected = labels.get(locale) if isinstance(labels.get(locale), dict) else {}
    if selected.get("label"):
        return str(selected["label"]).strip()
    legacy_locale = str(row.get("auto_location_language") or "de")
    return str(row.get("auto_location_label") or "").strip() if legacy_locale == locale else ""


def location_auto_label_expired(row: dict[str, Any], language: str = "de", now: float | None = None) -> bool:
    locale = "en" if str(language).lower().startswith("en") else "de"
    labels = row.get("auto_location_labels") if isinstance(row.get("auto_location_labels"), dict) else {}
    selected = labels.get(locale) if isinstance(labels.get(locale), dict) else {}
    resolved = selected.get("resolved_epoch")
    if not isinstance(resolved, (int, float)):
        return True
    current = time.time() if now is None else now
    return current - float(resolved) > _PLACE_CACHE_TTL


def location_auto_place(row: dict[str, Any], language: str = "de") -> dict[str, Any]:
    locale = "en" if str(language).lower().startswith("en") else "de"
    places = row.get("auto_location_places") if isinstance(row.get("auto_location_places"), dict) else {}
    selected = places.get(locale)
    if isinstance(selected, dict):
        return selected
    if str(row.get("auto_location_language") or "de") == locale and isinstance(row.get("auto_location_place"), dict):
        return row["auto_location_place"]
    return {}


def charging_location_display_name(row: dict[str, Any], language: str = "de") -> str:
    return (_legacy_custom_name(row) or location_auto_label(row, language)
            or str(row.get("name") or "").strip() or "Ladeort")


def deleted_location_labels() -> dict[str, Any]:
    value = _read(_path("deleted-location-labels.json"), {})
    return value if isinstance(value, dict) else {}


def deleted_location_label(ident: str, language: str = "de") -> str:
    record = deleted_location_labels().get(str(ident))
    if not isinstance(record, dict):
        return ""
    custom = _place_clean(record.get("custom_name"))
    labels = record.get("labels") if isinstance(record.get("labels"), dict) else {}
    locale = "en" if str(language).lower().startswith("en") else "de"
    return custom or _place_clean(labels.get(locale)) or _place_clean(record.get("fallback_name"))


def upsert_location(payload: dict[str, Any]) -> dict[str, Any]:
    try: lat = float(payload["latitude"]); lon = float(payload["longitude"])
    except (KeyError, TypeError, ValueError): raise ValueError("Koordinaten fehlen oder sind ungültig.")
    if not (-90 <= lat <= 90 and -180 <= lon <= 180): raise ValueError("Koordinaten außerhalb des gültigen Bereichs.")
    ident = str(payload.get("id") or "").strip()
    store = _path("locations.json")
    with _store_lock(store):
        rows = locations()
        row = next((item for item in rows if str(item.get("id")) == ident), None)
        if row is None:
            ident = f"location-{time.time_ns()}"
            while any(str(item.get("id")) == ident for item in rows):
                ident += "-1"
            row = {"id": ident, "created_at": _now(), "sessions": 0}
            rows.append(row)
        old_name = str(row.get("name") or "")
        fallback_name = old_name if re.fullmatch(r"Ladeort\s+\d+", old_name, flags=re.IGNORECASE) else f"Ladeort {len(rows)}"
        if "custom_name" in payload:
            custom_name = _safe_name(payload.get("custom_name")) or None
            incoming_name = _safe_name(payload.get("name"))
            prior_custom = _legacy_custom_name(row)
            if (incoming_name and incoming_name != old_name and incoming_name != charging_location_display_name(row)
                    and custom_name == prior_custom
                    and not re.fullmatch(r"Ladeort\s+\d+", incoming_name, flags=re.IGNORECASE)):
                custom_name = incoming_name
        elif "name" in payload:
            incoming_name = _safe_name(payload.get("name"))
            # Compatibility with old clients: an unchanged display/fallback
            # does not silently turn an auto label into a custom name.
            custom_name = _legacy_custom_name(row)
            if (incoming_name and incoming_name != old_name and incoming_name != charging_location_display_name(row)
                    and not re.fullmatch(r"Ladeort\s+\d+", incoming_name, flags=re.IGNORECASE)):
                custom_name = incoming_name
        else:
            custom_name = _legacy_custom_name(row)
        row.update({"id": ident, "name": custom_name or fallback_name, "custom_name": custom_name,
                    "latitude": lat, "longitude": lon, "updated_at": _now()})
        if "note" in payload:
            row["note"] = _safe_name(payload.get("note"))
        if "auto_location_label" in payload and custom_name is None:
            row["auto_location_label"] = _safe_name(payload.get("auto_location_label")) or None
        if any(key in payload for key in ("time_limit_enabled", "time_limit_minutes", "time_reminder_minutes")):
            prior = row.get("time_limit") if isinstance(row.get("time_limit"), dict) else {}
            try:
                enabled = bool(payload.get("time_limit_enabled", prior.get("enabled", False)))
                limit = int(payload.get("time_limit_minutes", prior.get("limit_minutes", 240)))
                reminder = int(payload.get("time_reminder_minutes", prior.get("reminder_minutes", 30)))
                notify_at_limit = bool(payload.get("time_limit_notify_at_limit", prior.get("notify_at_limit", True)))
            except (TypeError, ValueError) as exc:
                raise ValueError("Ungültiges Zeitlimit.") from exc
            if limit < 60 or limit > 2880 or reminder < 0 or reminder >= limit:
                raise ValueError("Zeitlimit oder Erinnerungszeit liegt außerhalb des gültigen Bereichs.")
            row["time_limit"] = {"enabled": enabled, "limit_minutes": limit, "reminder_minutes": reminder, "notify_at_limit": notify_at_limit}
        _atomic_json(store, rows)
        return row


def _place_clean(value: Any, limit: int = 90) -> str:
    value = " ".join(str(value or "").split())
    value = "".join(ch for ch in value if ord(ch) >= 32 and ord(ch) != 127)
    return value[:limit].strip()


def _haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6_371_000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1 - a)))


_LANDMARK_ALLOWLIST = {
    ("tourism", "attraction"), ("historic", "monument"), ("historic", "castle"),
    ("historic", "archaeological_site"), ("natural", "cave"), ("natural", "peak"),
    ("leisure", "nature_reserve"), ("leisure", "park"), ("waterway", "waterfall"),
}


def human_location_label(properties: dict[str, Any] | None, *, distance_m: float | None = None) -> dict[str, Any] | None:
    """Select a concise, deterministic place label from validated OSM properties."""
    if not isinstance(properties, dict):
        return None
    city = next((_place_clean(properties.get(key)) for key in ("city", "town", "village", "locality") if _place_clean(properties.get(key))), None)
    suburb = next((_place_clean(properties.get(key)) for key in ("suburb", "district") if _place_clean(properties.get(key))), None)
    municipality = next((_place_clean(properties.get(key)) for key in ("municipality", "county", "state") if _place_clean(properties.get(key))), None)
    # Reverse services may return a nearby-in-ranking but geographically distant
    # settlement centroid. Do not confidently name a vehicle location from it.
    if distance_m is not None and distance_m > 10_000:
        return None
    key = _place_clean(properties.get("osm_key"), 40).lower()
    value = _place_clean(properties.get("osm_value"), 40).lower()
    feature_type = f"{key}:{value}" if key and value else ""
    name = _place_clean(properties.get("name"))
    meaningful = (key, value) in _LANDMARK_ALLOWLIST and name and distance_m is not None and distance_m <= 120
    if meaningful:
        local = suburb or city or municipality
        label = f"{name} · {local}" if local and local.casefold() != name.casefold() else name
        return {"label": label, "compact_label": name, "locality": city, "suburb": suburb,
                "municipality": municipality, "road": _place_clean(properties.get("street")),
                "country_code": _place_clean(properties.get("countrycode"), 2).lower() or None,
                "named_feature": name, "feature_type": feature_type, "quality": "landmark"}
    if suburb and city and suburb.casefold() != city.casefold():
        label = f"{suburb} · {city}"
    else:
        label = city or suburb
    if not label:
        road = _place_clean(properties.get("street"))
        label = f"{road} · {municipality}" if road and municipality else None
    if not label:
        label = municipality
    if not label:
        return None
    return {"label": label, "compact_label": city or suburb or municipality or label,
            "locality": city, "suburb": suburb, "municipality": municipality,
            "road": _place_clean(properties.get("street")),
            "country_code": _place_clean(properties.get("countrycode"), 2).lower() or None,
                "named_feature": None, "feature_type": feature_type or None, "quality": "settlement"}


class ReverseGeocoderProvider:
    """Provider contract kept separate from location-label selection/persistence."""
    def resolve(self, latitude: float, longitude: float, *, language: str = "de") -> dict[str, Any] | None:
        raise NotImplementedError


class PhotonReverseGeocoder(ReverseGeocoderProvider):
    """Photon-compatible adapter; all network use is opt-in/lazy."""
    def __init__(self, endpoint: str | None = None, opener: Any = None):
        self.endpoint = endpoint or os.environ.get("ZERO_CONNECT_GEOCODER_URL", "https://photon.komoot.io/reverse")
        self.opener = opener or urllib.request.urlopen

    def resolve(self, latitude: float, longitude: float, *, language: str = "de") -> dict[str, Any] | None:
        if not (-90 <= latitude <= 90 and -180 <= longitude <= 180) or (latitude == 0 and longitude == 0):
            return None
        parsed = urllib.parse.urlsplit(self.endpoint)
        if parsed.scheme not in {"https", "http"} or not parsed.netloc or parsed.username or parsed.password:
            return None
        if parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
            return None
        query = urllib.parse.urlencode({"lat": f"{latitude:.6f}", "lon": f"{longitude:.6f}", "lang": "en" if language == "en" else "de", "limit": "5"})
        url = self.endpoint + ("&" if "?" in self.endpoint else "?") + query
        request = urllib.request.Request(url, headers={"Accept": "application/geo+json, application/json", "User-Agent": "ZeroConnect/0.9 (personal dashboard; unofficial)"})
        try:
            with self.opener(request, timeout=4) as response:
                if getattr(response, "status", 200) != 200:
                    return None
                raw = response.read(512_001)
            if len(raw) > 512_000:
                return None
            body = json.loads(raw)
        except (OSError, TimeoutError, ValueError, TypeError, urllib.error.URLError,
                http.client.HTTPException):
            return None
        features = body.get("features") if isinstance(body, dict) else None
        if not isinstance(features, list):
            return None
        candidates = []
        for feature in features[:5]:
            if not isinstance(feature, dict):
                continue
            props = feature.get("properties")
            geometry = feature.get("geometry")
            coords = geometry.get("coordinates") if isinstance(geometry, dict) else None
            if not isinstance(props, dict) or not isinstance(coords, list) or len(coords) < 2:
                continue
            try:
                lon, lat = float(coords[0]), float(coords[1])
                if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                    continue
                distance = _haversine_m(latitude, longitude, lat, lon)
            except (TypeError, ValueError):
                continue
            label = human_location_label(props, distance_m=distance)
            if label:
                candidates.append((0 if label["quality"] == "landmark" else 1, distance, label))
        return min(candidates, key=lambda item: (item[0], item[1]))[2] if candidates else None


class DisabledReverseGeocoder(ReverseGeocoderProvider):
    def resolve(self, latitude: float, longitude: float, *, language: str = "de") -> dict[str, Any] | None:
        return None


def reverse_geocoder_provider() -> ReverseGeocoderProvider:
    """Resolve the configured adapter at use time so operators can switch endpoints."""
    provider = os.environ.get("ZERO_CONNECT_GEOCODER_PROVIDER", "photon").strip().lower()
    if provider == "photon":
        return PhotonReverseGeocoder()
    # Unknown/disabled providers fail closed; labels and maps still work.
    return DisabledReverseGeocoder()


_PLACE_CACHE_LIMIT = 1000
_PLACE_CACHE_TTL = 30 * 86400
_PLACE_CACHE = _path("place-label-cache.json")
_GEOCODE_QUEUE: queue.Queue[tuple[str, float, float, str, str | None]] | None = None
_GEOCODE_GUARD = threading.Lock()
_GEOCODE_PENDING: set[str] = set()
_GEOCODE_PENDING_LOCATIONS: dict[str, set[str]] = {}


def _place_key(latitude: float, longitude: float, language: str = "de") -> str:
    # 0.001 degree cells (~100 m) suppress small GPS jitter without conflating
    # different city/neighbourhood labels in broad cells.
    locale = "en" if str(language).lower().startswith("en") else "de"
    provider = _geocoder_cache_namespace()
    cell = f"{round(latitude, 3):.3f},{round(longitude, 3):.3f}|{locale}|{provider}"
    return hashlib.sha256(cell.encode("ascii")).hexdigest()


def _geocoder_cache_namespace() -> str:
    provider = os.environ.get("ZERO_CONNECT_GEOCODER_PROVIDER", "photon").strip().lower()
    endpoint = os.environ.get("ZERO_CONNECT_GEOCODER_URL", "https://photon.komoot.io/reverse")
    return hashlib.sha256(f"{provider}|{endpoint}".encode("utf-8")).hexdigest()[:20]


def place_label_for(latitude: float, longitude: float, language: str = "de") -> dict[str, Any] | None:
    key = _place_key(latitude, longitude, language)
    cache = _read(_PLACE_CACHE, {})
    row = cache.get(key) if isinstance(cache, dict) else None
    if not isinstance(row, dict) or not isinstance(row.get("resolved_epoch"), (int, float)):
        return None
    if time.time() - float(row["resolved_epoch"]) > _PLACE_CACHE_TTL:
        return None
    return row.get("place") if isinstance(row.get("place"), dict) else None


def _store_place_label(key: str, latitude: float, longitude: float, place: dict[str, Any] | None) -> None:
    store = _PLACE_CACHE
    with _store_lock(store):
        cache = _read(store, {})
        if not isinstance(cache, dict):
            cache = {}
        cache[key] = {"cell_lat": round(latitude, 3), "cell_lon": round(longitude, 3),
                      "resolved_epoch": time.time(), "retry_after_epoch": time.time() + (30 * 86400 if place else 900),
                      "provider": "photon-compatible", "place": place}
        entries = [(key, row) for key, row in cache.items() if isinstance(row, dict) and isinstance(row.get("resolved_epoch"), (int, float))]
        if len(entries) > _PLACE_CACHE_LIMIT:
            keep = dict(sorted(entries, key=lambda item: float(item[1].get("resolved_epoch", 0)))[-_PLACE_CACHE_LIMIT:])
            keep.update({key: value for key, value in cache.items() if key.startswith("_")})
            cache = keep
        _atomic_json(store, cache)


def _apply_location_auto_label(location_id: str, place: dict[str, Any] | None, language: str = "de") -> None:
    if not location_id or not isinstance(place, dict) or not place.get("label"):
        return
    store = _path("locations.json")
    with _store_lock(store):
        rows = locations()
        row = next((item for item in rows if str(item.get("id")) == location_id), None)
        if row is None:
            return
        sanitized = {key: _safe_name(value, 120) if isinstance(value, str) else value
                     for key, value in place.items() if key in {"label", "compact_label", "locality", "suburb", "municipality", "road", "country_code", "named_feature", "feature_type", "quality"}}
        locale = "en" if str(language).lower().startswith("en") else "de"
        label_map = row.get("auto_location_labels") if isinstance(row.get("auto_location_labels"), dict) else {}
        place_map = row.get("auto_location_places") if isinstance(row.get("auto_location_places"), dict) else {}
        prior_label = label_map.get(locale) if isinstance(label_map.get(locale), dict) else {}
        if (prior_label.get("label") == _safe_name(place.get("label"))
                and prior_label.get("quality") == sanitized.get("quality")
                and place_map.get(locale) == sanitized
                and not location_auto_label_expired(row, locale)):
            return
        label_map[locale] = {"label": _safe_name(place.get("label")), "quality": sanitized.get("quality"), "resolved_epoch": time.time()}
        place_map[locale] = sanitized
        row["auto_location_labels"] = label_map
        row["auto_location_places"] = place_map
        row["auto_location_label"] = _safe_name(place.get("label"))
        row["auto_location_place"] = sanitized
        row["auto_location_language"] = locale
        _atomic_json(store, rows)


def _reserve_geocoder_slot() -> None:
    """Persist the next provider slot so a restart cannot reset the request limit."""
    store = _PLACE_CACHE
    with _store_lock(store):
        cache = _read(store, {})
        cache = cache if isinstance(cache, dict) else {}
        now = time.time()
        next_at = float(cache.get("_next_request_epoch", 0) or 0)
        wait = max(0.0, next_at - now)
        cache["_next_request_epoch"] = max(now, next_at) + 1.1
        _atomic_json(store, cache)
    if wait:
        time.sleep(wait)


def _geocode_worker(work: queue.Queue[tuple[str, float, float, str, str | None]]) -> None:
    while True:
        key, latitude, longitude, language, location_id = work.get()
        try:
            cached = place_label_for(latitude, longitude, language)
            if cached is not None:
                place = cached
            else:
                _reserve_geocoder_slot()
                # Endpoint is read for each work item so an operator can switch
                # a Photon-compatible service without changing UI/build code.
                place = reverse_geocoder_provider().resolve(latitude, longitude, language=language)
                _store_place_label(key, latitude, longitude, place)
            with _GEOCODE_GUARD:
                location_ids = _GEOCODE_PENDING_LOCATIONS.pop(key, set())
                _GEOCODE_PENDING.discard(key)
            if location_id:
                location_ids.add(location_id)
            for pending_location_id in location_ids:
                _apply_location_auto_label(pending_location_id, place, language)
        except Exception:
            # Geocoding is an optional enhancement and must never affect Web or Observer health.
            pass
        finally:
            with _GEOCODE_GUARD:
                _GEOCODE_PENDING.discard(key)
                _GEOCODE_PENDING_LOCATIONS.pop(key, None)
            work.task_done()


def request_place_label(latitude: float, longitude: float, *, language: str = "de", location_id: str | None = None) -> dict[str, Any]:
    locale = "en" if str(language).lower().startswith("en") else "de"
    key = _place_key(latitude, longitude, locale)
    cached = place_label_for(latitude, longitude, locale)
    if cached is not None:
        _apply_location_auto_label(location_id or "", cached, locale)
        return {"state": "ready", "place": cached}
    cache = _read(_PLACE_CACHE, {})
    prior = cache.get(key) if isinstance(cache, dict) else None
    if isinstance(prior, dict) and float(prior.get("retry_after_epoch", 0) or 0) > time.time():
        return {"state": "unavailable", "place": None}
    global _GEOCODE_QUEUE
    with _GEOCODE_GUARD:
        if _GEOCODE_QUEUE is None:
            _GEOCODE_QUEUE = queue.Queue(maxsize=32)
            thread = threading.Thread(target=_geocode_worker, args=(_GEOCODE_QUEUE,), name="zero-place-geocoder", daemon=True)
            thread.start()
        if key not in _GEOCODE_PENDING:
            _GEOCODE_PENDING.add(key)
            _GEOCODE_PENDING_LOCATIONS[key] = {location_id} if location_id else set()
            try:
                _GEOCODE_QUEUE.put_nowait((key, latitude, longitude, language, location_id))
            except queue.Full:
                _GEOCODE_PENDING.discard(key)
                _GEOCODE_PENDING_LOCATIONS.pop(key, None)
                return {"state": "unavailable", "place": None}
        elif location_id:
            _GEOCODE_PENDING_LOCATIONS.setdefault(key, set()).add(location_id)
    return {"state": "pending", "place": None}


def delete_location(ident: str) -> None:
    store = _path("locations.json")
    labels_store = _path("deleted-location-labels.json")
    # Keep only the human-readable name needed by existing history. Coordinates,
    # notes and time-limit rules are removed with the location itself.
    with ExitStack() as stack:
        for path in sorted((store, labels_store), key=lambda item: str(item.resolve())):
            stack.enter_context(_store_lock(path))
        rows = locations()
        removed = next((row for row in rows if str(row.get("id")) == str(ident)), None)
        if removed is not None:
            custom = _legacy_custom_name(removed)
            labels = {
                language: location_auto_label(removed, language)
                for language in ("de", "en")
            }
            fallback_name = _place_clean(removed.get("name"))
            if custom or any(labels.values()) or fallback_name:
                history_labels = deleted_location_labels()
                history_labels[str(ident)] = {"custom_name": custom, "labels": labels, "fallback_name": fallback_name}
                _atomic_json(labels_store, history_labels)
        _atomic_json(store, [row for row in rows if str(row.get("id")) != str(ident)])


def cluster_location(latitude: float, longitude: float, radius_m: float = 150.0) -> dict[str, Any] | None:
    """Find an existing charging place without reverse geocoding."""
    for row in locations():
        try:
            dlat = (float(row["latitude"]) - latitude) * 111_000
            dlon = (float(row["longitude"]) - longitude) * 111_000 * math.cos(math.radians(latitude))
            if math.hypot(dlat, dlon) <= radius_m: return row
        except (KeyError, TypeError, ValueError): continue
    return None


def maintenance() -> list[dict[str, Any]]:
    value = _read(_path("maintenance.json"), [])
    return value if isinstance(value, list) else []


def upsert_maintenance(payload: dict[str, Any]) -> dict[str, Any]:
    name = _safe_name(payload.get("name"))
    if not name: raise ValueError("Wartungsname fehlt.")
    try: due = float(payload["due_odometer"]); repeat = float(payload.get("repeat_km", 0) or 0)
    except (KeyError, TypeError, ValueError): raise ValueError("Kilometerstand ist ungültig.")
    if not math.isfinite(due) or not math.isfinite(repeat) or due < 0 or repeat < 0 or due > 10_000_000 or repeat > 10_000_000: raise ValueError("Kilometerstand ist ungültig.")
    store = _path("maintenance.json")
    with _store_lock(store):
        rows = maintenance(); ident = str(payload.get("id") or "")
        row = next((r for r in rows if str(r.get("id")) == ident), None)
        if row is None:
            ident = f"maintenance-{int(time.time() * 1000)}"; row = {"id": ident, "created_at": _now(), "completed": []}; rows.append(row)
        row.update({"id": ident, "name": name, "due_odometer": due, "repeat_km": repeat, "note": _safe_name(payload.get("note")), "updated_at": _now()})
        _atomic_json(store, rows); return row


def complete_maintenance(ident: str, odometer: float | None = None) -> dict[str, Any]:
    store = _path("maintenance.json")
    with _store_lock(store):
        rows = maintenance(); row = next((r for r in rows if str(r.get("id")) == str(ident)), None)
        if row is None: raise ValueError("Wartung nicht gefunden.")
        entry = {"completed_at": _now(), "odometer": odometer}
        row.setdefault("completed", []).append(entry)
        repeat = float(row.get("repeat_km", 0) or 0)
        if repeat > 0 and odometer is not None: row["due_odometer"] = float(odometer) + repeat
        _atomic_json(store, rows); return row


def delete_maintenance(ident: str) -> None:
    store = _path("maintenance.json")
    with _store_lock(store):
        _atomic_json(store, [r for r in maintenance() if str(r.get("id")) != str(ident)])


def maintenance_status(current_odometer: float | None) -> list[dict[str, Any]]:
    result = []
    try:
        current = float(current_odometer) if current_odometer is not None else None
        if current is not None and not math.isfinite(current): current = None
    except (TypeError, ValueError):
        current = None
    for row in maintenance():
        due = _num(row.get("due_odometer"))
        if due is not None and not math.isfinite(due): due = None
        exact_delta = None if due is None or current is None else due - current
        delta = exact_delta
        status = "unknown" if exact_delta is None else "overdue" if exact_delta < 0 else "due" if exact_delta == 0 else "upcoming"
        result.append({**row, "distance_remaining": delta, "status": status})
    return result


def odometer_milestones() -> list[dict[str, Any]]:
    value = _read(_path("odometer-milestones.json"), [])
    return value if isinstance(value, list) else []


def upsert_odometer_milestone(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        target = float(payload["target_odometer"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Kilometer-Meilenstein ist ungültig.") from exc
    if target < 0 or target > 10_000_000:
        raise ValueError("Kilometer-Meilenstein ist ungültig.")
    store = _path("odometer-milestones.json")
    with _store_lock(store):
        rows = odometer_milestones(); ident = str(payload.get("id") or "")
        row = next((item for item in rows if str(item.get("id")) == ident), None)
        if row is None:
            ident = f"odometer-{int(time.time() * 1000)}"
            row = {"id": ident, "created_at": _now(), "notified": False}; rows.append(row)
        row.update({"id": ident, "name": _safe_name(payload.get("name"), f"{target:g} km"), "target_odometer": target, "notify": bool(payload.get("notify", False)), "updated_at": _now()})
        _atomic_json(store, rows[-MAX_MILESTONES:])
        return row


def delete_odometer_milestone(ident: str) -> None:
    store = _path("odometer-milestones.json")
    with _store_lock(store):
        _atomic_json(store, [r for r in odometer_milestones() if str(r.get("id")) != str(ident)])


def check_odometer_milestones(current: float | None) -> list[dict[str, Any]]:
    if current is None:
        return []
    found = []
    store = _path("odometer-milestones.json")
    event_store = _path("events.json")
    # Keep the global multi-store lock order (events before odometer), also
    # used by restore_backup. Never call record_event while holding the second
    # lock: its separate flock descriptor would not be reentrant.
    with ExitStack() as stack:
        stack.enter_context(_store_lock(event_store))
        stack.enter_context(_store_lock(store))
        rows = odometer_milestones()
        events = notification_events(MAX_EVENTS)
        changed = False
        events_changed = False
        for row in rows:
            target = _num(row.get("target_odometer"))
            if target is None or current < target:
                continue
            event_key = f"odometer-milestone:{row.get('id')}:{target:g}"
            event = next((item for item in events if item.get("dedup_key") == event_key), None)
            if not row.get("notified"):
                if event is None:
                    event = {"kind": "odometer_milestone", "payload": {"id": row.get("id"), "name": row.get("name"), "odometer": current}, "dedup_key": event_key, "timestamp": _now()}
                    events.append(event)
                    events_changed = True
                row["notified"] = True; changed = True
            # The durable detection event is written before Push is attempted.
            # Return an opted-in milestone again during the bounded delivery
            # window so a crash between those steps can be reconciled on restart.
            if event is not None and bool(row.get("notify")):
                route_key = f"odometer_milestone:odometer-{row.get('id')}:{target:g}"
                suppressed = any(
                    item.get("kind") == "notification_suppressed"
                    and item.get("dedup_key") == f"notification-suppressed:{route_key}"
                    for item in events
                )
                dispatched = any(
                    item.get("kind") == "push_dispatch"
                    and isinstance(item.get("payload"), dict)
                    and item["payload"].get("event_key") == route_key
                    and item["payload"].get("provider_result") == "accepted"
                    for item in events
                )
                try:
                    event_epoch = datetime.fromisoformat(str(event.get("timestamp", "")).replace("Z", "+00:00")).timestamp()
                    recent = 0 <= time.time() - event_epoch <= 300
                except (TypeError, ValueError, OverflowError):
                    recent = False
                if recent and not suppressed and not dispatched:
                    found.append(row)
        if changed:
            _atomic_json(store, rows)
        if events_changed:
            _atomic_json(event_store, events[-MAX_EVENTS:])
    return found


def notification_events(limit: int = MAX_EVENTS) -> list[dict[str, Any]]:
    value = _read(_path("events.json"), [])
    return value[-max(1, min(limit, MAX_EVENTS)):] if isinstance(value, list) else []


def record_event(kind: str, payload: dict[str, Any] | None = None, dedup_key: str | None = None) -> bool:
    kind = _safe_name(kind)
    store = _path("events.json")
    with _store_lock(store):
        rows = notification_events(MAX_EVENTS)
        if dedup_key and any(r.get("dedup_key") == dedup_key for r in rows): return False
        rows.append({"kind": kind, "payload": payload or {}, "dedup_key": dedup_key, "timestamp": _now()})
        _atomic_json(store, rows[-MAX_EVENTS:]); return True


def subscriptions() -> list[dict[str, Any]]:
    value = _read(_path("subscriptions.json"), [])
    return value if isinstance(value, list) else []


def vapid_public_key() -> str | None:
    """Return a browser-safe VAPID public key, creating it on first use."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat, NoEncryption, PrivateFormat
        from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
        import base64
        key_path = _path("vapid-private.pem")
        if key_path.exists():
            from cryptography.hazmat.primitives.serialization import load_pem_private_key
            key = load_pem_private_key(key_path.read_bytes(), password=None)
        else:
            key = ec.generate_private_key(ec.SECP256R1())
            key_path.parent.mkdir(parents=True, exist_ok=True); key_path.parent.chmod(0o700)
            fd, temporary = tempfile.mkstemp(prefix=".vapid-private.", dir=key_path.parent)
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())); handle.flush(); os.fsync(handle.fileno())
                os.chmod(temporary, 0o600)
                os.replace(temporary, key_path)  # a cut-short key file would disable push for good
            finally:
                if os.path.exists(temporary): os.unlink(temporary)
        raw = key.public_key().public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    except Exception:
        return None


def push_status(endpoint: str | None = None) -> dict[str, Any]:
    public_key = vapid_public_key()
    registered = None
    endpoint_hash = None
    if endpoint:
        endpoint_hash = hashlib.sha256(endpoint.encode("utf-8")).hexdigest()[:12]
        registered = any(str(row.get("endpoint")) == endpoint for row in subscriptions())
    return {"supported": True, "vapid_configured": public_key is not None, "public_key": public_key, "subscriptions": len(subscriptions()), "device_count": len(subscriptions()), "registered": registered, "endpoint_hash": endpoint_hash, "sender": "pywebpush" if _pywebpush_available() else "not-installed"}


def _pywebpush_available() -> bool:
    try:
        import pywebpush  # type: ignore
        return True
    except ImportError:
        return False


def send_push(
    title: str,
    body: str,
    url: str = "/",
    *,
    localized_bodies: dict[str, str] | None = None,
    outcome_event: str = "push_test_result",
    skip_endpoint_hashes: set[str] | None = None,
    delivery_key: str | None = None,
    delivery_event: str | None = None,
) -> dict[str, Any]:
    """Send a notification when the optional sender is installed.

    Missing sender credentials/dependency is reported as an operational state;
    it never stops the Observer or changes vehicle data.
    """
    try:
        from pywebpush import webpush  # type: ignore
        from cryptography.hazmat.primitives.serialization import load_pem_private_key, Encoding, PrivateFormat, NoEncryption
        import base64
        key_path = _path("vapid-private.pem")
        if not key_path.exists(): vapid_public_key()
        key = load_pem_private_key(key_path.read_bytes(), password=None)
        raw = key.private_numbers().private_value.to_bytes(32, "big")
        private = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
        sent = 0; failed = 0; skipped = 0; outcomes = []
        selected_subscriptions = subscriptions()
        for sub in selected_subscriptions:
            endpoint = str(sub.get("endpoint") or "")
            endpoint_hash = hashlib.sha256(endpoint.encode("utf-8")).hexdigest()[:12]
            if endpoint_hash in (skip_endpoint_hashes or set()):
                skipped += 1
                continue
            provider = urlparse(endpoint).hostname or "unknown"
            language = str(sub.get("language", "de")).lower()
            localized_body = (localized_bodies or {}).get(language, body)
            try:
                webpush(sub, json.dumps({"title": title, "body": localized_body, "url": url}), vapid_private_key=private, vapid_claims={"sub": zero_remote.push_subject()}, ttl=60)
                sent += 1
                outcomes.append({"endpoint_hash": endpoint_hash, "provider": provider, "result": "accepted"})
            except Exception as exc:
                failed += 1
                response = getattr(exc, "response", None)
                status = getattr(response, "status_code", None)
                category = "expired" if status in (404, 410) else "provider_rejected" if status in (400, 401, 403) else "temporary_failure" if status in (408, 429) or status is None else "provider_failure"
                if category == "expired":
                    try:
                        _remove_expired_subscription(sub)
                    except OSError:
                        # Subscription cleanup is best-effort; retain delivery
                        # diagnostics and keep the Observer loop running.
                        pass
                outcomes.append({"endpoint_hash": endpoint_hash, "provider": provider, "result": category, "status": status})
        provider_result = "accepted" if not failed and (sent > 0 or skipped > 0) else "failed"
        result = {"sent": sent, "failed": failed, "skipped": skipped, "configured": True, "provider_result": provider_result, "outcomes": outcomes, "timestamp": _now()}
        event_kind = outcome_event if outcome_event in {"push_test_result", "push_delivery_result"} else "push_delivery_result"
        prefix = "push-test" if event_kind == "push_test_result" else "push-delivery"
        record_event(event_kind, {
            "selected": len(selected_subscriptions), "provider": sorted({o["provider"] for o in outcomes}),
            "result": result["provider_result"], "outcomes": outcomes, "skipped": skipped,
            "event_key": delivery_key, "event": delivery_event,
        }, f"{prefix}:{result['timestamp']}")
        return result
    except ImportError:
        return {"sent": 0, "failed": 0, "configured": False, "reason": "pywebpush nicht installiert"}


def save_subscription(payload: dict[str, Any]) -> dict[str, Any]:
    endpoint = str(payload.get("endpoint") or "").strip()
    if any(ord(ch) < 33 for ch in endpoint): raise ValueError("Ungültiger Push-Endpunkt.")
    keys = payload.get("keys", {})
    if not endpoint or len(endpoint) > 2048 or not endpoint.startswith("https://") or not isinstance(keys, dict): raise ValueError("Ungültige Push-Subscription.")
    language = str(payload.get("language", "de")).lower()
    if language not in {"de", "en"}: language = "de"
    store = _path("subscriptions.json")
    with _store_lock(store):
        rows = [r for r in subscriptions() if r.get("endpoint") != endpoint]
        rows.append({"endpoint": endpoint, "keys": {k: _safe_name(v) for k, v in keys.items() if k in ("p256dh", "auth")}, "language": language, "updated_at": _now()})
        _atomic_json(store, rows[-MAX_SUBSCRIPTIONS:]); return {"registered": True, "subscribed": True, "device_count": len(rows[-MAX_SUBSCRIPTIONS:])}


def remove_subscription(endpoint: str) -> None:
    store = _path("subscriptions.json")
    with _store_lock(store):
        _atomic_json(store, [r for r in subscriptions() if r.get("endpoint") != endpoint])


def _remove_expired_subscription(snapshot: dict[str, Any]) -> None:
    """Remove an expired device only if its stored subscription is unchanged."""
    endpoint = str(snapshot.get("endpoint") or "")
    if not endpoint:
        return
    store = _path("subscriptions.json")
    with _store_lock(store):
        rows = subscriptions()
        retained = [row for row in rows if not (
            isinstance(row, dict) and row.get("endpoint") == endpoint and row == snapshot
        )]
        if len(retained) != len(rows):
            _atomic_json(store, retained)


def _num(value: Any) -> float | None:
    try: return float(value) if value is not None else None
    except (TypeError, ValueError): return None


def valid_sessions(rows: Iterable[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[str]]:
    valid: list[dict[str, Any]] = []; issues: list[str] = []
    for row in rows:
        start, end = _num(row.get("start_soc")), _num(row.get("end_soc"))
        duration = _num(row.get("duration_seconds"))
        if start is not None and not 0 <= start <= 100: issues.append(f"{row.get('generation')}: start_soc")
        if end is not None and not 0 <= end <= 100: issues.append(f"{row.get('generation')}: end_soc")
        if duration is not None and duration < 0: issues.append(f"{row.get('generation')}: duration")
        if start is not None and end is not None and end < start: issues.append(f"{row.get('generation')}: SOC rückläufig")
        target = _num(row.get("target_soc"))
        if target is not None and not 0 <= target <= 100: issues.append(f"{row.get('generation')}: target")
        valid.append(row)
    return valid, issues


def filter_sessions(rows: list[dict[str, Any]], query: dict[str, Any]) -> list[dict[str, Any]]:
    def first(key: str) -> Any:
        value = query.get(key)
        return value[0] if isinstance(value, list) and value else value
    text = str(first("q") or "").strip().lower(); reason = str(first("completion_reason") or "").strip().lower(); location = str(first("location") or "").strip().lower()
    result = []
    for row in rows:
        blob = json.dumps(row, ensure_ascii=False).lower()
        if text and text not in blob: continue
        if reason and reason not in str(row.get("terminal_event", "")).lower() and reason not in str(row.get("completion_source", "")).lower(): continue
        if location and location not in str(row.get("location_name", "")).lower(): continue
        target = _num(first("target")); row_target = _num(row.get("target_soc"))
        if target is not None and row_target != target: continue
        result.append(row)
    return result


_CSV_COLUMNS = {
    "de": ("Datum", "Beginn", "Ende", "Dauer", "Start %", "Ende %", "Geladen %", "Ladeziel %", "Balancing Min.", "Abschluss", "Ladeort"),
    "en": ("Date", "Start", "End", "Duration", "Start %", "End %", "Charged %", "Target %", "Balancing min", "Result", "Place"),
}


def export_csv(rows: list[dict[str, Any]], language: str = "de") -> bytes:
    """Charging history as a spreadsheet-ready table: local times, readable columns, no coordinates.

    German uses ';' and a decimal comma so Excel and Numbers open it directly.
    """
    locale = "en" if str(language).lower().startswith("en") else "de"

    def local(value: Any) -> datetime | None:
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone() if value else None
        except (TypeError, ValueError, OverflowError):
            return None

    def number(value: Any) -> str:
        value = _num(value)
        if value is None:
            return ""
        text = f"{value:.0f}" if abs(value - round(value)) < 0.05 else f"{value:.1f}"
        return text.replace(".", ",") if locale == "de" else text

    def clock(seconds: Any) -> str:
        seconds = _num(seconds)
        if seconds is None:
            return ""
        minutes = int(round(seconds / 60))
        return f"{minutes // 60}:{minutes % 60:02d}"

    out = io.StringIO(newline="")
    writer = csv.writer(out, delimiter=";" if locale == "de" else ",")
    writer.writerow(_CSV_COLUMNS[locale])
    for row in rows:
        started = local(row.get("started_at_utc") or row.get("start_time"))
        ended = local(row.get("ended_at_utc") or row.get("end_time"))
        balancing = _num(row.get("balancing_duration_seconds"))
        values = [
            started.strftime("%d.%m.%Y" if locale == "de" else "%Y-%m-%d") if started else "",
            started.strftime("%H:%M") if started else "",
            ended.strftime("%H:%M") if ended else "",
            clock(row.get("session_duration_seconds", row.get("duration_seconds"))),
            number(row.get("start_soc")), number(row.get("end_soc")), number(row.get("delta_soc")),
            number(row.get("target_soc")), number(balancing / 60) if balancing is not None else "",
            str(row.get("terminal_label") or ""),
            str(row.get("location_display_name") or row.get("location_name") or ""),
        ]
        # A cell starting with a formula character must stay text in spreadsheets.
        writer.writerow(["'" + v if v[:1] in ("=", "+", "-", "@") else v for v in values])
    return out.getvalue().encode("utf-8-sig")


def analytics_export(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return {"format": "zero-connect-analytics", "schema_version": SCHEMA_VERSION, "created_at": _now(), "sessions": rows}


def backup(rows: list[dict[str, Any]], app_version: str, *, raw_history: list[dict[str, Any]] | None = None) -> bytes:
    samples: list[dict[str, Any]] = []
    sample_dir = DATA / "charging-samples"
    for path in sorted(sample_dir.glob("samples-*.jsonl")):
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                value = json.loads(line)
                if isinstance(value, dict): samples.append(value)
        except (OSError, ValueError): continue
    payload = {"format": "zero-connect-user-backup", "schema_version": SCHEMA_VERSION, "created_at": _now(), "app_version": app_version, "history": rows if raw_history is None else raw_history, "samples": samples, "session_removals": list(session_removals().values()), "locations": locations(), "deleted_location_labels": deleted_location_labels(), "maintenance": maintenance(), "odometer_milestones": odometer_milestones(), "preferences": preferences(), "events": notification_events()}
    raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive: archive.writestr("zero-connect-backup.json", raw)
    return out.getvalue()


def validate_backup(raw: bytes) -> dict[str, Any]:
    if len(raw) > 10 * 1024 * 1024: raise ValueError("Backup ist zu groß.")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            names = archive.namelist()
            if names != ["zero-connect-backup.json"]: raise ValueError("Ungültiger Backup-Inhalt.")
            value = json.loads(archive.read(names[0]))
    except (OSError, ValueError, zipfile.BadZipFile, json.JSONDecodeError) as exc: raise ValueError("Backup ist ungültig.") from exc
    if (not isinstance(value, dict) or value.get("format") != "zero-connect-user-backup"
            or type(value.get("schema_version")) is not int
            or value["schema_version"] != SCHEMA_VERSION):
        raise ValueError("Backup-Schema wird nicht unterstützt.")
    for key in ("history", "samples", "locations", "maintenance", "preferences", "events"):
        if key not in value: raise ValueError(f"Backup-Feld fehlt: {key}")
    record_lists = ("history", "samples", "locations", "maintenance", "events", "odometer_milestones")
    for key in record_lists:
        if key in value and (
            not isinstance(value[key], list)
            or any(not isinstance(row, dict) for row in value[key])
        ):
            raise ValueError(f"Backup-Feld ist ungültig: {key}")
    if "session_removals" in value and (
        not isinstance(value["session_removals"], list)
        or any(not isinstance(row, dict) or type(row.get("generation")) is not int or row["generation"] <= 0 for row in value["session_removals"])
    ):
        raise ValueError("Backup-Feld ist ungültig: session_removals")
    for key in ("preferences", "deleted_location_labels"):
        if key in value and not isinstance(value[key], dict):
            raise ValueError(f"Backup-Feld ist ungültig: {key}")
    if "preferences" in value:
        try:
            value["preferences"] = _normalize_preferences(value["preferences"])
        except ValueError as exc:
            raise ValueError("Backup-Feld ist ungültig: preferences") from exc
    return value


def compare_sessions(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    keys = ("start_soc", "end_soc", "target_soc", "duration_seconds", "average_soc_points_per_hour", "distance_since_previous_charge")
    return {key: {"left": left.get(key), "right": right.get(key)} for key in keys}


def restore_backup(
    raw: bytes, *, protected_session_generations: set[int] | None = None
) -> dict[str, Any]:
    value = validate_backup(raw)
    protected_generations = {
        int(generation) for generation in (protected_session_generations or set())
        if int(generation) > 0
    }
    incoming_removals = {int(row["generation"]) for row in value.get("session_removals", [])}
    if protected_generations & incoming_removals:
        raise ValueError("Backup enthält einen Entfernungsstatus für eine aktuell aktive Ladesitzung.")
    _recover_restore_transaction()
    # A restore replaces the same stores used by Observer and Web mutations.
    # Hold their locks together, in a stable order, so concurrent read-modify-
    # write operations cannot be silently overwritten by a restore snapshot.
    stores = [_path(name) for name in ("events.json", "locations.json", "deleted-location-labels.json", "maintenance.json", "odometer-milestones.json", "preferences.json", "session-removals.json")]
    staged: list[tuple[Path, Path]] = []
    # Hold the shared barrier before taking any store locks and retain it
    # until every replacement is durable, so readers cannot see mixed state.
    with _restore_barrier(), ExitStack() as stack:
        # Recheck after acquiring the transaction barrier and before resolving
        # feature-store locks or writing the pre-restore backup and staged data.
        _validate_restore_roots()
        for store in sorted(stores, key=lambda path: str(path.resolve())):
            stack.enter_context(_store_lock(store))
        # Removal is monotonic across restore: an older v1 backup without
        # tombstones must never reactivate a session already hidden locally.
        removal_store = _path("session-removals.json")
        existing_removals = _read_unlocked(removal_store, {})
        merged_removals = dict(existing_removals) if isinstance(existing_removals, dict) else {}
        if protected_generations & {int(key) for key in merged_removals if str(key).isdigit()}:
            raise ValueError("Eine aktuell aktive Ladesitzung ist als entfernt markiert; Wiederherstellung wurde angehalten.")
        for item in value.get("session_removals", []):
            generation = int(item["generation"])
            merged_removals[str(generation)] = {"generation": generation, "removed_at": str(item.get("removed_at") or "")}
        # Keep a recoverable pre-restore snapshot while the JSON stores are
        # quiescent. Existing session files are never deleted by a restore.
        snapshot = backup([], "pre-restore")
        backup_path = _path("pre-restore-backup.zip")
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        fd, backup_tmp_name = tempfile.mkstemp(prefix=".pre-restore-backup.", dir=backup_path.parent)
        with os.fdopen(fd, "wb") as handle:
            handle.write(snapshot); handle.flush(); os.fsync(handle.fileno())
        os.chmod(backup_tmp_name, 0o600); os.replace(backup_tmp_name, backup_path)
        dir_fd = os.open(backup_path.parent, os.O_RDONLY)
        try: os.fsync(dir_fd)
        finally: os.close(dir_fd)
        stamp = time.time_ns()
        transaction = DATA / ".functional-restore-transaction"
        try:
            for key in ("locations", "maintenance", "preferences", "events"):
                target = _path(f"{key}.json"); tmp = target.with_name(f".{target.name}.restore-{stamp}")
                tmp.parent.mkdir(parents=True, exist_ok=True)
                with tmp.open("w", encoding="utf-8") as handle:
                    handle.write(json.dumps(value[key], ensure_ascii=False, indent=2) + "\n"); handle.flush(); os.fsync(handle.fileno())
                os.chmod(tmp, 0o600); staged.append((tmp, target))
            if "deleted_location_labels" in value:
                target = _path("deleted-location-labels.json")
                tmp = target.with_name(f".{target.name}.restore-{stamp}")
                tmp.parent.mkdir(parents=True, exist_ok=True)
                with tmp.open("w", encoding="utf-8") as handle:
                    handle.write(json.dumps(value["deleted_location_labels"], ensure_ascii=False, indent=2) + "\n"); handle.flush(); os.fsync(handle.fileno())
                os.chmod(tmp, 0o600); staged.append((tmp, target))
            if "odometer_milestones" in value:
                target = _path("odometer-milestones.json"); tmp = target.with_name(f".{target.name}.restore-{stamp}")
                tmp.parent.mkdir(parents=True, exist_ok=True)
                with tmp.open("w", encoding="utf-8") as handle:
                    handle.write(json.dumps(value["odometer_milestones"], ensure_ascii=False, indent=2) + "\n"); handle.flush(); os.fsync(handle.fileno())
                os.chmod(tmp, 0o600); staged.append((tmp, target))
            target = removal_store
            tmp = target.with_name(f".{target.name}.restore-{stamp}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with tmp.open("w", encoding="utf-8") as handle:
                handle.write(json.dumps(merged_removals, ensure_ascii=False, indent=2) + "\n"); handle.flush(); os.fsync(handle.fileno())
            os.chmod(tmp, 0o600); staged.append((tmp, target))
            session_path = DATA / "sessions" / f"session-restored-{stamp}.jsonl"
            sample_path = DATA / "charging-samples" / f"samples-restored-{stamp}.jsonl"
            # Rows that are already on this device are not written a second time: restoring a backup into its own
            # source used to double the sample files with every round trip (to 198 MB after twelve).
            new_history = _rows_not_yet_present(value["history"], DATA / "sessions", "*.jsonl")
            new_samples = _rows_not_yet_present(value["samples"], DATA / "charging-samples", "*.jsonl")
            for target, rows in ((session_path, new_history), (sample_path, new_samples)):
                tmp = target.with_name(f".{target.name}.restore"); tmp.parent.mkdir(parents=True, exist_ok=True)
                with tmp.open("w", encoding="utf-8") as handle:
                    handle.write("\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + ("\n" if rows else "")); handle.flush(); os.fsync(handle.fileno())
                os.chmod(tmp, 0o600); staged.append((tmp, target))
            # Retain a complete immutable copy of every intended destination
            # before publishing a journal. Recovery always rolls forward from
            # these copies, including the additive history/sample files.
            transaction.mkdir(mode=0o700)
            entries = []
            for index, (tmp, target) in enumerate(staged):
                payload = transaction / f"{index}.jsonl" if target.suffix == ".jsonl" else transaction / f"{index}.json"
                with tmp.open("rb") as source, payload.open("wb") as output:
                    shutil.copyfileobj(source, output); output.flush(); os.fsync(output.fileno())
                os.chmod(payload, 0o600)
                root = FEATURES if target.resolve().is_relative_to(FEATURES.resolve()) else DATA
                digest = hashlib.sha256()
                size = 0
                with payload.open("rb") as handle:
                    for chunk in iter(lambda: handle.read(64 * 1024), b""):
                        digest.update(chunk)
                        size += len(chunk)
                entries.append({"root": "features" if root == FEATURES else "data", "target": str(target.relative_to(root)), "payload": payload.name, "sha256": digest.hexdigest(), "size": size})
            _atomic_json(transaction / "manifest.json", {"version": 2, "entries": entries})
            _fsync_directory(transaction)
            _fsync_directory(transaction.parent)
            _install_restore_transaction(transaction, entries, manifest_version=2)
            _commit_restore_transaction(transaction, entries)
            _atomic_json(_path("last-restore.json"), {"created_at": _now(), "sessions": len(value["history"]), "samples": len(value["samples"]), "pre_restore": str(_path("pre-restore-backup.zip"))})
        finally:
            for tmp, _ in staged:
                try: tmp.unlink()
                except FileNotFoundError: pass
    return {"restored": True, "sessions": len(value["history"]), "samples": len(value["samples"]), "pre_restore_backup": True}


def _canonical_row(row: Any) -> str:
    return json.dumps(row, sort_keys=True, ensure_ascii=False)


def _rows_not_yet_present(rows: list[Any], folder: Path, pattern: str) -> list[Any]:
    """The incoming rows without those that an existing file in `folder` already holds, line for line."""
    if not rows or not folder.is_dir():
        return rows
    wanted = {_canonical_row(row) for row in rows}
    present: set[str] = set()
    for path in sorted(folder.glob(pattern)):
        try:
            with path.open(encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    try:
                        canonical = _canonical_row(json.loads(line))
                    except ValueError:
                        continue
                    if canonical in wanted:
                        present.add(canonical)
        except OSError:
            continue
    return [row for row in rows if _canonical_row(row) not in present]


def _fsync_directory(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)


def _install_restore_transaction(transaction: Path, entries: list[dict[str, Any]], *, manifest_version: int) -> None:
    _validate_restore_roots()
    _validate_restore_entries(transaction, entries, manifest_version=manifest_version)
    # Session and sample files are additive. A target may already exist only
    # when a prior attempt from this same transaction installed identical data.
    # Check every additive destination before replacing any store.
    data_entries = [entry for entry in entries if entry["root"] == "data"]
    for entry in data_entries:
        target = DATA / entry["target"]
        payload = transaction / entry["payload"]
        if target.parent.is_symlink() or not target.parent.resolve().is_relative_to(DATA.resolve()):
            raise RuntimeError("Restore-Zielpfad ist ungültig; Recovery wurde angehalten.")
        if target.is_symlink() or (target.exists() and (not target.is_file() or not _same_file_contents(target, payload))):
            raise RuntimeError("Restore-Zieldatei existiert bereits mit anderem Inhalt; Recovery wurde angehalten.")
    for entry in entries:
        root = FEATURES if entry["root"] == "features" else DATA
        target = root / entry["target"]
        payload = transaction / entry["payload"]
        if entry["root"] == "data" and target.exists():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.recover-", dir=target.parent)
        try:
            with os.fdopen(fd, "wb") as output, payload.open("rb") as source:
                shutil.copyfileobj(source, output); output.flush(); os.fsync(output.fileno())
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, target)
            _fsync_directory(target.parent)
            if _RESTORE_AFTER_REPLACE is not None:
                _RESTORE_AFTER_REPLACE(target)
        finally:
            try: os.unlink(tmp_name)
            except FileNotFoundError: pass


def _same_file_contents(left: Path, right: Path) -> bool:
    if left.stat().st_size != right.stat().st_size:
        return False
    with left.open("rb") as left_handle, right.open("rb") as right_handle:
        while True:
            left_chunk = left_handle.read(64 * 1024)
            right_chunk = right_handle.read(64 * 1024)
            if left_chunk != right_chunk:
                return False
            if not left_chunk:
                return True


def _commit_restore_transaction(transaction: Path, entries: list[dict[str, Any]]) -> None:
    """Persist a verifiable completion receipt before removing the replay journal."""
    _atomic_json(transaction / "committed.json", {"version": 2, "entries": entries})
    (transaction / "manifest.json").unlink()
    _fsync_directory(transaction)
    _finish_committed_restore_transaction(transaction, {"version": 2, "entries": entries})


def _finish_committed_restore_transaction(transaction: Path, receipt: Any) -> None:
    """Clean up only when every committed target still matches its bound payload."""
    invalid = "Ungültiger Restore-Abschlussbeleg; Recovery wurde angehalten und Artefakte erhalten."
    if (not isinstance(receipt, dict) or set(receipt) != {"version", "entries"}
            or type(receipt.get("version")) is not int or receipt["version"] != 2):
        raise RuntimeError(invalid)
    entries = receipt.get("entries")
    _validate_restore_entries(transaction, entries, manifest_version=2, verify_payloads=False)
    _validate_restore_roots()
    expected_artifacts = {"committed.json"} | {entry["payload"] for entry in entries}
    if any(path.name not in expected_artifacts or path.is_symlink() or not path.is_file()
           for path in transaction.iterdir()):
        raise RuntimeError(invalid)
    for entry in entries:
        root = FEATURES if entry["root"] == "features" else DATA
        target = root / entry["target"]
        if (target.parent.is_symlink() or not target.parent.resolve().is_relative_to(root.resolve())
                or target.is_symlink() or not target.is_file()):
            raise RuntimeError(invalid)
        digest = hashlib.sha256()
        size = 0
        with target.open("rb") as handle:
            for chunk in iter(lambda: handle.read(64 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
        if size != entry["size"] or digest.hexdigest() != entry["sha256"]:
            raise RuntimeError(invalid)
    for entry in entries:
        (transaction / entry["payload"]).unlink(missing_ok=True)
    _fsync_directory(transaction)
    (transaction / "committed.json").unlink()
    _fsync_directory(transaction)
    transaction.rmdir()
    _fsync_directory(transaction.parent)


def _validate_restore_roots() -> None:
    """Keep fixed feature-store destinations inside the configured data root."""
    if FEATURES.is_symlink():
        raise RuntimeError("Restore-Zielpfad ist ungültig; Recovery wurde angehalten.")


def _validate_restore_entries(
    transaction: Path, entries: Any, *, manifest_version: int, verify_payloads: bool = True
) -> None:
    """Validate the entire journal before installing any recovery payload."""
    invalid = "Ungültiges Restore-Transaktionsjournal; automatische Recovery wurde angehalten."
    if not isinstance(entries, list) or not 6 <= len(entries) <= 9:
        raise RuntimeError(invalid)
    required_keys = {"root", "target", "payload", "sha256", "size"} if manifest_version == 2 else {"root", "target", "payload"}
    if manifest_version != 2 or any(not isinstance(entry, dict) or set(entry) != required_keys for entry in entries):
        raise RuntimeError(invalid)

    fixed = [
        ("features", "locations.json", "json"),
        ("features", "maintenance.json", "json"),
        ("features", "preferences.json", "json"),
        ("features", "events.json", "json"),
    ]
    optional = [
        ("features", "deleted-location-labels.json", "json"),
        ("features", "odometer-milestones.json", "json"),
        ("features", "session-removals.json", "json"),
    ]
    session_entries = [entry for entry in entries if entry.get("root") == "data" and isinstance(entry.get("target"), str)]
    session_targets = {entry["target"] for entry in session_entries}
    if len(session_entries) != 2:
        raise RuntimeError(invalid)
    session_match = re.fullmatch(r"sessions/session-restored-([0-9]+)\.jsonl", next((x for x in session_targets if x.startswith("sessions/")), ""))
    sample_match = re.fullmatch(r"charging-samples/samples-restored-([0-9]+)\.jsonl", next((x for x in session_targets if x.startswith("charging-samples/")), ""))
    if (len(session_targets) != 2 or session_match is None or sample_match is None
            or session_match.group(1) != sample_match.group(1)):
        raise RuntimeError(invalid)
    allowed = fixed + [
        item for item in optional
        if any(entry.get("root") == item[0] and entry.get("target") == item[1] for entry in entries)
    ] + [
        ("data", f"sessions/session-restored-{session_match.group(1)}.jsonl", "jsonl"),
        ("data", f"charging-samples/samples-restored-{sample_match.group(1)}.jsonl", "jsonl"),
    ]
    expected = [
        {"root": root, "target": target, "payload": f"{index}.{suffix}"}
        for index, (root, target, suffix) in enumerate(allowed)
    ]
    if [{key: entry.get(key) for key in ("root", "target", "payload")} for entry in entries] != expected:
        raise RuntimeError(invalid)
    transaction_resolved = transaction.resolve()
    for entry in entries:
        payload = transaction / entry["payload"]
        if (type(entry.get("size")) is not int or entry["size"] < 0
                or not isinstance(entry.get("sha256"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", entry["sha256"])):
            raise RuntimeError(invalid)
        if not verify_payloads:
            continue
        if payload.is_symlink() or not payload.is_file() or payload.resolve().parent != transaction_resolved:
            raise RuntimeError(invalid)
        digest = hashlib.sha256()
        size = 0
        with payload.open("rb") as handle:
            for chunk in iter(lambda: handle.read(64 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
        if size != entry["size"] or digest.hexdigest() != entry["sha256"]:
            raise RuntimeError("Restore-Payloadintegrität ungültig; automatische Recovery wurde angehalten.")


def _recover_restore_transaction() -> bool:
    with _restore_barrier(recover=False):
        return _recover_restore_transaction_locked()


def _recover_restore_transaction_locked() -> bool:
    _validate_restore_roots()
    transaction = DATA / ".functional-restore-transaction"
    if transaction.is_symlink():
        raise RuntimeError("Ungültiger Restore-Transaktionspfad; Recovery wurde angehalten.")
    manifest_path = transaction / "manifest.json"
    stores = [_path(name) for name in ("events.json", "locations.json", "deleted-location-labels.json", "maintenance.json", "odometer-milestones.json", "preferences.json")]
    with ExitStack() as stack:
        for store in sorted(stores, key=lambda path: str(path.resolve())):
            stack.enter_context(_store_lock(store))
        if not manifest_path.exists():
            if transaction.exists():
                receipt_path = transaction / "committed.json"
                if receipt_path.is_file() and not receipt_path.is_symlink():
                    _finish_committed_restore_transaction(transaction, _read_unlocked(receipt_path, None))
                    return True
                if transaction.is_dir() and not any(transaction.iterdir()):
                    transaction.rmdir()
                    _fsync_directory(transaction.parent)
                    return False
                # Preserve every unclassified artifact for safe reconciliation
                # instead of guessing whether it belongs to an interrupted write.
                raise RuntimeError("Restore-Transaktionsmanifest fehlt; automatische Recovery wurde angehalten und vorhandene Artefakte erhalten.")
            return False
        manifest = _read(manifest_path, {})
        entries = manifest.get("entries") if isinstance(manifest, dict) else None
        if (not isinstance(manifest, dict) or set(manifest) != {"version", "entries"}
                or type(manifest.get("version")) is not int or manifest.get("version") not in (1, 2)
                or not isinstance(entries, list)):
            raise RuntimeError("Ungültiges Restore-Transaktionsjournal; automatische Recovery wurde angehalten.")
        if manifest["version"] == 1:
            # Version 1 did not bind payload bytes to the journal. Keep every
            # recovery artifact intact for operator-assisted reconciliation.
            raise RuntimeError("Nicht verifiziertes Version-1-Restorejournal; automatische Recovery wurde angehalten und das Journal erhalten.")
        _install_restore_transaction(transaction, entries, manifest_version=2)
        _commit_restore_transaction(transaction, entries)
    return True


# Web/observer imports happen before serving or processing updates. Recover
# before either process can expose a mixed snapshot after a prior power loss.
# Integrity snapshots defer recovery so they can reject an incomplete restore
# without changing the data they are meant to measure.
# Without a transaction there is nothing to recover; skipping the lock then lets both
# processes start (and show the data) on read-only storage, e.g. a failing SD card.
_TRANSACTION = DATA / ".functional-restore-transaction"
if os.environ.get("ZERO_CONNECT_INTERNAL_TASK") != "production_integrity_snapshot" and (_TRANSACTION.exists() or _TRANSACTION.is_symlink()):
    _recover_restore_transaction()
