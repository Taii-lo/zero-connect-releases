#!/bin/sh
# First-boot target-system helper.  It grows the mounted root partition and
# ext4 filesystem once; it never runs in the static image build.
set -eu

marker=${ZERO_CONNECT_ROOT_RESIZE_MARKER:-/var/lib/zero-connect/.root-resize-complete}
log() { logger -t zero-connect-root-resize -- "$*" 2>/dev/null || printf '%s\n' "$*" >&2; }

grow_root() {
    rootdev=$1
    disk=$2
    partnum=$3
    if command -v growpart >/dev/null 2>&1; then
        set +e
        growpart "$disk" "$partnum"
        rc=$?
        set -e
        # growpart returns 1 for NOCHANGE, which is a successful idempotent case.
        [ "$rc" -eq 0 ] || [ "$rc" -eq 1 ] || { log "partition growth failed ($rc)"; return "$rc"; }
    else
        log "growpart is missing; refusing to guess partition geometry"
        return 1
    fi

    resize2fs "$rootdev"
    install -d -m 0700 "$(dirname "$marker")"
    touch "$marker"
    chmod 0600 "$marker"
    log "root partition and filesystem ready: $rootdev"
}

# The kernel exposes the partition number in sysfs.  This is authoritative for
# names such as /dev/mmcblk0p2 and avoids passing a device name (or a by-slot
# alias) to growpart.  lsblk remains a compatibility fallback for platforms
# where the sysfs partition attribute is unavailable.
SYSFS_ROOT=${ZERO_CONNECT_SYSFS_ROOT:-/sys}
ROOT_DISK=
ROOT_PARTNUM=
resolve_root_metadata() {
    device=$1
    name=${device##*/}
    partition_file="$SYSFS_ROOT/class/block/$name/partition"
    if [ -r "$partition_file" ]; then
        candidate_part=$(cat "$partition_file" 2>/dev/null || true)
        sysfs_device=$(readlink -f "$SYSFS_ROOT/class/block/$name" 2>/dev/null || true)
        candidate_parent=$(basename "$(dirname "$sysfs_device")")
        case "$candidate_part" in
            ''|*[!0-9]*) ;;
            *)
                if [ -n "$sysfs_device" ] && [ -n "$candidate_parent" ] && [ "$candidate_parent" != "." ] && [ "$candidate_parent" != "$name" ] &&
                   [ -e "$SYSFS_ROOT/class/block/$candidate_parent" ]; then
                    ROOT_DISK="/dev/$candidate_parent"
                    ROOT_PARTNUM="$candidate_part"
                    return 0
                fi
                ;;
        esac
    fi

    candidate_parent=$(lsblk -nr -o PKNAME "$device" 2>/dev/null | head -n 1 || true)
    candidate_part=$(lsblk -nr -o PARTN "$device" 2>/dev/null | head -n 1 || true)
    case "$candidate_part" in ''|*[!0-9]*) return 1 ;; esac
    [ -n "$candidate_parent" ] || return 1
    ROOT_DISK="/dev/$candidate_parent"
    ROOT_PARTNUM="$candidate_part"
}

# A small, side-effect-free inspection mode keeps the device-name contract
# directly testable without requiring a block device in the build container.
if [ "${ZERO_CONNECT_ROOT_RESIZE_TEST_ONLY:-0}" = 1 ]; then
    resolve_root_metadata "${1:?root device required}"
    printf '%s\n%s\n' "$ROOT_DISK" "$ROOT_PARTNUM"
    exit 0
fi

# Side-effect-isolated command-flow mode for regression tests. Device metadata
# resolution remains covered separately; production never sets this variable.
if [ "${ZERO_CONNECT_ROOT_RESIZE_TEST_RUN:-0}" = 1 ]; then
    [ -e "$marker" ] && exit 0
    grow_root "${1:?root device required}" "${2:?parent disk required}" "${3:?partition number required}"
    exit $?
fi

[ -e "$marker" ] && exit 0
fstype=$(findmnt -n -o FSTYPE / 2>/dev/null || true)
[ "$fstype" = ext4 ] || { log "unsupported root filesystem: ${fstype:-unknown}"; exit 1; }
source=$(findmnt -n -o SOURCE / 2>/dev/null || true)
[ -n "$source" ] || { log "root device could not be determined"; exit 1; }
rootdev=$(readlink -f "$source" 2>/dev/null || true)
[ -b "$rootdev" ] || { log "root source is not a block device: $source"; exit 1; }
resolve_root_metadata "$rootdev" || { log "root partition metadata unavailable: $rootdev"; exit 1; }
disk=$ROOT_DISK
partnum=$ROOT_PARTNUM
[ -b "$disk" ] || { log "root parent is not a block device: $disk"; exit 1; }
case "$partnum" in ''|*[!0-9]*) log "invalid numeric partition number: $partnum"; exit 2 ;; esac

grow_root "$rootdev" "$disk" "$partnum"
