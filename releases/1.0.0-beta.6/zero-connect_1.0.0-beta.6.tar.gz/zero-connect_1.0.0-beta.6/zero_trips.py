"""Rides derived from the vehicle's own telemetry (ignition, odometer, speed, SOC, GPS).

Nothing here is estimated except the range, which is labelled as such: a ride is a
run of reports with the ignition on, its distance is the odometer difference and
its battery use is the SOC difference. Zero reports miles and mph; everything
returned is in km and km/h. Finished rides are kept in ``trips.json`` so they
survive the pruning of the raw report history.
"""
from __future__ import annotations

import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

MILES_TO_KM = 1.609344
MAX_GAP_SECONDS = 10 * 60          # longer silence ends a ride
MIN_DISTANCE_KM = 0.5              # moving the bike in the garage is not a ride
MAX_PLAUSIBLE_MPH = 130.0          # a single glitchy speed report must not become the top speed
FINISHED_AFTER_SECONDS = 15 * 60   # a ride is final once the bike has been quiet this long
RANGE_WINDOW_KM = 200.0            # consumption from roughly the last 200 km between charges
RANGE_MIN_KM = 50.0                # below this there is not enough evidence for a range
ODOMETER_JUMP_MIN_MI = 25.0        # a single glitchy odometer report must not become a ride
ODOMETER_JUMP_MAX_MPH = 250.0      # report times are coarse; real rides show up to ~150 mph between reports
ODOMETER_CONFIRMATIONS = 2         # later reports at the new level make a jump real


def _float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _on(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _epoch(status: dict[str, Any]) -> float | None:
    # Same result as strptime("%Y%m%d%H%M%S"), several times faster: a year of
    # reports is parsed on every new report.
    for key in ("datetime_actual", "datetime_utc"):
        raw = str(status.get(key) or "")
        if len(raw) != 14 or not raw.isascii() or not raw.isdigit():
            continue
        try:
            return datetime(int(raw[:4]), int(raw[4:6]), int(raw[6:8]), int(raw[8:10]), int(raw[10:12]), int(raw[12:]),
                            tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue
    return None


def _point(status: dict[str, Any]) -> tuple[float, float] | None:
    lat, lon = _float(status.get("latitude")), _float(status.get("longitude"))
    if lat is None or lon is None or (lat == 0 and lon == 0) or not -90 <= lat <= 90 or not -180 <= lon <= 180:
        return None
    satellites = _float(status.get("satellites"))
    if satellites is not None and satellites < 4:
        return None
    return round(lat, 5), round(lon, 5)


def _iso(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()


def _ordered(statuses: Iterable[dict[str, Any]]) -> list[tuple[float, dict[str, Any]]]:
    """Time-ordered reports; an odometer value that jumps implausibly (and is not confirmed
    by the following reports) or falls back is blanked so it cannot become distance."""
    rows = sorted(((epoch, row) for row in statuses if isinstance(row, dict) and (epoch := _epoch(row)) is not None), key=lambda item: item[0])
    miles = [_float(row.get("mileage")) for _, row in rows]
    trusted: tuple[float, float] | None = None
    for index, (epoch, row) in enumerate(rows):
        value = miles[index]
        if value is None:
            continue
        if value < 0:
            rows[index] = (epoch, {**row, "mileage": None})
            continue
        if trusted is not None:
            allowed = max(ODOMETER_JUMP_MIN_MI, ODOMETER_JUMP_MAX_MPH * max(0.0, epoch - trusted[0]) / 3600)
            if value < trusted[1] - 0.1 or value > trusted[1] + allowed:
                later = [m for m in miles[index + 1:] if m is not None][:ODOMETER_CONFIRMATIONS]
                if len(later) < ODOMETER_CONFIRMATIONS or not all(value - 0.1 <= m <= value + ODOMETER_JUMP_MIN_MI for m in later):
                    rows[index] = (epoch, {**row, "mileage": None})
                    continue
        trusted = (epoch, value)
    return rows


def _summarize(run: list[tuple[float, dict[str, Any]]], offset_km: float) -> dict[str, Any] | None:
    # Trim standing time with the key on: the ride runs from the report before the
    # first odometer step to the report with the last one.
    miles = [_float(row.get("mileage")) for _, row in run]
    steps = [i for i in range(1, len(run)) if miles[i] is not None and miles[i - 1] is not None and miles[i] > miles[i - 1]]
    if not steps:
        return None
    run = run[steps[0] - 1:steps[-1] + 1]
    first_epoch, first = run[0]
    last_epoch, last = run[-1]
    start_mi, end_mi = _float(first.get("mileage")), _float(last.get("mileage"))
    if start_mi is None or end_mi is None or end_mi < start_mi:
        return None
    distance = (end_mi - start_mi) * MILES_TO_KM
    if distance < MIN_DISTANCE_KM:
        return None
    speeds = [s for _, row in run if (s := _float(row.get("velocity"))) is not None and 0 <= s <= MAX_PLAUSIBLE_MPH]
    altitudes = [a for _, row in run if _point(row) and (a := _float(row.get("altitude"))) is not None and a > 0]
    climb = sum(b - a for a, b in zip(altitudes, altitudes[1:]) if 0 < b - a < 100)
    # A 0 % report in the middle of normal levels is a telemetry glitch, not a reading.
    socs = [soc for _, row in run if (soc := _float(row.get("soc"))) is not None and 0 < soc <= 100]
    start_soc, end_soc = (socs[0], socs[-1]) if socs else (None, None)
    duration = max(0.0, last_epoch - first_epoch)
    points: list[list[float]] = []
    for _, row in run:
        point = _point(row)
        if point and (not points or points[-1] != list(point)):
            points.append(list(point))
    return {
        "id": f"ride-{int(first_epoch)}",
        "started_at_utc": _iso(first_epoch),
        "ended_at_utc": _iso(last_epoch),
        "duration_seconds": round(duration),
        "distance_km": round(distance, 1),
        "start_odometer_km": round(start_mi * MILES_TO_KM + offset_km, 1),
        "start_soc": start_soc,
        "end_soc": end_soc,
        "soc_used": round(start_soc - end_soc, 1) if start_soc is not None and end_soc is not None else None,
        "top_speed_kmh": round(max(speeds) * MILES_TO_KM) if speeds and max(speeds) > 0 else None,
        "average_speed_kmh": round(distance / (duration / 3600)) if duration >= 60 else None,
        "climb_m": round(climb) if len(altitudes) >= 2 else None,
        "points": points,
    }


def detect(statuses: Iterable[dict[str, Any]], *, offset_km: float = 0.0, now_epoch: float | None = None) -> list[dict[str, Any]]:
    """Split time-ordered raw reports into rides; the newest ride is marked ``in_progress`` while it may continue.

    A ride ends when the ignition goes off, the bike is plugged in, the reports
    pause for more than ten minutes, or it stands for more than ten minutes with the key on.
    """
    return _detect(_ordered(statuses), offset_km=offset_km, now_epoch=now_epoch)


def _detect(rows: list[tuple[float, dict[str, Any]]], *, offset_km: float, now_epoch: float | None) -> list[dict[str, Any]]:
    rides: list[dict[str, Any]] = []
    run: list[tuple[float, dict[str, Any]]] = []
    last_move = 0.0

    def close() -> None:
        ride = _summarize(run, offset_km) if len(run) >= 2 else None
        if ride:
            rides.append(ride)
        run.clear()

    for epoch, row in rows:
        if run and epoch == run[-1][0]:
            continue
        if run and epoch - run[-1][0] > MAX_GAP_SECONDS:
            close()
        if _on(row.get("charging")) or _on(row.get("pluggedin")):
            close()
            continue
        miles = _float(row.get("mileage"))
        previous = _float(run[-1][1].get("mileage")) if run else None
        moved = miles is not None and previous is not None and miles > previous
        if not _on(row.get("ignition")):
            if run:
                run.append((epoch, row))  # the first report after switching off carries the final odometer
            close()
            continue
        if run and not moved and epoch - last_move > MAX_GAP_SECONDS:
            close()
        if moved or not run:
            last_move = epoch
        run.append((epoch, row))
    if run:
        last_epoch = run[-1][0]
        count = len(rides)
        close()
        now = now_epoch if now_epoch is not None else datetime.now(timezone.utc).timestamp()
        if len(rides) > count and now - last_epoch < FINISHED_AFTER_SECONDS:
            rides[-1]["in_progress"] = True
    return rides


# Parsed reports per file, extended by what was appended since: the history only
# grows between prunings, and re-reading a year of it on every report is slow on a Pi 3.
_RAW_CACHE: dict[str, tuple[int, int, bytes, list[dict[str, Any]]]] = {}
_TAIL = 256
RAW_CACHE_MAX_BYTES = 64 * 1024 * 1024


def read_raw_history(path: Path) -> list[dict[str, Any]]:
    try:
        handle = path.open("rb")
    except OSError:
        _RAW_CACHE.pop(str(path), None)
        return []
    with handle:
        stat = os.fstat(handle.fileno())
        cached = _RAW_CACHE.get(str(path))
        offset, rows = 0, []
        if cached and cached[0] == stat.st_ino and cached[1] <= stat.st_size:
            # Only an appended file continues where the last read ended: the bytes
            # before that point must be the ones read then.
            handle.seek(max(0, cached[1] - _TAIL))
            if handle.read(min(_TAIL, cached[1])) == cached[2]:
                offset, rows = cached[1], list(cached[3])
        handle.seek(offset)
        data = handle.read()
    complete = data.rfind(b"\n") + 1  # a line still being written is read next time
    for line in data[:complete].splitlines():
        try:
            status = json.loads(line).get("status")
        except (ValueError, AttributeError):
            continue
        if isinstance(status, list):
            status = status[0] if status else None
        if isinstance(status, dict):
            rows.append(status)
    end = offset + complete
    if end <= RAW_CACHE_MAX_BYTES:  # a year of reports is ~15 MB; anything far beyond is not worth keeping in memory
        tail = (cached[2] if offset and cached else b"") + data[:complete]
        _RAW_CACHE[str(path)] = (stat.st_ino, end, tail[-_TAIL:], rows)
    else:
        _RAW_CACHE.pop(str(path), None)
    return list(rows)


def discharge_stretches(statuses: Iterable[dict[str, Any]]) -> list[tuple[float, float, float]]:
    """(end epoch, km, SOC points used) per stretch between two charges, parking included.

    Each stretch runs from the first report after a charge (unplugged) to the last
    report before the next one; whole stretches make the 1 % steps of the SOC negligible.
    """
    return _stretches(_ordered(statuses))


def _stretches(rows: list[tuple[float, dict[str, Any]]]) -> list[tuple[float, float, float]]:
    stretches: list[tuple[float, float, float]] = []
    start: tuple[float, float, float] | None = None
    end: tuple[float, float, float] | None = None

    def close() -> None:
        if start and end and (distance := (end[1] - start[1]) * MILES_TO_KM) >= 5 and (used := start[0] - end[0]) >= 3:
            stretches.append((end[2], distance, used))

    for epoch, row in rows:
        soc, miles = _float(row.get("soc")), _float(row.get("mileage"))
        if soc is None or not 0 < soc <= 100 or miles is None:
            continue
        if _on(row.get("charging")) or _on(row.get("pluggedin")):
            close()
            start = end = None
            continue
        if start is None:
            start = (soc, miles, epoch)
        end = (soc, miles, epoch)
    close()
    return stretches


def discharge_consumption(stretches: list[tuple[float, float, float]], window_km: float = RANGE_WINDOW_KM) -> dict[str, Any] | None:
    """SOC points per 100 km over the newest stretches adding up to about ``window_km``."""
    distance = used = 0.0
    for _, stretch_distance, stretch_used in reversed(stretches):
        distance += stretch_distance
        used += stretch_used
        if distance >= window_km:
            break
    if distance < RANGE_MIN_KM or used <= 0:
        return None
    return {"percent_per_100km": round(used / distance * 100, 1), "distance_km": round(distance)}


def _plausible(ride: dict[str, Any]) -> bool:
    """A kept ride from before the odometer check could still carry a glitch distance."""
    distance, duration = _float(ride.get("distance_km")), _float(ride.get("duration_seconds"))
    if distance is None or distance < 0:
        return False
    limit_km = max(ODOMETER_JUMP_MIN_MI, ODOMETER_JUMP_MAX_MPH * max(0.0, duration or 0.0) / 3600) * MILES_TO_KM
    return distance <= limit_km


_CACHE: dict[str, Any] = {}


def load(raw_path: Path, store_path: Path, *, offset_km: float = 0.0, now_epoch: float | None = None) -> dict[str, Any]:
    """Rides (newest first: kept ones plus those in the raw history) and the recent consumption.

    Finished rides are written to ``store_path`` so they outlive the raw history.
    """
    try:
        stat = raw_path.stat()
        key = (str(raw_path), stat.st_mtime_ns, stat.st_size, offset_km)
    except OSError:
        key = (str(raw_path), None, None, offset_km)
    if _CACHE.get("key") == key and now_epoch is None:
        return _CACHE["value"]
    try:
        kept = json.loads(store_path.read_text(encoding="utf-8"))
        kept = kept if isinstance(kept, list) else []
    except (OSError, ValueError):
        kept = []
    ordered = _ordered(read_raw_history(raw_path))
    found = _detect(ordered, offset_km=offset_km, now_epoch=now_epoch)
    merged = {str(ride.get("id")): ride for ride in kept if isinstance(ride, dict) and ride.get("id") and _plausible(ride)}
    for ride in found:
        merged[ride["id"]] = ride
    rides = sorted(merged.values(), key=lambda ride: str(ride.get("started_at_utc")), reverse=True)
    finished = [ride for ride in rides if not ride.get("in_progress")]
    if finished != kept:
        try:
            store_path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=store_path.parent, delete=False) as handle:
                json.dump(finished, handle, ensure_ascii=False)
                temp = handle.name
            os.chmod(temp, 0o600)
            os.replace(temp, store_path)
        except OSError:
            pass
    stretches = _stretches(ordered)
    value = {"rides": rides, "stretches": stretches, "consumption": discharge_consumption(stretches)}
    _CACHE.update(key=key, value=value)
    return value


def range_km(soc: float | None, consumption: dict[str, Any] | None) -> dict[str, Any] | None:
    """Estimated range for the current level from the measured consumption, rounded to 5 km."""
    if soc is None or not consumption or consumption["percent_per_100km"] <= 0:
        return None
    per_percent = 100 / consumption["percent_per_100km"]
    return {"km": int(round(soc * per_percent / 5) * 5), "full_km": int(round(100 * per_percent / 5) * 5), **consumption}


def months(rides: list[dict[str, Any]], stretches: list[tuple[float, float, float]] = ()) -> list[dict[str, Any]]:
    """Distance and rides per local calendar month (newest first), with the consumption between charges ending that month."""
    month_of = lambda epoch: datetime.fromtimestamp(epoch, timezone.utc).astimezone().strftime("%Y-%m")
    groups: dict[str, dict[str, float]] = {}
    for ride in rides:
        if ride.get("in_progress"):
            continue
        try:
            month = month_of(datetime.fromisoformat(str(ride["started_at_utc"])).timestamp())
        except (KeyError, ValueError):
            continue
        group = groups.setdefault(month, {"distance": 0.0, "rides": 0, "used": 0.0, "used_distance": 0.0})
        group["distance"] += float(ride.get("distance_km") or 0)
        group["rides"] += 1
    for epoch, distance, used in stretches:
        group = groups.get(month_of(epoch))
        if group is not None:
            group["used"] += used
            group["used_distance"] += distance
    return [{
        "month": month,
        "distance_km": round(group["distance"]),
        "rides": int(group["rides"]),
        "percent_per_100km": round(group["used"] / group["used_distance"] * 100, 1) if group["used_distance"] >= RANGE_MIN_KM else None,
    } for month, group in sorted(groups.items(), reverse=True)]


def without_points(ride: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in ride.items() if key != "points"} | {"has_route": bool(ride.get("points"))}
