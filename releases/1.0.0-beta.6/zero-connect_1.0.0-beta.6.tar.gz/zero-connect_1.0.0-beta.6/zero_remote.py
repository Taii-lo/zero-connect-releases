"""Remote access address (Tailscale or any HTTPS address) – owner-specific, never hard-coded."""
from __future__ import annotations

import json
import re
import subprocess
import time
import urllib.parse
from typing import Any

from zero_paths import PATHS

_HOST = re.compile(r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
FALLBACK_SUBJECT = "mailto:zero-connect@example.invalid"


def normalize_url(text: str) -> str:
    """`https://host` without path or credentials; empty string clears the setting."""
    value = str(text or "").strip()
    if not value:
        return ""
    if "://" not in value:
        value = "https://" + value
    parsed = urllib.parse.urlparse(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not _HOST.match(host) or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Bitte eine HTTPS-Adresse wie https://geraet.dein-netz.ts.net eingeben.")
    return f"https://{host}" + (f":{parsed.port}" if parsed.port and parsed.port != 443 else "")


def configured_url() -> str:
    try:
        return normalize_url(json.loads(PATHS.config_file.read_text(encoding="utf-8")).get("remote_url") or "")
    except (OSError, ValueError, AttributeError):
        return ""


def detect() -> dict[str, Any]:
    """What the local Tailscale client reports; empty/unknown when it is not installed or not readable."""
    info: dict[str, Any] = {"installed": False, "state": "unknown", "url": "", "auth_url": "", "serving": False}
    try:
        result = subprocess.run(["tailscale", "status", "--json"], capture_output=True, text=True, timeout=4, check=False)
    except (OSError, subprocess.SubprocessError):
        return info
    info["installed"] = True
    if result.returncode != 0:
        return info
    try:
        data = json.loads(result.stdout)
    except ValueError:
        return info
    info["state"] = "connected" if data.get("BackendState") == "Running" else str(data.get("BackendState") or "unknown").lower()
    name = str((data.get("Self") or {}).get("DNSName") or "").rstrip(".").lower()
    if name and _HOST.match(name):
        info["url"] = f"https://{name}"
    auth = str(data.get("AuthURL") or "")
    if auth.startswith("https://login.tailscale.com/"):
        info["auth_url"] = auth
    if info["state"] == "connected":
        info["serving"] = serving()
    return info


def serving() -> bool:
    """True when Tailscale already publishes the app over HTTPS (any serve config counts)."""
    try:
        result = subprocess.run(["tailscale", "serve", "status", "--json"], capture_output=True, text=True, timeout=4, check=False)
        return result.returncode == 0 and bool((json.loads(result.stdout or "{}") or {}).get("TCP"))
    except (OSError, subprocess.SubprocessError, ValueError):
        return False


_SERVE_ENABLE = re.compile(r"https://login\.tailscale\.com/\S+")


def connect(port: int = 8080, wait: float = 20.0) -> dict[str, Any]:
    """One button for the owner: log in when needed, otherwise publish the app over HTTPS.

    Needs the app user as Tailscale operator (set at boot by zero-connect-tailscale-operator.service).
    Returns the link the owner has to open next, if any; never changes an already working setup.
    """
    info = detect()
    if not info["installed"]:
        return {**info, "error_code": "remote_missing"}
    if info["state"] != "connected":
        if not info["auth_url"]:
            try:
                # Turned off but signed in: just switch it on; otherwise start a sign-in.
                command = ["tailscale", "up"] if info["state"] == "stopped" else ["tailscale", "login", "--timeout=15m"]
                subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, start_new_session=True)
            except OSError:
                return {**info, "error_code": "remote_failed"}
            deadline = time.monotonic() + wait
            while time.monotonic() < deadline and not info["auth_url"] and info["state"] != "connected":
                time.sleep(0.5)
                info = detect()
        # A slow Pi can take 15+ seconds to get the link; the page keeps polling and shows it when it arrives.
        return {**info, "next_url": info["auth_url"]} if info["auth_url"] else {**info, "pending": info["state"] != "connected"}
    if info["serving"]:
        return {**info, "next_url": ""}
    # A new tailnet may first have to allow HTTPS; Tailscale then prints a link and waits for it.
    try:
        proc = subprocess.Popen(["tailscale", "serve", "--bg", "--yes", str(int(port))], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, start_new_session=True)
    except OSError:
        return {**info, "error_code": "remote_failed"}
    link, output, deadline = "", "", time.monotonic() + wait
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            output += proc.stdout.read() if proc.stdout else ""
            break
        line = proc.stdout.readline() if proc.stdout else ""
        output += line
        match = _SERVE_ENABLE.search(line)
        if match:
            link = match.group(0).rstrip(".,")
            break
    info = detect()
    if info["serving"]:
        return {**info, "next_url": ""}
    if link:
        return {**info, "next_url": link, "needs": "https"}
    if proc.poll() is None:
        proc.kill()
    return {**info, "error_code": "remote_failed"}


def effective_url(detected: dict[str, Any] | None = None) -> str:
    return configured_url() or str((detected if detected is not None else detect()).get("url") or "")


def push_subject() -> str:
    """Contact for web push (required by the protocol): the owner's own address, else a neutral placeholder."""
    host = urllib.parse.urlparse(configured_url() or detect().get("url") or "").hostname
    return f"mailto:zero-connect@{host}" if host else FALLBACK_SUBJECT


def status() -> dict[str, Any]:
    detected = detect()
    return {"configured_url": configured_url(), "detected": detected, "effective_url": effective_url(detected)}
