#!/usr/bin/env python3
"""Retry-safe, persistent post-boot validation for the appliance host."""
from __future__ import annotations

import json
import os
import pathlib
import socket
import subprocess
import time
import urllib.request


ROOT = pathlib.Path("/")
DATA = ROOT / "var/lib/zero-connect"
REPORT = DATA / "postboot-verification.json"
MIN_SESSIONS_FILE = DATA / "postboot-min-sessions"
EXPECTED_HOST = "zero-pi"
API_URLS = (
    "http://127.0.0.1:8080/api/health",
    "http://zero-pi.local:8080/api/health",
    "http://100.72.68.24:8080/api/health",
)


def command(*args: str) -> str:
    return subprocess.run(args, check=False, capture_output=True, text=True).stdout.strip()


def active(unit: str) -> str:
    return command("systemctl", "is-active", unit)


def enabled(unit: str) -> str:
    return command("systemctl", "is-enabled", unit)


def api_ok(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            payload = json.loads(response.read())
        return payload.get("ok") is True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def count_process(fragment: str) -> int:
    return sum(1 for entry in pathlib.Path("/proc").iterdir() if entry.name.isdigit()
               and fragment in (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace"))


def listener_count() -> int:
    output = command("ss", "-ltnH", "sport", "=", ":8080")
    return len(output.splitlines()) if output else 0


def sessions_count() -> int:
    return sum(1 for path in (DATA / "sessions").glob("*") if path.is_file())


def minimum_sessions() -> int:
    try:
        return max(0, int(MIN_SESSIONS_FILE.read_text().strip()))
    except (OSError, ValueError):
        return 9


def validate() -> dict[str, object]:
    revision_path = pathlib.Path("/opt/zero-connect/.deploy-revision")
    config_path = ROOT / "etc/zero-connect/zero_config.json"
    revision = revision_path.read_text().strip() if revision_path.is_file() else ""
    try:
        config = json.loads(config_path.read_text())
        first_run = not bool(config.get("setup", {}).get("completed", False))
    except (OSError, ValueError, TypeError):
        first_run = None
    urls = {url: api_ok(url) for url in API_URLS}
    sessions = sessions_count()
    result: dict[str, object] = {
        "host": socket.gethostname(),
        "boot_id": pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "web": active("zero-connect-web.service"),
        "observer": active("zero-observer.service"),
        "web_enabled": enabled("zero-connect-web.service"),
        "observer_enabled": enabled("zero-observer.service"),
        "api": urls,
        "observer_processes": count_process("/opt/zero-connect/zero_observer.py"),
        "web_processes": count_process("/opt/zero-connect/zero_connect_web.py"),
        "port_8080_listeners": listener_count(),
        "first_run": first_run,
        "sessions": sessions,
        "minimum_sessions": minimum_sessions(),
        "revision": revision,
    }
    result["ok"] = (
        result["host"] == EXPECTED_HOST
        and result["web"] == result["observer"] == "active"
        and result["web_enabled"] == result["observer_enabled"] == "enabled"
        and all(urls.values())
        and result["observer_processes"] == result["web_processes"] == 1
        and result["port_8080_listeners"] == 1
        and result["first_run"] is False
        and sessions >= int(result["minimum_sessions"])
        and len(revision) == 40
    )
    return result


def main() -> int:
    result: dict[str, object] = {"ok": False}
    for _ in range(30):
        result = validate()
        if result["ok"]:
            break
        time.sleep(2)
    DATA.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    os.chmod(REPORT, 0o600)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
