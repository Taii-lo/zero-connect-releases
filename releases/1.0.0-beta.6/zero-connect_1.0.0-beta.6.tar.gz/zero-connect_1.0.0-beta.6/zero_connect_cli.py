#!/usr/bin/env python3
"""Unified, German-language command line interface for Zero Connect."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import socket
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any
from zero_paths import PATHS

PROJECT_DIR = PATHS.program_dir
PUBLIC_VERSION = "1.0.0-beta.6"
INTERNAL_VERSION = "3.0.0-alpha.45"
SERVICE = "zero-observer.service"
WEB_SERVICE = "zero-connect-web.service"
PIN_FILE = PATHS.data_dir / "web_admin_pin"


class GermanArgumentParser(argparse.ArgumentParser):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        add_help = bool(kwargs.pop("add_help", True))
        super().__init__(*args, add_help=False, **kwargs)
        self._positionals.title = "Argumente"
        self._optionals.title = "Optionen"
        if add_help:
            self.add_argument("-h", "--help", action="help", help="diese Hilfe anzeigen und beenden")

    def _check_value(self, action: argparse.Action, value: Any) -> None:
        if action.choices is not None and value not in action.choices:
            choices = ", ".join(map(str, action.choices))
            raise argparse.ArgumentError(action, f"ungültige Auswahl '{value}' (möglich: {choices})")

    def format_usage(self) -> str:
        return super().format_usage().replace("usage:", "Verwendung:", 1)

    def format_help(self) -> str:
        return (
            super()
            .format_help()
            .replace("usage:", "Verwendung:", 1)
            .replace("positional arguments:", "Argumente:")
            .replace("options:", "Optionen:")
        )

    def error(self, message: str) -> None:
        self.print_usage(sys.stderr)
        self.exit(2, f"{self.prog}: Fehler: {message}\n")


def german_int(value: str) -> int:
    try:
        return int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"'{value}' ist keine ganze Zahl") from exc


def run_python(script: str, args: list[str] | None = None) -> int:
    command = [sys.executable, str(PROJECT_DIR / script), *(args or [])]
    return subprocess.call(command)


def safe_extract(archive: Path, destination: Path) -> None:
    destination_real = destination.resolve()
    with tarfile.open(archive, "r:*") as tf:
        for member in tf.getmembers():
            target = (destination / member.name).resolve()
            if target != destination_real and destination_real not in target.parents:
                raise RuntimeError("Unsicherer Pfad im Update-Bundle.")
            if member.issym() or member.islnk():
                raise RuntimeError("Symlinks sind in Update-Bundles nicht erlaubt.")
            if member.isdev() or member.isfifo():
                raise RuntimeError("Geräte/FIFOs sind in Update-Bundles nicht erlaubt.")
        # Python >=3.12 supports extraction filters. Older supported versions are
        # protected by the explicit path/type checks above.
        if hasattr(tarfile, "data_filter"):
            tf.extractall(destination, filter="data")
        else:
            tf.extractall(destination)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_manifest(bundle_root: Path) -> None:
    manifest = bundle_root / "MANIFEST.sha256"
    if not manifest.is_file():
        raise RuntimeError("MANIFEST.sha256 fehlt.")
    expected: dict[str, str] = {}
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64})  (.+)", line)
        if not match:
            raise RuntimeError(f"Ungültige Manifest-Zeile {number}.")
        rel = match.group(2)
        rel_path = Path(rel)
        if rel_path.is_absolute() or ".." in rel_path.parts or rel == "MANIFEST.sha256":
            raise RuntimeError(f"Unsicherer Manifest-Pfad: {rel}")
        expected[rel] = match.group(1).lower()

    if not expected:
        raise RuntimeError("MANIFEST.sha256 ist leer.")
    actual = {
        path.relative_to(bundle_root).as_posix()
        for path in bundle_root.rglob("*")
        if path.is_file() and path.name != "MANIFEST.sha256" and "__pycache__" not in path.parts
    }
    if actual != set(expected):
        missing = sorted(set(expected) - actual)
        extra = sorted(actual - set(expected))
        detail = []
        if missing:
            detail.append("fehlt: " + ", ".join(missing[:5]))
        if extra:
            detail.append("nicht im Manifest: " + ", ".join(extra[:5]))
        raise RuntimeError("Bundle-Inhalt stimmt nicht mit Manifest überein (" + "; ".join(detail) + ").")

    for rel, wanted in expected.items():
        path = bundle_root / rel
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"Manifest-Datei ist nicht regulär: {rel}")
        got = sha256_file(path)
        if got != wanted:
            raise RuntimeError(f"Prüfsumme stimmt nicht: {rel}")


def parse_version(value: str) -> tuple[int, int, int, int, int]:
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z]+)\.(\d+))?", value.strip())
    if not match:
        raise RuntimeError(f"Versionsformat nicht unterstützt: {value}")
    major, minor, patch = (int(match.group(i)) for i in (1, 2, 3))
    tag = (match.group(4) or "final").lower()
    number = int(match.group(5) or 0)
    rank = {"alpha": 0, "beta": 1, "rc": 2, "final": 3}.get(tag)
    if rank is None:
        raise RuntimeError(f"Versionskanal nicht unterstützt: {tag}")
    return major, minor, patch, rank, number


def read_public_version(path: Path) -> str:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        value = str(data["public_version"]).strip()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise RuntimeError(f"VERSION.json unlesbar: {exc}") from exc
    parse_version(value)
    return value


def command_update(bundle_text: str, *, allow_downgrade: bool, verbose: bool) -> int:
    bundle = Path(bundle_text).expanduser().resolve()
    if not bundle.is_file():
        print(f"Bundle nicht gefunden: {bundle}", file=sys.stderr)
        return 2
    with tempfile.TemporaryDirectory(prefix="zero-connect-update-") as temp:
        root = Path(temp)
        try:
            safe_extract(bundle, root)
            installers = list(root.rglob("install.sh"))
            if len(installers) != 1:
                raise RuntimeError("Bundle enthält keinen eindeutigen install.sh.")
            bundle_root = installers[0].parent
            verify_manifest(bundle_root)
            incoming = read_public_version(bundle_root / "VERSION.json")
            current = read_public_version(PROJECT_DIR / "VERSION.json")
            if parse_version(incoming) < parse_version(current) and not allow_downgrade:
                raise RuntimeError(
                    f"Downgrade {current} -> {incoming} blockiert. "
                    "Nur bewusst mit --allow-downgrade zulassen."
                )
        except (tarfile.TarError, RuntimeError, OSError) as error:
            print(f"Update-Bundle abgelehnt: {error}", file=sys.stderr)
            return 2

        print(f"Update geprüft: {current} -> {incoming}")
        command = ["bash", str(installers[0]), "--upgrade"]
        if PATHS.mode == "appliance": command.append("--appliance")
        if verbose:
            command.append("--verbose")
        return subprocess.call(command)


def run_selftest(verbose: bool) -> int:
    if verbose:
        return run_python("zero_observer.py", ["--self-test"])
    log_dir = PATHS.data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    try:
        log_dir.chmod(0o700)
    except OSError:
        pass
    stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    log_path = log_dir / f"selftest-{stamp}.log"
    result = subprocess.run(
        [sys.executable, str(PROJECT_DIR / "zero_observer.py"), "--self-test"],
        capture_output=True,
        text=True,
        check=False,
    )
    try:
        log_path.write_text((result.stdout or "") + (result.stderr or ""), encoding="utf-8")
        log_path.chmod(0o600)
    except OSError:
        log_path = Path("<nicht schreibbar>")
    if result.returncode == 0:
        print("[OK] Selbsttest: Syntax und Regressionstests bestanden")
        return 0
    print("[✗] Selbsttest fehlgeschlagen", file=sys.stderr)
    print(f"Details: {log_path}", file=sys.stderr)
    return result.returncode or 1


def command_support(export: bool, days: int | None) -> int:
    print("Zero Connect Support-Übersicht")
    print("══════════════════════════════")
    doctor_rc = run_python("zero_doctor.py")
    run_python("zero_status.py", ["--verbose"])
    run_python("zero_diagnostics.py", ["summary"])
    if export:
        args = ["export"]
        if days is not None:
            args.extend(["--days", str(days)])
        return max(doctor_rc, run_python("zero_diagnostics.py", args))
    print("Supportpaket: zero-connect support --export")
    return doctor_rc


def build_parser() -> tuple[GermanArgumentParser, dict[str, argparse.ArgumentParser]]:
    parser = GermanArgumentParser(prog="zero-connect", description="Zero Connect verwalten")
    sub = parser.add_subparsers(dest="command", required=True, parser_class=GermanArgumentParser)
    parsers: dict[str, argparse.ArgumentParser] = {}

    status = sub.add_parser("status", help="Fahrzeug- und Dienststatus anzeigen")
    status.add_argument("--verbose", "-v", action="store_true", help="technische Details anzeigen")
    parsers["status"] = status
    parsers["setup"] = sub.add_parser("setup", help="vollständigen Setup-Assistenten starten")
    parsers["doctor"] = sub.add_parser("doctor", help="read-only Systemdiagnose ausführen")
    test = sub.add_parser("test", help="lokale Regressionstests ausführen")
    test.add_argument("--verbose", action="store_true", help="vollständige Testausgabe anzeigen")
    parsers["test"] = test

    configure = sub.add_parser("configure", help="einzelne Einstellungen nachträglich ändern")
    configure.add_argument("section", metavar="BEREICH", help="aivi | abrp | vehicle | diagnostics | all")
    parsers["configure"] = configure

    logs = sub.add_parser("logs", help="persistente Observer-Logs anzeigen")
    logs.add_argument("--follow", "-f", action="store_true", help="Logs fortlaufend anzeigen")
    logs.add_argument("--lines", "-n", type=german_int, default=50, help="Anzahl letzter Zeilen")
    logs.add_argument("--journal", action="store_true", help="stattdessen systemd-Journal anzeigen")
    parsers["logs"] = logs

    parsers["diagnostics"] = sub.add_parser(
        "diagnostics", help="Diagnose-/Speichernutzung und Aufbewahrung anzeigen"
    )
    export_logs = sub.add_parser("export-logs", help="datenschutzbereinigtes Diagnosepaket erzeugen")
    export_logs.add_argument("--days", type=german_int, help="Anzahl Tage; Standard aus Konfiguration")
    export_logs.add_argument("--output", help="optionaler Zielpfad für .tar.gz")
    export_logs.add_argument(
        "--include-location", action="store_true",
        help="Standort/Fahrzeugkennung und lokale Systemidentität im Export belassen",
    )
    parsers["export-logs"] = export_logs

    history = sub.add_parser("history", help="letzte abgeschlossene Ladesitzungen anzeigen")
    history.add_argument("--limit", "-n", type=german_int, default=10, help="maximale Anzahl")
    parsers["history"] = history

    support = sub.add_parser("support", help="Support-Übersicht und optional Diagnosepaket erzeugen")
    support.add_argument("--export", action="store_true", help="zusätzlich anonymisiertes Diagnosepaket erzeugen")
    support.add_argument("--days", type=german_int, help="Exportzeitraum in Tagen")
    parsers["support"] = support

    aivi = sub.add_parser("aivi-test", help="synthetische Aivi Live Activity senden oder zurücksetzen")
    aivi.add_argument(
        "action", nargs="?", default="run", choices=("run", "reset", "idle"),
        help="run = Test starten; reset/idle = alle konfigurierten Activities beenden",
    )
    aivi.add_argument("--interval", type=german_int, default=30, help="Sekunden zwischen Zuständen")
    aivi.add_argument("--final-hold", type=german_int, default=5, help="Sekunden, die der Abschluss im Test sichtbar bleibt")
    parsers["aivi-test"] = aivi

    parsers["restart"] = sub.add_parser("restart", help="Observer neu starten")
    parsers["web"] = sub.add_parser("web", help="Adresse und Admin-PIN der lokalen Web-UI anzeigen")
    parsers["version"] = sub.add_parser("version", help="Versionsstand anzeigen")

    update = sub.add_parser("update", help="lokales Zero-Connect-Bundle prüfen und installieren")
    update.add_argument("bundle", metavar="BUNDLE", help="Pfad zu .tar.gz/.tgz Bundle")
    update.add_argument("--allow-downgrade", action="store_true", help="ältere Version bewusst zulassen")
    update.add_argument("--verbose", action="store_true", help="vollständige Installationsausgabe anzeigen")
    parsers["update"] = update

    help_cmd = sub.add_parser("help", help="Befehlsübersicht oder Detailhilfe anzeigen")
    help_cmd.add_argument("topic", nargs="?", metavar="BEFEHL", help="optional: Befehl für Detailhilfe")
    parsers["help"] = help_cmd
    return parser, parsers


def main() -> None:
    parser, parsers = build_parser()
    args = parser.parse_args()

    if args.command == "help":
        if args.topic:
            target = parsers.get(args.topic)
            if target is None:
                parser.error(f"unbekannter Hilfebefehl '{args.topic}'")
            target.print_help()
        else:
            parser.print_help()
        return
    if args.command == "status":
        raise SystemExit(run_python("zero_status.py", ["--verbose"] if args.verbose else []))
    if args.command == "setup":
        raise SystemExit(run_python("zero_setup.py", ["--section", "all"]))
    if args.command == "configure":
        valid = {"aivi", "abrp", "vehicle", "diagnostics", "all"}
        if args.section not in valid:
            parser.error(
                f"ungültiger Konfigurationsbereich '{args.section}' "
                "(möglich: aivi, abrp, vehicle, diagnostics, all)"
            )
        raise SystemExit(run_python("zero_setup.py", ["--section", args.section]))
    if args.command == "doctor":
        raise SystemExit(run_python("zero_doctor.py"))
    if args.command == "test":
        raise SystemExit(run_selftest(args.verbose))
    if args.command == "logs":
        if args.journal:
            command = ["journalctl", "--user-unit", SERVICE, "-n", str(max(1, args.lines)), "--no-pager"]
            if args.follow:
                command.append("--follow")
            os.execvp(command[0], command)
        persistent = PATHS.data_dir / "logs" / "observer.log"
        if not persistent.exists():
            print("Noch kein persistentes Observer-Log vorhanden.", file=sys.stderr)
            print("Alternativ: zero-connect logs --journal", file=sys.stderr)
            raise SystemExit(1)
        command = ["tail", "-n", str(max(1, args.lines))]
        if args.follow:
            command.append("-F")
        command.append(str(persistent))
        os.execvp(command[0], command)
    if args.command == "diagnostics":
        raise SystemExit(run_python("zero_diagnostics.py", ["summary"]))
    if args.command == "export-logs":
        diag_args = ["export"]
        if args.days is not None:
            diag_args.extend(["--days", str(args.days)])
        if args.output:
            diag_args.extend(["--output", args.output])
        if args.include_location:
            diag_args.append("--include-location")
        raise SystemExit(run_python("zero_diagnostics.py", diag_args))
    if args.command == "history":
        raise SystemExit(run_python("zero_history.py", ["--limit", str(max(1, args.limit))]))
    if args.command == "support":
        raise SystemExit(command_support(args.export, args.days))
    if args.command == "aivi-test":
        action = "reset" if args.action in {"reset", "idle"} else "run"
        test_args = [action]
        if action == "run":
            test_args.extend(["--interval", str(max(1, args.interval)), "--final-hold", str(max(0, args.final_hold))])
        raise SystemExit(run_python("aivi_live_test.py", test_args))
    if args.command == "restart":
        result = subprocess.run(PATHS.service_command("restart", SERVICE), check=False)
        if result.returncode == 0:
            print("Observer neu gestartet.")
        raise SystemExit(result.returncode)
    if args.command == "web":
        try:
            cfg = json.loads(PATHS.config_file.read_text(encoding="utf-8"))
            port = int(cfg.get("web", {}).get("port", 8080))
        except (OSError, ValueError, TypeError, AttributeError):
            port = 8080
        try:
            pin = PIN_FILE.read_text(encoding="utf-8").strip()
        except OSError:
            pin = "noch nicht erzeugt"
        result = subprocess.run(PATHS.service_command("is-active", WEB_SERVICE), capture_output=True, text=True, check=False)
        active = result.stdout.strip() == "active"
        host = socket.gethostname().strip() or "zero-connect"
        print(f"Web-UI:    http://{host}.local:{port}")
        print(f"Admin-PIN: {pin}")
        print(f"Dienst:    {'aktiv' if active else 'nicht aktiv'}")
        return
    if args.command == "version":
        print(f"Zero Connect {PUBLIC_VERSION} (intern v{INTERNAL_VERSION})")
        return
    if args.command == "update":
        raise SystemExit(
            command_update(
                args.bundle,
                allow_downgrade=args.allow_downgrade,
                verbose=args.verbose,
            )
        )


if __name__ == "__main__":
    main()
