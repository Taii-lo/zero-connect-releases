#!/usr/bin/env python3
"""Root-owned, socket-activated NetworkManager helper for Zero Connect.

This file is installed to /usr/lib/zero-connect (root:root, 0755).  Its
protocol is deliberately tiny: one JSON request on stdin and one JSON response
on stdout.  It never executes a shell and never places a Wi-Fi password in a
process argument or response.
"""
from __future__ import annotations

import argparse, fcntl, hashlib, json, os, re, subprocess, sys, tempfile, time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable
from zero_paths import PATHS

HOTSPOT = "Zero Connect Setup"
PROFILE = "/etc/NetworkManager/system-connections/Zero Connect Setup.nmconnection"
NETWORK_CONNECTIONS = Path("/etc/NetworkManager/system-connections")
RUNTIME = PATHS.runtime_dir
SSID_RE = re.compile(r"^[^\x00\r\n]{1,32}$")
PSK_RE = re.compile(r"^[\x20-\x7e]{8,63}$|^[0-9A-Fa-f]{64}$")
DEVICE_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,15}$")
BOOT_NETWORK_GRACE_SECONDS = 8
LOCK_WAIT_SECONDS = 2.0
LOCK_FILE = "network.lock"
RESULT_FILE = "network-result.json"

class NetworkError(RuntimeError): pass

@contextmanager
def transition_lock(timeout: float = LOCK_WAIT_SECONDS):
    """Serialize all NetworkManager mutations across socket helpers/watcher."""
    RUNTIME.mkdir(mode=0o710, parents=True, exist_ok=True)
    fd = os.open(RUNTIME / LOCK_FILE, os.O_CREAT | os.O_RDWR | os.O_CLOEXEC, 0o600)
    os.fchmod(fd, 0o600)
    deadline = time.monotonic() + max(0.0, timeout)
    try:
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise NetworkError("Eine WLAN-Aktion läuft bereits.")
                time.sleep(0.05)
        yield
    finally:
        try: fcntl.flock(fd, fcntl.LOCK_UN)
        finally: os.close(fd)

def write_transition(phase: str, *, error_code: str = "", recovery_available: bool = False) -> None:
    """Persist only non-secret, short-lived handover state in root-owned tmpfs."""
    RUNTIME.mkdir(mode=0o710, parents=True, exist_ok=True)
    data = {"phase": phase, "error_code": error_code, "recovery_available": bool(recovery_available), "updated_epoch": int(time.time())}
    fd, name = tempfile.mkstemp(prefix=".network-result-", dir=RUNTIME)
    try:
        os.fchmod(fd, 0o600)
        os.write(fd, (json.dumps(data, separators=(",", ":")) + "\n").encode())
        os.close(fd); fd = -1
        os.replace(name, RUNTIME / RESULT_FILE)
    finally:
        if fd >= 0: os.close(fd)
        Path(name).unlink(missing_ok=True)

def read_transition() -> dict[str, Any]:
    try:
        value = json.loads((RUNTIME / RESULT_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"phase": "idle", "error_code": "", "recovery_available": False, "updated_epoch": 0}
    allowed_phases = {"idle", "connecting", "connected", "failed"}
    phase = str(value.get("phase", "idle"))
    return {
        "phase": phase if phase in allowed_phases else "idle",
        "error_code": str(value.get("error_code", "")) if value.get("error_code") == "wifi_connection_failed" else "",
        "recovery_available": bool(value.get("recovery_available", False)),
        "updated_epoch": int(value.get("updated_epoch", 0)) if str(value.get("updated_epoch", "")).isdigit() else 0,
    }

def nmcli(*args: str, timeout: int = 30) -> subprocess.CompletedProcess[str]:
    environment = {**os.environ, "LC_ALL": "C"}
    return subprocess.run(["nmcli", *args], capture_output=True, text=True, check=False, timeout=timeout, env=environment)

def load_secret_values(path: Path) -> dict[str, str]:
    """Read the small persisted KEY=value contract without extra dependencies."""
    values: dict[str, str] = {}
    for raw in path.read_bytes().decode("utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.removeprefix("export ").split("=", 1)
        key = key.strip()
        value = value.strip()
        try:
            decoded = json.loads(value)
            values[key] = str(decoded or "")
        except (ValueError, TypeError):
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            values[key] = value
    return values

def first_run(project: Path) -> bool:
    try:
        config_file = PATHS.config_file if PATHS.mode == "appliance" else project / "zero_config.json"
        secrets_file = PATHS.secrets_file if PATHS.mode == "appliance" else project / ".env"
        try:
            cfg = json.loads(config_file.read_text(encoding="utf-8"))
            if not isinstance(cfg, dict): raise ValueError("config is not an object")
        except (OSError, ValueError):
            # A damaged file falls back to the copy of the last configuration saved intact.
            cfg = json.loads(config_file.with_name(config_file.name + ".last-good").read_text(encoding="utf-8"))
        env = load_secret_values(secrets_file) if secrets_file.exists() else {}
    except (OSError, ValueError): return True
    setup = cfg.get("setup", {}) if isinstance(cfg, dict) else {}
    complete = bool(setup.get("completed")) and not bool(setup.get("forced"))
    cloud_configured = all(str(env.get(key, "")).strip() for key in ("ZERO_CLOUD_USER", "ZERO_CLOUD_PASSWORD", "ZERO_UNIT_NUMBER"))
    # Reopening the configuration wizard is a deliberate reconfiguration, not
    # permission to disrupt a working network with a setup hotspot.
    if bool(setup.get("forced")) and cloud_configured:
        return False
    return not complete or not cloud_configured

def active_names() -> set[str]:
    result = nmcli("-t", "-f", "NAME", "connection", "show", "--active", timeout=15)
    return {line.strip() for line in result.stdout.splitlines() if line.strip()} if result.returncode == 0 else set()

def normal_network_available(runner: Callable[..., Any] | None = None) -> bool:
    """Return whether NetworkManager has a real Wi-Fi or Ethernet uplink.

    Connection names are deliberately not used as evidence: NetworkManager's
    active loopback profile made Beta 26 treat an offline Pi as connected.
    """
    args = ["nmcli", "-t", "-e", "no", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"]
    if runner is None:
        result = nmcli(*args[1:], timeout=15)
    else:
        try:
            result = runner(args, capture_output=True, text=True, check=False, timeout=15)
        except (OSError, subprocess.SubprocessError):
            return False
    if result.returncode != 0:
        return False
    for line in str(result.stdout).splitlines():
        fields = line.split(":", 3)
        if len(fields) != 4:
            continue
        device, kind, state, connection = (field.strip() for field in fields)
        connected = state == "connected" or state.startswith("connected ")
        if connected and kind in {"wifi", "ethernet"} and device != "lo" and not device.startswith("p2p-") and connection != HOTSPOT:
            return True
    return False

def target_wifi_connected(profile_name: str, wifi_device: str) -> bool:
    """Confirm that the requested target profile, not another uplink, owns Wi-Fi."""
    if not DEVICE_RE.fullmatch(wifi_device): return False
    result = nmcli("-t", "-e", "no", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status", timeout=15)
    if result.returncode != 0: return False
    expected = f"{wifi_device}:wifi:connected:{profile_name}"
    return expected in {line.strip() for line in result.stdout.splitlines()}

def managed_wifi_device() -> str:
    result = nmcli("-t", "-e", "no", "-f", "DEVICE,TYPE,STATE", "device", "status", timeout=15)
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            fields = line.split(":", 2)
            if len(fields) == 3 and fields[1].strip() == "wifi" and fields[2].strip() != "unmanaged":
                device = fields[0].strip()
                if DEVICE_RE.fullmatch(device):
                    return device
    raise NetworkError("Kein verwaltetes WLAN-Gerät für den Setup-Hotspot verfügbar.")

def portal(active: bool) -> None:
    # Unit names are fixed; no caller-controlled service value is accepted.
    units = ("zero-connect-captive-dns.service", "zero-connect-captive-portal.service")
    failed = False
    if active:
        # A prior transient failure may have exhausted systemd's start counter.
        # `reset-failed` itself rejects inactive static units which have never
        # been started. Query first, then reset only an actual failed state.
        for unit in units:
            state = subprocess.run(["systemctl", "is-failed", "--quiet", unit], capture_output=True, text=True, check=False, timeout=20)
            if state.returncode == 0:
                result = subprocess.run(["systemctl", "reset-failed", unit], capture_output=True, text=True, check=False, timeout=20)
                failed = failed or result.returncode != 0
    for unit in (units if active else tuple(reversed(units))):
        if active and failed:
            break
        result = subprocess.run(["systemctl", "start" if active else "stop", unit], capture_output=True, text=True, check=False, timeout=20)
        failed = failed or result.returncode != 0
    if active and failed:
        for cleanup in reversed(units):
            subprocess.run(["systemctl", "stop", cleanup], capture_output=True, text=True, check=False, timeout=20)
    if failed: raise NetworkError("Captive-Portal-Dienst konnte nicht geschaltet werden.")

def ensure_profile(wifi_device: str | None = None) -> None:
    device = wifi_device or managed_wifi_device()
    if not DEVICE_RE.fullmatch(device):
        raise NetworkError("Ungültiges WLAN-Gerät für den Setup-Hotspot.")
    path = Path(PROFILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = f"""[connection]\nid=Zero Connect Setup\ntype=wifi\ninterface-name={device}\nautoconnect=false\n\n[wifi]\nmode=ap\nssid=Zero Connect Setup\n\n[ipv4]\nmethod=manual\naddress1=10.42.0.1/24\n\n[ipv6]\nmethod=disabled\n"""
    if path.exists() and path.read_text(encoding="utf-8") == content:
        return
    path.write_text(content, encoding="utf-8")
    path.chmod(0o600)
    if nmcli("connection", "load", str(path)).returncode != 0: raise NetworkError("Setup-Hotspot konnte nicht provisioniert werden.")

def _activate(project: Path, wifi_device: str | None = None) -> dict[str, Any]:
    if not first_run(project) or normal_network_available(): return {"active": False, "reason": "not_needed"}
    ensure_profile(wifi_device)
    if nmcli("connection", "up", HOTSPOT, timeout=30).returncode != 0: raise NetworkError("Setup-Hotspot konnte nicht aktiviert werden.")
    portal(True); return {"active": True, "ssid": HOTSPOT}

def activate(project: Path, wifi_device: str | None = None) -> dict[str, Any]:
    with transition_lock(): return _activate(project, wifi_device)

def _reconcile(project: Path, wifi_device: str | None = None) -> None:
    """Make the setup AP follow first-run and NetworkManager state."""
    names = active_names()
    available = normal_network_available()
    if first_run(project) and not available:
        if HOTSPOT in names:
            portal(True)
            if read_transition()["phase"] == "connecting": write_transition("failed", error_code="wifi_connection_failed", recovery_available=True)
            return
        _activate(project, wifi_device)
        if read_transition()["phase"] == "connecting": write_transition("failed", error_code="wifi_connection_failed", recovery_available=True)
        return
    if HOTSPOT in names:
        if nmcli("connection", "down", HOTSPOT, timeout=20).returncode != 0:
            raise NetworkError("Setup-Hotspot konnte nicht beendet werden.")
    portal(False)
    if read_transition()["phase"] == "connecting": write_transition("connected" if available else "failed", error_code="" if available else "wifi_connection_failed")

def reconcile(project: Path, wifi_device: str | None = None) -> bool:
    """Reconcile unless a socket helper owns the single-radio handover."""
    try:
        with transition_lock(timeout=0.0): _reconcile(project, wifi_device)
    except NetworkError as exc:
        if str(exc) == "Eine WLAN-Aktion läuft bereits.": return False
        raise
    return True

def watcher_reconcile(project: Path, wifi_device: str | None = None) -> None:
    """Do not lose an NM event merely because a socket transaction owns the lock."""
    while not reconcile(project, wifi_device):
        time.sleep(1)

def watch(project: Path, wifi_device: str | None = None) -> None:
    """Event-driven first-run recovery; no periodic network polling."""
    # NetworkManager.service is considered started before a saved Wi-Fi
    # profile necessarily completes autoconnect. Give that one boot attempt a
    # bounded head start so the setup AP does not preempt a known WLAN.
    time.sleep(BOOT_NETWORK_GRACE_SECONDS)
    while True:
        monitor: subprocess.Popen[str] | None = None
        try:
            watcher_reconcile(project, wifi_device)
            monitor = subprocess.Popen(["nmcli", "monitor"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            assert monitor.stdout is not None
            for _line in monitor.stdout:
                watcher_reconcile(project, wifi_device)
        except (NetworkError, OSError, subprocess.SubprocessError):
            print("Zero Connect Netzwerkabgleich fehlgeschlagen; erneuter Versuch folgt.", file=sys.stderr, flush=True)
        finally:
            if monitor is not None and monitor.poll() is None:
                monitor.terminate()
                try: monitor.wait(timeout=2)
                except subprocess.TimeoutExpired: monitor.kill()
        time.sleep(5)

def scan() -> dict[str, Any]:
    result = nmcli("-t", "-f", "SSID", "device", "wifi", "list", "--rescan", "yes", timeout=30)
    if result.returncode != 0: raise NetworkError("WLAN-Netze konnten nicht gesucht werden.")
    return {"networks": sorted({x.strip() for x in result.stdout.splitlines() if x.strip()})}

def connect(project: Path, ssid: str, password: str, wifi_device: str | None = None) -> dict[str, Any]:
    if not first_run(project): raise NetworkError("WLAN-Ersteinrichtung ist nicht aktiv.")
    if not SSID_RE.fullmatch(ssid) or not PSK_RE.fullmatch(password): raise NetworkError("WLAN-Name oder Passwort ist ungültig.")
    device = wifi_device or managed_wifi_device()
    profile_name = "zero-connect-target-" + hashlib.sha256(ssid.encode()).hexdigest()[:16]
    # NetworkManager keyfile keeps the secret out of argv, logs, URLs and IPC replies.
    keyfile = "[connection]\nid=%s\ntype=wifi\ninterface-name=%s\nautoconnect=true\n\n[wifi]\nssid=%s\n\n[wifi-security]\nkey-mgmt=wpa-psk\npsk=%s\n\n[ipv4]\nmethod=auto\n\n[ipv6]\nmethod=auto\n" % (profile_name, device, ssid, password)
    # os.replace is atomic only within one filesystem.  /run is normally a
    # tmpfs while NetworkManager profiles live under /etc, so stage the secret
    # keyfile in its final filesystem.
    target = NETWORK_CONNECTIONS / (profile_name + ".nmconnection")
    with transition_lock():
        write_transition("connecting")
        NETWORK_CONNECTIONS.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".zero-connect-target-", suffix=".tmp", dir=NETWORK_CONNECTIONS)
        try:
            portal(False)
            if HOTSPOT in active_names():
                if nmcli("connection", "down", HOTSPOT, timeout=20).returncode != 0:
                    raise NetworkError("Setup-Hotspot konnte für den WLAN-Wechsel nicht beendet werden.")
            os.fchmod(fd, 0o600); os.write(fd, keyfile.encode()); os.close(fd); fd = -1
            os.replace(name, target); target.chmod(0o600)
            if nmcli("connection", "load", str(target)).returncode != 0:
                raise NetworkError("WLAN-Konfiguration konnte nicht vorbereitet werden.")
            result = nmcli("connection", "up", profile_name, timeout=45)
            if result.returncode != 0 or not target_wifi_connected(profile_name, device) or not normal_network_available():
                raise NetworkError("WLAN-Verbindung fehlgeschlagen.")
            if HOTSPOT in active_names(): nmcli("connection", "down", HOTSPOT, timeout=20)
            write_transition("connected")
            return {"connected": True}
        except (NetworkError, OSError, subprocess.SubprocessError):
            recovered = False
            try:
                try: nmcli("connection", "delete", profile_name, timeout=20)
                except (OSError, subprocess.SubprocessError): pass
                try: target.unlink(missing_ok=True)
                except OSError: pass
                try: recovered = bool(_activate(project, device).get("active"))
                except (NetworkError, OSError, subprocess.SubprocessError): recovered = False
            finally:
                write_transition("failed", error_code="wifi_connection_failed", recovery_available=recovered)
            raise NetworkError("WLAN-Verbindung fehlgeschlagen; der Setup-Hotspot ist wieder verfügbar.")
        finally:
            if fd >= 0: os.close(fd)
            Path(name).unlink(missing_ok=True)

def deactivate(project: Path) -> dict[str, Any]:
    with transition_lock():
        nmcli("connection", "down", HOTSPOT, timeout=20); portal(False)
        return {"active": False}

def handle(project: Path, request: dict[str, Any], wifi_device: str | None = None) -> dict[str, Any]:
    action = request.get("action")
    if action == "status": return {"first_run": first_run(project), "network_available": normal_network_available(), "hotspot_active": HOTSPOT in active_names(), "transition": read_transition()}
    if action == "ensure_hotspot": return activate(project, wifi_device)
    if action == "deactivate_hotspot": return deactivate(project)
    if action == "scan": return scan()
    if action == "connect": return connect(project, str(request.get("ssid", "")), str(request.get("password", "")), wifi_device)
    if action == "recover": return activate(project, wifi_device)
    raise NetworkError("Unzulässige Netzwerkaktion.")

def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--project-dir", type=Path, required=True); parser.add_argument("--watch", action="store_true"); parser.add_argument("--wifi-device"); args = parser.parse_args()
    if args.wifi_device is not None and not DEVICE_RE.fullmatch(args.wifi_device):
        parser.error("Ungültiges WLAN-Gerät")
    if args.watch:
        watch(args.project_dir.resolve(), args.wifi_device)
        return
    try:
        raw = sys.stdin.buffer.readline(8192); request = json.loads(raw.decode("utf-8"))
        if not isinstance(request, dict): raise NetworkError("Ungültige Anfrage.")
        response = {"ok": True, **handle(args.project_dir.resolve(), request, args.wifi_device)}
    except (NetworkError, OSError, ValueError, subprocess.SubprocessError): response = {"ok": False, "error": "WLAN-Aktion konnte nicht ausgeführt werden."}
    sys.stdout.write(json.dumps(response) + "\n"); sys.stdout.flush()

if __name__ == "__main__": main()
