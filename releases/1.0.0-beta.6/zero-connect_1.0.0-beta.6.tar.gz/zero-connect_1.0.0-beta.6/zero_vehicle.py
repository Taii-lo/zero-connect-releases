#!/usr/bin/env python3
"""Small, pure helpers for normalized vehicle freshness and session analytics.

The module deliberately does not invent telemetry. Optional energy and power
values are aggregated only when the persisted session actually contains them.
"""
from __future__ import annotations

from datetime import datetime, timezone
from statistics import mean
from typing import Any


def numeric(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def timestamp_epoch(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        pass
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except ValueError:
        return None


def freshness(age_seconds: Any, max_age_seconds: Any = 900) -> dict[str, Any]:
    """Return stable connectivity semantics without changing legacy UI state."""
    age = numeric(age_seconds)
    limit = max(1.0, numeric(max_age_seconds) or 900.0)
    if age is None:
        return {"state": "unknown", "age_seconds": None, "quality": "missing"}
    if age <= limit:
        state = "online"
        quality = "good"
    elif age <= limit * 4:
        state = "stale"
        quality = "partial"
    else:
        state = "offline"
        quality = "incomplete"
    return {"state": state, "age_seconds": round(max(0.0, age), 1), "quality": quality}


def daily_driver_context(facts: dict[str, Any]) -> dict[str, Any]:
    """Choose one deterministic daily-driver summary from already known facts."""
    charge = str(facts.get("charge_state") or "unavailable")
    vehicle = str(facts.get("vehicle_state") or "missing")
    limit = str(facts.get("time_limit_state") or "normal")
    maintenance = str(facts.get("maintenance_state") or "normal")
    plugged = bool(facts.get("plugged"))
    connected = bool(facts.get("still_connected", plugged))
    location_stale = bool(facts.get("location_stale"))
    secondary = None
    if vehicle != "current":
        kind, attention = "offline", "warning"
    elif limit == "reached":
        kind, attention = "time_limit_reached", "warning"
    elif maintenance in {"due", "overdue"}:
        kind, attention = "maintenance_due", "action-soon"
    elif limit == "soon" and charge == "completed" and connected:
        kind, attention = "charge_complete_plugged", "info"
        secondary = "time_limit_soon"
    elif limit == "soon":
        kind, attention = "time_limit_soon", "action-soon"
    elif maintenance == "soon":
        kind, attention = "maintenance_soon", "info"
    elif charge == "balancing":
        kind, attention = "balancing", "info"
    elif charge == "charging":
        kind, attention = "charging", "info"
    elif charge == "completed" and connected:
        kind, attention = "charge_complete_plugged", "info"
    elif plugged or charge == "connected_idle":
        kind, attention = "plugged_not_charging", "info"
    elif location_stale:
        kind, attention = "location_stale", "info"
    else:
        kind, attention = "normal", "normal"
    if secondary is None and vehicle == "current" and kind in {
        "time_limit_soon", "time_limit_reached", "maintenance_due", "maintenance_soon"
    }:
        if charge == "charging":
            secondary = "charging"
        elif charge == "balancing":
            secondary = "balancing"
        elif charge == "completed" and connected:
            secondary = "charge_complete_plugged"
        elif plugged:
            secondary = "plugged_not_charging"
    return {
        "kind": kind,
        "attention": attention,
        "secondary": secondary,
        "minutes_until_limit": facts.get("minutes_until_limit"),
        "maintenance_remaining_km": facts.get("maintenance_remaining_km"),
    }


def _window_start(record: dict[str, Any]) -> float | None:
    return timestamp_epoch(record.get("started_at_utc")) or timestamp_epoch(record.get("recorded_at_utc"))


def _duration(record: dict[str, Any]) -> float | None:
    duration = numeric(record.get("duration_seconds"))
    if duration is not None and duration >= 0:
        return duration
    start = timestamp_epoch(record.get("started_at_utc"))
    end = timestamp_epoch(record.get("ended_at_utc"))
    if start is not None and end is not None and end >= start:
        return end - start
    return None


def _period(records: list[dict[str, Any]], start_epoch: float | None) -> dict[str, Any]:
    selected = [r for r in records if start_epoch is None or (_window_start(r) or 0) >= start_epoch]
    durations = [d for r in selected if (d := _duration(r)) is not None]
    energies = [e for r in selected if (e := numeric(r.get("energy_added_kwh"))) is not None and e >= 0]
    powers = [p for r in selected if (p := numeric(r.get("average_power_kw"))) is not None and p >= 0]
    starts = [s for r in selected if (s := numeric(r.get("start_soc"))) is not None and 0 <= s <= 100]
    ends = [e for r in selected if (e := numeric(r.get("end_soc"))) is not None and 0 <= e <= 100]
    return {
        "sessions": len(selected),
        "duration_seconds": round(sum(durations)) if durations else None,
        "energy_added_kwh": round(sum(energies), 3) if energies else None,
        "average_power_kw": round(mean(powers), 2) if powers else None,
        "average_start_soc": round(mean(starts), 1) if starts else None,
        "average_end_soc": round(mean(ends), 1) if ends else None,
        "data_quality": "good" if selected and len(durations) == len(selected) else "partial" if selected else "empty",
    }


def analytics(records: list[dict[str, Any]], now_epoch: float) -> dict[str, Any]:
    """Aggregate only persisted session facts for 7 days, 30 days and all time."""
    return {
        "periods": {
            "7d": _period(records, now_epoch - 7 * 86400),
            "30d": _period(records, now_epoch - 30 * 86400),
            "all": _period(records, None),
        },
        "energy_source": "persisted_session_value_only",
    }
