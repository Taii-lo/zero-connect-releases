> AI development entry: [CLAUDE.md](CLAUDE.md) and [AGENTS.md](AGENTS.md).

# Zero Connect 1.0.0-beta.1

> Independent, unofficial project – not affiliated with Zero Motorcycles. See [NOTICE.md](NOTICE.md).

Internal version: 3.0.0-alpha.45

Zero Connect observes a Zero motorcycle through Zero Cloud, optionally uploads telemetry to ABRP, drives Aivi Live Activities and provides a local Web UI.

Round 12B makes charging locations readable, synchronizes selected map markers with the list, fixes lazy label resolution after settings navigation, and removes duplicate technical/navigation controls from the Overview. The appliance/SD image baseline remains Beta 36; this app release does not build or update a Pi image.

In the legacy heuristic phase named `balancing` (not measured cell balancing), qualified `reason=5` ignition-off evidence from both the
normal status poll and a bounded read-only Zero History poll receives a short
confirmation window. Charging-off and the existing sleep timeout remain the
stronger/fallback completion paths.

## Normal use

```bash
zero-connect status
zero-connect doctor
zero-connect history
zero-connect web
```

Open the Production Web App at your own Tailscale address (Settings → Remote access
shows and stores it, for example `https://<device>.<your-tailnet>.ts.net`) while
Tailscale is connected. The local diagnostic fallback remains
`http://zero-pi.local:8080`.

The normal settings include persistent choices for the supported Zero SR/S
(blue), Zero SR/F (black) and Zero DSR/X (white) vehicle images (downloaded on first use from the manufacturer, or your own photo). While an
image loads—or if it cannot load—the reserved area stays neutral; no generic
motorcycle illustration is shown.

The location card is an interactive OpenStreetMap map with a clearly marked
last known position and its measurement time. Leaflet itself is bundled
locally; when the map is visible, the browser requests only the needed OSM
tiles without API keys or additional vehicle/account parameters. This lets the
tile service technically infer the requested map area and client IP. The map
shows the required OpenStreetMap attribution and can fail without affecting the
rest of the local dashboard. The precise location and map require the existing
Admin-PIN session; without it, only the last measurement time is shown locally.

The local Web UI separates the daily overview, charging details, history,
normal settings and technical system tools into five compact tabs; phones use
a safe-area-aware bottom navigation so every area remains reachable.

## Homescreen app

The local Web UI includes a web app manifest, local Zero Connect icons and the
Apple Homescreen metadata. After adding it to the Homescreen, supported iPhone
and Android browsers start it in standalone mode at the overview; normal
browser use remains unchanged. No Service Worker is registered, so this release
does not cache the UI for offline use and updates cannot be held back by a
stale application cache.

Reliable Chromium installability and Service Worker features require HTTPS (or
localhost). Production uses the Tailscale HTTPS address as the
canonical Homescreen address; `http://zero-pi.local:8080` remains the local
diagnostic fallback. TestPi is local-only at
`http://zero-connect-test.local:8080`; it does not use Tailscale.

On a fresh installation the Web UI opens a guided first-run wizard. It walks
through the vehicle and Zero Cloud connection first, with optional Aivi and
ABRP steps. Credentials are stored locally and are never returned to the
browser. The wizard can be reopened from the System tab.

## Aivi Live Activity

Create one Aivi **Progress** Live Activity, for example `zero-srs`. Zero Connect
uses that same activity while charging, during the legacy post-charge heuristic phase and for the final
charging summary. The summary stays visible for 10 minutes by default.

Set Aivi's **Dismissal Delay to immediate**. Zero Connect controls the summary
lifetime and closes it before a subsequent charging session starts.

Synthetic test:

```bash
zero-connect aivi-test --interval 10 --final-hold 30
```

Reset all configured Aivi activities:

```bash
zero-connect aivi-test reset
```

`zero-connect aivi-test idle` is an alias for the same reset.

## Web UI security

Read-only status pages are available on the local network. Precise location and map access require the existing Admin-PIN session. Configuration
changes, diagnostics, restart, support export and Admin-PIN changes also require
the six-digit Admin PIN entered in the local action dialog. A successful unlock
lasts 20 minutes in a server-side session:

```bash
zero-connect web
```

Stored passwords and API tokens are never returned to the browser.

## Developer workflow

Call `zero-dev` to start Claude Code in `~/ZeroConnect-dev` (tmux session `zero-dev`). It develops,
tests and builds only in that repository; Production changes go through the guarded `tools/prod` / `tools/release.py`
transaction (see `docs/AUTOPILOT.md`). The development dependencies live separately in
`~/ZeroConnect-dev/.venv`; no production interpreter is used for the pre-deployment test run.

For the dedicated hardware-test Pi, the safe non-destructive readiness smoke
run is:

```bash
./tools/testpi beta-gate
```

It checks the hardware guard, service/API health, required charging fixtures,
all dashboard/charging/settings views on iPhone and desktop emulation, and
repository diff cleanliness. It does not reboot, interrupt networking, run
service chaos, or trigger vehicle actions. A real charge, external Aivi/ABRP
credentials and push transport remain outside this gate; push notifications
are not part of the current beta.

### Production workflow

Production uses the appliance layout (`/opt/zero-connect`,
`/etc/zero-connect`, `/var/lib/zero-connect`, `/run/zero-connect`) and system
services running as `zero-connect`. The canonical commands are:

```bash
./tools/prod status
./tools/prod doctor
./tools/prod migrate --execute   # one-time legacy migration
./tools/prod deploy              # subsequent releases
./tools/prod verify
./tools/prod rollback
```

Migration creates a restricted legacy backup, preserves configuration,
credentials, state, history and sessions, and switches services only after
the appliance tree is ready. Deployments record the exact source revision in
`/opt/zero-connect/.deploy-revision`; failed health checks restore the previous
immutable application tree while leaving mutable state in place.
The direct `./tools/prod deploy` entry point also enforces the Autopilot
deployment window, client-idle heartbeat, fresh unplugged vehicle state,
recent-movement quiet period, inactive Aivi activity, and shared deploy lock
before it builds or installs a release.

## Diagnostics

```bash
zero-connect diagnostics
zero-connect support --export
```

Exports redact location, identifiers and local system identity by default and never include `.env`.
