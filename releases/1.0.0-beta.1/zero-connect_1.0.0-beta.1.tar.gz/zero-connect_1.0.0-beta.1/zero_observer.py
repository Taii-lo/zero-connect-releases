#!/usr/bin/env python3

"""Zero Connect cloud observer 1.0.0-beta.1 (internal v3.0.0-alpha.45).

Features:
- robust freshness evaluation using datetime_actual and datetime_utc
- adaptive polling
- ABRP telemetry with validated values
- persistent diagnostics for zero-status
- direct optional Aivi Live Activity integration
- synthetic and real-recording regression tests
- high-priority quiet Aivi updates, phase colors and one-minute interpolation
- Aivi-managed final dismissal with a short IDLE handoff
- DNS-safe startup retry without credential leakage in logs
"""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import math
import os
import signal
import shutil
import sys
import tempfile
import threading
import time
from contextlib import contextmanager
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import requests
import zero_charging
import zero_functional
from dotenv import load_dotenv
from zero_paths import PATHS

try:  # Linux appliance; retain importability on Windows development hosts.
    import fcntl
except ImportError:  # pragma: no cover - Windows development fallback
    fcntl = None


PROJECT_DIR = PATHS.program_dir
DATA_DIR = PATHS.data_dir
ENV_FILE = PATHS.secrets_file
CONFIG_FILE = PATHS.config_file

ZERO_API_URL = "https://mongol.brono.com/mongol/api.php"
ABRP_API_URL = "https://api.iternio.com/1/tlm/send"
MILES_TO_KM = 1.609344
ABRP_DIAGNOSTIC_FILE = PATHS.data_dir / "abrp_last_telemetry.json"


def _coordinate_hash(latitude: float, longitude: float) -> str:
    value = f"{latitude:.7f},{longitude:.7f}".encode("ascii")
    return hashlib.sha256(value).hexdigest()[:16]
LOCAL_TZ = datetime.now().astimezone().tzinfo
HISTORY_POLL_INTERVAL_SECONDS = 60
HISTORY_POLL_OVERLAP_SECONDS = 180
HISTORY_CONFIRMATION_SECONDS = 60
HISTORY_BACKOFF_INITIAL_SECONDS = 60
HISTORY_BACKOFF_MAX_SECONDS = 240
HISTORY_MAX_SEEN_EVENTS = 256
HISTORY_TERMINAL_FOLLOWUP_SECONDS = 900

HISTORY_FILE = DATA_DIR / "zero_valid_changes_v2.jsonl"
RAW_HISTORY_FILE = DATA_DIR / "zero_raw_changes_v2.jsonl"
LATEST_FILE = DATA_DIR / "last_valid_transmit.json"
LATEST_RAW_FILE = DATA_DIR / "last_raw_transmit.json"
RUNTIME_STATE_FILE = DATA_DIR / "runtime_state_v2.json"
LOG_DIR = DATA_DIR / "logs"
POLL_HISTORY_DIR = DATA_DIR / "polls"
EVENT_HISTORY_DIR = DATA_DIR / "events"
SESSION_HISTORY_DIR = DATA_DIR / "sessions"
CHARGING_SAMPLE_DIR = DATA_DIR / "charging-samples"
_FILE_LOGGER: logging.Logger | None = None
_RUNTIME_STATE_LOCK = threading.RLock()


class SecureTimedRotatingFileHandler(TimedRotatingFileHandler):
    def _open(self):  # type: ignore[no-untyped-def]
        stream = super()._open()
        try:
            os.chmod(self.baseFilename, 0o600)
        except OSError:
            pass
        return stream

REAL_FIXTURE_CANDIDATES = (
    PROJECT_DIR / "tests" / "fixtures" / "charge_65.jsonl",
    DATA_DIR / "zero_raw_samples.jsonl",
)
REAL_100_FIXTURE = PROJECT_DIR / "tests" / "fixtures" / "charge_100_20260814.jsonl"
REAL_100_SLEEP_FIXTURE = PROJECT_DIR / "tests" / "fixtures" / "charge_100_20260815_sleep.jsonl"
REAL_TARGET90_THEN_100_FIXTURE = PROJECT_DIR / "tests" / "fixtures" / "charge_target90_then_100_20260824.jsonl"

FINGERPRINT_FIELDS = (
    "datetime_utc",
    "datetime_actual",
    "soc",
    "charging",
    "chargecomplete",
    "pluggedin",
    "chargingtimeleft",
    "latitude",
    "longitude",
    "altitude",
    "heading",
    "velocity",
    "mileage",
    "gps_valid",
    "ignition",
    "logic_state",
    "reason",
    "response",
)

DEFAULT_CONFIG: dict[str, Any] = {
    "schema_version": 5,
    "vehicle_label": "Zero Motorcycle",
    "vehicle_model": "Zero Motorcycle",
    "request_timeout_seconds": 30,
    "freshness": {
        "max_contact_age_seconds": 15 * 60,
        "future_tolerance_seconds": 5 * 60,
    },
    "odometer": {
        "source_field": "mileage",
        "source_unit": "mi",
        # Provider telemetry is calibrated from an independently verified
        # vehicle display reading.  The offset is zero for new installations;
        # production may persist an evidence-backed vehicle-specific offset.
        "offset_km": 0.0,
    },
    "polling": {
        "charging_seconds": 30,
        "recent_seconds": 30,
        "idle_seconds": 30,
        "recent_window_seconds": 15 * 60,
        "error_initial_seconds": 30,
        "error_max_seconds": 5 * 60,
    },
    "abrp": {
        "enabled": False,
        "min_interval_seconds": 55,
        "error_initial_seconds": 60,
        "error_max_seconds": 900,
    },
    "charging": {
        "sample_interval_seconds": 120,
        "interruption_confirmation_polls": 2,
        "full_target_fallback_soc": 100,
        "full_target_requires_zero_minutes": True,
        "complete_after_target_when_idle": True,
        "balancing_sleep_completion": {
            "enabled": True,
            "timeout_seconds": 360,
            "confirmation_polls": 3,
            "require_full_soc": True,
            "require_zero_minutes": True
        },
    },
    "diagnostics": {
        "retention_days": 180,
        "cleanup_interval_hours": 24,
        "persistent_text_log": True,
        "poll_history": True,
        "event_history": True,
        "export_default_days": 7,
        "max_size_mib": 2048,
    },
    "aivi": {
        "enabled": False,
        "language": "de",
        "request_timeout_seconds": 15,
        "error_initial_seconds": 60,
        "error_max_seconds": 900,
        "activity_slug": "zero-connect",
        "mode": "single_progress",
        "balancing_activity_slug": "",
        "complete_activity_slug": "",
        "finalize_delay_seconds": 5,
        "complete_summary_seconds": 600,
        "balancing_update_seconds": 60,
        "live_activity": {
            "template": "progress",
            "intermediate_delay_seconds": 60,
            "styles": {
                "charging": {
                    "icon": "motorcycle.fill",
                    "icon_color": "blue",
                    "icon_rendering_mode": "hierarchical",
                    "icon_color_rendering": "gradient",
                    "header_color": "blue",
                    "progress_color": "blue",
                },
                "target_reached": {
                    "icon": "motorcycle.fill",
                    "icon_color": "orange",
                    "icon_rendering_mode": "hierarchical",
                    "icon_color_rendering": "gradient",
                    "header_color": "orange",
                    "progress_color": "orange",
                },
                "complete": {
                    "icon": "checkmark.circle.fill",
                    "icon_color": "green",
                    "icon_rendering_mode": "hierarchical",
                    "icon_color_rendering": "gradient",
                    "header_color": "green",
                    "progress_color": "green",
                },
                "ended": {
                    "icon": "checkmark.circle.fill",
                    "icon_color": "green",
                    "icon_rendering_mode": "hierarchical",
                    "icon_color_rendering": "gradient",
                    "header_color": "green",
                    "progress_color": "green",
                },
                "interrupted": {
                    "icon": "exclamationmark.triangle.fill",
                    "icon_color": "red",
                    "icon_rendering_mode": "hierarchical",
                    "icon_color_rendering": "flat",
                    "header_color": "gray",
                    "progress_color": "gray3",
                },
            },
            "labels": {
                "charging": "Laden",
                "charging_right": "Ladezeit",
                "target": "Ladevorgang abgeschlossen",
                "target_right": "Weiterhin angesteckt",
                "complete": "Laden abgeschlossen",
                "complete_right": "Vollständig geladen",
                "ended": "Laden beendet",
                "ended_right": "Vom Ladepunkt getrennt",
                "balancing_ended": "Laden beendet",
                "balancing_ended_right": "Zellenausgleich beendet",
                "interrupted": "Ladeunterbrechung",
                "interrupted_right": "Kabel angeschlossen",
                "balancing_interrupted": "Zellenausgleich unterbrochen",
                "balancing_interrupted_right": "Kabel angeschlossen",
            },
        },
    },
    "web": {
        "enabled": True,
        "host": "0.0.0.0",
        "port": 8080,
    },
    "setup": {
        "completed": False,
        "forced": False,
        "wizard_started": False,
        "step": "welcome",
    },
}

# ---------------------------------------------------------------------------
# General helpers and configuration
# ---------------------------------------------------------------------------


def configure_persistent_logging(config: dict[str, Any]) -> None:
    """Enable app-local persistent logs without making diagnostics a core dependency."""
    global _FILE_LOGGER
    _FILE_LOGGER = None
    if not bool(config.get("diagnostics", {}).get("persistent_text_log", True)):
        return
    retention_days = max(1, int(config.get("diagnostics", {}).get("retention_days", 180)))
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        DATA_DIR.chmod(0o700)
        for directory in (LOG_DIR, POLL_HISTORY_DIR, EVENT_HISTORY_DIR, SESSION_HISTORY_DIR):
            directory.mkdir(parents=True, exist_ok=True)
            directory.chmod(0o700)
        logger = logging.getLogger("zero-connect-persistent")
        logger.setLevel(logging.INFO)
        logger.propagate = False
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass
        handler = SecureTimedRotatingFileHandler(
            LOG_DIR / "observer.log",
            when="midnight",
            interval=1,
            backupCount=retention_days,
            encoding="utf-8",
            delay=True,
        )
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
        _FILE_LOGGER = logger
    except OSError as error:
        print(
            f"[Zero Connect] Warnung: persistentes Logging nicht verfügbar: {error}",
            flush=True,
        )


def log(message: str) -> None:
    now = datetime.now(LOCAL_TZ).strftime("%Y-%m-%d %H:%M:%S %Z")
    line = f"[{now}] {message}"
    print(line, flush=True)
    if _FILE_LOGGER is not None:
        try:
            _FILE_LOGGER.info(line)
        except Exception:
            # Persistent diagnostics must never stop the observer.
            pass


def configure_console_output() -> None:
    """Keep CLI logging non-fatal on consoles with limited encodings."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if not callable(reconfigure):
            continue
        try:
            reconfigure(errors="replace")
        except (OSError, ValueError):
            pass


def to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return False


def vehicle_gps_coordinates(status: dict[str, Any]) -> tuple[float, float] | None:
    """Return a non-null vehicle coordinate; quality is conveyed separately."""
    latitude = to_float_or_none(status.get("latitude"))
    longitude = to_float_or_none(status.get("longitude"))
    if latitude is None or longitude is None or not -90 <= latitude <= 90 or not -180 <= longitude <= 180 or (latitude == 0 and longitude == 0):
        return None
    # Production emits useful non-zero coordinates while gps_valid and
    # satellite flags are transiently low. Consumers must share the point and
    # expose quality/freshness instead of silently falling back to an older one.
    return latitude, longitude


def to_float_or_none(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def vehicle_odometer_km(
    status: dict[str, Any], config: dict[str, Any] | None = None
) -> float | None:
    """Return the canonical odometer in kilometres from Zero's mileage field.

    Zero Cloud exposes ``mileage`` in miles; all internal consumers use km.
    Keeping this conversion in one function prevents reminder/session drift.
    """
    mileage = to_float_or_none(status.get("mileage"))
    if mileage is None or not math.isfinite(mileage) or mileage < 0:
        return None
    settings = config or DEFAULT_CONFIG
    odometer_cfg = settings.get("odometer", {}) if isinstance(settings, dict) else {}
    offset = to_float_or_none(odometer_cfg.get("offset_km")) if isinstance(odometer_cfg, dict) else None
    if offset is None:
        offset = 0.0
    return mileage * MILES_TO_KM + offset


# A real odometer cannot jump far ahead between two reports. Zero's report times are
# coarse (rides show up to ~150 mph between reports), so the bound is generous; a
# bigger jump is only taken once later reports confirm the new level.
ODOMETER_JUMP_MIN_KM = 40.0
ODOMETER_JUMP_MAX_KMH = 400.0
ODOMETER_JUMP_CONFIRMATIONS = 2


def preserve_monotonic_odometer(
    status: dict[str, Any], state: dict[str, Any], config: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Keep the last valid odometer when a poll is null, arrives out of order or jumps implausibly."""
    candidate = vehicle_odometer_km(status, config)
    previous = to_float_or_none(state.get("last_odometer_km"))
    if previous is not None and not math.isfinite(previous):
        previous = None
    previous_raw = state.get("last_odometer_raw")
    if candidate is None:
        if previous is not None and previous_raw is not None:
            status["mileage"] = previous_raw
        return status
    if previous is not None and candidate < previous - 0.1 and previous_raw is not None:
        status["mileage"] = previous_raw
        return status
    if previous is not None and previous_raw is not None:
        report_epoch = status_contact_epoch(status)
        last_seen = timestamp_or_none(state.get("last_odometer_observed_at"))
        elapsed = report_epoch - last_seen.timestamp() if report_epoch and last_seen else 0.0
        allowed = max(ODOMETER_JUMP_MIN_KM, ODOMETER_JUMP_MAX_KMH * max(0.0, elapsed) / 3600)
        if candidate > previous + allowed:
            pending = to_float_or_none(state.get("odometer_jump_pending_km"))
            pending_epoch = to_float_or_none(state.get("odometer_jump_pending_epoch")) or 0.0
            if pending is not None and pending - 0.1 <= candidate <= pending + ODOMETER_JUMP_MIN_KM:
                if report_epoch > pending_epoch:  # the same report polled again confirms nothing
                    state["odometer_jump_confirmations"] = int(state.get("odometer_jump_confirmations") or 0) + 1
            else:
                state["odometer_jump_confirmations"] = 0
            state["odometer_jump_pending_km"] = candidate
            state["odometer_jump_pending_epoch"] = max(report_epoch, pending_epoch) if pending is not None else report_epoch
            if int(state.get("odometer_jump_confirmations") or 0) < ODOMETER_JUMP_CONFIRMATIONS:
                status["mileage"] = previous_raw
                return status
    for key in ("odometer_jump_pending_km", "odometer_jump_pending_epoch", "odometer_jump_confirmations"):
        state.pop(key, None)
    state["last_odometer_km"] = candidate
    state["last_odometer_raw"] = status.get("mileage")
    state["last_odometer_observed_at"] = status.get("datetime_utc") or status.get("datetime_actual")
    return status


def to_float(value: Any, default: float = 0.0) -> float:
    converted = to_float_or_none(value)
    return default if converted is None else converted


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


CONFIG_SCHEMA_VERSION = 5
DIAGNOSTICS_MIN_SIZE_MIB = 100
DIAGNOSTICS_MAX_SIZE_MIB = 1_048_576


def migrate_config(user_config: dict[str, Any]) -> dict[str, Any]:
    """Migrate persisted configuration without discarding user choices."""
    migrated = copy.deepcopy(user_config)
    try:
        version = int(migrated.get("schema_version", 1) or 1)
    except (TypeError, ValueError):
        version = 1
    if version > CONFIG_SCHEMA_VERSION:
        raise RuntimeError(
            f"Konfigurationsschema {version} ist neuer als unterstützt ({CONFIG_SCHEMA_VERSION})."
        )
    if version < 2:
        migrated["schema_version"] = 2
        version = 2
    if version < 3:
        migrated["schema_version"] = 3
        aivi = migrated.setdefault("aivi", {})
        aivi.setdefault("mode", "legacy")
        aivi.setdefault("balancing_activity_slug", "")
        aivi.setdefault("complete_activity_slug", "")
        migrated.setdefault("web", {"enabled": True, "host": "0.0.0.0", "port": 8080})
        version = 3
    if version < 4:
        migrated["schema_version"] = 4
        aivi = migrated.setdefault("aivi", {})
        aivi.setdefault("complete_summary_seconds", 600)
        aivi.setdefault("balancing_update_seconds", 60)
        version = 4
    if version < 5:
        migrated["schema_version"] = 5
        migrated.setdefault(
            "vehicle_model",
            str(migrated.get("vehicle_label") or "Zero Motorcycle"),
        )
        # Beta 8 uses one Progress activity for charging, balancing and the
        # completion summary. Historical Monitor slugs remain persisted so an
        # in-flight Beta-7 activity can be closed during the runtime handoff.
        migrated.setdefault("aivi", {})["mode"] = "single_progress"
        version = 5
    aivi = migrated.setdefault("aivi", {})
    if str(aivi.get("mode", "single_progress")).strip().lower() in {
        "legacy",
        "three_phase",
    }:
        aivi["mode"] = "single_progress"
    migrated.setdefault(
        "setup",
        {"completed": False, "forced": False, "wizard_started": False, "step": "welcome"},
    )
    if not isinstance(migrated.get("odometer"), dict):
        migrated["odometer"] = {}
    return migrated


_CONFIG_FALLBACK_LOGGED: list[bool] = []


def config_backup_path(path: Path = CONFIG_FILE) -> Path:
    return path.with_name(path.name + ".last-good")


def _parse_config_file(path: Path) -> dict[str, Any]:
    try:
        user_config = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise RuntimeError(f"Konfigurationsdatei unlesbar: {error}") from error

    if not isinstance(user_config, dict):
        raise RuntimeError("zero_config.json muss ein JSON-Objekt enthalten.")

    try:
        config = deep_merge(DEFAULT_CONFIG, migrate_config(user_config))
        validate_config(config)
    except RuntimeError:
        raise
    except (AttributeError, KeyError, TypeError, ValueError) as error:
        raise RuntimeError(f"zero_config.json enthält ungültige Werte: {type(error).__name__}") from error
    return config


def load_config(path: Path = CONFIG_FILE) -> dict[str, Any]:
    if not path.exists():
        log("zero_config.json fehlt; verwende sichere Standardwerte.")
        return copy.deepcopy(DEFAULT_CONFIG)

    try:
        return _parse_config_file(path)
    except RuntimeError as error:
        # A damaged file (power loss, hand edit) must not lock the owner out:
        # fall back to the copy of the last configuration that was saved intact.
        backup = config_backup_path(path)
        if not backup.exists():
            raise
        try:
            config = _parse_config_file(backup)
        except RuntimeError:
            raise error from None
        if not _CONFIG_FALLBACK_LOGGED:
            _CONFIG_FALLBACK_LOGGED.append(True)
            log(f"Warnung: {error} Verwende den zuletzt gespeicherten intakten Stand.")
        return config


def positive_number(value: Any, name: str) -> float:
    number = to_float_or_none(value)
    if number is None or number <= 0:
        raise RuntimeError(f"Ungültiger Konfigurationswert {name}: {value!r}")
    return number


def validate_config(config: dict[str, Any]) -> None:
    if int(config.get("schema_version", 0) or 0) != CONFIG_SCHEMA_VERSION:
        raise RuntimeError(
            f"schema_version muss {CONFIG_SCHEMA_VERSION} sein."
        )
    positive_number(config["request_timeout_seconds"], "request_timeout_seconds")
    odometer_cfg = config.get("odometer", {})
    if not isinstance(odometer_cfg, dict):
        raise RuntimeError("odometer muss ein Objekt sein.")
    source_field = str(odometer_cfg.get("source_field", "mileage"))
    if source_field != "mileage":
        raise RuntimeError("odometer.source_field muss 'mileage' sein.")
    if str(odometer_cfg.get("source_unit", "mi")).lower() not in {"mi", "mile", "miles"}:
        raise RuntimeError("odometer.source_unit muss 'mi' sein.")
    offset = to_float_or_none(odometer_cfg.get("offset_km", 0.0))
    if offset is None or not -100000 <= offset <= 100000:
        raise RuntimeError("odometer.offset_km ist ungueltig.")
    for key in ("max_contact_age_seconds", "future_tolerance_seconds"):
        positive_number(config["freshness"][key], f"freshness.{key}")
    for key in (
        "charging_seconds",
        "recent_seconds",
        "idle_seconds",
        "recent_window_seconds",
        "error_initial_seconds",
        "error_max_seconds",
    ):
        positive_number(config["polling"][key], f"polling.{key}")
    positive_number(config["abrp"]["min_interval_seconds"], "abrp.min_interval_seconds")
    positive_number(config["abrp"]["error_initial_seconds"], "abrp.error_initial_seconds")
    positive_number(config["abrp"]["error_max_seconds"], "abrp.error_max_seconds")
    confirmations = int(config["charging"]["interruption_confirmation_polls"])
    if confirmations < 2:
        raise RuntimeError(
            "charging.interruption_confirmation_polls muss mindestens 2 sein."
        )
    fallback_soc = int(config["charging"].get("full_target_fallback_soc", 100))
    if not 90 <= fallback_soc <= 100:
        raise RuntimeError("charging.full_target_fallback_soc muss zwischen 90 und 100 liegen.")
    sleep_cfg = config["charging"].get("balancing_sleep_completion", {})
    positive_number(sleep_cfg.get("timeout_seconds", 360), "charging.balancing_sleep_completion.timeout_seconds")
    sleep_confirmations = int(sleep_cfg.get("confirmation_polls", 3))
    if sleep_confirmations < 2:
        raise RuntimeError("charging.balancing_sleep_completion.confirmation_polls muss mindestens 2 sein.")
    retention = int(config.get("diagnostics", {}).get("retention_days", 180))
    if retention < 1:
        raise RuntimeError("diagnostics.retention_days muss mindestens 1 sein.")
    cleanup_hours = float(config.get("diagnostics", {}).get("cleanup_interval_hours", 24))
    if cleanup_hours <= 0:
        raise RuntimeError("diagnostics.cleanup_interval_hours muss > 0 sein.")
    max_size_mib = int(config.get("diagnostics", {}).get("max_size_mib", 2048))
    if not DIAGNOSTICS_MIN_SIZE_MIB <= max_size_mib <= DIAGNOSTICS_MAX_SIZE_MIB:
        raise RuntimeError(
            "diagnostics.max_size_mib muss zwischen "
            f"{DIAGNOSTICS_MIN_SIZE_MIB} und {DIAGNOSTICS_MAX_SIZE_MIB} liegen."
        )

    aivi_config = config["aivi"]
    if str(aivi_config.get("language", "de")).lower() not in {"de", "en"}:
        raise RuntimeError("aivi.language muss 'de' oder 'en' sein.")
    positive_number(
        aivi_config["request_timeout_seconds"],
        "aivi.request_timeout_seconds",
    )
    positive_number(aivi_config["error_initial_seconds"], "aivi.error_initial_seconds")
    positive_number(aivi_config["error_max_seconds"], "aivi.error_max_seconds")
    positive_number(
        aivi_config["finalize_delay_seconds"],
        "aivi.finalize_delay_seconds",
    )
    positive_number(
        aivi_config.get("complete_summary_seconds", 600),
        "aivi.complete_summary_seconds",
    )
    positive_number(
        aivi_config.get("balancing_update_seconds", 60),
        "aivi.balancing_update_seconds",
    )
    live_config = aivi_config["live_activity"]
    positive_number(
        live_config["intermediate_delay_seconds"],
        "aivi.live_activity.intermediate_delay_seconds",
    )
    if str(live_config.get("template")) != "progress":
        raise RuntimeError("aivi.live_activity.template muss 'progress' sein.")

    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")

    def validate_slug(value: Any, name: str, *, allow_empty: bool = False) -> str:
        slug_value = str(value or "").strip()
        if allow_empty and not slug_value:
            return slug_value
        if not slug_value or len(slug_value) > 128 or any(char not in allowed for char in slug_value):
            raise RuntimeError(
                f"{name} darf nur Buchstaben, Zahlen, Bindestriche und Unterstriche enthalten."
            )
        return slug_value

    validate_slug(aivi_config.get("activity_slug", ""), "aivi.activity_slug")
    mode = str(aivi_config.get("mode", "single_progress")).strip().lower()
    if mode not in {"single_progress", "legacy", "three_phase"}:
        raise RuntimeError(
            "aivi.mode muss 'single_progress', 'legacy' oder 'three_phase' sein."
        )
    balancing_slug = validate_slug(
        aivi_config.get("balancing_activity_slug", ""),
        "aivi.balancing_activity_slug",
        allow_empty=True,
    )
    complete_slug = validate_slug(
        aivi_config.get("complete_activity_slug", ""),
        "aivi.complete_activity_slug",
        allow_empty=True,
    )
    if mode == "three_phase" and (not balancing_slug or not complete_slug):
        raise RuntimeError("Aivi-Dreiphasenmodus benötigt Balancing- und Abschluss-Slug.")

    web_cfg = config.get("web", {})
    port = int(web_cfg.get("port", 8080))
    if not 1 <= port <= 65535:
        raise RuntimeError("web.port muss zwischen 1 und 65535 liegen.")
    if not str(web_cfg.get("host", "0.0.0.0")).strip():
        raise RuntimeError("web.host darf nicht leer sein.")

    required_styles = {"charging", "target_reached", "complete", "ended", "interrupted"}
    styles = live_config.get("styles", {})
    missing_styles = required_styles.difference(styles)
    if missing_styles:
        raise RuntimeError(
            "Fehlende Aivi-Live-Activity-Stile: " + ", ".join(sorted(missing_styles))
        )

    valid_colors = {
        "red", "orange", "yellow", "green", "mint", "teal", "cyan", "blue",
        "indigo", "purple", "pink", "brown", "gray", "gray2", "gray3",
        "gray4", "gray5", "gray6",
    }
    for phase, style in styles.items():
        if not isinstance(style, dict) or not str(style.get("icon", "")).strip():
            raise RuntimeError(f"Aivi-Stil {phase} benötigt ein SF-Symbol.")
        for field in ("icon_color", "header_color", "progress_color"):
            if str(style.get(field)) not in valid_colors:
                raise RuntimeError(
                    f"Aivi-Stil {phase}.{field} enthält eine ungültige Farbe."
                )

def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        temporary.chmod(0o600)
        os.replace(temporary, path)
        path.chmod(0o600)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try: os.fsync(directory_fd)
        finally: os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def append_jsonl(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = (json.dumps(value, ensure_ascii=False) + "\n").encode("utf-8")
    fd = os.open(path, os.O_RDWR | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        size = os.lseek(fd, 0, os.SEEK_END)
        if size and os.pread(fd, 1, size - 1) != b"\n":
            line = b"\n" + line  # a line cut short by a power loss must not swallow the next record
        try:
            written = 0
            while written < len(line):
                written += os.write(fd, line[written:])
        except OSError:
            # Full storage: drop the partial line instead of leaving it behind.
            try:
                os.ftruncate(fd, size)
            except OSError:
                pass
            raise
    finally:
        os.close(fd)
    path.chmod(0o600)


def safe_append_jsonl(path: Path, value: dict[str, Any], state: dict[str, Any] | None = None) -> bool:
    try:
        append_jsonl(path, value)
        if state is not None:
            state["last_diagnostics_error"] = ""
        return True
    except OSError as error:
        if state is not None:
            state["last_diagnostics_error"] = f"Diagnosedaten konnten nicht geschrieben werden: {error}"
        log("Warnung: Diagnosedaten konnten nicht geschrieben werden; Observer läuft weiter.")
        return False


def diagnostics_daily_path(directory: Path, prefix: str, now_epoch: float | None = None) -> Path:
    if now_epoch is None:
        now_epoch = time.time()
    date_text = datetime.fromtimestamp(now_epoch, LOCAL_TZ).strftime("%Y-%m-%d")
    # Directory creation happens inside append_jsonl and is therefore covered by
    # safe_append_jsonl's OSError handling. Diagnostics must never stop polling.
    return directory / f"{prefix}-{date_text}.jsonl"


def json_time(value: datetime | None) -> str | None:
    return value.isoformat() if value is not None else None


def save_poll_diagnostic(
    raw_status: dict[str, Any],
    valid_status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    time_info: dict[str, Any],
    now_epoch: float,
    *,
    raw_changed: bool,
    valid_changed: bool,
    soc_accepted: bool,
    soc_note: str | None,
    fresh: bool,
    phase_before: str,
    phase_after: str,
    state_events: list[str],
) -> None:
    if not bool(config.get("diagnostics", {}).get("poll_history", True)):
        return
    record = {
        "fetched_at_utc": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(),
        "fresh": fresh,
        "raw_changed": raw_changed,
        "valid_changed": valid_changed,
        "soc_accepted": soc_accepted,
        "soc_note": soc_note,
        "phase_before": phase_before,
        "phase_after": phase_after,
        "state_events": list(state_events),
        "session_generation": int(state.get("charge_session_generation", 0)),
        "session_active": bool(state.get("session_active", False)),
        "target_soc": state.get("target_soc"),
        "target_source": state.get("target_source", ""),
        "confidence": state.get("charge_state_confidence", "unknown"),
        "completion_source": state.get("charge_completion_source", ""),
        "completion_reason": state.get("completion_reason", ""),
        "balancing_end_evidence": state.get("balancing_end_evidence", ""),
        "balancing_end_at": state.get("balancing_end_at_epoch", 0.0),
        "completion_detected_at": state.get("completion_detected_at_epoch", 0.0),
        "history_last_event": state.get("history_last_event_epoch", 0.0),
        "history_candidate": state.get("balancing_end_candidate_epoch", 0.0),
        "time": {
            "measurement": json_time(time_info.get("measurement_time")),
            "actual": json_time(time_info.get("actual_time")),
            "contact": json_time(time_info.get("contact_time")),
            "measurement_age_seconds": time_info.get("measurement_age_seconds"),
            "contact_age_seconds": time_info.get("contact_age_seconds"),
        },
        "raw_status": raw_status,
        "valid_status": valid_status,
    }
    safe_append_jsonl(diagnostics_daily_path(POLL_HISTORY_DIR, "poll", now_epoch), record, state)


def save_event_diagnostic(
    event_type: str,
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
    **details: Any,
) -> None:
    if not bool(config.get("diagnostics", {}).get("event_history", True)):
        return
    record = {
        "recorded_at_utc": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(),
        "event_type": event_type,
        "phase": str(state.get("charge_phase", "unknown")),
        "session_generation": int(state.get("charge_session_generation", 0)),
        "session_active": bool(state.get("session_active", False)),
        "target_soc": state.get("target_soc"),
        "target_source": state.get("target_source", ""),
        "confidence": state.get("charge_state_confidence", "unknown"),
        "completion_source": state.get("charge_completion_source", ""),
        "soc": to_float_or_none(status.get("soc")),
        "charging": int(to_bool(status.get("charging"))),
        "chargecomplete": int(to_bool(status.get("chargecomplete"))),
        "pluggedin": int(to_bool(status.get("pluggedin"))),
        "chargingtimeleft": to_float_or_none(status.get("chargingtimeleft")),
        "vehicle_time": status.get("datetime_utc"),
        "contact_time": status.get("datetime_actual"),
        "details": details,
    }
    safe_append_jsonl(diagnostics_daily_path(EVENT_HISTORY_DIR, "event", now_epoch), record, state)


def physical_session_id(state: dict[str, Any]) -> str:
    """Return the stable namespace for user-visible charging side effects."""
    value = str(state.get("physical_session_id") or "").strip()
    if value:
        return value
    generation = int(state.get("charge_session_generation", 0) or 0)
    started = float(state.get("session_started_epoch", 0.0) or 0.0)
    return f"session-{generation}-{int(started)}" if started > 0 else f"session-{generation}"


def _event_matches_session(row: dict[str, Any], event_type: str, state: dict[str, Any], session_id: str) -> bool:
    if str(row.get("kind") or "") != event_type:
        return False
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    if str(payload.get("physical_session_id") or "") == session_id:
        return True
    # Compatibility with pre-round-8 records: only accept the old generation
    # key when its recorded time is close to this session's persisted start.
    generation = int(state.get("charge_session_generation", 0) or 0)
    if int(payload.get("generation", -1) or -1) != generation:
        return False
    started = float(state.get("session_started_epoch", 0.0) or 0.0)
    if started <= 0:
        return False
    try:
        stamp = datetime.fromisoformat(str(row.get("timestamp", "")).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError, OverflowError):
        return False
    return abs(stamp - started) <= 180.0


def route_user_event(
    event_type: str,
    status: dict[str, Any],
    state: dict[str, Any],
    now_epoch: float,
    *,
    event_suffix: str = "",
    preference_override: bool | None = None,
    preference_key_override: str | None = None,
    event_scope: str | None = None,
    event_metadata: dict[str, Any] | None = None,
    suppression_reason: str | None = None,
) -> None:
    """Persist one canonical user event and fan it out only when enabled."""
    generation = int(state.get("charge_session_generation", 0) or 0)
    soc = to_float_or_none(status.get("soc"))
    session_id = physical_session_id(state)
    namespace = str(event_scope or session_id)
    key = f"{event_type}:{namespace}" + (f":{event_suffix}" if event_suffix else "")
    existing = next(
        (row for row in zero_functional.notification_events() if row.get("dedup_key") == key or (not event_suffix and not event_scope and _event_matches_session(row, event_type, state, session_id))),
        None,
    )
    if existing is not None:
        # A just-persisted event without an accepted dispatch is retryable
        # after a crash/provider failure. Never replay old historical events.
        try:
            event_age = max(0.0, now_epoch - datetime.fromisoformat(str(existing.get("timestamp", "")).replace("Z", "+00:00")).timestamp())
        except (TypeError, ValueError, OverflowError):
            event_age = 10_000.0
        dispatch_done = any(
            row.get("kind") == "push_dispatch"
            and isinstance(row.get("payload"), dict)
            and row["payload"].get("event_key") == key
            and row["payload"].get("provider_result") == "accepted"
            for row in zero_functional.notification_events()
        )
        terminal_suppression = any(
            row.get("kind") == "notification_suppressed"
            and isinstance(row.get("payload"), dict)
            and row["payload"].get("event_key") == key
            and row["payload"].get("reason") in {"coalesced_same_sample", "preference_disabled"}
            for row in zero_functional.notification_events()
        )
        if event_age > 300.0 or dispatch_done or terminal_suppression:
            return
    if existing is None:
        event_payload = {"generation": generation if not event_scope else None, "physical_session_id": session_id if not event_scope else None, "event_scope": event_scope, "soc": soc}
        if event_type in {"blocking_fee_reminder", "blocking_fee_limit_reached"}:
            event_payload.update({
                "limit_minutes": int(status.get("blocking_fee_limit_minutes", 0) or 0),
                "connected_seconds": max(0, int(status.get("connected_seconds", 0) or 0)),
                "minutes_until_limit": max(0, int(status.get("blocking_fee_minutes_until", 0) or 0)),
            })
        if event_type == "maintenance_reminder":
            event_payload.update({
                "maintenance_id": str(status.get("maintenance_id") or ""),
                "name": str(status.get("maintenance_name") or ""),
                "remaining_km": status.get("maintenance_remaining_km"),
            })
        if event_type == "post_charge_reminder":
            event_payload["reminder_minutes"] = int(status.get("post_charge_reminder_minutes", 0) or 0)
        if event_metadata:
            event_payload.update(event_metadata)
        if not zero_functional.record_event(
            event_type,
            event_payload,
            key,
        ):
            return
    # Zero's raw target-reached flag marks an internal charge phase. There is
    # no user-selected numeric target in this telemetry, so retain the event
    # for diagnosis while suppressing the unsupported user-facing claim.
    if event_type == "charge_target_reached":
        zero_functional.record_event(
            "notification_suppressed",
            {"event": event_type, "reason": "numeric_user_target_unknown", "session": session_id},
            f"notification-suppressed:{key}",
        )
        return
    if event_type == "full_reached" and (soc is None or soc < 100):
        zero_functional.record_event(
            "notification_suppressed",
            {"event": event_type, "reason": "observed_soc_below_100", "session": session_id},
            f"notification-suppressed:{key}",
        )
        return
    prefs = zero_functional.preferences().get("notifications", {})
    preference_key = {
        "charge_target_reached": "target_reached",
        "charging_stopped_before_target": "charging_completed",
    }.get(event_type, event_type)
    if preference_key_override:
        preference_key = preference_key_override
    preference_enabled = bool(prefs.get(preference_key, False)) if preference_override is None else preference_override
    if not preference_enabled:
        zero_functional.record_event(
            "notification_suppressed",
            {"event": event_type, "event_key": key,
             "reason": suppression_reason or "preference_disabled",
             "preference": preference_key,
             "preference_enabled": bool(prefs.get(preference_key, False)) if suppression_reason else False,
             "session": session_id if not event_scope else None, "event_scope": event_scope,
             **(event_metadata or {})},
            f"notification-suppressed:{key}",
        )
        return
    label = str(state.get("vehicle_label", "Zero Motorcycle"))
    text = {"charging_started": "Laden gestartet", "charge_target_reached": "Ladeziel erreicht", "full_reached": "100 % erreicht", "charging_completed": "Ladevorgang abgeschlossen", "vehicle_offline": "Fahrzeug länger offline", "vehicle_online_again": "Fahrzeug wieder online"}.get(event_type, event_type)
    english = {"charging_started": "Charging started", "charge_target_reached": "Charge phase reached", "full_reached": "100% reached", "charging_completed": "Charging complete", "vehicle_offline": "Vehicle offline for a while", "vehicle_online_again": "Vehicle online again"}.get(event_type, event_type)
    if event_type == "soc_milestone":
        milestone = int(round(soc or 0))
        text = f"Ladestand {milestone} % erreicht"
        english = f"SOC reached {milestone}%"
    if event_type == "odometer_milestone":
        milestone_name = str(status.get("odometer_milestone_name") or "Kilometer-Meilenstein")
        milestone_value = status.get("odometer_milestone_value")
        text = f"Kilometer-Meilenstein erreicht · {milestone_name} bei {milestone_value:g} km" if isinstance(milestone_value, (int, float)) else f"Kilometer-Meilenstein erreicht · {milestone_name}"
        english = f"Odometer milestone reached · {milestone_name} at {milestone_value:g} km" if isinstance(milestone_value, (int, float)) else f"Odometer milestone reached · {milestone_name}"
    if event_type == "maintenance_reminder":
        name = str(status.get("maintenance_name") or "Wartung")
        remaining = status.get("maintenance_remaining_km")
        if isinstance(remaining, (int, float)) and remaining < 0:
            overdue = f"{abs(remaining):.2f}".rstrip("0").rstrip(".")
            overdue_de, overdue_en = ("<0,01", "<0.01") if abs(remaining) < 0.01 else (overdue.replace(".", ","), overdue)
            text = f"Wartung überfällig · {name} · um {overdue_de} km"
            english = f"Maintenance overdue · {name} · {overdue_en} km overdue"
        elif isinstance(remaining, (int, float)) and remaining == 0:
            text, english = f"Wartung fällig · {name}", f"Maintenance due · {name}"
        elif isinstance(remaining, (int, float)):
            text, english = f"Wartung bald fällig · {name} · noch {remaining:g} km", f"Maintenance due soon · {name} · {remaining:g} km remaining"
        else:
            text, english = f"Wartungserinnerung · {name}", f"Maintenance reminder · {name}"
    if event_type in {"blocking_fee_reminder", "blocking_fee_limit_reached"}:
        limit_minutes = int(status.get("blocking_fee_limit_minutes", 0) or 0)
        limit_hours = limit_minutes // 60
        elapsed_seconds = max(0, float(status.get("connected_seconds", 0) or 0))
        elapsed_minutes = int(elapsed_seconds // 60)
        if event_type == "blocking_fee_reminder":
            remaining_minutes = int(status.get("blocking_fee_minutes_until", 0) or 0)
            text = f"Zeitlimit an der Ladesäule · seit {elapsed_minutes // 60} h {elapsed_minutes % 60:02d} min angeschlossen. Dein eingestelltes Zeitlimit von {limit_hours} h wird in {remaining_minutes} min erreicht."
            english = f"Charger time limit · connected for {elapsed_minutes // 60} h {elapsed_minutes % 60:02d} min. Your {limit_hours} h limit will be reached in {remaining_minutes} min."
        else:
            text = f"Eingestelltes Zeitlimit von {limit_hours} h an der Ladesäule erreicht · seit {elapsed_minutes // 60} h {elapsed_minutes % 60:02d} min angeschlossen."
            english = f"Your {limit_hours} h charger time limit has been reached · connected for {elapsed_minutes // 60} h {elapsed_minutes % 60:02d} min."
    if event_type == "post_charge_reminder":
        text = "Laden abgeschlossen · das Motorrad ist noch angeschlossen."
        english = "Charging complete · the motorcycle is still plugged in."
    if event_type == "charging_not_started":
        text = "Angeschlossen, aber Laden startet nicht. Bitte den Ladestand prüfen."
        english = "Plugged in, but charging has not started. Check the vehicle when convenient."
    if event_type == "evening_reminder":
        level = int(round(soc or 0))
        text = f"Akku bei {level} % und nicht angesteckt · heute noch laden?"
        english = f"Battery at {level}% and not plugged in · charge tonight?"
    if event_type == "theft_alert":
        text = "Das Motorrad hat sich bei ausgeschalteter Zündung deutlich bewegt. Bitte prüfen."
        english = "The motorcycle moved noticeably with the ignition off. Please check."
    if event_type == "tipover_alert":
        text = "Das Motorrad meldet, dass es umgekippt ist. Bitte prüfen."
        english = "The motorcycle reports that it has tipped over. Please check."
    if event_type == "firmware_changed":
        text = f"Neue Fahrzeug-Firmware erkannt · {status.get('software_version')}"
        english = f"New vehicle firmware detected · {status.get('software_version')}"
    if event_type == "battery_care":
        if str(status.get("battery_care_band")) == "low":
            text = "Der Akku steht seit 3 Tagen fast leer. Bitte bald laden, ein sehr leerer Akku sollte nicht lange stehen."
            english = "The battery has been almost empty for 3 days. Please charge soon; a very empty battery should not sit for long."
        else:
            text = "Der Akku steht seit 3 Tagen fast voll. Für längeres Stehen ist ein mittlerer Ladestand (etwa 50–60 %) schonender."
            english = "The battery has been almost full for 3 days. For longer standing, a medium charge level (about 50–60%) is gentler."
    prior_dispatches = [
        row for row in zero_functional.notification_events()
        if row.get("kind") == "push_dispatch"
        and isinstance(row.get("payload"), dict)
        and row["payload"].get("event_key") == key
    ]
    accepted_endpoints = {
        str(outcome.get("endpoint_hash"))
        for row in prior_dispatches
        for outcome in row.get("payload", {}).get("outcomes", [])
        if outcome.get("result") == "accepted" and outcome.get("endpoint_hash")
    }
    # send_push commits provider outcomes before this router commits its
    # event-specific dispatch record. Correlated outcomes close that crash
    # window so a restart does not repeat a notification already accepted.
    accepted_endpoints.update(
        str(outcome.get("endpoint_hash"))
        for row in zero_functional.notification_events()
        if row.get("kind") == "push_delivery_result"
        and isinstance(row.get("payload"), dict)
        and row["payload"].get("event_key") == key
        for outcome in row["payload"].get("outcomes", [])
        if outcome.get("result") == "accepted" and outcome.get("endpoint_hash")
    )
    result = zero_functional.send_push(
        label,
        text,
        "/settings" if event_type in {"maintenance_reminder", "odometer_milestone"} else "/",
        localized_bodies={"de": text, "en": english},
        outcome_event="push_delivery_result",
        skip_endpoint_hashes=accepted_endpoints,
        delivery_key=key,
        delivery_event=event_type,
    )
    attempts = sum(
        1 for row in zero_functional.notification_events()
        if row.get("kind") == "push_dispatch"
        and isinstance(row.get("payload"), dict)
        and row["payload"].get("event_key") == key
    ) + 1
    zero_functional.record_event(
        "push_dispatch",
        {
            "event": event_type,
            "event_key": key,
            "session": session_id if not event_scope else None,
            "event_scope": event_scope,
            "preference": preference_key,
            "preference_enabled": True,
            "attempt": attempts,
            "provider_result": result.get("provider_result", "unknown"),
            "sent": int(result.get("sent", 0) or 0),
            "failed": int(result.get("failed", 0) or 0),
            "skipped": int(result.get("skipped", 0) or 0),
            "outcomes": result.get("outcomes", []),
        },
        f"push-dispatch:{key}:{attempts}",
    )
    if result.get("failed"):
        zero_functional.record_event("push_failed", {"event": event_type, "failed": result["failed"]}, f"push-failed:{key}")


SOC_NOTIFICATION_MILESTONES = (50, 60, 70, 80, 90)


def evaluate_soc_milestones(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Notify only observed threshold crossings in the current physical session."""
    current = to_float_or_none(status.get("soc"))
    session_id = physical_session_id(state)
    previous = to_float_or_none(state.get("session_last_observed_soc"))
    if previous is None:
        # Hydrating an older state cannot prove which values were crossed.
        # Seed from this fresh sample and never replay historical thresholds.
        state["session_last_observed_soc"] = current
        return
    if current is None:
        return
    if state.get("session_active") and previous < 100 <= current:
        route_user_event("full_reached", status, state, now_epoch)
    prefs = zero_functional.preferences().get("notifications", {})
    if state.get("session_active"):
        crossed = [threshold for threshold in SOC_NOTIFICATION_MILESTONES if previous < threshold <= current]
        if crossed:
            highest = max(crossed)
            notifications_enabled = bool(prefs.get("soc_milestone", False))
            batch = {
                "sample_from_soc": previous,
                "sample_to_soc": current,
                "crossed_thresholds": crossed,
                "user_event_threshold": highest,
            }
            # Preserve a durable per-threshold event key for every crossing.
            # Lower crossings in this same sample are explicitly terminally
            # suppressed; only the highest newly reached level is user-facing.
            for threshold in crossed:
                route_user_event(
                    "soc_milestone",
                    {**status, "soc": threshold},
                    state,
                    now_epoch,
                    event_suffix=str(threshold),
                    preference_override=(False if notifications_enabled and threshold != highest else None),
                    event_metadata=batch,
                    suppression_reason=("coalesced_same_sample"
                        if notifications_enabled and threshold != highest else None),
                )
            if len(crossed) > 1:
                zero_functional.record_event(
                    "soc_milestone_batch",
                    {"physical_session_id": session_id, **batch},
                    f"soc_milestone_batch:{session_id}:{int(now_epoch)}:{previous:g}:{current:g}",
                )
    state["session_last_observed_soc"] = current


def evaluate_blocking_fee_reminders(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Apply an explicit charging-location limit from the observed plug edge."""
    started = float(state.get("plugged_episode_started_epoch", 0.0) or state.get("plugged_started_epoch", 0.0) or 0.0)
    location_id = str(state.get("session_location_id") or "")
    if started <= 0 or not location_id or not bool(to_bool(status.get("pluggedin"))):
        return
    location = next((row for row in zero_functional.locations() if str(row.get("id")) == location_id), None)
    rule = location.get("time_limit") if isinstance(location, dict) else None
    if not isinstance(rule, dict) or not bool(rule.get("enabled", False)):
        return
    try:
        limit_minutes = int(rule.get("limit_minutes", 0))
        reminder_minutes = int(rule.get("reminder_minutes", 0))
    except (TypeError, ValueError):
        return
    if limit_minutes < 60 or reminder_minutes < 0 or reminder_minutes >= limit_minutes:
        return
    elapsed_seconds = max(0.0, now_epoch - started)
    limit_seconds = limit_minutes * 60
    augmented = {
        **status,
        "connected_seconds": elapsed_seconds,
        "blocking_fee_limit_minutes": limit_minutes,
        "blocking_fee_minutes_until": max(0, int((limit_seconds - elapsed_seconds) // 60)),
    }
    episode_id = str(state.get("plugged_episode_id") or "")
    event_scope = f"plug-{episode_id}" if episode_id else None

    def already_sent_legacy_stage(event_type: str, suffix: str) -> bool:
        # Beta37 keyed these events by physical session. Honor that key only
        # when its timestamp belongs to this same observed plug episode.
        if not episode_id:
            return False
        episode_started = float(state.get("plugged_episode_started_epoch", 0.0) or 0.0)
        if episode_started <= 0:
            return False
        legacy_key = f"{event_type}:{physical_session_id(state)}:{suffix}"
        for row in zero_functional.notification_events():
            if str(row.get("dedup_key") or "") != legacy_key:
                continue
            try:
                event_epoch = datetime.fromisoformat(str(row.get("timestamp", "")).replace("Z", "+00:00")).timestamp()
            except (TypeError, ValueError, OverflowError):
                continue
            if event_epoch >= episode_started:
                return True
        return False

    if elapsed_seconds >= limit_seconds and bool(rule.get("notify_at_limit", True)):
        if already_sent_legacy_stage("blocking_fee_limit_reached", "limit"):
            return
        route_user_event(
            "blocking_fee_limit_reached", augmented, state, now_epoch,
            event_suffix="limit",
            preference_override=True,
            preference_key_override="location_time_limit",
            event_scope=event_scope,
        )
    elif elapsed_seconds < limit_seconds and reminder_minutes > 0 and elapsed_seconds >= limit_seconds - reminder_minutes * 60:
        if already_sent_legacy_stage("blocking_fee_reminder", "pre-limit"):
            return
        route_user_event(
            "blocking_fee_reminder", augmented, state, now_epoch,
            event_suffix="pre-limit",
            preference_override=True,
            preference_key_override="location_time_limit",
            event_scope=event_scope,
        )


def observe_plug_episode(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Track a confirmed plug episode independently of charge generations."""
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60:
        return
    previous_contact = float(state.get("plugged_episode_last_contact_epoch", 0.0) or 0.0)
    if contact <= previous_contact:
        return
    plugged = bool(to_bool(status.get("pluggedin")))
    if not bool(state.get("plugged_episode_initialized", False)):
        # A first snapshot already plugged has no provable connection start.
        state["plugged_episode_initialized"] = True
        state["plugged_episode_active"] = plugged
        state["plugged_episode_last_contact_epoch"] = contact
        state["plugged_episode_observation_count"] = 1 if plugged else 0
        state["plugged_episode_start_soc"] = to_float_or_none(status.get("soc")) if plugged else None
        state["plugged_episode_unplug_candidates"] = 0 if plugged else 2
        return
    if plugged:
        if bool(state.get("plugged_episode_active", False)):
            state["plugged_episode_unplug_candidates"] = 0
            state["plugged_episode_observation_count"] = int(state.get("plugged_episode_observation_count", 0) or 0) + 1
        elif int(state.get("plugged_episode_unplug_candidates", 0) or 0) >= 2:
            state["plugged_episode_id"] = f"plug-{int(contact * 1000)}"
            state["plugged_episode_started_epoch"] = contact
            state["plugged_episode_active"] = True
            state["plugged_episode_observation_count"] = 1
            state["plugged_episode_unplug_candidates"] = 0
            state["plugged_episode_start_soc"] = to_float_or_none(status.get("soc"))
            state["post_charge_cancelled_session_id"] = physical_session_id(state)
        else:
            # One false sample followed by true is telemetry noise, not unplug.
            state["plugged_episode_unplug_candidates"] = 0
    elif bool(state.get("plugged_episode_active", False)):
        candidates = int(state.get("plugged_episode_unplug_candidates", 0) or 0) + 1
        state["plugged_episode_unplug_candidates"] = candidates
        if candidates >= 2:
            state["plugged_episode_active"] = False
            state["plugged_episode_observation_count"] = 0
            state["plugged_episode_started_epoch"] = 0.0
            state["plugged_episode_start_soc"] = None
            state["post_charge_cancelled_session_id"] = physical_session_id(state)
    else:
        state["plugged_episode_unplug_candidates"] = int(state.get("plugged_episode_unplug_candidates", 0) or 0) + 1
    state["plugged_episode_last_contact_epoch"] = contact


def evaluate_post_charge_reminder(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    prefs = zero_functional.preferences()
    try:
        delay_minutes = int(prefs.get("post_charge_reminder_minutes", 0) or 0)
    except (TypeError, ValueError):
        return
    session_id = physical_session_id(state)
    completed = float(state.get("session_completed_epoch", 0.0) or 0.0)
    if delay_minutes not in (10, 30, 60) or not session_id or completed <= 0:
        return
    if not bool(state.get("session_completion_witnessed", False)) or str(state.get("charge_phase")) not in {"complete", "plugged_idle"} or bool(state.get("session_active")):
        return
    if not bool(to_bool(status.get("pluggedin"))):
        return
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60 or now_epoch - contact > 900:
        return
    if str(state.get("post_charge_cancelled_session_id") or "") == session_id:
        return
    previous_contact = float(
        state.get("post_charge_last_contact_epoch", 0.0)
        or state.get("session_completion_contact_epoch", 0.0)
        or 0.0
    )
    if contact <= previous_contact:
        return
    if previous_contact > 0 and contact - previous_contact > 300.0:
        # Preserve the original completion deadline. Require two distinct,
        # fresh plugged observations after an ambiguous data gap before push.
        state["post_charge_recovery_required"] = True
        state["post_charge_recovery_count"] = 1
        state["post_charge_last_contact_epoch"] = contact
        return
    if bool(state.get("post_charge_recovery_required", False)):
        recovery_count = int(state.get("post_charge_recovery_count", 0) or 0) + 1
        state["post_charge_recovery_count"] = recovery_count
        state["post_charge_last_contact_epoch"] = contact
        if recovery_count < 2:
            return
        state["post_charge_recovery_required"] = False
        state["post_charge_recovery_count"] = 0
    else:
        state["post_charge_last_contact_epoch"] = contact
    age = now_epoch - completed
    if age < delay_minutes * 60 or age > 24 * 3600:
        return
    route_user_event(
        "post_charge_reminder", {**status, "post_charge_reminder_minutes": delay_minutes}, state, now_epoch,
        event_scope=f"post-charge-{session_id}",
        preference_override=True, preference_key_override="post_charge_reminder",
    )


def evaluate_failed_start_reminder(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    prefs = zero_functional.preferences()
    try:
        delay_minutes = int(prefs.get("charging_not_started_minutes", 0) or 0)
    except (TypeError, ValueError):
        return
    episode_id = str(state.get("plugged_episode_id") or "")
    started = float(state.get("plugged_episode_started_epoch", 0.0) or 0.0)
    contact = status_contact_epoch(status)
    phase = str(state.get("charge_phase") or "")
    if delay_minutes not in (5, 10, 15) or not episode_id or started <= 0:
        return
    if not bool(state.get("plugged_episode_active", False)):
        return
    if not bool(to_bool(status.get("pluggedin"))) or bool(to_bool(status.get("charging"))) or bool(to_bool(status.get("chargecomplete"))):
        if bool(to_bool(status.get("charging"))) or bool(to_bool(status.get("chargecomplete"))):
            state["failed_start_cancelled_episode_id"] = episode_id
            state["failed_start_evidence_episode_id"] = episode_id
            state["failed_start_evidence_count"] = 0
        return
    if phase in {"charging", "target_reached", "complete", "interrupted"} or bool(state.get("session_active")):
        state["failed_start_cancelled_episode_id"] = episode_id
        return
    if str(state.get("failed_start_cancelled_episode_id") or "") == episode_id:
        return
    if contact <= 0 or contact > now_epoch + 60 or now_epoch - contact > 900:
        return
    previous_contact = float(state.get("failed_start_last_contact_epoch", 0.0) or 0.0)
    if contact <= previous_contact:
        return
    state["failed_start_last_contact_epoch"] = contact
    current_soc = to_float_or_none(status.get("soc"))
    if current_soc is None:
        return
    evidence_episode = str(state.get("failed_start_evidence_episode_id") or "")
    evidence_started = float(state.get("failed_start_evidence_started_epoch", 0.0) or 0.0)
    evidence_soc = to_float_or_none(state.get("failed_start_evidence_start_soc"))
    evidence_count = int(state.get("failed_start_evidence_count", 0) or 0)
    # A cloud gap makes the unobserved interval ambiguous. Restart the dwell
    # from the first fresh recovery sample and require a new continuous span.
    if (
        evidence_episode != episode_id
        or evidence_started <= 0
        or contact - previous_contact > 300.0
        or evidence_soc is None
        or abs(current_soc - evidence_soc) > 0.1
    ):
        evidence_started = contact
        evidence_soc = current_soc
        evidence_count = 1
        state["failed_start_evidence_episode_id"] = episode_id
        state["failed_start_evidence_started_epoch"] = contact
        state["failed_start_evidence_start_soc"] = current_soc
        state["failed_start_evidence_count"] = 1
        return
    evidence_count += 1
    state["failed_start_evidence_count"] = evidence_count
    if evidence_count < 2 or contact - evidence_started < delay_minutes * 60:
        return
    route_user_event(
        "charging_not_started", status, state, now_epoch,
        event_suffix="not-started", event_scope=f"plug-{episode_id}",
        preference_override=True, preference_key_override="charging_not_started",
    )


EVENING_REMINDER_SOC_LIMITS = (30, 50, 70)
EVENING_REMINDER_HOURS = (18, 19, 20, 21, 22)
EVENING_REMINDER_MAX_CONTACT_AGE = 4 * 3600


def evaluate_evening_reminder(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Once per evening: remind when the last known level is below the chosen limit and the bike is not plugged in.

    Runs on every poll (a parked bike reports rarely), but only on vehicle data
    at most a few hours old, so an old unplugged reading cannot trigger it.
    """
    prefs = zero_functional.preferences()
    try:
        limit = int(prefs.get("evening_reminder_soc", 0) or 0)
        hour = int(prefs.get("evening_reminder_hour", 20) or 20)
    except (TypeError, ValueError):
        return
    if limit not in EVENING_REMINDER_SOC_LIMITS or hour not in EVENING_REMINDER_HOURS:
        return
    local = datetime.fromtimestamp(now_epoch).astimezone()
    if local.hour < hour:
        return
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60 or now_epoch - contact > EVENING_REMINDER_MAX_CONTACT_AGE:
        return
    soc = to_float_or_none(status.get("soc"))
    if soc is None or soc >= limit:
        return
    if bool(to_bool(status.get("pluggedin"))) or bool(to_bool(status.get("charging"))) or bool(state.get("session_active")):
        return
    route_user_event(
        "evening_reminder", status, state, now_epoch,
        event_scope=f"evening-{local.date().isoformat()}",
        preference_override=True, preference_key_override="evening_reminder",
    )


BATTERY_CARE_FULL_SOC = 95.0
BATTERY_CARE_LOW_SOC = 15.0
BATTERY_CARE_DAYS = 3


def battery_care_band(soc: float | None) -> str:
    if soc is None:
        return ""
    return "full" if soc >= BATTERY_CARE_FULL_SOC else "low" if soc <= BATTERY_CARE_LOW_SOC else ""


def evaluate_battery_care(status: dict[str, Any], state: dict[str, Any], config: dict[str, Any] | None, now_epoch: float) -> None:
    """Track how long the bike has stood almost full or almost empty, from real vehicle contacts only.

    The clock starts at the first contact inside the band and restarts on any
    contact outside it, a new charge or a ride (odometer change). After three
    days a single hint is sent per standing period.
    """
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60 or contact <= float(state.get("battery_care_last_contact_epoch", 0.0) or 0.0):
        return
    state["battery_care_last_contact_epoch"] = contact
    band = battery_care_band(to_float_or_none(status.get("soc")))
    odometer = vehicle_odometer_km(status, config)
    previous_odometer = to_float_or_none(state.get("battery_care_odometer"))
    ridden = odometer is not None and previous_odometer is not None and abs(odometer - previous_odometer) >= 0.5
    charging = bool(to_bool(status.get("charging"))) or str(state.get("charge_phase") or "") == "charging"
    if band == "low" and charging:
        band = ""
    if band != str(state.get("battery_care_band") or "") or ridden or (band == "full" and charging):
        state["battery_care_band"] = band
        state["battery_care_since_epoch"] = contact if band else 0.0
    if odometer is not None:
        state["battery_care_odometer"] = odometer
    since = float(state.get("battery_care_since_epoch", 0.0) or 0.0)
    if not band or since <= 0 or contact - since < BATTERY_CARE_DAYS * 86400:
        return
    route_user_event(
        "battery_care", {**status, "battery_care_band": band}, state, now_epoch,
        event_scope=f"battery-care-{band}-{int(since)}",
    )


THEFT_DISTANCE_M = 1000.0


def evaluate_parked_movement(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Experimental: warn once when the parked bike (ignition off) is more than 1 km from where it was parked.

    Needs a good GPS fix (at least 4 satellites) and two reports in a row away
    from the parked point, so normal GPS jitter or one stray fix cannot trigger it.
    Coordinates stay in the runtime state; the event itself carries none.
    """
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60 or now_epoch - contact > 900:
        return
    if bool(to_bool(status.get("ignition"))):
        state["parked_anchor"] = None
        state["parked_moved_count"] = 0
        return
    point = vehicle_gps_coordinates(status)
    satellites = to_float_or_none(status.get("satellites"))
    if point is None or satellites is None or satellites < 4:
        return
    anchor = state.get("parked_anchor")
    if not isinstance(anchor, dict):
        state["parked_anchor"] = {"lat": point[0], "lon": point[1], "since": contact}
        state["parked_moved_count"] = 0
        return
    distance = zero_functional._haversine_m(float(anchor["lat"]), float(anchor["lon"]), point[0], point[1])
    if distance < THEFT_DISTANCE_M:
        state["parked_moved_count"] = 0
        return
    state["parked_moved_count"] = int(state.get("parked_moved_count", 0) or 0) + 1
    if state["parked_moved_count"] < 2:
        return
    route_user_event(
        "theft_alert", status, state, now_epoch,
        event_scope=f"parked-{int(float(anchor.get('since') or 0))}",
        preference_key_override="theft_alert",
    )


def evaluate_vehicle_flags(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Experimental: tip-over flag and firmware changes, each reported once when it first appears."""
    contact = status_contact_epoch(status)
    if contact <= 0 or contact > now_epoch + 60 or now_epoch - contact > 900:
        return
    tipped = bool(to_bool(status.get("tipover")))
    if tipped and not bool(state.get("last_tipover", False)):
        route_user_event("tipover_alert", status, state, now_epoch, event_scope=f"tipover-{int(contact)}", preference_key_override="tipover_alert")
    state["last_tipover"] = tipped
    firmware = str(status.get("software_version") or "").strip()
    if firmware:
        previous = str(state.get("vehicle_firmware") or "")
        if previous and firmware != previous:
            route_user_event("firmware_changed", status, state, now_epoch, event_scope=f"firmware-{firmware}", preference_key_override="firmware_changed")
        state["vehicle_firmware"] = firmware


def observe_plug_connection(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Track only a fresh plug edge observed after observer initialization."""
    plugged = bool(to_bool(status.get("pluggedin")))
    if plugged and not bool(state.get("last_pluggedin", False)):
        if bool(state.get("initialized", False)):
            contact = status_contact_epoch(status)
            state["plugged_started_epoch"] = contact if 0 < contact <= now_epoch else now_epoch
    elif not plugged:
        state["plugged_started_epoch"] = 0.0


def reconcile_charging_events(
    status: dict[str, Any], state: dict[str, Any], now_epoch: float
) -> None:
    """Repair missed side effects for the current physical session only.

    Completed historical sessions are intentionally excluded, so startup or
    deploy cannot replay old notifications. Each event is keyed by the
    physical session namespace and is safe to process on every poll.
    """
    phase = str(state.get("charge_phase", ""))
    active = bool(state.get("session_active", False))
    uncertain = bool(state.get("session_start_uncertain", False))
    desired: list[str] = []
    if active and bool(state.get("start_notified", False)) and not uncertain:
        desired.append("charging_started")
    observed_soc = to_float_or_none(status.get("soc"))
    target_epoch = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    target_recent = target_epoch > 0 and 0 <= now_epoch - target_epoch <= 300.0
    if active and phase == "target_reached" and target_recent and observed_soc is not None and observed_soc >= 100:
        # Reconcile only a recent missed phase edge. An old active phase after
        # deploy must not create a historical 100% Push.
        desired.append("full_reached")
    completed_epoch = float(state.get("session_completed_epoch", 0.0) or 0.0)
    if (
        phase == "complete"
        and completed_epoch > 0
        and now_epoch - completed_epoch <= 300.0
    ):
        desired.append("charging_completed")
        if observed_soc is not None and observed_soc >= 100:
            desired.append("full_reached")
    for event_type in desired:
        route_user_event(event_type, status, state, now_epoch)


def evaluate_functional_reminders(
    status: dict[str, Any], state: dict[str, Any], config: dict[str, Any] | None = None,
    now_epoch: float | None = None,
) -> None:
    """Run bounded user reminders from fresh odometer observations only."""
    odometer = vehicle_odometer_km(status, config)
    if odometer is None:
        return
    now_epoch = time.time() if now_epoch is None else now_epoch
    for milestone in zero_functional.check_odometer_milestones(odometer):
        if not bool(milestone.get("notify", False)):
            continue
        route_user_event(
            "odometer_milestone",
            {**status, "odometer_milestone_name": milestone.get("name"), "odometer_milestone_value": milestone.get("target_odometer")},
            state, now_epoch,
            event_suffix=f"{float(milestone.get('target_odometer', odometer)):g}",
            event_scope=f"odometer-{milestone.get('id')}",
        )
    prefs = zero_functional.preferences().get("notifications", {})
    for row in zero_functional.maintenance_status(odometer):
        remaining = row.get("distance_remaining")
        if row.get("status") not in {"due", "overdue"} or remaining is None:
            continue
        route_user_event(
            "maintenance_reminder",
            {**status, "maintenance_id": row.get("id"), "maintenance_name": row.get("name"),
             "maintenance_remaining_km": remaining},
            state, now_epoch,
            # Preserve the former due-stage dedup key so an already delivered
            # due notice is not repeated when upgrading from the 100/500 km stages.
            event_suffix=f"0:{row.get('due_odometer')}",
            preference_override=bool(prefs.get("maintenance", False)),
            preference_key_override="maintenance",
            event_scope=f"maintenance-{row.get('id')}",
        )


def evaluate_vehicle_connectivity_notifications(state: dict[str, Any], now_epoch: float) -> None:
    """Send opted-in offline/recovery notices from the last vehicle contact."""
    prefs = zero_functional.preferences()
    notifications = prefs.get("notifications", {})
    try:
        threshold_minutes = int(prefs.get("offline_threshold_minutes", 0) or 0)
    except (TypeError, ValueError):
        threshold_minutes = 0
    last_contact = float(state.get("last_contact_epoch", 0.0) or 0.0)
    episode = float(state.get("offline_episode_started_epoch", 0.0) or 0.0)
    episode_contact = float(state.get("offline_episode_contact_epoch", 0.0) or 0.0)
    if threshold_minutes <= 0 or last_contact <= 0:
        state["offline_episode_started_epoch"] = 0.0
        state["offline_episode_contact_epoch"] = 0.0
        return
    offline = now_epoch - last_contact >= threshold_minutes * 60
    if offline:
        if episode <= 0:
            episode = last_contact
            state["offline_episode_started_epoch"] = episode
            episode_contact = last_contact
            state["offline_episode_contact_epoch"] = episode_contact
        scope = f"contact-{int(episode)}"
        if bool(notifications.get("offline", False)):
            route_user_event(
                "vehicle_offline", {"soc": None}, state, now_epoch,
                event_suffix="offline", preference_key_override="offline", event_scope=scope,
            )
        return
    # A preference change can move the stale-contact cutoff without a vehicle
    # reconnect. Only a newer vehicle-provided contact timestamp closes this
    # episode. This also makes a persisted episode safe across Observer restart.
    if episode > 0 and episode_contact <= 0:
        # Older runtime snapshots stored the episode start as the contact
        # timestamp that triggered it, so use that as the migration baseline.
        episode_contact = episode
        state["offline_episode_contact_epoch"] = episode_contact
    if episode > 0 and last_contact > episode_contact and last_contact <= now_epoch:
        if bool(notifications.get("online_again", False)):
            scope = f"contact-{int(episode)}"
            route_user_event(
                "vehicle_online_again", {"soc": None}, state, now_epoch,
                event_suffix="recovered", preference_key_override="online_again", event_scope=scope,
            )
        state["offline_episode_started_epoch"] = 0.0
        state["offline_episode_contact_epoch"] = 0.0


def capture_session_location(status: dict[str, Any], state: dict[str, Any], now_epoch: float) -> None:
    """Capture at most one sufficiently fresh GPS point per charging session."""
    if state.get("session_location_id"): return
    lat, lon = to_float_or_none(status.get("latitude")), to_float_or_none(status.get("longitude"))
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0): return
    contact = timestamp_or_none(status.get("datetime_actual") or status.get("datetime_utc"))
    if contact is None or now_epoch - contact.timestamp() > 900: return
    existing = zero_functional.cluster_location(lat, lon)
    row = existing or zero_functional.upsert_location({"latitude": lat, "longitude": lon, "name": f"Ladeort {len(zero_functional.locations()) + 1}"})
    state["session_location_id"] = row.get("id")


def session_terminal_end_epoch(state: dict[str, Any], terminal_event: str) -> float:
    """Return the best evidenced active-charge end, without sleep-time extension."""
    target_end = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    if terminal_event == "complete":
        source = str(state.get("charge_completion_source", ""))
        if source == "history_charging_zero":
            evidenced_end = float(state.get("balancing_end_at_epoch", 0.0) or 0.0)
        elif source in {"cloud_chargecomplete", "full_soc_idle", "vehicle_status"}:
            evidenced_end = float(state.get("session_completion_contact_epoch", 0.0) or 0.0)
        elif source == "shutdown_zero_pulse":
            evidenced_end = float(state.get("shutdown_zero_pulse_epoch", 0.0) or 0.0)
        else:
            evidenced_end = 0.0
        if evidenced_end > target_end:
            return evidenced_end
        if target_end > 0:
            return target_end
        return max(0.0, evidenced_end)
    if target_end > 0:
        return target_end
    # A generic unplug/interruption time does not establish when active
    # charging stopped. Without a target or a separate evidenced stop source,
    # leave the duration unknown instead of projecting elapsed plugged time.
    return 0.0


def record_charge_session(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
    terminal_event: str,
) -> None:
    generation = int(state.get("charge_session_generation", 0))
    if generation <= 0 or int(state.get("session_history_recorded_generation", -1)) == generation:
        return
    session_started_epoch = float(state.get("session_started_epoch", 0.0) or 0.0)
    target_end_epoch = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    active_end_epoch = session_terminal_end_epoch(state, terminal_event)
    if terminal_event in {"ended", "interrupted"} and target_end_epoch <= 0:
        # A generic unplug/interruption time is not enough to claim active
        # charging duration when no target or explicit stop witness exists.
        active_end_epoch = 0.0
    sample_rows = load_charging_sample_rows(generation)
    end_soc = zero_charging.observed_soc_at(sample_rows, active_end_epoch)
    if end_soc is None and terminal_event == "complete" and target_end_epoch > 0:
        # The bike often sleeps between reaching the target and the completion
        # witness (shutdown pulse); the SOC observed when the target was reached
        # is then the last measurement of this charge.
        end_soc = zero_charging.observed_soc_at(sample_rows, target_end_epoch)
    record = {
        "recorded_at_utc": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(),
        "generation": generation,
        "vehicle_label": str(config.get("vehicle_label", "Zero Motorcycle")),
        "started_at_utc": (
            datetime.fromtimestamp(session_started_epoch, timezone.utc).isoformat()
            if session_started_epoch > 0 else None
        ),
        "start_time_confidence": (
            "uncertain" if bool(state.get("session_start_uncertain", False)) else "observed"
        ),
        "start_observed_at_utc": (
            datetime.fromtimestamp(float(state.get("session_start_observed_epoch", 0.0)), timezone.utc).isoformat()
            if float(state.get("session_start_observed_epoch", 0.0) or 0.0) > 0 else None
        ),
        "target_reached_at_utc": (
            datetime.fromtimestamp(float(state.get("session_target_reached_epoch", 0.0)), timezone.utc).isoformat()
            if float(state.get("session_target_reached_epoch", 0.0) or 0.0) > 0 else None
        ),
        "ended_at_utc": (
            datetime.fromtimestamp(active_end_epoch, timezone.utc).isoformat()
            if active_end_epoch > 0 else None
        ),
        "completion_detected_at_utc": datetime.fromtimestamp(
            float(state.get("completion_detected_at_epoch", now_epoch) or now_epoch), timezone.utc
        ).isoformat(),
        "duration_seconds": (
            max(0, int(round(active_end_epoch - session_started_epoch)))
            if active_end_epoch > 0 and session_started_epoch > 0 and not bool(state.get("session_start_uncertain", False)) else None
        ),
        "start_soc": state.get("session_start_soc"),
        "target_soc": state.get("target_soc"),
        "end_soc": end_soc,
        "end_soc_source": "observed_sample" if end_soc is not None else None,
        "terminal_event": terminal_event,
        "completion_source": str(state.get("charge_completion_source", "")),
        "confidence": str(state.get("charge_state_confidence", "unknown")),
        "target_source": str(state.get("target_source", "")),
        "location_id": str(state.get("session_location_id") or "") or None,
        "balancing_duration_seconds": None,
        "balancing_end_at_utc": None,
        "shutdown_zero_pulse": bool(
            state.get("shutdown_zero_pulse_observed", False)
            and int(state.get("shutdown_zero_pulse_generation", -1)) == generation
        ),
        "shutdown_zero_pulse_at_utc": (
            datetime.fromtimestamp(float(state.get("shutdown_zero_pulse_epoch", 0.0)), timezone.utc).isoformat()
            if bool(state.get("shutdown_zero_pulse_observed", False))
            and int(state.get("shutdown_zero_pulse_generation", -1)) == generation
            and float(state.get("shutdown_zero_pulse_epoch", 0.0) or 0.0) > 0 else None
        ),
        "record_type": "session",
        "sample_count": len(zero_charging.ordered_samples(sample_rows)),
        "sample_sequence_watermark": max(
            len(sample_rows),
            max(
                (int(row["sample_sequence"]) for row in sample_rows
                 if type(row.get("sample_sequence")) is int and row["sample_sequence"] >= 0),
                default=0,
            ),
        ),
    }
    if safe_append_jsonl(diagnostics_daily_path(SESSION_HISTORY_DIR, "session", now_epoch), record, state):
        state["session_history_recorded_generation"] = generation


def load_charging_samples(generation: int) -> list[dict[str, Any]]:
    """Load normalized session samples for live calculations."""
    rows = zero_charging.ordered_samples(load_charging_sample_rows(generation))
    for row in rows:
        row.pop("sample_sequence", None)
    return rows


def load_charging_sample_rows_for_generations(
    generations: set[int],
) -> dict[int, list[dict[str, Any]]]:
    """Load requested generations with one pass over daily sample files."""
    wanted: set[int] = set()
    for generation in generations:
        try:
            parsed = int(generation)
        except (TypeError, ValueError, OverflowError):
            continue
        if parsed > 0:
            wanted.add(parsed)
    grouped = {generation: [] for generation in wanted}
    if not wanted:
        return grouped
    if not CHARGING_SAMPLE_DIR.exists():
        return grouped
    paths = sorted(CHARGING_SAMPLE_DIR.glob("samples-*.jsonl"))
    for path in paths:
        for sample_generation, item in _charging_sample_file(path):
            if sample_generation in grouped:
                grouped[sample_generation].append(dict(item))  # callers may modify their rows
    for stale in set(_SAMPLE_FILE_CACHE) - {str(path) for path in paths}:
        _SAMPLE_FILE_CACHE.pop(stale, None)
    return grouped


# Parsed daily sample files, reused until a file changes: during a charge only
# today's file grows, so a year of older files is not parsed again on every poll.
# Bounded: a year of real samples is a few MB; files beyond the budget are simply read each time
# (an unbounded cache once held 2 GB of test leftovers per process).
SAMPLE_CACHE_MAX_FILE_BYTES = 8 * 1024 * 1024
SAMPLE_CACHE_MAX_TOTAL_BYTES = 64 * 1024 * 1024
_SAMPLE_FILE_CACHE: dict[str, tuple[int, int, list[tuple[int, dict[str, Any]]]]] = {}


def _charging_sample_file(path: Path) -> list[tuple[int, dict[str, Any]]]:
    try:
        stat = path.stat()
    except OSError:
        return []
    cached = _SAMPLE_FILE_CACHE.get(str(path))
    # File times have a coarse tick: a file changed in the last two seconds may
    # change again without a visible difference, so it is never taken from the cache.
    settled = time.time() - stat.st_mtime > 2.0
    if cached and settled and cached[0] == stat.st_mtime_ns and cached[1] == stat.st_size:
        return cached[2]
    rows: list[tuple[int, dict[str, Any]]] = []
    try:
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line in handle:
                try: item = json.loads(line)
                except ValueError: continue
                if not isinstance(item, dict):
                    continue
                try:
                    sample_generation = int(item.get("generation", 0) or 0)
                except (ValueError, TypeError, OverflowError):
                    continue
                rows.append((sample_generation, item))
    except OSError:
        return []
    others = sum(entry[1] for key, entry in _SAMPLE_FILE_CACHE.items() if key != str(path))
    if settled and stat.st_size <= SAMPLE_CACHE_MAX_FILE_BYTES and others + stat.st_size <= SAMPLE_CACHE_MAX_TOTAL_BYTES:
        _SAMPLE_FILE_CACHE[str(path)] = (stat.st_mtime_ns, stat.st_size, rows)
    else:
        _SAMPLE_FILE_CACHE.pop(str(path), None)
    return rows


def load_charging_sample_rows(generation: int) -> list[dict[str, Any]]:
    """Load one generation in durable append order, without deduplication."""
    return load_charging_sample_rows_for_generations({generation}).get(generation, [])


def record_charging_sample(status: dict[str, Any], state: dict[str, Any], config: dict[str, Any], now_epoch: float) -> None:
    phase = str(state.get("charge_phase", ""))
    generation = int(state.get("charge_session_generation", 0) or 0)
    if generation <= 0 or phase not in {"charging", "target_reached"}:
        return
    if (
        int(state.get("session_history_recorded_generation", -1)) == generation
        or bool(state.get("session_terminal", False))
        or bool(state.get("complete_notified", False))
    ):
        return
    if phase == "target_reached":
        if (
            float(state.get("session_target_reached_epoch", 0.0) or 0.0) <= 0
            or bool(state.get("session_start_uncertain", False))
            or not bool(state.get("session_active", False))
            or not to_bool(status.get("charging"))
            or not to_bool(status.get("pluggedin"))
        ):
            return
    contact = status_contact_epoch(status) or now_epoch
    canonical_odometer = vehicle_odometer_km(status, config)
    cached_generation = int(state.get("charging_sample_sequence_generation", -1) or -1)
    cached_next = state.get("charging_sample_sequence_next")
    if cached_generation == generation and type(cached_next) is int and cached_next > 0:
        sample_sequence = cached_next
    else:
        existing_rows = load_charging_sample_rows(generation)
        latest_sequence = max(
            (int(row["sample_sequence"]) for row in existing_rows
             if type(row.get("sample_sequence")) is int and row["sample_sequence"] >= 0),
            default=0,
        )
        sample_sequence = max(latest_sequence, len(existing_rows)) + 1
    sample = {"record_type": "charging_sample", "generation": generation, "sample_sequence": sample_sequence, "timestamp": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(), "contact_time": datetime.fromtimestamp(contact, timezone.utc).isoformat(), "soc": to_float_or_none(status.get("soc")), "charge_target": to_float_or_none(state.get("target_soc")), "remaining_time": to_float_or_none(status.get("chargingtimeleft")), "odometer": to_float_or_none(status.get("mileage")), "odometer_km": canonical_odometer, "charging": int(to_bool(status.get("charging"))), "pluggedin": int(to_bool(status.get("pluggedin")))}
    if not zero_charging.valid_sample(sample): return
    fingerprint = json.dumps({k: sample.get(k) for k in ("generation", "soc", "charge_target", "remaining_time", "odometer", "charging", "pluggedin")}, sort_keys=True)
    interval = int(config.get("charging", {}).get("sample_interval_seconds", 120))
    if fingerprint == state.get("last_charging_sample_fingerprint") and now_epoch - float(state.get("last_charging_sample_epoch", 0) or 0) < interval:
        return
    CHARGING_SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    try: CHARGING_SAMPLE_DIR.chmod(0o700)
    except OSError: pass
    if safe_append_jsonl(diagnostics_daily_path(CHARGING_SAMPLE_DIR, "samples", now_epoch), sample, state):
        state["last_charging_sample_fingerprint"] = fingerprint
        state["last_charging_sample_epoch"] = now_epoch
        state["charging_sample_sequence_generation"] = generation
        state["charging_sample_sequence_next"] = sample_sequence + 1


def record_shutdown_zero_evidence(
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
) -> None:
    generation = int(state.get("shutdown_zero_pulse_generation", -1))
    if generation <= 0:
        return
    if int(state.get("shutdown_zero_evidence_recorded_generation", -1)) == generation:
        return
    if int(state.get("session_history_recorded_generation", -1)) != generation:
        return
    record = {
        "recorded_at_utc": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(),
        "record_type": "evidence_update",
        "generation": generation,
        "shutdown_zero_pulse": True,
        "shutdown_zero_pulse_at_utc": datetime.fromtimestamp(
            float(state.get("shutdown_zero_pulse_epoch", now_epoch)), timezone.utc
        ).isoformat(),
    }
    if safe_append_jsonl(diagnostics_daily_path(SESSION_HISTORY_DIR, "session", now_epoch), record, state):
        state["shutdown_zero_evidence_recorded_generation"] = generation


def status_contact_epoch(status: dict[str, Any]) -> float:
    values = [timestamp_or_none(status.get("datetime_utc")), timestamp_or_none(status.get("datetime_actual"))]
    parsed = [value.timestamp() for value in values if value is not None]
    return max(parsed) if parsed else 0.0


def history_event_timestamp(event: dict[str, Any]) -> datetime | None:
    """Return the timestamp belonging to the history message itself.

    Zero's history payloads have appeared with both ISO timestamps and the
    legacy 14-digit values.  ``datetime_actual``/message fields describe when
    the message was produced; ``datetime_utc`` is only the vehicle measurement
    time and is therefore the final fallback.
    """
    candidates = (
        "message_timestamp", "message_time", "event_timestamp", "event_time",
        "timestamp", "created_at", "datetime_actual", "datetime_utc",
    )
    for key in candidates:
        value = event.get(key)
        if value in (None, ""):
            continue
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            try:
                return datetime.fromtimestamp(float(value), timezone.utc)
            except (OverflowError, OSError, ValueError):
                continue
        text = str(value).strip()
        try:
            if len(text) == 14 and text.isdigit():
                return zero_timestamp_to_datetime(text)
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            continue
    return None


def history_event_identity(event: dict[str, Any]) -> str:
    """Build a stable, non-secret identity for one history event."""
    for key in ("event_id", "message_id", "record_id", "id"):
        value = str(event.get(key, "")).strip()
        if value:
            return f"id:{value}"
    relevant = {
        key: event.get(key)
        for key in (
            "message_timestamp", "message_time", "event_timestamp", "event_time",
            "timestamp", "created_at", "datetime_actual", "datetime_utc",
            "soc", "charging", "chargecomplete", "pluggedin", "ignition",
            "reason", "chargingtimeleft",
        )
    }
    digest = hashlib.sha256(
        json.dumps(relevant, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()
    return f"hash:{digest}"


def _history_records(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        records: list[dict[str, Any]] = []
        for item in value:
            records.extend(_history_records(item))
        return records
    if not isinstance(value, dict):
        return []
    nested = value.get("status")
    if isinstance(nested, dict):
        record = dict(nested)
        for key in ("id", "event_id", "message_id", "record_id", "message_timestamp", "message_time", "event_time", "timestamp"):
            if key not in record and key in value:
                record[key] = value[key]
        return [record]
    event_fields = {
        "datetime_utc", "datetime_actual", "message_timestamp", "message_time",
        "event_timestamp", "event_time", "timestamp", "created_at", "reason",
        "charging", "chargecomplete", "pluggedin", "ignition",
    }
    if event_fields.intersection(value):
        return [dict(value)]
    records = []
    for key in (
        "history", "historyreport", "history_report", "items", "records",
        "events", "results", "data", "response", "rows", "transmissions",
    ):
        if key in value:
            records.extend(_history_records(value[key]))
    return records


def history_response_recognized(value: Any) -> bool:
    """Recognize an empty but documented History response without accepting any dict."""
    if isinstance(value, list):
        return True
    if not isinstance(value, dict):
        return False
    if "status" in value:
        return isinstance(value["status"], dict)
    known = {
        "history", "historyreport", "history_report", "items", "records",
        "events", "results", "data", "response", "rows", "transmissions",
    }
    return bool(known.intersection(value)) or bool({
        "datetime_utc", "datetime_actual", "reason", "charging", "ignition",
    }.intersection(value))


def parse_history_events(payload: Any) -> list[dict[str, Any]]:
    """Normalize the small set of history response shapes seen in the API."""
    parsed: list[dict[str, Any]] = []
    for record in _history_records(payload):
        event = dict(record)
        timestamp = history_event_timestamp(event)
        if timestamp is None:
            continue
        event["_history_id"] = history_event_identity(event)
        event["_history_epoch"] = float(timestamp.timestamp())
        event["_history_source"] = "zero_history_api"
        parsed.append(event)
    parsed.sort(key=lambda item: float(item["_history_epoch"]))
    return parsed


def _history_event_status(event: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in event.items() if not key.startswith("_")}


def _history_event_is_continuation(event: dict[str, Any]) -> bool:
    return bool(to_bool(event.get("ignition")) or to_bool(event.get("charging")))


def _clear_balancing_end_candidate(state: dict[str, Any], reason: str = "") -> None:
    state["balancing_end_candidate_epoch"] = 0.0
    state["balancing_end_candidate_seen_epoch"] = 0.0
    state["balancing_end_candidate_confirm_due_epoch"] = 0.0
    state["balancing_end_candidate_event_id"] = ""
    state["balancing_end_candidate_source"] = ""
    state["balancing_end_candidate_generation"] = -1
    state["history_candidate_cancel_reason"] = reason


def _history_event_charging_zero(event: dict[str, Any]) -> bool:
    """Accept charging-off evidence only when the field is explicitly zero."""
    if "charging" not in event or event.get("charging") in (None, ""):
        return False
    value = event.get("charging")
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value == 0
    text = str(value).strip().lower()
    if text in {"0", "false", "no", "off"}:
        return True
    try:
        return float(text) == 0
    except (TypeError, ValueError):
        return False


def _history_session_eligible(state: dict[str, Any]) -> bool:
    return bool(
        state.get("session_active", False)
        and state.get("target_notified", False)
        and str(state.get("charge_phase", "")) == "target_reached"
        and not state.get("complete_notified", False)
        and not state.get("session_terminal", False)
    )


def _terminal_history_followup_eligible(state: dict[str, Any], now_epoch: float) -> bool:
    """Allow bounded history reconciliation after ambiguous terminal evidence."""
    generation = int(state.get("charge_session_generation", 0) or 0)
    if (
        generation <= 0
        or int(state.get("session_history_recorded_generation", -1)) != generation
        or not bool(state.get("session_terminal", False))
        or float(state.get("session_target_reached_epoch", 0.0) or 0.0) <= 0
        or str(state.get("charge_completion_source", "")) not in {
            "history_ignition_off", "last_transmit_ignition_off", "balancing_sleep_timeout",
        }
    ):
        return False
    completed = float(
        state.get("completion_detected_at_epoch", 0.0)
        or state.get("session_completed_epoch", 0.0)
        or 0.0
    )
    age = now_epoch - completed
    return completed > 0 and 0.0 <= age <= HISTORY_TERMINAL_FOLLOWUP_SECONDS


def process_balancing_end_evidence(
    event: dict[str, Any],
    event_epoch: float,
    event_id: str,
    source: str,
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
    *,
    require_current_balancing: bool = False,
) -> bool:
    """Apply the same qualified reason=5 evidence rule to every source."""
    if not _history_session_eligible(state):
        return False
    if require_current_balancing and classify_charge_phase(event, state, config) != "target_reached":
        return False
    generation = int(state.get("charge_session_generation", 0) or 0)
    target_start = max(
        float(state.get("session_started_epoch", 0.0) or 0.0),
        float(state.get("session_balancing_started_epoch", 0.0) or 0.0),
        float(state.get("session_target_reached_epoch", 0.0) or 0.0),
    )
    if event_epoch <= target_start + 0.5:
        return False
    candidate_epoch = float(state.get("balancing_end_candidate_epoch", 0.0) or 0.0)
    if candidate_epoch > 0 and event_epoch > candidate_epoch + 0.5 and _history_event_is_continuation(event):
        _clear_balancing_end_candidate(state, "continuation")
        save_event_diagnostic(
            "balancing_end_candidate_cancelled", event, state, config, now_epoch,
            reason="continuation", evidence_source=source, evidence_id=event_id,
        )
        candidate_epoch = 0.0
    if str(event.get("reason", "")).strip() != "5" or to_bool(event.get("ignition")):
        return False
    if not bool(state.get("last_pluggedin", False)) and not to_bool(event.get("pluggedin")):
        return False
    if candidate_epoch > 0:
        return False
    state["balancing_end_candidate_epoch"] = event_epoch
    state["balancing_end_candidate_seen_epoch"] = now_epoch
    state["balancing_end_candidate_confirm_due_epoch"] = now_epoch + HISTORY_CONFIRMATION_SECONDS
    state["balancing_end_candidate_event_id"] = event_id
    state["balancing_end_candidate_source"] = source
    state["balancing_end_candidate_generation"] = generation
    state["history_candidate_cancel_reason"] = ""
    save_event_diagnostic(
        "balancing_end_candidate", event, state, config, now_epoch,
        evidence_source=source, evidence_id=event_id, balancing_end_at=event_epoch,
    )
    return True


def _set_history_completion(
    event: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
    *,
    source: str,
    reason: str,
) -> bool:
    event_epoch = float(event.get("_history_epoch", 0.0) or 0.0)
    if event_epoch <= 0:
        return False
    if state.get("complete_notified", False) or state.get("session_terminal", False):
        existing = float(state.get("balancing_end_at_epoch", 0.0) or 0.0)
        previous_source = str(state.get("charge_completion_source", ""))
        previous_active_end = session_terminal_end_epoch(state, "complete")
        explicit_stop = source == "history_charging_zero" and event_epoch > float(
            state.get("session_target_reached_epoch", 0.0) or 0.0
        )
        prior_source_is_direct = previous_source in {
            "history_charging_zero", "cloud_chargecomplete", "full_soc_idle",
            "vehicle_status", "shutdown_zero_pulse",
        }
        should_upgrade_to_explicit_stop = explicit_stop and (
            not prior_source_is_direct or previous_active_end <= 0 or event_epoch < previous_active_end
        )
        should_keep_earlier_terminal_evidence = existing <= 0 or event_epoch < existing
        if should_upgrade_to_explicit_stop or should_keep_earlier_terminal_evidence:
            if explicit_stop and not append_session_evidence_update(
                state, config, now_epoch, source, event_epoch,
            ):
                return False
            state["balancing_end_at_epoch"] = event_epoch
            state["balancing_end_evidence"] = source
            if explicit_stop:
                state["charge_completion_source"] = source
            save_event_diagnostic(
                "completion_evidence_update",
                _history_event_status(event), state, config, now_epoch,
                evidence=source, balancing_end_at=event_epoch,
            )
        return True
    state["pending_history_completion"] = source
    state["charge_completion_source"] = source
    state["completion_reason"] = reason
    state["balancing_end_at_epoch"] = event_epoch
    state["balancing_end_evidence"] = source
    state["completion_detected_at_epoch"] = now_epoch
    return True


def append_session_evidence_update(
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
    evidence_source: str,
    end_epoch: float,
) -> bool:
    """Append a reversible projection update for later explicit charging-off evidence."""
    if evidence_source != "history_charging_zero":
        return False
    generation = int(state.get("charge_session_generation", 0) or 0)
    start_epoch = float(state.get("session_started_epoch", 0.0) or 0.0)
    target_epoch = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    if generation <= 0 or end_epoch <= target_epoch or end_epoch > now_epoch + 60.0:
        return False
    if int(state.get("session_history_recorded_generation", -1)) != generation:
        return True
    if start_epoch <= 0 or bool(state.get("session_start_uncertain", False)):
        return False
    record = {
        "record_type": "evidence_update",
        "generation": generation,
        "evidence_updated_at_utc": datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(),
        "ended_at_utc": datetime.fromtimestamp(end_epoch, timezone.utc).isoformat(),
        "duration_seconds": max(0, int(round(end_epoch - start_epoch))),
        "completion_source": evidence_source,
        # The chosen active-end time changed; an SOC snapshot attached to the
        # previous terminal row is no longer evidence for this new endpoint.
        "end_soc": None,
        "end_soc_source": None,
    }
    return safe_append_jsonl(
        diagnostics_daily_path(SESSION_HISTORY_DIR, "session", now_epoch), record, state
    )


def process_history_events(
    events: list[dict[str, Any]],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> None:
    """Consume normalized history events once and derive bounded evidence."""
    if now_epoch is None:
        now_epoch = time.time()
    raw_seen = state.get("history_events_seen", [])
    seen = [str(value) for value in raw_seen if value] if isinstance(raw_seen, list) else []
    seen_set = set(seen)
    target_start = max(
        float(state.get("session_started_epoch", 0.0) or 0.0),
        float(state.get("session_balancing_started_epoch", 0.0) or 0.0),
        float(state.get("session_target_reached_epoch", 0.0) or 0.0),
    )
    for event in sorted(events, key=lambda item: float(item.get("_history_epoch", 0.0) or 0.0)):
        event_id = str(event.get("_history_id") or history_event_identity(event))
        if event_id in seen_set:
            continue
        seen.append(event_id)
        seen_set.add(event_id)
        if len(seen) > HISTORY_MAX_SEEN_EVENTS:
            seen = seen[-HISTORY_MAX_SEEN_EVENTS:]
            seen_set = set(seen)
        event_epoch = float(event.get("_history_epoch", 0.0) or 0.0)
        state["history_last_event_epoch"] = max(
            float(state.get("history_last_event_epoch", 0.0) or 0.0), event_epoch
        )
        event_status = _history_event_status(event)
        save_event_diagnostic(
            "history_event_seen", event_status, state, config, now_epoch,
            history_event_id=event_id, history_event_epoch=event_epoch,
        )

        if event_epoch <= target_start + 0.5:
            continue

        if (state.get("complete_notified", False) or state.get("session_terminal", False)):
            if _history_event_charging_zero(event):
                applied = _set_history_completion(
                    event, state, config, now_epoch,
                    source="history_charging_zero", reason="charging_zero",
                )
                if not applied:
                    seen.remove(event_id)
                    seen_set.discard(event_id)
            continue

        if _history_session_eligible(state) and _history_event_charging_zero(event):
            applied = _set_history_completion(
                event, state, config, now_epoch,
                source="history_charging_zero", reason="charging_zero",
            )
            if not applied:
                seen.remove(event_id)
                seen_set.discard(event_id)
            continue

        process_balancing_end_evidence(
            event, event_epoch, event_id, "history_reason_5", state, config, now_epoch
        )

    state["history_events_seen"] = seen


def maybe_confirm_balancing_end_candidate(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> bool:
    if now_epoch is None:
        now_epoch = time.time()
    if not _history_session_eligible(state):
        return False
    candidate_epoch = float(state.get("balancing_end_candidate_epoch", 0.0) or 0.0)
    due_epoch = float(state.get("balancing_end_candidate_confirm_due_epoch", 0.0) or 0.0)
    if candidate_epoch <= 0 or due_epoch <= 0:
        return False
    contact = status_time_info(status, config, now_epoch).get("contact_time")
    current_epoch = float(contact.timestamp()) if contact is not None else 0.0
    if current_epoch > candidate_epoch + 0.5 and _history_event_is_continuation(status):
        _clear_balancing_end_candidate(state, "current_status_continuation")
        save_event_diagnostic(
            "balancing_end_candidate_cancelled", status, state, config, now_epoch,
            reason="current_status_continuation",
        )
        return False
    if now_epoch < due_epoch:
        return False
    source = str(state.get("balancing_end_candidate_source", "history_reason_5"))
    completion_source = source.replace("reason_5", "ignition_off")
    state["pending_history_completion"] = completion_source
    state["charge_completion_source"] = completion_source
    state["completion_reason"] = "qualified_ignition_off"
    state["balancing_end_at_epoch"] = candidate_epoch
    state["balancing_end_evidence"] = source
    state["completion_detected_at_epoch"] = now_epoch
    state["balancing_end_candidate_confirm_due_epoch"] = 0.0
    save_event_diagnostic(
        "balancing_end_confirmed", status, state, config, now_epoch,
        balancing_end_at=candidate_epoch, completion_detected_at=now_epoch,
    )
    return True


def poll_balancing_history(
    session: requests.Session,
    username: str,
    password: str,
    unit_number: str,
    now_epoch: float,
    state: dict[str, Any],
    config: dict[str, Any],
) -> list[dict[str, Any]]:
    """Poll active balancing or briefly reconcile ambiguous terminal evidence."""
    active_history = _history_session_eligible(state)
    terminal_followup = _terminal_history_followup_eligible(state, now_epoch)
    if not active_history and not terminal_followup:
        return []
    if now_epoch < float(state.get("history_next_poll_epoch", 0.0) or 0.0):
        return []
    last_event = float(state.get("history_last_event_epoch", 0.0) or 0.0)
    session_start = float(state.get("session_started_epoch", 0.0) or 0.0)
    if terminal_followup:
        target_epoch = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
        start_epoch = max(session_start, target_epoch - HISTORY_POLL_OVERLAP_SECONDS)
    else:
        start_epoch = max(session_start, last_event - HISTORY_POLL_OVERLAP_SECONDS, now_epoch - HISTORY_POLL_OVERLAP_SECONDS)
    start_text = datetime.fromtimestamp(start_epoch, timezone.utc).strftime("%Y%m%d%H%M%S")
    end_text = datetime.fromtimestamp(now_epoch, timezone.utc).strftime("%Y%m%d%H%M%S")
    state["history_last_query_epoch"] = now_epoch
    try:
        payload = request_zero(
            session,
            "get_history",
            username,
            password,
            float(config["request_timeout_seconds"]),
            unitnumber=unit_number,
            startdate=start_text,
            enddate=end_text,
        )
        raw_record_count = len(_history_records(payload))
        events = parse_history_events(payload)
    except Exception as error:
        delay = int(state.get("history_backoff_seconds", HISTORY_BACKOFF_INITIAL_SECONDS) or HISTORY_BACKOFF_INITIAL_SECONDS)
        delay = max(HISTORY_BACKOFF_INITIAL_SECONDS, min(HISTORY_BACKOFF_MAX_SECONDS, delay))
        state["history_next_poll_epoch"] = now_epoch + delay
        state["history_backoff_seconds"] = min(HISTORY_BACKOFF_MAX_SECONDS, delay * 2)
        log(f"Zero-History-Abfrage fehlgeschlagen: {error} · neuer Versuch frühestens in {delay} s")
        error_category = getattr(error, "category", "unknown")
        error_details = getattr(error, "details", {})
        details = {
            "command": "get_history",
            "unitnumber_supplied": bool(unit_number),
            "startdate": start_text,
            "enddate": end_text,
            "window_seconds": int(max(0.0, now_epoch - start_epoch)),
            "error_category": str(error_category),
            "delay_seconds": delay,
        }
        if isinstance(error_details, dict):
            details.update(error_details)
        error_text = str(error).lower()
        save_event_diagnostic(
            "history_rate_limited" if error_category == "http" and error_details.get("http_status") == 429 or "rate limit" in error_text else "history_backoff",
            {}, state, config, now_epoch, **details,
        )
        return []

    state["history_next_poll_epoch"] = now_epoch + HISTORY_POLL_INTERVAL_SECONDS
    state["history_backoff_seconds"] = HISTORY_BACKOFF_INITIAL_SECONDS
    response_shape = type(payload).__name__
    response_keys = sorted(str(key) for key in payload)[:20] if isinstance(payload, dict) else []
    response_recognized = history_response_recognized(payload)
    event_type = (
        "history_poll"
        if events or not payload or (response_recognized and raw_record_count == 0)
        else "history_response_unparsed"
    )
    save_event_diagnostic(
        event_type, {}, state, config, now_epoch,
        command="get_history", unitnumber_supplied=bool(unit_number),
        startdate=start_text, enddate=end_text,
        window_seconds=int(max(0.0, now_epoch - start_epoch)),
        response_shape=response_shape, response_keys=response_keys,
        response_recognized=response_recognized,
        raw_record_count=raw_record_count, parsed_event_count=len(events),
    )
    process_history_events(events, state, config, now_epoch)
    return events


def terminal_phase_override(status: dict[str, Any], state: dict[str, Any], config: dict[str, Any]) -> str | None:
    if not bool(state.get("session_terminal", False)):
        return None
    phase = classify_charge_phase(status, state, config)
    if phase not in {"charging", "target_reached"}:
        return None
    terminal_contact = float(state.get("session_terminal_contact_epoch", 0.0) or 0.0)
    contact = status_contact_epoch(status)
    if terminal_contact > 0 and contact > 0 and contact <= terminal_contact + 0.5:
        return "complete"
    return None


def prune_jsonl_by_time(path: Path, cutoff_epoch: float) -> None:
    if not path.exists():
        return
    kept: list[str] = []
    changed = False
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                record = json.loads(line)
                stamp = record.get("fetched_at_utc") or record.get("recorded_at_utc")
                epoch = datetime.fromisoformat(str(stamp).replace("Z", "+00:00")).timestamp()
                if epoch < cutoff_epoch:
                    changed = True
                    continue
            except (ValueError, TypeError, AttributeError):
                # Keep malformed/legacy lines rather than deleting evidence.
                pass
            kept.append(line)
    except OSError:
        return
    if changed:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
        temporary.chmod(0o600)
        temporary.replace(path)
        path.chmod(0o600)


def cleanup_diagnostics_if_due(
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    diag = config.get("diagnostics", {})
    interval = float(diag.get("cleanup_interval_hours", 24)) * 3600
    last = float(state.get("last_diagnostics_cleanup_epoch", 0.0) or 0.0)
    if last > 0 and now_epoch - last < interval:
        return

    retention_days = max(1, int(diag.get("retention_days", 180)))
    cutoff_epoch = now_epoch - retention_days * 86400
    cutoff_date = datetime.fromtimestamp(cutoff_epoch, LOCAL_TZ).date()
    removed = 0
    for directory, prefix in (
        (POLL_HISTORY_DIR, "poll-"),
        (EVENT_HISTORY_DIR, "event-"),
    ):
        if not directory.exists():
            continue
        for path in directory.glob(f"{prefix}*.jsonl"):
            try:
                date_text = path.stem[len(prefix):]
                file_date = datetime.strptime(date_text, "%Y-%m-%d").date()
            except ValueError:
                continue
            if file_date < cutoff_date:
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    pass

    # Beta-2 change histories are single JSONL files; keep them bounded too.
    prune_jsonl_by_time(RAW_HISTORY_FILE, cutoff_epoch)
    prune_jsonl_by_time(HISTORY_FILE, cutoff_epoch)
    # Optional size cap protects small SD cards even with long retention.
    max_size_bytes = min(
        DIAGNOSTICS_MAX_SIZE_MIB,
        max(
            DIAGNOSTICS_MIN_SIZE_MIB,
            int(diag.get("max_size_mib", 2048)),
        ),
    ) * 1024 * 1024
    try:
        candidates = []
        for directory in (POLL_HISTORY_DIR, EVENT_HISTORY_DIR, LOG_DIR):
            if not directory.exists():
                continue
            for path in directory.iterdir():
                if not path.is_file() or path.name == "observer.log":
                    continue
                candidates.append(path)
        def data_size() -> int:
            total = 0
            if DATA_DIR.exists():
                for path in DATA_DIR.rglob("*"):
                    if path.is_file() and not path.is_symlink():
                        try:
                            total += path.stat().st_size
                        except OSError:
                            pass
            return total
        current_size = data_size()
        for path in sorted(candidates, key=lambda item: item.stat().st_mtime):
            if current_size <= max_size_bytes:
                break
            try:
                size = path.stat().st_size
                path.unlink()
                current_size = max(0, current_size - size)
                removed += 1
            except OSError:
                pass
    except OSError:
        pass

    state["last_diagnostics_cleanup_epoch"] = now_epoch
    if removed:
        log(
            f"Diagnose-Aufbewahrung: {removed} alte Dateien entfernt "
            f"(Zeitlimit {retention_days} Tage, Größenlimit {int(diag.get('max_size_mib', 2048))} MiB)."
        )


# ---------------------------------------------------------------------------
# Time semantics and freshness
# ---------------------------------------------------------------------------


def zero_timestamp_to_datetime(value: Any) -> datetime:
    return datetime.strptime(str(value), "%Y%m%d%H%M%S").replace(
        tzinfo=timezone.utc
    )


def timestamp_or_none(value: Any) -> datetime | None:
    try:
        return zero_timestamp_to_datetime(value)
    except (TypeError, ValueError):
        return None


def format_datetime_local(value: datetime | None) -> str:
    if value is None:
        return "unbekannt"
    local = value.astimezone(LOCAL_TZ)
    return f"{local:%Y-%m-%d %H:%M:%S %Z}"


def format_zero_time(value: Any) -> str:
    parsed = timestamp_or_none(value)
    if parsed is None:
        return f"unbekannt ({value!r})"
    return (
        f"{parsed:%Y-%m-%d %H:%M:%S UTC} / "
        f"{parsed.astimezone(LOCAL_TZ):%Y-%m-%d %H:%M:%S %Z}"
    )


def status_time_info(
    status: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> dict[str, Any]:
    """Interpret Zero's two timestamps without conflating their roles.

    datetime_utc is treated as the vehicle/measurement time.
    datetime_actual behaves like a later contact/update time in the observed
    data. Freshness therefore uses the newest plausible one, while both are
    retained for diagnostics.
    """
    if now_epoch is None:
        now_epoch = time.time()

    future_tolerance = float(
        config["freshness"]["future_tolerance_seconds"]
    )
    measurement = timestamp_or_none(status.get("datetime_utc"))
    actual = timestamp_or_none(status.get("datetime_actual"))

    def plausible(value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.timestamp() > now_epoch + future_tolerance:
            return None
        return value

    measurement = plausible(measurement)
    actual = plausible(actual)
    candidates = [value for value in (measurement, actual) if value]
    contact = max(candidates) if candidates else None

    def age(value: datetime | None) -> float:
        if value is None:
            return float("inf")
        return max(0.0, now_epoch - value.timestamp())

    return {
        "measurement_time": measurement,
        "actual_time": actual,
        "contact_time": contact,
        "measurement_age_seconds": age(measurement),
        "actual_age_seconds": age(actual),
        "contact_age_seconds": age(contact),
    }


def format_age(age_seconds: float) -> str:
    if age_seconds == float("inf"):
        return "unbekannt"
    if age_seconds < 120:
        return f"{int(age_seconds)} s"
    return f"{int(age_seconds // 60)} min"


def is_fresh(
    status: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> bool:
    info = status_time_info(status, config, now_epoch)
    return info["contact_age_seconds"] <= float(
        config["freshness"]["max_contact_age_seconds"]
    )


# ---------------------------------------------------------------------------
# Fingerprinting and persistent runtime state
# ---------------------------------------------------------------------------


def status_fingerprint(status: dict[str, Any]) -> str:
    relevant = {field: status.get(field) for field in FINGERPRINT_FIELDS}
    canonical = json.dumps(
        relevant,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def default_runtime_state() -> dict[str, Any]:
    return {
        "version": 16,
        "initialized": False,
        "charge_session_generation": 0,
        "physical_session_id": "",
        "last_processed_fingerprint": "",
        "last_raw_fingerprint": "",
        "last_valid_soc": None,
        "zero_candidate_count": 0,
        "zero_candidate_first_seen_epoch": None,
        "zero_candidate_vehicle_times": [],
        "charge_phase": "unknown",
        "session_active": False,
        "target_soc": None,
        "target_source": "",
        "start_notified": False,
        "target_notified": False,
        "complete_notified": False,
        "session_end_notified": False,
        "session_end_reason": "",
        "interruption_candidate_count": 0,
        "interruption_candidate_phase": "",
        "interruption_candidate_last_contact_epoch": 0.0,
        "charge_state_confidence": "unknown",
        "charge_completion_source": "",
        "session_started_epoch": 0.0,
        "session_start_observed_epoch": 0.0,
        "session_start_uncertain": False,
        "session_start_soc": None,
        "session_last_observed_soc": None,
        "plugged_started_epoch": 0.0,
        "plugged_episode_initialized": False,
        "plugged_episode_id": "",
        "plugged_episode_started_epoch": 0.0,
        "plugged_episode_active": False,
        "plugged_episode_last_contact_epoch": 0.0,
        "plugged_episode_observation_count": 0,
        "plugged_episode_unplug_candidates": 0,
        "plugged_episode_start_soc": None,
        "failed_start_last_contact_epoch": 0.0,
        "failed_start_cancelled_episode_id": "",
        "failed_start_evidence_episode_id": "",
        "failed_start_evidence_started_epoch": 0.0,
        "failed_start_evidence_start_soc": None,
        "failed_start_evidence_count": 0,
        "post_charge_cancelled_session_id": "",
        "battery_care_band": "",
        "battery_care_since_epoch": 0.0,
        "battery_care_last_contact_epoch": 0.0,
        "battery_care_odometer": None,
        "parked_anchor": None,
        "parked_moved_count": 0,
        "last_tipover": False,
        "vehicle_firmware": "",
        "session_location_id": "",
        "session_target_reached_epoch": 0.0,
        "session_target_soc": None,
        "session_completed_epoch": 0.0,
        "session_completion_witnessed": False,
        "session_completion_contact_epoch": 0.0,
        "post_charge_last_contact_epoch": 0.0,
        "post_charge_recovery_required": False,
        "post_charge_recovery_count": 0,
        "session_ended_epoch": 0.0,
        "session_history_recorded_generation": -1,
        "last_charging_sample_fingerprint": "",
        "last_charging_sample_epoch": 0.0,
        "charging_sample_sequence_generation": -1,
        "charging_sample_sequence_next": None,
        "session_terminal": False,
        "session_terminal_contact_epoch": 0.0,
        "session_unplug_confirmed": False,
        "session_balancing_started_epoch": 0.0,
        "shutdown_zero_pulse_observed": False,
        "shutdown_zero_pulse_epoch": 0.0,
        "shutdown_zero_pulse_generation": -1,
        "shutdown_zero_evidence_recorded_generation": -1,
        "balancing_last_contact_value_epoch": 0.0,
        "balancing_last_progress_observed_epoch": 0.0,
        "balancing_stale_success_polls": 0,
        "balancing_sleep_completion_contact_epoch": 0.0,
        "last_pluggedin": False,
        "last_ignition": False,
        "history_next_poll_epoch": 0.0,
        "history_last_query_epoch": 0.0,
        "history_last_event_epoch": 0.0,
        "history_backoff_seconds": 60,
        "history_events_seen": [],
        "balancing_end_candidate_epoch": 0.0,
        "balancing_end_candidate_seen_epoch": 0.0,
        "balancing_end_candidate_confirm_due_epoch": 0.0,
        "balancing_end_candidate_event_id": "",
        "balancing_end_candidate_source": "",
        "balancing_end_candidate_generation": -1,
        "history_candidate_cancel_reason": "",
        "balancing_end_at_epoch": 0.0,
        "balancing_end_evidence": "",
        "completion_reason": "",
        "completion_detected_at_epoch": 0.0,
        "pending_history_completion": "",
        "last_abrp_send_epoch": 0.0,
        "last_abrp_fingerprint": "",
        "last_abrp_success_epoch": 0.0,
        "last_abrp_error": "",
        "abrp_consecutive_errors": 0,
        "abrp_next_retry_epoch": 0.0,
        "last_live_activity_success_epoch": 0.0,
        "last_live_activity_action": "",
        "last_live_activity_error": "",
        "aivi_consecutive_errors": 0,
        "aivi_next_retry_epoch": 0.0,
        "live_activity_active": False,
        "live_activity_session_generation": -1,
        "live_activity_session_id": "",
        "live_activity_last_payload_fingerprint": "",
        "live_activity_last_phase": "",
        "live_activity_last_update_epoch": 0.0,
        "live_activity_final_sent": False,
        "live_activity_idle_due_epoch": 0.0,
        "live_activity_idle_payload": None,
        "live_activity_idle_sent": False,
        "live_activity_intermediate_due_epoch": 0.0,
        "live_activity_intermediate_payload": None,
        "live_activity_intermediate_session_generation": -1,
        "live_activity_intermediate_interval_seconds": 60.0,
        "live_activity_real_update_count": 0,
        "live_activity_intermediate_update_count": 0,
        "live_activity_balancing_display_bucket": -1,
        "live_activity_closed_for_session": False,
        "three_phase_active_kind": "",
        "three_phase_active_slug": "",
        "three_phase_active_payload": None,
        "three_phase_session_generation": -1,
        "three_phase_complete_started_generation": -1,
        "three_phase_terminal_phase": "",
        "three_phase_idle_due_epoch": 0.0,
        "three_phase_idle_payload": None,
        "three_phase_idle_slug": "",
        "three_phase_idle_sent": False,
        "three_phase_balancing_display_bucket": -1,
        "last_poll_attempt_epoch": 0.0,
        "last_poll_success_epoch": 0.0,
        "last_status_change_epoch": 0.0,
        "last_contact_epoch": 0.0,
        "offline_episode_started_epoch": 0.0,
        "offline_episode_contact_epoch": 0.0,
        "last_measurement_epoch": 0.0,
        "last_poll_interval_seconds": 0,
        "consecutive_errors": 0,
        "last_error": "",
        "last_diagnostics_cleanup_epoch": 0.0,
        "last_diagnostics_error": "",
        "last_shutdown_epoch": 0.0,
        "last_shutdown_reason": "",
    }


def sanitize_runtime_types(stored: dict[str, Any]) -> dict[str, Any]:
    """Numbers stay numbers: a damaged value falls back to its default instead of
    stopping the Observer at every start (and the dashboard on every request)."""
    defaults = default_runtime_state()
    cleaned = dict(stored)
    for key, default in defaults.items():
        if key not in cleaned or isinstance(default, bool) or not isinstance(default, (int, float)):
            continue
        value = cleaned[key]
        if value is None or (isinstance(value, (int, float)) and not isinstance(value, bool)):
            if isinstance(value, float) and not math.isfinite(value):
                cleaned[key] = default
            continue
        number = to_float_or_none(value)
        if number is None or not math.isfinite(number):
            cleaned[key] = default
        else:
            cleaned[key] = int(number) if isinstance(default, int) and number.is_integer() else number
    return cleaned


def migrate_runtime_state(stored: dict[str, Any]) -> dict[str, Any]:
    stored = sanitize_runtime_types(stored)
    previous_version = int(stored.get("version", 0) or 0)
    state = {**default_runtime_state(), **stored, "version": 16}

    if (
        previous_version < 15
        and "interruption_candidate_last_contact_epoch" not in stored
        and int(state.get("interruption_candidate_count", 0) or 0) > 0
        and str(state.get("interruption_candidate_phase", "")) == "unplugged"
    ):
        previous_contact = float(state.get("last_contact_epoch", 0.0) or 0.0)
        if previous_contact > 0:
            # Preserve an in-progress confirmation without counting the same
            # persisted vehicle observation again immediately after an upgrade.
            state["interruption_candidate_last_contact_epoch"] = previous_contact
        else:
            # Without a persisted contact baseline the pending confirmation is
            # ambiguous, so require two newly observed contacts after upgrade.
            state["interruption_candidate_count"] = 0
            state["interruption_candidate_phase"] = ""

    if previous_version < 16:
        try:
            sequence_generation = int(state.get("charging_sample_sequence_generation", -1) or -1)
        except (TypeError, ValueError, OverflowError):
            sequence_generation = -1
        next_sequence = state.get("charging_sample_sequence_next")
        if sequence_generation <= 0 or type(next_sequence) is not int or next_sequence <= 0:
            state["charging_sample_sequence_generation"] = -1
            state["charging_sample_sequence_next"] = None

    # Keep the semantic identity of a physical charge separate from the
    # observer generation. Older states get a deterministic compatibility id
    # from their persisted start time.
    if not str(state.get("physical_session_id") or "").strip():
        try:
            generation = int(state.get("charge_session_generation", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            generation = 0
        started = float(state.get("session_started_epoch", 0.0) or 0.0)
        if generation > 0:
            state["physical_session_id"] = (
                f"session-{generation}-{int(started)}" if started > 0
                else f"session-{generation}"
            )

    if (
        bool(stored.get("interruption_notified", False))
        and not state.get("session_end_notified", False)
    ):
        state["session_end_notified"] = True
        state["session_end_reason"] = "interrupted"

    # Reset retired Live-Activity transport state when migrating runtime data.
    # Never inherit an apparently active HA activity into the Aivi session.
    if previous_version < 9:
        for key, value in {
            "last_live_activity_success_epoch": 0.0,
            "last_live_activity_action": "",
            "last_live_activity_error": "",
            "live_activity_active": False,
            "live_activity_session_generation": -1,
            "live_activity_last_payload_fingerprint": "",
            "live_activity_last_phase": "",
            "live_activity_last_update_epoch": 0.0,
            "live_activity_final_sent": False,
            "live_activity_idle_due_epoch": 0.0,
            "live_activity_idle_payload": None,
            "live_activity_idle_sent": False,
            "live_activity_intermediate_due_epoch": 0.0,
            "live_activity_intermediate_payload": None,
            "live_activity_intermediate_session_generation": -1,
            "live_activity_intermediate_interval_seconds": 60.0,
            "live_activity_real_update_count": 0,
            "live_activity_intermediate_update_count": 0,
            "live_activity_closed_for_session": False,
        }.items():
            state[key] = value

    if previous_version == 9:
        # Beta 2 could carry success timestamps from an old Aivi slug / legacy ABRP
        # configuration across migration.  Clear display-only integration history
        # once; session continuity and deduplication fingerprints are preserved.
        state["last_live_activity_success_epoch"] = 0.0
        state["last_live_activity_action"] = ""
        state["last_live_activity_error"] = ""
        state["live_activity_real_update_count"] = 0
        state["live_activity_intermediate_update_count"] = 0
        state["last_abrp_success_epoch"] = 0.0
        state["last_abrp_error"] = ""

    if previous_version < 12:
        # Beta 4 could leave a sleep-completed session active forever. Mark any
        # already-completed session terminal; a genuinely newer charging contact
        # is allowed to open the next generation.
        if bool(state.get("complete_notified", False)) or bool(state.get("session_end_notified", False)):
            state["session_terminal"] = True
            state["session_active"] = False
            contact = float(state.get("balancing_sleep_completion_contact_epoch", 0.0) or 0.0)
            if contact <= 0:
                contact = float(state.get("last_contact_epoch", 0.0) or 0.0)
            state["session_terminal_contact_epoch"] = max(
                float(state.get("session_terminal_contact_epoch", 0.0) or 0.0), contact
            )

    for retired_key in (
        "last_push_success_epoch", "last_push_title", "last_push_error",
        "last_ha_success_epoch", "last_ha_action", "last_ha_error",
        "last_ha_notification_success_epoch", "last_ha_notification_title",
        "last_ha_notification_error", "interruption_notified",
        "live_activity_clear_due_epoch", "live_activity_clear_schedule_epochs",
        "live_activity_clear_attempt_index", "live_activity_clear_attempt_count",
        "live_activity_last_clear_attempt_epoch",
    ):
        state.pop(retired_key, None)

    return state

def load_runtime_state() -> dict[str, Any]:
    if not RUNTIME_STATE_FILE.exists():
        return default_runtime_state()
    try:
        stored = json.loads(RUNTIME_STATE_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        log("Runtime-State war unlesbar; starte mit sicherem Grundzustand.")
        return default_runtime_state()
    if not isinstance(stored, dict):
        return default_runtime_state()
    state = migrate_runtime_state(stored)
    # A sample append and runtime-state save are separate durable writes. A
    # crash between them can leave a valid-looking but stale next-sequence
    # cache; rebuild it from the append-only samples after every process start.
    state["charging_sample_sequence_generation"] = -1
    state["charging_sample_sequence_next"] = None
    return state


def save_runtime_state(state: dict[str, Any]) -> None:
    with runtime_state_lock():
        # Observer may have computed this state before a history-removal
        # request acquired the persistence lock. Reconcile at the write
        # boundary so a late active state cannot coexist with a tombstone for
        # the same generation.
        try:
            generation = int(state.get("charge_session_generation", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            generation = 0
        active = (
            bool(state.get("session_active"))
            or bool(state.get("plugged_episode_active"))
            or str(state.get("charge_phase") or "") in {"charging", "target_reached"}
        )
        if generation > 0 and active and generation in zero_functional.session_removals():
            zero_functional.set_session_removed(generation, False)
        atomic_write_json(RUNTIME_STATE_FILE, state)


@contextmanager
def runtime_state_lock():
    """Serialize runtime-state reads that gate mutations with Observer writes."""
    with _RUNTIME_STATE_LOCK:
        RUNTIME_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        lock_path = RUNTIME_STATE_FILE.with_name(f".{RUNTIME_STATE_FILE.name}.lock")
        with lock_path.open("a+b") as handle:
            try:
                os.chmod(lock_path, 0o600)
            except OSError:
                pass
            if fcntl is not None:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if fcntl is not None:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def safe_save_runtime_state(state: dict[str, Any]) -> bool:
    try:
        save_runtime_state(state)
        return True
    except OSError as error:
        state["last_diagnostics_error"] = f"Runtime-State konnte nicht gespeichert werden: {error}"
        log("Warnung: Runtime-State konnte nicht gespeichert werden; Observer läuft weiter.")
        return False


# ---------------------------------------------------------------------------
# Zero Cloud
# ---------------------------------------------------------------------------


class ZeroRequestError(RuntimeError):
    """Secret-safe Zero Cloud failure with diagnostics suitable for local logs."""

    def __init__(self, category: str, message: str, **details: Any) -> None:
        super().__init__(message)
        self.category = category
        self.details = details


def request_zero(
    session: requests.Session,
    command: str,
    username: str,
    password: str,
    timeout_seconds: float,
    **extra_parameters: Any,
) -> Any:
    """Query Zero Cloud without exposing credentials in errors.

    The legacy endpoint carries username and password in the query string.
    Raw ``requests`` exceptions can therefore contain the complete URL.
    Convert every transport failure to a deliberately generic message before
    it can reach the journal or runtime diagnostics.
    """
    parameters = {
        "commandname": command,
        "user": username,
        "pass": password,
        "format": "json",
        **extra_parameters,
    }
    try:
        response = session.get(
            ZERO_API_URL,
            params=parameters,
            timeout=timeout_seconds,
        )
        response.raise_for_status()
    except requests.Timeout:
        raise ZeroRequestError("timeout", "Zero-Cloud-Anfrage mit Zeitüberschreitung.") from None
    except requests.ConnectionError:
        raise ZeroRequestError("connection", "Zero Cloud nicht erreichbar (Netzwerk oder DNS).") from None
    except requests.HTTPError as error:
        status = (
            error.response.status_code
            if error.response is not None
            else "unbekannt"
        )
        response = error.response
        raise ZeroRequestError(
            "http", f"Zero Cloud antwortete mit HTTP-Fehler {status}.",
            http_status=status,
            content_type=(response.headers.get("Content-Type", "") if response is not None else ""),
            content_length=(len(response.content) if response is not None else 0),
        ) from None
    except requests.RequestException:
        raise ZeroRequestError("request", "Zero-Cloud-Anfrage fehlgeschlagen.") from None

    try:
        data = response.json()
    except ValueError:
        raise ZeroRequestError(
            "invalid_json", "Zero Cloud lieferte keine gültige JSON-Antwort.",
            content_type=response.headers.get("Content-Type", ""),
            content_length=len(response.content),
        ) from None

    if isinstance(data, dict) and data.get("error"):
        error_value = data.get("error")
        raise ZeroRequestError(
            "api_error", "Zero Cloud meldete einen API-Fehler.",
            error_value_type=type(error_value).__name__,
            error_keys=(sorted(str(key) for key in error_value) if isinstance(error_value, dict) else []),
        )
    return data


def vehicle_display_label(vehicle: dict[str, Any], index: int = 1) -> str:
    """Return a useful label without relying on one specific Zero API schema."""
    candidates = (
        "unitname", "name", "vehicle_name", "model", "modelname",
        "vehiclemodel", "type",
    )
    for key in candidates:
        value = str(vehicle.get(key, "")).strip()
        if value and value.lower() not in {"none", "null"}:
            return value
    unit = str(vehicle.get("unitnumber", "")).strip()
    if unit:
        return f"Zero Motorcycle ({unit})"
    return f"Zero Motorcycle {index}"


def vehicle_model_label(vehicle: dict[str, Any]) -> str:
    """Return the API model independently from a user-defined display name."""
    for key in ("model", "modelname", "vehiclemodel", "type"):
        value = str(vehicle.get(key, "")).strip()
        if value and value.lower() not in {"none", "null"}:
            return value
    return "Zero Motorcycle"


def select_account_vehicle(
    vehicles: list[Any], selected_unit_number: str | None
) -> dict[str, Any]:
    usable = [vehicle for vehicle in vehicles if isinstance(vehicle, dict)]
    if not usable:
        raise RuntimeError("Kein verwendbares Fahrzeug im Zero-Konto gefunden.")

    selected = str(selected_unit_number or "").strip()
    if selected:
        for vehicle in usable:
            if str(vehicle.get("unitnumber", "")).strip() == selected:
                return vehicle
        raise RuntimeError(
            "Das konfigurierte Fahrzeug wurde im Zero-Konto nicht gefunden. "
            "Bitte 'zero-connect setup' erneut ausführen."
        )

    if len(usable) == 1:
        return usable[0]
    raise RuntimeError(
        "Mehrere Fahrzeuge im Zero-Konto gefunden, aber keines ausgewählt. "
        "Bitte 'zero-connect setup' ausführen."
    )


# ---------------------------------------------------------------------------
# Plausibility filtering
# ---------------------------------------------------------------------------


def reset_zero_candidate(state: dict[str, Any]) -> None:
    state["zero_candidate_count"] = 0
    state["zero_candidate_first_seen_epoch"] = None
    state["zero_candidate_vehicle_times"] = []


def filter_soc(
    raw_status: dict[str, Any],
    state: dict[str, Any],
    now_epoch: float,
) -> tuple[dict[str, Any], bool, str | None]:
    status = copy.deepcopy(raw_status)
    raw_soc = to_float_or_none(raw_status.get("soc"))
    last_valid = to_float_or_none(state.get("last_valid_soc"))

    if raw_soc is None or not 0 <= raw_soc <= 100:
        if last_valid is None:
            return status, False, "SoC fehlt oder liegt außerhalb 0…100 %."
        status["soc"] = last_valid
        return status, False, "Ungültiger SoC durch letzten gültigen Wert ersetzt."

    current_generation = int(state.get("charge_session_generation", 0) or 0)
    shutdown_pulse_for_session = bool(
        state.get("shutdown_zero_pulse_observed", False)
        and int(state.get("shutdown_zero_pulse_generation", -1)) == current_generation
    )
    terminal_charge = bool(
        state.get("target_notified", False) or state.get("session_terminal", False)
    )

    # A previously qualified shutdown pulse remains evidence for this physical
    # session. Recover an already-persisted zero from its own final charging
    # sample; if no trustworthy sample exists, suppress the display value.
    # This is exceptional (raw SOC 0 after a terminal session only), so the
    # normal poll path performs no additional sample-history reads.
    if (
        raw_soc <= 0
        and shutdown_pulse_for_session
        and terminal_charge
        and not to_bool(raw_status.get("charging"))
    ):
        if last_valid is None or last_valid <= 2:
            try:
                samples = load_charging_samples(current_generation)
            except (OSError, ValueError, TypeError):
                samples = []
            recovery_candidates: list[float | None] = []
            for sample in samples:
                try:
                    sample_generation = int(sample.get("generation", 0) or 0)
                except (ValueError, TypeError, OverflowError):
                    continue
                if sample_generation == current_generation:
                    recovery_candidates.append(to_float_or_none(sample.get("soc")))
            recovered_soc = next(
                (value for value in reversed(recovery_candidates) if value is not None and 2 < value <= 100),
                None,
            )
            if recovered_soc is not None:
                last_valid = recovered_soc
                state["last_valid_soc"] = recovered_soc
        if last_valid is None or last_valid <= 2:
            status["soc"] = None
            return status, False, "Shutdown-SoC 0 % ohne gültige Wiederherstellungsprobe ausgeblendet."
        status["soc"] = last_valid
        return status, False, f"Shutdown-SoC 0 % verworfen; verwende {last_valid:.0f} % aus Session {current_generation}."

    if raw_soc > 0 or last_valid is None or last_valid <= 2:
        status["soc"] = raw_soc
        state["last_valid_soc"] = raw_soc
        reset_zero_candidate(state)
        return status, True, None

    # A repeatable raw 0-% pulse has been observed while the SR/S shuts down
    # after balancing. In that context it is evidence, never a real displayed
    # SoC, even if the telematics unit repeats the pulse for several minutes.
    post_balancing_shutdown = (
        (last_valid >= 90 or shutdown_pulse_for_session)
        and terminal_charge
    )
    if post_balancing_shutdown:
        status["soc"] = last_valid
        return status, False, f"Shutdown-SoC 0 % verworfen; verwende {last_valid:.0f} %."

    state["zero_candidate_count"] = min(
        3, int(state.get("zero_candidate_count", 0)) + 1
    )
    if state.get("zero_candidate_first_seen_epoch") is None:
        state["zero_candidate_first_seen_epoch"] = now_epoch

    vehicle_time = (
        f"{raw_status.get('datetime_utc', '')}|"
        f"{raw_status.get('datetime_actual', '')}"
    )
    candidate_times = list(state.get("zero_candidate_vehicle_times", []))
    if vehicle_time != "|" and vehicle_time not in candidate_times:
        candidate_times.append(vehicle_time)
    state["zero_candidate_vehicle_times"] = candidate_times[-5:]

    first_seen = float(state["zero_candidate_first_seen_epoch"])
    span = now_epoch - first_seen
    count = int(state["zero_candidate_count"])
    distinct_times = len(state["zero_candidate_vehicle_times"])

    if count >= 3 and span >= 120 and distinct_times >= 2:
        status["soc"] = 0.0
        state["last_valid_soc"] = 0.0
        reset_zero_candidate(state)
        return status, True, "Bestätigter SoC 0 % nach Plausibilisierung."

    status["soc"] = last_valid
    return (
        status,
        False,
        (
            f"Transienter SoC 0 % verworfen; verwende {last_valid:.0f} % "
            f"(Bestätigung {count}/3)."
        ),
    )


# ---------------------------------------------------------------------------
# ABRP
# ---------------------------------------------------------------------------


def send_to_abrp(
    status: dict[str, Any],
    abrp_token: str,
    abrp_api_key: str,
    timeout_seconds: float,
    *,
    telemetry_utc: int | None = None,
    config: dict[str, Any] | None = None,
) -> None:
    telemetry: dict[str, Any] = {
        "utc": int(telemetry_utc if telemetry_utc is not None else time.time()),
        "soc": to_float(status.get("soc")),
        "is_charging": int(to_bool(status.get("charging"))),
    }

    coordinates = vehicle_gps_coordinates(status)
    if coordinates is not None:
        latitude, longitude = coordinates
        telemetry["lat"] = latitude
        telemetry["lon"] = longitude

    altitude = to_float_or_none(status.get("altitude"))
    if altitude is not None:
        telemetry["elevation"] = altitude

    heading = to_float_or_none(status.get("heading"))
    if heading is not None:
        telemetry["heading"] = heading

    speed_mph = to_float_or_none(status.get("velocity"))
    odometer_km = vehicle_odometer_km(status, config)
    if odometer_km is not None:
        telemetry["odometer"] = odometer_km
    if speed_mph is not None:
        telemetry["speed"] = speed_mph * MILES_TO_KM

    try:
        response = requests.post(
            ABRP_API_URL,
            params={
                "token": abrp_token,
                "api_key": abrp_api_key,
                "tlm": json.dumps(telemetry, separators=(",", ":")),
            },
            timeout=timeout_seconds,
        )
    except requests.Timeout:
        raise RuntimeError("ABRP-Anfrage mit Zeitüberschreitung.") from None
    except requests.ConnectionError:
        raise RuntimeError("ABRP nicht erreichbar (Netzwerk oder DNS).") from None
    except requests.RequestException:
        raise RuntimeError("ABRP-Anfrage fehlgeschlagen.") from None

    if response.status_code >= 400:
        raise RuntimeError(f"ABRP antwortete mit HTTP {response.status_code}.")

    try:
        result = response.json()
    except ValueError as error:
        raise RuntimeError("ABRP hat keine gültige JSON-Antwort geliefert.") from error
    if result.get("status") != "ok":
        raise RuntimeError(f"ABRP-Fehler: {result}")

    # Redacted runtime evidence for source-of-truth forensics. Never include
    # ABRP credentials or the full request URL.
    try:
        diagnostic = {"sent_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "source": "normalized_vehicle_state", "lat_rounded": round(float(telemetry["lat"]), 2) if telemetry.get("lat") is not None else None, "lon_rounded": round(float(telemetry["lon"]), 2) if telemetry.get("lon") is not None else None, "coordinate_hash": _coordinate_hash(float(telemetry["lat"]), float(telemetry["lon"])) if telemetry.get("lat") is not None and telemetry.get("lon") is not None else None, "utc": telemetry.get("utc"), "soc": telemetry.get("soc"), "is_charging": telemetry.get("is_charging"), "odometer_km": round(float(telemetry["odometer"]), 1) if telemetry.get("odometer") is not None else None}
        temporary = ABRP_DIAGNOSTIC_FILE.with_suffix(".tmp")
        temporary.write_text(json.dumps(diagnostic, ensure_ascii=False), encoding="utf-8")
        temporary.replace(ABRP_DIAGNOSTIC_FILE)
    except OSError:
        pass

    # Keep a bounded, privacy-preserving runtime proof of the actual accepted
    # request. Two decimal places identify only a broad area; exact values are
    # compared transiently in the operator's live validation.
    sent_location = "ohne GPS"
    if telemetry.get("lat") is not None and telemetry.get("lon") is not None:
        sent_location = f"GPS: {float(telemetry['lat']):.2f},{float(telemetry['lon']):.2f}"
    log(
        "ABRP aktualisiert | "
        f"SoC: {telemetry['soc']:.0f} % | "
        f"Laden: {telemetry['is_charging']} | {sent_location}"
    )


# ---------------------------------------------------------------------------
# Charging state machine
# ---------------------------------------------------------------------------


def classify_charge_phase(
    status: dict[str, Any],
    state: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
) -> str:
    """Classify Zero's charging flags, including observed 100-% cloud behavior.

    On the SR/S real-world 100-% recording from 2026-08-14 the cloud kept
    ``chargecomplete=0`` throughout balancing.  The reliable target signal was
    instead SoC=100, charging=1, pluggedin=1 and chargingtimeleft=0.  Later the
    bike reported charging=0 while the cable was still attached.  That second
    state is only interpreted as a completed session when this observer already
    saw the target for the same active charge session; otherwise it remains a
    debounced interruption candidate.
    """
    charging = to_bool(status.get("charging"))
    complete = to_bool(status.get("chargecomplete"))
    plugged = to_bool(status.get("pluggedin"))
    soc = int(round(to_float(status.get("soc"))))
    minutes_left = to_float_or_none(status.get("chargingtimeleft"))
    charging_cfg = (config or DEFAULT_CONFIG).get("charging", {})

    if plugged and charging and complete:
        return "target_reached"

    if plugged and charging and not complete:
        fallback_soc = int(charging_cfg.get("full_target_fallback_soc", 100))
        requires_zero_minutes = bool(
            charging_cfg.get("full_target_requires_zero_minutes", True)
        )
        zero_minutes = minutes_left is not None and minutes_left <= 0
        if soc >= fallback_soc and (zero_minutes or not requires_zero_minutes):
            return "target_reached"
        return "charging"

    if plugged and not charging and complete:
        return "complete"

    if plugged and not charging and not complete:
        if state is not None and bool(
            charging_cfg.get("complete_after_target_when_idle", True)
        ):
            target_soc = to_float_or_none(state.get("target_soc"))
            reached_target = bool(state.get("target_notified", False))
            active_session = bool(state.get("session_active", False))
            at_target = target_soc is not None and soc >= int(round(target_soc))
            if (
                active_session
                and reached_target
                and at_target
            ):
                return "complete"
        return "plugged_idle"

    if not plugged and not charging and not complete:
        return "unplugged"
    return "other"


def format_template(template: str, **values: Any) -> str:
    try:
        return template.format(**values)
    except (KeyError, ValueError) as error:
        raise RuntimeError(f"Ungültige Textvorlage: {error}") from error


def reset_interruption_candidate(state: dict[str, Any]) -> None:
    state["interruption_candidate_count"] = 0
    state["interruption_candidate_phase"] = ""
    state["interruption_candidate_last_contact_epoch"] = 0.0


def reset_balancing_sleep_tracker(state: dict[str, Any]) -> None:
    state["balancing_last_contact_value_epoch"] = 0.0
    state["balancing_last_progress_observed_epoch"] = 0.0
    state["balancing_stale_success_polls"] = 0
    state["balancing_sleep_completion_contact_epoch"] = 0.0


def reset_balancing_history_state(state: dict[str, Any]) -> None:
    for key, value in {
        "history_next_poll_epoch": 0.0,
        "history_last_query_epoch": 0.0,
        "history_last_event_epoch": 0.0,
        "history_backoff_seconds": HISTORY_BACKOFF_INITIAL_SECONDS,
        "balancing_end_candidate_epoch": 0.0,
        "balancing_end_candidate_seen_epoch": 0.0,
        "balancing_end_candidate_confirm_due_epoch": 0.0,
        "balancing_end_candidate_event_id": "",
        "balancing_end_candidate_source": "",
        "balancing_end_candidate_generation": -1,
        "history_candidate_cancel_reason": "",
        "balancing_end_at_epoch": 0.0,
        "balancing_end_evidence": "",
        "completion_reason": "",
        "completion_detected_at_epoch": 0.0,
        "pending_history_completion": "",
    }.items():
        state[key] = value


def note_balancing_cloud_error(state: dict[str, Any], now_epoch: float | None = None) -> None:
    """Make a cloud/network outage restart the balancing-sleep evidence window."""
    state["balancing_stale_success_polls"] = 0
    if now_epoch is None:
        now_epoch = time.time()
    if (
        bool(state.get("session_active", False))
        and bool(state.get("target_notified", False))
        and str(state.get("target_source", "")) in {"full_soc_fallback", "chargecomplete"}
        and not bool(state.get("complete_notified", False))
    ):
        state["balancing_last_progress_observed_epoch"] = now_epoch


def maybe_infer_balancing_sleep_completion(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    time_info: dict[str, Any],
    now_epoch: float,
) -> bool:
    """Infer completion when the bike sleeps after an observed target balancing.

    This fallback is intentionally narrow: the same session must already have
    reached its configured target, Zero Cloud polling must currently succeed,
    and the vehicle/contact timestamp must stop advancing for a configured
    timeout across multiple successful polls.  A full-SoC requirement, when
    explicitly configured, only applies to the synthetic full-SoC target path;
    documented ``chargecomplete`` targets such as 65/85/90 % remain eligible.
    """
    sleep_cfg = config.get("charging", {}).get("balancing_sleep_completion", {})
    if not bool(sleep_cfg.get("enabled", True)):
        return False

    # A sleep-completed session is terminal only for the stale vehicle contact
    # that caused the inference. A genuinely newer charging contact must be able
    # to start the next session instead of being swallowed by the old latch.
    if (
        bool(state.get("complete_notified", False))
        and str(state.get("charge_completion_source", "")) == "balancing_sleep_timeout"
        and bool(state.get("session_terminal", False))
    ):
        contact = time_info.get("contact_time")
        contact_epoch = float(contact.timestamp()) if contact is not None else 0.0
        terminal_contact = float(state.get("session_terminal_contact_epoch", 0.0) or 0.0)
        if terminal_contact > 0 and contact_epoch > 0 and contact_epoch <= terminal_contact + 0.5:
            return True
        return False

    if not (
        bool(state.get("session_active", False))
        and bool(state.get("target_notified", False))
        and str(state.get("target_source", "")) in {"full_soc_fallback", "chargecomplete"}
        and not bool(state.get("complete_notified", False))
    ):
        reset_balancing_sleep_tracker(state)
        return False

    soc = int(round(to_float(status.get("soc"))))
    charging = to_bool(status.get("charging"))
    complete = to_bool(status.get("chargecomplete"))
    plugged = to_bool(status.get("pluggedin"))
    minutes = to_float_or_none(status.get("chargingtimeleft"))
    fallback_soc = int(config.get("charging", {}).get("full_target_fallback_soc", 100))
    target_soc = to_float_or_none(state.get("target_soc"))
    if target_soc is None or soc < target_soc:
        reset_balancing_sleep_tracker(state)
        return False
    if (
        bool(sleep_cfg.get("require_full_soc", False))
        and str(state.get("target_source", "")) == "full_soc_fallback"
        and soc < fallback_soc
    ):
        reset_balancing_sleep_tracker(state)
        return False
    if bool(sleep_cfg.get("require_zero_minutes", True)) and (minutes is None or minutes > 0):
        reset_balancing_sleep_tracker(state)
        return False
    if not (plugged and charging) or (
        complete and str(state.get("target_source", "")) != "chargecomplete"
    ):
        reset_balancing_sleep_tracker(state)
        return False

    contact = time_info.get("contact_time")
    if contact is None:
        return False
    contact_epoch = float(contact.timestamp())
    previous_contact = float(state.get("balancing_last_contact_value_epoch", 0.0) or 0.0)
    if contact_epoch > previous_contact + 0.5:
        state["balancing_last_contact_value_epoch"] = contact_epoch
        state["balancing_last_progress_observed_epoch"] = now_epoch
        state["balancing_stale_success_polls"] = 0
        return False

    if float(state.get("balancing_last_progress_observed_epoch", 0.0) or 0.0) <= 0:
        state["balancing_last_progress_observed_epoch"] = now_epoch
        return False

    state["balancing_stale_success_polls"] = int(
        state.get("balancing_stale_success_polls", 0)
    ) + 1
    timeout = float(sleep_cfg.get("timeout_seconds", 360))
    confirmations = int(sleep_cfg.get("confirmation_polls", 3))
    elapsed = now_epoch - float(state["balancing_last_progress_observed_epoch"])
    if elapsed < timeout or int(state["balancing_stale_success_polls"]) < confirmations:
        return False

    state["charge_completion_source"] = "balancing_sleep_timeout"
    state["charge_state_confidence"] = "inferred"
    state["balancing_sleep_completion_contact_epoch"] = contact_epoch
    state["balancing_end_at_epoch"] = contact_epoch
    state["balancing_end_evidence"] = "stale_vehicle_contact"
    state["completion_reason"] = "balancing_sleep_timeout"
    log(
        "Ladeende abgeleitet: nach erreichtem Ladeziel seit "
        f"{int(elapsed)} s keine neuen Fahrzeugdaten bei erreichbarer Zero Cloud."
    )
    return True


def evaluate_charge_state(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    event_sender: Callable[[str], None],
    *,
    phase_override: str | None = None,
    now_epoch: float | None = None,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    phase = phase_override or classify_charge_phase(status, state, config)
    previous_phase = str(state.get("charge_phase", "unknown"))
    soc = int(round(to_float(status.get("soc"))))

    # Once this generation is persisted, a later same-SOC contact while still
    # plugged is a status refresh, not a new charge.  A confirmed unplug or a
    # lower-SOC charging observation remains eligible to start a real cycle.
    try:
        current_generation = int(state.get("charge_session_generation", 0) or 0)
        recorded_generation = int(state.get("session_history_recorded_generation", -1))
        current_target = to_float_or_none(state.get("target_soc"))
    except (TypeError, ValueError):
        current_generation, recorded_generation, current_target = 0, -1, None
    if (
        current_generation > 0
        and recorded_generation == current_generation
        and phase in {"charging", "target_reached"}
        and to_bool(status.get("pluggedin"))
        and not bool(state.get("session_unplug_confirmed", False))
        and current_target is not None
        and soc >= int(round(current_target))
    ):
        state["session_active"] = False
        state["session_terminal"] = True
        state["complete_notified"] = True
        state["charge_phase"] = "complete"
        return

    # A terminal session is not proof of a physical unplug.  In particular,
    # the vehicle may go quiet during the post-target balancing phase and then
    # report the same plugged/charging state again.  Keep the physical session
    # alive until we have either an explicit unplug or strong new-cycle
    # evidence (a lower SOC).  This prevents a cloud/telemetry gap from
    # manufacturing a second 100 -> 100 session.
    same_physical_session = (
        bool(state.get("session_terminal", False))
        and bool(state.get("complete_notified", False))
        and not bool(state.get("session_unplug_confirmed", False))
        and to_bool(status.get("pluggedin"))
        and (phase in {"charging", "target_reached"})
        and status_contact_epoch(status) > float(state.get("session_terminal_contact_epoch", 0.0) or 0.0) + 0.5
        and to_float_or_none(state.get("target_soc")) is not None
        and soc == int(round(float(state["target_soc"])))
        and (
            to_float_or_none(state.get("session_start_soc")) is None
            or soc >= int(round(float(state["session_start_soc"])))
        )
    )
    if same_physical_session:
        state["session_active"] = True
        state["session_terminal"] = False
        state["complete_notified"] = False
        state["session_end_notified"] = False
        state["session_end_reason"] = ""
        state["charge_completion_source"] = ""
        state["completion_reason"] = ""
        state["session_completed_epoch"] = 0.0
        state["session_completion_witnessed"] = False
        state["session_completion_contact_epoch"] = 0.0
        state["post_charge_last_contact_epoch"] = 0.0
        state["post_charge_recovery_required"] = False
        state["post_charge_recovery_count"] = 0
        state["completion_detected_at_epoch"] = 0.0
        state["physical_session_continued"] = True
        log("Bestehende physische Ladesitzung fortgesetzt | kein Unplug-Evidenz")

    # Do not treat a repeated/stale terminal transmit as a new session.  A
    # genuinely new cycle must carry newer vehicle-contact evidence.
    if (
        bool(state.get("session_terminal", False))
        and to_bool(status.get("pluggedin"))
        and phase in {"charging", "target_reached"}
        and status_contact_epoch(status) <= float(state.get("session_terminal_contact_epoch", 0.0) or 0.0) + 0.5
    ):
        state["charge_phase"] = phase
        return

    if not state.get("initialized", False):
        state["initialized"] = True
        state["charge_phase"] = phase
        state["session_active"] = phase in {"charging", "target_reached"}
        state["session_terminal"] = phase == "complete"
        if state["session_active"] or phase == "complete":
            state["charge_session_generation"] = max(
                1,
                int(state.get("charge_session_generation", 0)),
            )
            state["physical_session_id"] = (
                f"session-{int(state['charge_session_generation'])}-{int(now_epoch)}"
            )
            # A first poll already in an active or completed phase is not proof
            # of the physical plug-in moment. Keep the identity internally, but
            # do not manufacture an exact start timestamp.
            start_is_uncertain = bool(state["session_active"] or phase == "complete")
            state["session_started_epoch"] = 0.0 if start_is_uncertain else now_epoch
            state["session_start_observed_epoch"] = now_epoch
            state["session_start_uncertain"] = start_is_uncertain
            state["session_location_id"] = ""
            state["session_start_soc"] = soc
            state["session_last_observed_soc"] = soc
        if phase in {"charging", "target_reached", "complete"}:
            state["start_notified"] = False if state["session_active"] else True
        if phase in {"target_reached", "complete"}:
            state["target_soc"] = soc
            state["session_target_soc"] = soc if 0 < soc <= 100 else None
            state["session_target_reached_epoch"] = now_epoch
            state["session_balancing_started_epoch"] = now_epoch
            if phase == "target_reached":
                state["target_source"] = (
                    "chargecomplete" if to_bool(status.get("chargecomplete")) else "full_soc_fallback"
                )
                state["charge_state_confidence"] = (
                    "confirmed" if to_bool(status.get("chargecomplete")) else "derived"
                )
            state["target_notified"] = True
        if phase == "complete":
            state["complete_notified"] = True
            state["session_completed_epoch"] = now_epoch
            state["session_completion_witnessed"] = False
            state["session_completion_contact_epoch"] = status_contact_epoch(status) or now_epoch
            state["post_charge_last_contact_epoch"] = state["session_completion_contact_epoch"]
            state["post_charge_recovery_required"] = False
            state["post_charge_recovery_count"] = 0
            state["completion_detected_at_epoch"] = now_epoch
            if float(state.get("balancing_end_at_epoch", 0.0) or 0.0) <= 0:
                state["balancing_end_at_epoch"] = status_contact_epoch(status) or now_epoch
                state["balancing_end_evidence"] = "vehicle_status"
            state["session_terminal"] = True
            state["session_terminal_contact_epoch"] = status_contact_epoch(status)
            if not state.get("charge_completion_source"):
                state["charge_completion_source"] = (
                    "cloud_chargecomplete" if to_bool(status.get("chargecomplete")) else "full_soc_idle"
                )
            state["completion_reason"] = str(state.get("charge_completion_source", "") or "vehicle_status")
            if state.get("charge_state_confidence") == "unknown":
                state["charge_state_confidence"] = (
                    "confirmed" if to_bool(status.get("chargecomplete")) else "derived"
                )
        reset_interruption_candidate(state)
        log(f"Ladezustandsautomat initialisiert | Phase: {phase}")
        return

    if phase == "charging":
        reset_interruption_candidate(state)
        new_session = (
            not state.get("session_active", False)
            or bool(state.get("complete_notified", False))
            or bool(state.get("session_end_notified", False))
            or bool(state.get("session_terminal", False))
        )
        if new_session:
            state["session_active"] = True
            state["charge_session_generation"] = int(
                state.get("charge_session_generation", 0)
            ) + 1
            state["physical_session_id"] = (
                f"session-{int(state['charge_session_generation'])}-{int(now_epoch)}"
            )
            state["target_soc"] = None
            state["session_target_soc"] = None
            state["target_source"] = ""
            state["start_notified"] = False
            state["target_notified"] = False
            state["complete_notified"] = False
            state["session_end_notified"] = False
            state["session_end_reason"] = ""
            state["session_terminal"] = False
            state["session_terminal_contact_epoch"] = 0.0
            state["session_unplug_confirmed"] = False
            state["session_balancing_started_epoch"] = 0.0
            state["shutdown_zero_pulse_observed"] = False
            state["shutdown_zero_pulse_epoch"] = 0.0
            state["shutdown_zero_pulse_generation"] = -1
            state["charge_state_confidence"] = "confirmed"
            state["charge_completion_source"] = ""
            state["session_started_epoch"] = now_epoch
            state["session_start_observed_epoch"] = now_epoch
            state["session_start_uncertain"] = False
            state["session_location_id"] = ""
            state["session_start_soc"] = soc
            state["session_last_observed_soc"] = soc
            state["session_target_reached_epoch"] = 0.0
            state["session_completed_epoch"] = 0.0
            state["session_completion_witnessed"] = False
            state["session_completion_contact_epoch"] = 0.0
            state["post_charge_last_contact_epoch"] = 0.0
            state["post_charge_recovery_required"] = False
            state["post_charge_recovery_count"] = 0
            state["session_ended_epoch"] = 0.0
            reset_balancing_sleep_tracker(state)
            reset_balancing_history_state(state)
            log(f"Neue Ladesitzung erkannt | SoC: {soc} %")

        if not state.get("start_notified", False):
            event_sender("start")
            state["start_notified"] = True

    elif phase == "target_reached":
        reset_interruption_candidate(state)
        if (
            not state.get("session_active", False)
            or bool(state.get("complete_notified", False))
            or bool(state.get("session_end_notified", False))
            or bool(state.get("session_terminal", False))
        ):
            state["session_active"] = True
            state["charge_session_generation"] = int(
                state.get("charge_session_generation", 0)
            ) + 1
            state["physical_session_id"] = (
                f"session-{int(state['charge_session_generation'])}-{int(now_epoch)}"
            )
            state["start_notified"] = True
            state["target_notified"] = False
            state["complete_notified"] = False
            state["session_end_notified"] = False
            state["session_end_reason"] = ""
            state["session_terminal"] = False
            state["session_terminal_contact_epoch"] = 0.0
            state["session_unplug_confirmed"] = False
            state["session_balancing_started_epoch"] = 0.0
            state["shutdown_zero_pulse_observed"] = False
            state["shutdown_zero_pulse_epoch"] = 0.0
            state["shutdown_zero_pulse_generation"] = -1
            # A first sample already in the target phase does not reveal when
            # charging began. Preserve the observed target-phase time separately.
            state["session_started_epoch"] = 0.0
            state["session_start_observed_epoch"] = now_epoch
            state["session_start_uncertain"] = True
            state["session_location_id"] = ""
            state["session_start_soc"] = soc
            # This is the first observed sample of a new physical session.
            # Never compare it with the prior session's SOC and backfill
            # milestones when the session is first seen in target phase.
            state["session_last_observed_soc"] = soc
            state["charge_completion_source"] = ""
            state["session_completed_epoch"] = 0.0
            state["session_ended_epoch"] = 0.0
            state["session_completion_witnessed"] = False
            state["session_completion_contact_epoch"] = 0.0
            state["post_charge_last_contact_epoch"] = 0.0
            state["post_charge_recovery_required"] = False
            state["post_charge_recovery_count"] = 0
            reset_balancing_sleep_tracker(state)
            reset_balancing_history_state(state)

        state["target_soc"] = soc
        state["target_source"] = (
            "chargecomplete" if to_bool(status.get("chargecomplete")) else "full_soc_fallback"
        )
        state["charge_state_confidence"] = (
            "confirmed" if to_bool(status.get("chargecomplete")) else "derived"
        )
        if not state.get("target_notified", False):
            state["session_target_soc"] = soc if 0 < soc <= 100 else None
            state["session_target_reached_epoch"] = now_epoch
            state["session_balancing_started_epoch"] = now_epoch
            event_sender("target")
            state["target_notified"] = True

    elif phase == "complete":
        reset_interruption_candidate(state)
        if state.get("target_soc") is None:
            state["target_soc"] = soc

        if state.get("session_active", False) and not state.get("complete_notified", False):
            if not state.get("charge_completion_source"):
                state["charge_completion_source"] = (
                    "cloud_chargecomplete" if to_bool(status.get("chargecomplete")) else "full_soc_idle"
                )
            state["completion_reason"] = str(state.get("charge_completion_source", "") or "vehicle_status")
            if state.get("charge_state_confidence") != "inferred":
                state["charge_state_confidence"] = (
                    "confirmed" if to_bool(status.get("chargecomplete")) else "derived"
                )
            state["session_completed_epoch"] = now_epoch
            state["session_completion_witnessed"] = True
            state["session_completion_contact_epoch"] = status_contact_epoch(status) or now_epoch
            state["post_charge_last_contact_epoch"] = state["session_completion_contact_epoch"]
            state["post_charge_recovery_required"] = False
            state["post_charge_recovery_count"] = 0
            state["completion_detected_at_epoch"] = now_epoch
            if float(state.get("balancing_end_at_epoch", 0.0) or 0.0) <= 0:
                state["balancing_end_at_epoch"] = status_contact_epoch(status) or now_epoch
                state["balancing_end_evidence"] = "vehicle_status"
            event_sender("complete")
            state["complete_notified"] = True
            state["session_terminal"] = True
            state["session_active"] = False
            state["session_terminal_contact_epoch"] = max(
                status_contact_epoch(status),
                float(state.get("balancing_sleep_completion_contact_epoch", 0.0) or 0.0),
            )

    elif phase in {"unplugged", "plugged_idle", "other"}:
        unfinished_session = (
            state.get("session_active", False)
            and not state.get("complete_notified", False)
        )
        # Plugged-idle is not a physical end. Zero Cloud can transiently
        # report charging=0 (including the known shutdown-SoC pulse) while the
        # cable remains attached. Hold the same physical identity until a
        # confirmed unplug arrives; otherwise every transient flap becomes a
        # false user-visible zero-delta session.
        if phase == "plugged_idle":
            reset_interruption_candidate(state)
            if (state.get("complete_notified", False)
                    and not state.get("session_unplug_confirmed", False)
                    and float(state.get("session_completed_epoch", 0.0) or 0.0) > 0):
                # Completion remains the user-visible result while the same
                # physical connection stays attached, even if Zero later
                # drops its transient chargecomplete/target flags.
                state["charge_phase"] = "complete"
                return
            state["charge_phase"] = phase
            return

        end_reason = "ended" if phase == "unplugged" else ""

        if unfinished_session and end_reason:
            candidate_phase = str(state.get("interruption_candidate_phase", ""))
            contact_epoch = status_contact_epoch(status)
            last_candidate_contact = float(
                state.get("interruption_candidate_last_contact_epoch", 0.0) or 0.0
            )
            if contact_epoch > 0 and contact_epoch > last_candidate_contact + 0.5:
                if candidate_phase == phase:
                    state["interruption_candidate_count"] = int(
                        state.get("interruption_candidate_count", 0)
                    ) + 1
                else:
                    state["interruption_candidate_phase"] = phase
                    state["interruption_candidate_count"] = 1
                state["interruption_candidate_last_contact_epoch"] = contact_epoch

                required = int(config["charging"]["interruption_confirmation_polls"])
                count = int(state["interruption_candidate_count"])
                label = (
                    "Mögliches bewusstes Ladeende"
                    if end_reason == "ended"
                    else "Mögliche Ladeunterbrechung"
                )
                log(f"{label} | Bestätigung {count}/{required} | Phase: {phase}")

                if count >= required and not state.get("session_end_notified", False):
                    event_sender(end_reason)
                    state["session_end_notified"] = True
                    state["session_end_reason"] = end_reason
                    state["session_ended_epoch"] = now_epoch
                    state["charge_state_confidence"] = "confirmed"
                    if not state.get("charge_completion_source"):
                        state["charge_completion_source"] = end_reason
                    state["session_active"] = False
                    state["session_terminal"] = True
                    state["session_terminal_contact_epoch"] = contact_epoch
                    if phase == "unplugged":
                        state["session_unplug_confirmed"] = True
                    reset_interruption_candidate(state)
        else:
            reset_interruption_candidate(state)
            if phase == "unplugged" and not unfinished_session:
                state["session_unplug_confirmed"] = True
                state["session_active"] = False

    state["charge_phase"] = phase
    if phase != previous_phase:
        log(f"Ladephase: {previous_phase} → {phase}")

# ---------------------------------------------------------------------------
# Aivi Live Activity
# ---------------------------------------------------------------------------

AIVI_API_BASE_URL = "https://api.getaivi.app"


def aivi_is_configured(
    config: dict[str, Any],
    token: str | None,
    activity_slug: str | None,
) -> bool:
    return bool(config["aivi"].get("enabled", False) and token and activity_slug)


def send_aivi_activity(
    payload: dict[str, Any],
    token: str,
    activity_slug: str,
    timeout_seconds: float,
) -> None:
    try:
        response = requests.patch(
            f"{AIVI_API_BASE_URL}/activity/{activity_slug}",
            headers={
                "Authorization": f"Token {token}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=timeout_seconds,
        )
    except requests.Timeout:
        raise RuntimeError("Aivi-Anfrage mit Zeitüberschreitung.") from None
    except requests.ConnectionError:
        raise RuntimeError("Aivi nicht erreichbar (Netzwerk oder DNS).") from None
    except requests.RequestException:
        raise RuntimeError("Aivi-Anfrage fehlgeschlagen.") from None

    if response.status_code >= 400:
        detail = ""
        try:
            body = response.json()
            if isinstance(body, dict):
                detail = str(body.get("detail", "")).strip()
        except ValueError:
            detail = ""
        suffix = f": {detail}" if detail else ""
        raise RuntimeError(f"Aivi antwortete mit HTTP {response.status_code}{suffix}.")


def live_payload_fingerprint(payload: dict[str, Any]) -> str:
    canonical = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def rounded_charge_minutes(status: dict[str, Any]) -> int | None:
    minutes = to_float_or_none(status.get("chargingtimeleft"))
    if minutes is None or not 1 <= minutes <= 24 * 60:
        return None
    return max(1, int(round(minutes)))


AIVI_ENGLISH_LABELS = {
    "charging": "Charging",
    "charging_right": "until target",
    "target": "Charging complete",
    "target_right": "Still connected",
    "complete": "Charging complete",
    "complete_right": "Fully charged",
    "ended": "Charging ended",
    "ended_right": "Unplugged",
    "balancing_ended": "Charging ended",
    "balancing_ended_right": "Unplugged",
    "interrupted": "Charging interrupted",
    "interrupted_right": "Connection status unknown",
    "balancing_interrupted": "Charging interrupted",
    "balancing_interrupted_right": "Connection status unknown",
}


def aivi_labels(config: dict[str, Any]) -> dict[str, str]:
    aivi = config.get("aivi", {})
    if str(aivi.get("language", "de")).lower() == "en":
        return dict(AIVI_ENGLISH_LABELS)
    labels = {str(key): str(value) for key, value in aivi.get("live_activity", {}).get("labels", {}).items()}
    # Older installed configs may still store the pre-Round-9 target wording.
    # These concepts are now fixed by observed state semantics, not user labels.
    labels.update({
        "charging_right": "bis Ladeziel",
        "target": "Ladevorgang abgeschlossen",
        "target_right": "Weiterhin angesteckt",
    })
    return labels


def live_style(phase: str, config: dict[str, Any]) -> dict[str, Any]:
    styles = config["aivi"]["live_activity"]["styles"]
    key = phase if phase in styles else "charging"
    return dict(styles[key])


def live_text_parts(
    phase: str,
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> tuple[str, str, str, str]:
    labels = aivi_labels(config)
    english = str(config.get("aivi", {}).get("language", "de")).lower() == "en"
    soc = max(0, min(100, int(round(to_float(status.get("soc"))))))
    if phase == "charging":
        remaining = rounded_charge_minutes(status)
        if remaining is None:
            header_right = "Charging" if english else "Lädt"
        else:
            header_right = duration_text(remaining * 60)
        compact = f"{soc} %"
        return (header_right, str(labels["charging"]), str(labels["charging_right"]), compact)
    if phase == "target_reached":
        return (
            "Done" if english else "Fertig",
            str(labels["target"]), str(labels["target_right"]), f"{soc} %",
        )
    if phase == "complete":
        return ("Done" if english else "Fertig", str(labels["complete"]), str(labels["complete_right"]), "✓")
    if phase == "ended":
        if state.get("target_notified", False):
            footer_left = "Charging ended" if english else "Laden beendet"
            footer_right = "Unplugged" if english else "Nicht mehr angesteckt"
        else:
            footer_left = labels["ended"]
            footer_right = labels["ended_right"]
        return ("Ended" if english else "Beendet"), str(footer_left), str(footer_right), "✓"
    if phase == "interrupted":
        if state.get("target_notified", False):
            footer_left = "Charging interrupted" if english else "Ladeunterbrechung"
            footer_right = "Connection status unknown" if english else "Anschlussstatus unbekannt"
        else:
            footer_left = labels["interrupted"]
            footer_right = labels["interrupted_right"]
        return ("Interrupted" if english else "Störung"), str(footer_left), str(footer_right), "!"
    raise RuntimeError(f"Unbekannte Live-Activity-Phase: {phase}")


def build_live_update_payload(
    phase: str,
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    lifecycle_state: str = "ONGOING",
    now_epoch: float | None = None,
) -> dict[str, Any]:
    if now_epoch is None:
        now_epoch = time.time()
    soc = max(0, min(100, int(round(to_float(status.get("soc"))))))
    style = live_style(phase, config)
    header_right, footer_left, footer_right, compact = live_text_parts(
        phase,
        status,
        state,
        config,
        now_epoch=now_epoch,
    )
    if phase == "complete":
        english = str(config.get("aivi", {}).get("language", "de")).lower() == "en"
        plugged_value = status.get("pluggedin")
        if plugged_value is True or plugged_value == 1 or str(plugged_value).lower() in {"true", "yes", "on"}:
            footer_right = "Still connected" if english else "Weiterhin angesteckt"
        elif plugged_value is False or plugged_value == 0 or str(plugged_value).lower() in {"false", "no", "off"}:
            footer_right = "Unplugged" if english else "Nicht mehr angesteckt"
        else:
            footer_right = "Charge target reached" if english else "Ladeziel erreicht"

    header_left = f"{soc} %"
    progress = soc / 100.0
    single_progress = str(
        config.get("aivi", {}).get("mode", "single_progress")
    ) == "single_progress"
    if phase == "charging" and single_progress:
        target_soc = to_float_or_none(state.get("target_soc"))
        if target_soc is not None and target_soc > 0:
            progress = min(1.0, soc / target_soc)
    elif phase == "target_reached" and single_progress:
        header_right = "Done" if str(config.get("aivi", {}).get("language", "de")).lower() == "en" else "Fertig"
        progress = 1.0
    elif phase in {"complete", "ended", "interrupted"} and single_progress:
        started = float(state.get("session_started_epoch", 0.0) or 0.0)
        completed = session_terminal_end_epoch(state, phase)
        start_soc = to_float_or_none(state.get("session_start_soc"))
        end_soc = completed_session_end_soc(state)
        start_text = "?" if start_soc is None else str(int(round(start_soc)))
        end_text = "?" if end_soc is None else str(int(round(end_soc)))
        header_left = f"{start_text} → {end_text} %"
        header_right = (
            duration_text(max(0.0, completed - started))
            if completed > 0 and started > 0 and not bool(state.get("session_start_uncertain", False))
            else "Fertig"
        )
        english = str(config.get("aivi", {}).get("language", "de")).lower() == "en"
        plugged_value = status.get("pluggedin")
        if plugged_value is True or plugged_value == 1 or str(plugged_value).lower() in {"true", "yes", "on"}:
            footer_right = "Still connected" if english else "Weiterhin angesteckt"
        elif plugged_value is False or plugged_value == 0 or str(plugged_value).lower() in {"false", "no", "off"}:
            footer_right = "Unplugged" if english else "Nicht mehr angesteckt"
        else:
            footer_right = "Charge target reached" if english else "Ladeziel erreicht"
        progress = 1.0

    return {
        "state": lifecycle_state,
        "content": {
            "template": "progress",
            "icon": {
                "name": str(style["icon"]),
                "rendering_mode": str(style.get("icon_rendering_mode", "monochrome")),
                "primary_color": str(style["icon_color"]),
                "color_rendering": str(style.get("icon_color_rendering", "flat")),
            },
            "header_left": {
                "value": header_left,
                "text_color": str(style["header_color"]),
            },
            "header_right": {"value": header_right},
            "progress": {
                "style": "simple",
                "value": progress,
                "color": str(style["progress_color"]),
            },
            "footer_left": {"value": footer_left, "text_color": "gray"},
            "footer_right": {"value": footer_right, "text_color": "gray"},
            "compact_value": {"value": compact},
        },
    }


def aivi_three_phase_configured(config: dict[str, Any], token: str | None, charging_slug: str | None) -> bool:
    aivi = config.get("aivi", {})
    return bool(
        aivi.get("enabled", False)
        and str(aivi.get("mode", "legacy")) == "three_phase"
        and token
        and charging_slug
        and str(aivi.get("balancing_activity_slug", "")).strip()
        and str(aivi.get("complete_activity_slug", "")).strip()
    )


def iso_epoch(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat().replace("+00:00", "Z")


def duration_text(seconds: float) -> str:
    total = max(0, int(round(seconds)))
    minutes = total // 60
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours} h {minutes:02d} min"
    return f"{minutes} min"


def balancing_duration_text(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    minutes = int(seconds // 60)
    if minutes < 1:
        return "< 1 min"
    if minutes < 60:
        return f"{minutes} min"
    hours, rest = divmod(minutes, 60)
    return f"{hours} h {rest:02d} min"


def balancing_display_end_epoch(state: dict[str, Any], now_epoch: float) -> float:
    """Freeze the shown balancing duration from qualified end evidence onward."""
    candidate = float(state.get("balancing_end_candidate_epoch", 0.0) or 0.0)
    if candidate > 0:
        return min(now_epoch, candidate)
    balancing_end = float(state.get("balancing_end_at_epoch", 0.0) or 0.0)
    return min(now_epoch, balancing_end) if balancing_end > 0 else now_epoch


def build_balancing_monitor_payload(
    status: dict[str, Any], state: dict[str, Any], lifecycle_state: str = "ONGOING",
    now_epoch: float | None = None, language: str = "de",
) -> dict[str, Any]:
    if now_epoch is None:
        now_epoch = time.time()
    soc = max(0, min(100, int(round(to_float(status.get("soc"))))))
    english = str(language).lower() == "en"
    return {
        "state": lifecycle_state,
        "content": {
            "template": "monitor",
            "icon": {
                "name": "battery.100percent",
                "rendering_mode": "hierarchical",
                "primary_color": "orange",
                "color_rendering": "gradient",
            },
            "left_column": {
                "header": "CHARGE" if english else "LADESTAND",
                "value": {"value": f"{soc} %", "text_color": "orange"},
                "footer": "current" if english else "aktuell",
            },
            "right_column": {
                "header": "CONNECTION" if english else "ANSCHLUSS",
                "value": {"value": "connected" if english else "angesteckt"},
                "footer": "Charging complete · still connected" if english else "Laden abgeschlossen · weiterhin angesteckt",
            },
            "primary_column": "left",
        },
    }

def build_completion_monitor_payload(
    status: dict[str, Any], state: dict[str, Any], terminal_phase: str = "complete",
    lifecycle_state: str = "ONGOING", language: str = "de",
) -> dict[str, Any]:
    start_soc = to_float_or_none(state.get("session_start_soc"))
    end_soc = completed_session_end_soc(state)
    target_soc = to_float_or_none(state.get("target_soc"))
    start_text = "?" if start_soc is None else f"{start_soc:.0f}"
    end_text = "?" if end_soc is None else f"{end_soc:.0f}"
    started = float(state.get("session_started_epoch", 0.0) or 0.0)
    ended = session_terminal_end_epoch(state, terminal_phase)
    total_seconds = max(0.0, ended - started) if ended > 0 and started > 0 and not bool(state.get("session_start_uncertain", False)) else None
    english = str(language).lower() == "en"
    if terminal_phase == "interrupted":
        footer = "Charging interrupted" if english else "Laden unterbrochen"
        color = "red"
    elif terminal_phase == "ended":
        footer = "Charging ended" if english else "Laden beendet"
        color = "green"
    else:
        if english:
            footer = "Fully charged" if (target_soc or 0) >= 100 else "Charge target reached"
        else:
            footer = "Vollständig geladen" if (target_soc or 0) >= 100 else "Ladeziel abgeschlossen"
        color = "green"
    plugged_value = status.get("pluggedin")
    if plugged_value is True or plugged_value == 1 or str(plugged_value).lower() in {"true", "yes", "on"}:
        right_footer = "Still connected" if english else "Weiterhin angesteckt"
    elif plugged_value is False or plugged_value == 0 or str(plugged_value).lower() in {"false", "no", "off"}:
        right_footer = "Unplugged" if english else "Nicht mehr angesteckt"
    else:
        right_footer = "Charge target reached" if english else "Ladeziel erreicht"
    return {
        "state": lifecycle_state,
        "content": {
            "template": "monitor",
            "icon": {
                "name": "checkmark.circle.fill" if terminal_phase != "interrupted" else "exclamationmark.triangle.fill",
                "rendering_mode": "hierarchical",
                "primary_color": color,
                "color_rendering": "gradient",
            },
            "left_column": {
                "header": "CHARGED" if english else "GELADEN",
                "value": {"value": f"{start_text} → {end_text} %", "text_color": color},
                "footer": footer,
            },
            "right_column": {
                "header": "DURATION" if english else "DAUER",
                "value": {"value": duration_text(total_seconds) if total_seconds is not None else "–"},
                "footer": right_footer,
            },
            "primary_column": "left",
        },
    }


def completed_session_end_soc(state: dict[str, Any]) -> float | None:
    """Return only a frozen target snapshot; legacy target_soc may have drifted."""
    target_epoch = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    target_soc = to_float_or_none(state.get("session_target_soc"))
    return target_soc if target_epoch > 0 and target_soc is not None else None


def close_three_phase_activity(
    state: dict[str, Any], sender: Callable[[str, str, dict[str, Any]], None]
) -> None:
    slug = str(state.get("three_phase_active_slug", "") or "")
    payload = state.get("three_phase_active_payload")
    kind = str(state.get("three_phase_active_kind", "") or "")
    if slug and isinstance(payload, dict):
        idle = copy.deepcopy(payload)
        idle["state"] = "IDLE"
        sender(slug, f"idle_{kind or 'phase'}", idle)
    state["three_phase_active_kind"] = ""
    state["three_phase_active_slug"] = ""
    state["three_phase_active_payload"] = None
    state["three_phase_balancing_display_bucket"] = -1


def handoff_three_phase_activity(
    state: dict[str, Any],
    sender: Callable[[str, str, dict[str, Any]], None],
) -> bool:
    """Close a persisted Beta-7 Monitor before single-progress operation.

    All cleanup happens only after the remote IDLE update succeeds. A network
    error therefore leaves the persisted markers intact for the next retry.
    """
    slug = str(
        state.get("three_phase_active_slug", "")
        or state.get("three_phase_idle_slug", "")
        or ""
    )
    payload = (
        state.get("three_phase_active_payload")
        or state.get("three_phase_idle_payload")
    )
    if not slug or not isinstance(payload, dict):
        return False
    idle = copy.deepcopy(payload)
    idle["state"] = "IDLE"
    sender(slug, "idle_migration", idle)
    for key, value in {
        "three_phase_active_kind": "",
        "three_phase_active_slug": "",
        "three_phase_active_payload": None,
        "three_phase_idle_due_epoch": 0.0,
        "three_phase_idle_payload": None,
        "three_phase_idle_slug": "",
        "three_phase_idle_sent": True,
        "three_phase_terminal_phase": "",
        "three_phase_balancing_display_bucket": -1,
    }.items():
        state[key] = value
    return True


def synchronize_three_phase_activity(
    status: dict[str, Any], state: dict[str, Any], config: dict[str, Any], charging_slug: str,
    sender: Callable[[str, str, dict[str, Any]], None], now_epoch: float | None = None,
    source_changed: bool = True,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    aivi = config.get("aivi", {})
    complete_slug = str(aivi.get("complete_activity_slug", "")).strip()
    phase = str(state.get("charge_phase", "unknown"))
    generation = int(state.get("charge_session_generation", 0))
    if (
        phase == "target_reached"
        and bool(state.get("session_active", False))
        and to_bool(status.get("charging"))
    ):
        # Do not start a completion monitor until the direct charging flag has
        # stopped. Reaching the selected SoC alone is not balancing evidence.
        phase = "charging"

    # If Legacy mode left a Progress activity open, close it before the first
    # three-phase session starts.
    if state.get("live_activity_active", False):
        legacy_payload = build_live_update_payload("charging", status, state, config, lifecycle_state="IDLE")
        sender(charging_slug, "idle_legacy", legacy_payload)
        state["live_activity_active"] = False
        state["live_activity_closed_for_session"] = True

    if phase in {"charging", "target_reached"} and int(state.get("three_phase_session_generation", -1)) != generation:
        close_three_phase_activity(state, sender)
        state["three_phase_session_generation"] = generation
        state["three_phase_complete_started_generation"] = -1
        state["three_phase_terminal_phase"] = ""
        state["three_phase_idle_due_epoch"] = 0.0
        state["three_phase_idle_payload"] = None
        state["three_phase_idle_slug"] = ""
        state["three_phase_idle_sent"] = False
        state["three_phase_balancing_display_bucket"] = -1

    if phase == "charging":
        payload = build_live_update_payload("charging", status, state, config)
        if state.get("three_phase_active_kind") != "charging":
            close_three_phase_activity(state, sender)
            sender(charging_slug, "start_charging", payload)
        elif source_changed and live_payload_fingerprint(payload) != live_payload_fingerprint(state.get("three_phase_active_payload") or {}):
            sender(charging_slug, "update_charging", payload)
        state["three_phase_active_kind"] = "charging"
        state["three_phase_active_slug"] = charging_slug
        state["three_phase_active_payload"] = payload
        return

    if phase == "target_reached":
        payload = build_completion_monitor_payload(
            status, state, "complete",
            language=str(config.get("aivi", {}).get("language", "de")),
        )
        if int(state.get("three_phase_complete_started_generation", -1)) != generation:
            close_three_phase_activity(state, sender)
            sender(complete_slug, "start_complete", payload)
            state["three_phase_complete_started_generation"] = generation
            state["three_phase_idle_sent"] = False
        elif state.get("three_phase_active_kind") == "complete":
            previous = state.get("three_phase_active_payload") or {}
            if source_changed and live_payload_fingerprint(payload) != live_payload_fingerprint(previous):
                sender(complete_slug, "update_complete", payload)
        else:
            close_three_phase_activity(state, sender)
            sender(complete_slug, "start_complete", payload)
            state["three_phase_idle_sent"] = False
            state["three_phase_complete_started_generation"] = generation
        state["three_phase_terminal_phase"] = ""
        state["three_phase_idle_due_epoch"] = 0.0
        state["three_phase_idle_payload"] = None
        state["three_phase_idle_slug"] = ""
        state["three_phase_active_kind"] = "complete"
        state["three_phase_active_slug"] = complete_slug
        state["three_phase_active_payload"] = payload
        return

    terminal_phase: str | None = None
    if phase == "complete":
        terminal_phase = "complete"
    elif state.get("session_end_notified", False):
        reason = str(state.get("session_end_reason", ""))
        if reason in {"ended", "interrupted"}:
            terminal_phase = reason
    if terminal_phase is not None:
        payload = build_completion_monitor_payload(
            status, state, terminal_phase,
            language=str(config.get("aivi", {}).get("language", "de")),
        )
        already_started = int(state.get("three_phase_complete_started_generation", -1)) == generation
        already_active = (
            state.get("three_phase_active_kind") == "complete"
            and str(state.get("three_phase_active_slug", "")) == complete_slug
        )
        terminal_changed = str(state.get("three_phase_terminal_phase", "")) != terminal_phase
        payload_changed = already_active and live_payload_fingerprint(payload) != live_payload_fingerprint(
            state.get("three_phase_active_payload") or {}
        )
        refresh = terminal_changed or payload_changed
        activity_refreshed = False
        if not already_started or (not already_active and terminal_changed):
            close_three_phase_activity(state, sender)
            sender(complete_slug, "start_complete", payload)
            state["three_phase_complete_started_generation"] = generation
            state["three_phase_idle_sent"] = False
            activity_refreshed = True
        elif already_active and refresh:
            sender(complete_slug, "update_complete", payload)
            activity_refreshed = True
        if activity_refreshed or already_active:
            state["three_phase_active_kind"] = "complete"
            state["three_phase_active_slug"] = complete_slug
            state["three_phase_active_payload"] = payload
        if activity_refreshed:
            idle = copy.deepcopy(payload)
            idle["state"] = "IDLE"
            state["three_phase_idle_payload"] = idle
            state["three_phase_idle_slug"] = complete_slug
            state["three_phase_idle_due_epoch"] = now_epoch + float(aivi.get("complete_summary_seconds", 600))
            state["three_phase_idle_sent"] = False
        state["three_phase_terminal_phase"] = terminal_phase


def send_three_phase_idle_if_due(
    state: dict[str, Any], sender: Callable[[str, str, dict[str, Any]], None], now_epoch: float | None = None
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    due = float(state.get("three_phase_idle_due_epoch", 0.0) or 0.0)
    payload = state.get("three_phase_idle_payload")
    slug = str(state.get("three_phase_idle_slug", "") or "")
    if not slug or not isinstance(payload, dict) or due <= 0 or now_epoch < due or state.get("three_phase_idle_sent", False):
        return
    sender(slug, "idle_complete", payload)
    state["three_phase_idle_sent"] = True
    state["three_phase_idle_due_epoch"] = 0.0
    state["three_phase_idle_payload"] = None
    state["three_phase_idle_slug"] = ""
    state["three_phase_active_kind"] = ""
    state["three_phase_active_slug"] = ""
    state["three_phase_active_payload"] = None


def cancel_intermediate_update(state: dict[str, Any]) -> None:
    state["live_activity_intermediate_due_epoch"] = 0.0
    state["live_activity_intermediate_payload"] = None
    state["live_activity_intermediate_session_generation"] = -1


def cancel_idle_handoff(state: dict[str, Any]) -> None:
    state["live_activity_idle_due_epoch"] = 0.0
    state["live_activity_idle_payload"] = None


def reset_live_activity_for_session(
    state: dict[str, Any],
    generation: int,
) -> None:
    state["live_activity_active"] = False
    state["live_activity_session_generation"] = generation
    state["live_activity_last_payload_fingerprint"] = ""
    state["live_activity_last_phase"] = ""
    state["live_activity_last_update_epoch"] = 0.0
    state["live_activity_final_sent"] = False
    state["live_activity_idle_sent"] = False
    state["live_activity_real_update_count"] = 0
    state["live_activity_intermediate_update_count"] = 0
    state["live_activity_balancing_display_bucket"] = -1
    state["live_activity_closed_for_session"] = False
    cancel_intermediate_update(state)
    cancel_idle_handoff(state)


def schedule_intermediate_update(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
) -> None:
    if rounded_charge_minutes(status) is None:
        cancel_intermediate_update(state)
        return
    interval = max(15.0, float(config["aivi"]["live_activity"]["intermediate_delay_seconds"]))
    due = now_epoch + interval
    payload = build_live_update_payload(
        "charging",
        status,
        state,
        config,
        now_epoch=due,
    )
    state["live_activity_intermediate_due_epoch"] = due
    state["live_activity_intermediate_payload"] = payload
    state["live_activity_intermediate_session_generation"] = int(
        state.get("charge_session_generation", 0)
    )
    state["live_activity_intermediate_interval_seconds"] = interval


def schedule_idle_handoff(
    final_payload: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
) -> None:
    idle_payload = copy.deepcopy(final_payload)
    idle_payload["state"] = "IDLE"
    state["live_activity_idle_payload"] = idle_payload
    delay_key = (
        "complete_summary_seconds"
        if str(config.get("aivi", {}).get("mode", "single_progress")) == "single_progress"
        else "finalize_delay_seconds"
    )
    state["live_activity_idle_due_epoch"] = now_epoch + float(
        config["aivi"][delay_key]
    )
    state["live_activity_idle_sent"] = False


def synchronize_live_activity(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    sender: Callable[[str, dict[str, Any]], None],
    now_epoch: float | None = None,
    source_changed: bool = True,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()

    phase = str(state.get("charge_phase", "unknown"))
    if phase not in {"charging", "target_reached", "complete", "unplugged", "plugged_idle", "other"}:
        phase = classify_charge_phase(status, state, config)
    if (
        phase == "target_reached"
        and bool(state.get("session_active", False))
        and to_bool(status.get("charging"))
    ):
        phase = "charging"
    generation = int(state.get("charge_session_generation", 0))
    stored_generation = int(state.get("live_activity_session_generation", -1))
    session_id = physical_session_id(state)
    stored_session_id = str(state.get("live_activity_session_id") or "")

    if phase in {"charging", "target_reached"}:
        if stored_generation != generation or stored_session_id != session_id:
            if state.get("live_activity_active", False):
                rollover_payload = state.get("live_activity_idle_payload")
                if not isinstance(rollover_payload, dict):
                    rollover_payload = build_live_update_payload(
                        "charging",
                        status,
                        state,
                        config,
                        lifecycle_state="IDLE",
                        now_epoch=now_epoch,
                    )
                sender("idle", copy.deepcopy(rollover_payload))
            reset_live_activity_for_session(state, generation)
            state["live_activity_session_id"] = session_id

        if state.get("live_activity_closed_for_session", False):
            return

        balancing_bucket = -1
        if phase == "target_reached":
            balancing_started = float(
                state.get("session_balancing_started_epoch", 0.0) or now_epoch
            )
            balancing_bucket = int(
                max(0.0, now_epoch - balancing_started)
                // max(30.0, float(config["aivi"].get("balancing_update_seconds", 60)))
            )
        if (
            state.get("live_activity_active", False)
            and not source_changed
            and not state.get("last_live_activity_error")
            and phase == state.get("live_activity_last_phase")
            and (
                phase != "target_reached"
                or balancing_bucket
                == int(state.get("live_activity_balancing_display_bucket", -1))
            )
        ):
            return

        payload = build_live_update_payload(
            phase, status, state, config, now_epoch=now_epoch
        )
        fingerprint = live_payload_fingerprint(payload)
        if (
            state.get("live_activity_active", False)
            and not state.get("last_live_activity_error")
            and fingerprint == state.get("live_activity_last_payload_fingerprint", "")
        ):
            if phase == "charging" and source_changed:
                schedule_intermediate_update(status, state, config, now_epoch)
            return

        action = "start" if not state.get("live_activity_active") else "update"
        sender(action, payload)
        state["live_activity_active"] = True
        state["live_activity_last_payload_fingerprint"] = fingerprint
        state["live_activity_last_phase"] = phase
        state["live_activity_last_update_epoch"] = now_epoch
        if phase == "target_reached":
            state["live_activity_balancing_display_bucket"] = balancing_bucket
        state["live_activity_final_sent"] = False
        state["live_activity_idle_sent"] = False
        state["live_activity_closed_for_session"] = False
        cancel_idle_handoff(state)
        state["live_activity_real_update_count"] = int(
            state.get("live_activity_real_update_count", 0)
        ) + 1
        if phase == "charging":
            schedule_intermediate_update(status, state, config, now_epoch)
        else:
            cancel_intermediate_update(state)
        return

    final_phase: str | None = None
    if phase == "complete":
        final_phase = "complete"
    elif (
        phase == "unplugged"
        and state.get("session_unplug_confirmed", False)
        and (
            float(state.get("session_target_reached_epoch", 0.0) or 0.0) > 0
            or (
                state.get("complete_notified", False)
                and float(state.get("session_completed_epoch", 0.0) or 0.0) > 0
            )
        )
    ):
        final_phase = "complete"
    elif state.get("session_end_notified", False):
        reason = str(state.get("session_end_reason", ""))
        if reason in {"ended", "interrupted"}:
            final_phase = reason

    if (
        final_phase == "complete"
        and phase == "unplugged"
        and state.get("live_activity_active", False)
        and state.get("live_activity_final_sent", False)
    ):
        # Completion may have been published while still plugged. Refresh that
        # summary once the confirmed physical connection state changes.
        payload = build_live_update_payload(
            "complete", status, state, config, now_epoch=now_epoch
        )
        fingerprint = live_payload_fingerprint(payload)
        if fingerprint != state.get("live_activity_last_payload_fingerprint", ""):
            sender("update", payload)
            state["live_activity_last_payload_fingerprint"] = fingerprint
            state["live_activity_last_phase"] = "complete"
            state["live_activity_last_update_epoch"] = now_epoch
            state["live_activity_real_update_count"] = int(
                state.get("live_activity_real_update_count", 0)
            ) + 1
            schedule_idle_handoff(payload, state, config, now_epoch)
        return

    if (
        final_phase is not None
        and state.get("live_activity_active", False)
        and not state.get("live_activity_final_sent", False)
    ):
        payload = build_live_update_payload(
            final_phase, status, state, config, now_epoch=now_epoch
        )
        sender("final", payload)
        state["live_activity_last_payload_fingerprint"] = live_payload_fingerprint(payload)
        state["live_activity_last_phase"] = final_phase
        state["live_activity_last_update_epoch"] = now_epoch
        state["live_activity_final_sent"] = True
        state["live_activity_real_update_count"] = int(
            state.get("live_activity_real_update_count", 0)
        ) + 1
        cancel_intermediate_update(state)
        schedule_idle_handoff(payload, state, config, now_epoch)


def send_live_intermediate_if_due(
    state: dict[str, Any],
    sender: Callable[[str, dict[str, Any]], None],
    now_epoch: float | None = None,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    due = float(state.get("live_activity_intermediate_due_epoch", 0.0) or 0.0)
    payload = state.get("live_activity_intermediate_payload")
    same_generation = int(
        state.get("live_activity_intermediate_session_generation", -1)
    ) == int(state.get("charge_session_generation", 0))
    if (
        not state.get("live_activity_active", False)
        or state.get("live_activity_final_sent", False)
        or state.get("live_activity_last_phase") != "charging"
        or not same_generation
        or due <= 0
        or now_epoch < due
        or not isinstance(payload, dict)
    ):
        return

    fingerprint = live_payload_fingerprint(payload)
    if fingerprint != state.get("live_activity_last_payload_fingerprint", ""):
        sender("intermediate", payload)
        state["live_activity_last_payload_fingerprint"] = fingerprint
        state["live_activity_last_update_epoch"] = now_epoch
        state["live_activity_intermediate_update_count"] = int(
            state.get("live_activity_intermediate_update_count", 0)
        ) + 1
    interval = max(15.0, float(state.get("live_activity_intermediate_interval_seconds", 60.0) or 60.0))
    state["live_activity_intermediate_due_epoch"] = now_epoch + interval
    state["live_activity_intermediate_payload"] = copy.deepcopy(payload)
    state["live_activity_intermediate_session_generation"] = int(state.get("charge_session_generation", 0))


def send_live_idle_if_due(
    state: dict[str, Any],
    sender: Callable[[str, dict[str, Any]], None],
    now_epoch: float | None = None,
) -> None:
    if now_epoch is None:
        now_epoch = time.time()
    due = float(state.get("live_activity_idle_due_epoch", 0.0) or 0.0)
    payload = state.get("live_activity_idle_payload")
    if (
        not state.get("live_activity_active", False)
        or not state.get("live_activity_final_sent", False)
        or state.get("live_activity_idle_sent", False)
        or due <= 0
        or now_epoch < due
        or not isinstance(payload, dict)
    ):
        return

    sender("idle", payload)
    state["live_activity_idle_sent"] = True
    state["live_activity_active"] = False
    state["live_activity_closed_for_session"] = True
    state["live_activity_last_payload_fingerprint"] = live_payload_fingerprint(payload)
    state["live_activity_last_update_epoch"] = now_epoch
    cancel_idle_handoff(state)

# ---------------------------------------------------------------------------
# Persistence, diagnostics and processing
# ---------------------------------------------------------------------------


def save_raw_change(raw_status: dict[str, Any], state: dict[str, Any] | None = None) -> None:
    fetched_at = datetime.now(timezone.utc).isoformat()
    try:
        append_jsonl(
            RAW_HISTORY_FILE,
            {"fetched_at_utc": fetched_at, "status": raw_status},
        )
        atomic_write_json(LATEST_RAW_FILE, raw_status)
    except OSError as error:
        if state is not None:
            state["last_diagnostics_error"] = f"Rohhistorie konnte nicht gespeichert werden: {error}"
        log("Warnung: Rohhistorie konnte nicht gespeichert werden; Observer läuft weiter.")


def save_valid_change(valid_status: dict[str, Any], state: dict[str, Any] | None = None) -> None:
    fetched_at = datetime.now(timezone.utc).isoformat()
    try:
        append_jsonl(
            HISTORY_FILE,
            {"fetched_at_utc": fetched_at, "status": valid_status},
        )
        atomic_write_json(LATEST_FILE, valid_status)
    except OSError as error:
        if state is not None:
            state["last_diagnostics_error"] = f"Validierte Historie konnte nicht gespeichert werden: {error}"
        log("Warnung: Validierte Historie konnte nicht gespeichert werden; Observer läuft weiter.")


def update_time_diagnostics(
    status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float,
) -> dict[str, Any]:
    info = status_time_info(status, config, now_epoch)
    contact = info["contact_time"]
    measurement = info["measurement_time"]
    state["last_contact_epoch"] = contact.timestamp() if contact else 0.0
    state["last_measurement_epoch"] = (
        measurement.timestamp() if measurement else 0.0
    )
    return info


def integration_retry_allowed(state: dict[str, Any], name: str, now_epoch: float) -> bool:
    return now_epoch >= float(state.get(f"{name}_next_retry_epoch", 0.0) or 0.0)


def integration_mark_success(state: dict[str, Any], name: str) -> None:
    state[f"{name}_consecutive_errors"] = 0
    state[f"{name}_next_retry_epoch"] = 0.0


def integration_mark_failure(
    state: dict[str, Any],
    name: str,
    config: dict[str, Any],
    now_epoch: float,
) -> int:
    errors = int(state.get(f"{name}_consecutive_errors", 0)) + 1
    state[f"{name}_consecutive_errors"] = errors
    cfg = config.get(name, {})
    initial = max(1.0, float(cfg.get("error_initial_seconds", 60)))
    maximum = max(initial, float(cfg.get("error_max_seconds", 900)))
    delay = min(maximum, initial * (2 ** max(0, errors - 1)))
    state[f"{name}_next_retry_epoch"] = now_epoch + delay
    return int(round(delay))


def process_status(
    raw_status: dict[str, Any],
    state: dict[str, Any],
    config: dict[str, Any],
    abrp_token: str | None,
    abrp_api_key: str | None,
    aivi_token: str | None,
    aivi_activity_slug: str | None,
) -> dict[str, Any]:
    now_epoch = time.time()
    phase_before = str(state.get("charge_phase", "unknown"))
    raw_fingerprint = status_fingerprint(raw_status)
    valid_status, soc_accepted, soc_note = filter_soc(raw_status, state, now_epoch)
    valid_status = preserve_monotonic_odometer(valid_status, state, config)
    valid_fingerprint = status_fingerprint(valid_status)

    raw_changed = raw_fingerprint != state.get("last_raw_fingerprint", "")
    valid_changed = valid_fingerprint != state.get("last_processed_fingerprint", "")

    if raw_changed:
        state["last_raw_fingerprint"] = raw_fingerprint
        save_raw_change(raw_status, state)

    if soc_note and (raw_changed or not soc_accepted):
        log(soc_note)

    time_info = update_time_diagnostics(valid_status, state, config, now_epoch)
    phase_preview = classify_charge_phase(valid_status, state, config)
    fresh = time_info["contact_age_seconds"] <= float(
        config["freshness"]["max_contact_age_seconds"]
    )

    if valid_changed:
        state["last_processed_fingerprint"] = valid_fingerprint
        state["last_status_change_epoch"] = now_epoch
        save_valid_change(valid_status, state)
        log(
            "Statusänderung | "
            f"Fahrzeugzeit: {format_zero_time(valid_status.get('datetime_utc'))} | "
            f"Kontaktzeit: {format_datetime_local(time_info['contact_time'])} | "
            f"SoC: {to_float(valid_status.get('soc')):.0f} % | "
            f"charging: {int(to_bool(valid_status.get('charging')))} | "
            f"chargecomplete: {int(to_bool(valid_status.get('chargecomplete')))} | "
            f"pluggedin: {int(to_bool(valid_status.get('pluggedin')))} | "
            f"Restzeit: {to_float(valid_status.get('chargingtimeleft')):.0f} min | "
            f"Phase: {phase_preview} | Kontaktalter: "
            f"{format_age(time_info['contact_age_seconds'])}"
        )
    else:
        log(
            "Keine relevante Statusänderung | "
            f"Kontaktalter: {format_age(time_info['contact_age_seconds'])} | "
            f"Fahrzeugdaten: {format_age(time_info['measurement_age_seconds'])}"
        )

    state_events: list[str] = []

    contact = time_info.get("contact_time")
    if fresh and contact is not None:
        process_balancing_end_evidence(
            valid_status,
            float(contact.timestamp()),
            f"last_transmit:{status_fingerprint(valid_status)}",
            "last_transmit_reason_5",
            state,
            config,
            now_epoch,
            require_current_balancing=True,
        )
    if fresh:
        observe_plug_connection(valid_status, state, now_epoch)
        observe_plug_episode(valid_status, state, now_epoch)
        state["last_pluggedin"] = bool(to_bool(valid_status.get("pluggedin")))
    state["last_ignition"] = bool(to_bool(valid_status.get("ignition")))

    history_confirmed = maybe_confirm_balancing_end_candidate(
        valid_status, state, config, now_epoch
    )
    history_override = str(state.get("pending_history_completion", "") or "")
    if history_override:
        completion_epoch = float(state.get("balancing_end_at_epoch", 0.0) or 0.0)
        current_epoch = status_contact_epoch(valid_status)
        if (
            current_epoch > completion_epoch + 0.5
            and _history_event_is_continuation(valid_status)
        ):
            state["pending_history_completion"] = ""
            history_override = ""
            save_event_diagnostic(
                "completion_evidence_cancelled", valid_status, state, config, now_epoch,
                reason="newer_current_status",
            )
        else:
            state["pending_history_completion"] = ""

    raw_soc = to_float_or_none(raw_status.get("soc"))
    shutdown_zero = bool(
        raw_soc is not None
        and raw_soc <= 0
        and bool(state.get("target_notified", False))
        and (bool(state.get("session_active", False)) or bool(state.get("session_terminal", False)))
        and not to_bool(raw_status.get("charging"))
    )
    if shutdown_zero:
        generation = int(state.get("charge_session_generation", 0))
        if not (
            bool(state.get("shutdown_zero_pulse_observed", False))
            and int(state.get("shutdown_zero_pulse_generation", -1)) == generation
        ):
            state["shutdown_zero_pulse_observed"] = True
            state["shutdown_zero_pulse_epoch"] = now_epoch
            state["shutdown_zero_pulse_generation"] = generation
            log(f"Shutdown-Signal erkannt: Raw-SoC 0 % nach Balancing · Session {generation}.")
            save_event_diagnostic(
                "shutdown_zero_pulse", valid_status, state, config, now_epoch, raw_soc=raw_soc
            )
            record_shutdown_zero_evidence(state, config, now_epoch)

    inferred_complete = maybe_infer_balancing_sleep_completion(
        valid_status, state, config, time_info, now_epoch
    )
    terminal_override = terminal_phase_override(valid_status, state, config)
    shutdown_override = (
        "complete"
        if shutdown_zero
        and bool(state.get("session_active", False))
        and bool(state.get("target_notified", False))
        and not bool(state.get("complete_notified", False))
        else None
    )
    if shutdown_override:
        state["charge_completion_source"] = "shutdown_zero_pulse"
        state["charge_state_confidence"] = "confirmed"

    abrp_ready = bool(
        config.get("abrp", {}).get("enabled", False)
        and abrp_token
        and abrp_api_key
    )
    # A missing diagnostic may trigger one isolated ABRP evidence probe. It
    # must never bypass the stale-data guard for charging/session/Aivi logic.
    abrp_probe_pending = abrp_ready and not ABRP_DIAGNOSTIC_FILE.exists() and not state.get("abrp_probe_attempted", False)
    if not fresh and not inferred_complete and not history_override and not history_confirmed:
        if abrp_probe_pending:
            state["abrp_probe_attempted"] = True
            last_abrp = float(state.get("last_abrp_send_epoch", 0.0) or 0.0)
            min_interval = float(config["abrp"]["min_interval_seconds"])
            if now_epoch - last_abrp >= min_interval:
                try:
                    measurement = timestamp_or_none(valid_status.get("datetime_utc"))
                    if measurement is not None:
                        send_to_abrp(
                            valid_status,
                            str(abrp_token),
                            str(abrp_api_key),
                            float(config["request_timeout_seconds"]),
                            telemetry_utc=int(measurement.timestamp()),
                            config=config,
                        )
                        success_epoch = time.time()
                        state["last_abrp_send_epoch"] = success_epoch
                        state["last_abrp_success_epoch"] = success_epoch
                        state["last_abrp_fingerprint"] = valid_fingerprint
                        state["last_abrp_error"] = ""
                        integration_mark_success(state, "abrp")
                except (requests.RequestException, ValueError, KeyError, RuntimeError) as error:
                    state["last_abrp_error"] = str(error)
                    integration_mark_failure(state, "abrp", config, time.time())
        if valid_changed:
            log(
                "Datensatz ist veraltet; keine externe Übertragung und "
                "keine Live-Activity-Auswertung."
            )
        save_poll_diagnostic(
            raw_status,
            valid_status,
            state,
            config,
            time_info,
            now_epoch,
            raw_changed=raw_changed,
            valid_changed=valid_changed,
            soc_accepted=soc_accepted,
            soc_note=soc_note,
            fresh=False,
            phase_before=phase_before,
            phase_after=str(state.get("charge_phase", phase_before)),
            state_events=state_events,
        )
        cleanup_diagnostics_if_due(state, config, now_epoch)
        return valid_status

    if abrp_ready and fresh:
        last_abrp_fingerprint = state.get("last_abrp_fingerprint", "")
        if (last_abrp_fingerprint != valid_fingerprint or abrp_probe_pending) and integration_retry_allowed(state, "abrp", now_epoch):
            if abrp_probe_pending:
                state["abrp_probe_attempted"] = True
            last_abrp = float(state.get("last_abrp_send_epoch", 0.0))
            min_interval = float(config["abrp"]["min_interval_seconds"])
            if now_epoch - last_abrp >= min_interval:
                try:
                    send_to_abrp(
                        valid_status,
                        str(abrp_token),
                        str(abrp_api_key),
                        float(config["request_timeout_seconds"]),
                        config=config,
                    )
                    success_epoch = time.time()
                    state["last_abrp_send_epoch"] = success_epoch
                    state["last_abrp_success_epoch"] = success_epoch
                    state["last_abrp_fingerprint"] = valid_fingerprint
                    state["last_abrp_error"] = ""
                    integration_mark_success(state, "abrp")
                    save_event_diagnostic(
                        "abrp_success", valid_status, state, config, success_epoch
                    )
                except (
                    requests.RequestException,
                    ValueError,
                    KeyError,
                    RuntimeError,
                ) as error:
                    state["last_abrp_error"] = str(error)
                    delay = integration_mark_failure(state, "abrp", config, time.time())
                    log(f"ABRP-Übertragung fehlgeschlagen: {error} · neuer Versuch frühestens in {delay} s")
                    save_event_diagnostic(
                        "abrp_error",
                        valid_status,
                        state,
                        config,
                        time.time(),
                        error=str(error),
                    )
            elif valid_changed:
                log("ABRP-Übertragung wegen Mindestintervall zurückgestellt.")

    if history_override:
        state["charge_completion_source"] = history_override
        state["charge_state_confidence"] = "confirmed" if history_override == "history_charging_zero" else "inferred"
    evaluate_charge_state(
        valid_status,
        state,
        config,
        state_events.append,
        phase_override=(shutdown_override or terminal_override or ("complete" if inferred_complete or history_override or history_confirmed else None)),
        now_epoch=now_epoch,
    )
    phase_after = str(state.get("charge_phase", phase_preview))
    if phase_after in {"charging", "target_reached"}:
        capture_session_location(valid_status, state, now_epoch)
    if fresh:
        record_charging_sample(valid_status, state, config, now_epoch)
        evaluate_functional_reminders(valid_status, state, config, now_epoch)
        evaluate_blocking_fee_reminders(valid_status, state, now_epoch)
        evaluate_soc_milestones(valid_status, state, now_epoch)
        evaluate_post_charge_reminder(valid_status, state, now_epoch)
        evaluate_failed_start_reminder(valid_status, state, now_epoch)
    evaluate_evening_reminder(valid_status, state, now_epoch)
    evaluate_battery_care(valid_status, state, config, now_epoch)
    evaluate_parked_movement(valid_status, state, now_epoch)
    evaluate_vehicle_flags(valid_status, state, now_epoch)
    if phase_after != phase_before:
        save_event_diagnostic(
            "phase_transition",
            valid_status,
            state,
            config,
            now_epoch,
            from_phase=phase_before,
            to_phase=phase_after,
        )
    for state_event in state_events:
        save_event_diagnostic(
            f"charge_{state_event}", valid_status, state, config, now_epoch
        )
        event_name = {"start": "charging_started", "target_reached": "charge_target_reached", "ended": "charging_completed", "interrupted": "charging_stopped_before_target"}.get(state_event)
        if event_name:
            route_user_event(event_name, valid_status, state, now_epoch)
        if state_event in {"complete", "ended", "interrupted"}:
            record_charge_session(valid_status, state, config, now_epoch, state_event)

    # Reconcile the current physical session after transition processing. This
    # covers a restart/cloud gap where the edge transition was not observed,
    # while excluding completed historical sessions.
    reconcile_charging_events(valid_status, state, now_epoch)

    aivi_ready = aivi_is_configured(config, aivi_token, aivi_activity_slug)
    if aivi_ready and integration_retry_allowed(state, "aivi", now_epoch):
        def send_for_slug(slug: str, action: str, payload: dict[str, Any]) -> None:
            try:
                send_aivi_activity(
                    payload,
                    str(aivi_token),
                    str(slug),
                    float(config["aivi"]["request_timeout_seconds"]),
                )
            except Exception as error:
                state["last_live_activity_error"] = str(error)
                delay = integration_mark_failure(state, "aivi", config, time.time())
                state["last_live_activity_error"] = f"{error} (Retry in {delay} s)"
                save_event_diagnostic(
                    "aivi_error", valid_status, state, config, time.time(),
                    action=action, slug=slug, error=str(error),
                )
                raise
            success_epoch = time.time()
            state["last_live_activity_success_epoch"] = success_epoch
            state["last_live_activity_action"] = action
            state["last_live_activity_error"] = ""
            integration_mark_success(state, "aivi")
            content = payload.get("content", {})
            template = str(content.get("template", ""))
            display = ""
            if template == "progress":
                header = str(content.get("header_right", {}).get("value", ""))
                footer = str(content.get("footer_left", {}).get("value", ""))
                display = " · ".join(value for value in (header, footer) if value)
            elif template == "monitor":
                left = str(content.get("left_column", {}).get("value", {}).get("value", ""))
                right = str(content.get("right_column", {}).get("value", {}).get("value", ""))
                display = " · ".join(value for value in (left, right) if value)
            log(f"Aivi Live Activity | Aktion: {action} | Slug: {slug}" + (f" | Anzeige: {display}" if display else ""))
            save_event_diagnostic(
                "aivi_success", valid_status, state, config, success_epoch,
                action=action, slug=slug, display=display,
            )

        try:
            handoff_three_phase_activity(state, send_for_slug)
            def live_sender(action: str, payload: dict[str, Any]) -> None:
                send_for_slug(str(aivi_activity_slug), action, payload)
            synchronize_live_activity(
                valid_status, state, config, live_sender, now_epoch,
                source_changed=valid_changed,
            )
        except (requests.RequestException, ValueError, RuntimeError) as error:
            log(f"Aivi-Live-Activity-Aktualisierung fehlgeschlagen: {error}")

    save_poll_diagnostic(
        raw_status,
        valid_status,
        state,
        config,
        time_info,
        now_epoch,
        raw_changed=raw_changed,
        valid_changed=valid_changed,
        soc_accepted=soc_accepted,
        soc_note=soc_note,
        fresh=fresh,
        phase_before=phase_before,
        phase_after=phase_after,
        state_events=state_events,
    )
    cleanup_diagnostics_if_due(state, config, now_epoch)
    return valid_status

# ---------------------------------------------------------------------------
# Adaptive polling
# ---------------------------------------------------------------------------


def cap_interval_for_live_tasks(
    interval: int,
    state: dict[str, Any],
    now_epoch: float | None = None,
) -> int:
    """Wake no later than the next intermediate update or Aivi IDLE handoff."""
    if now_epoch is None:
        now_epoch = time.time()
    if not state.get("live_activity_active", False) and not float(state.get("three_phase_idle_due_epoch", 0.0) or 0.0):
        return interval

    due_values = []
    for key in (
        "live_activity_intermediate_due_epoch",
        "live_activity_idle_due_epoch",
        "three_phase_idle_due_epoch",
    ):
        due = float(state.get(key, 0.0) or 0.0)
        if due > 0:
            due_values.append(due)
    if not due_values:
        return interval

    remaining = min(due_values) - now_epoch
    if remaining <= 0:
        return 1
    return max(1, min(interval, int(math.ceil(remaining))))

def calculate_poll_interval(
    status: dict[str, Any] | None,
    state: dict[str, Any],
    config: dict[str, Any],
    now_epoch: float | None = None,
) -> int:
    if now_epoch is None:
        now_epoch = time.time()

    errors = int(state.get("consecutive_errors", 0))
    polling = config["polling"]
    if errors > 0:
        initial = float(polling["error_initial_seconds"])
        maximum = float(polling["error_max_seconds"])
        return max(1, int(min(maximum, initial * (2 ** (errors - 1)))))

    if status is None:
        return int(float(polling["idle_seconds"]))

    # A stale ignition/charging flag must not keep the observer permanently in
    # the fast polling mode. Fresh activity will be detected on the next idle
    # poll and immediately switch the cadence again.
    if not is_fresh(status, config, now_epoch):
        return int(float(polling["idle_seconds"]))

    phase = classify_charge_phase(status, state, config)
    if phase in {"charging", "target_reached", "plugged_idle"}:
        return int(float(polling["charging_seconds"]))

    ignition = to_bool(status.get("ignition"))
    velocity = abs(to_float(status.get("velocity")))
    last_change = float(state.get("last_status_change_epoch", 0.0))
    recently_changed = (
        last_change > 0
        and now_epoch - last_change
        <= float(polling["recent_window_seconds"])
    )
    if ignition or velocity > 0 or recently_changed or phase == "complete":
        return int(float(polling["recent_seconds"]))

    return int(float(polling["idle_seconds"]))


# ---------------------------------------------------------------------------
# Self-test and real recording replay
# ---------------------------------------------------------------------------


def make_test_status(
    soc: int,
    charging: int,
    complete: int,
    plugged: int,
    timestamp: str,
    minutes_left: int = 0,
    actual_timestamp: str | None = None,
) -> dict[str, Any]:
    return {
        "datetime_utc": timestamp,
        "datetime_actual": actual_timestamp or timestamp,
        "soc": soc,
        "charging": charging,
        "chargecomplete": complete,
        "pluggedin": plugged,
        "chargingtimeleft": minutes_left,
        "mileage": 1000,
        "velocity": 0,
        "ignition": 0,
    }


def capture_sequence(
    sequence: list[dict[str, Any]],
    config: dict[str, Any],
) -> list[str]:
    events: list[str] = []
    state = default_runtime_state()
    for status in sequence:
        evaluate_charge_state(status, state, config, events.append)
    return events


def replay_fixture(fixture: Path, config: dict[str, Any]) -> tuple[list[str], dict[str, Any]]:
    state = default_runtime_state()
    events: list[str] = []
    synthetic_epoch = 1_000_000.0
    for line_number, line in enumerate(
        fixture.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            status = record.get("status", record)
            valid_status, _, _ = filter_soc(
                status,
                state,
                synthetic_epoch + line_number * 30,
            )
            evaluate_charge_state(valid_status, state, config, events.append)
        except (ValueError, TypeError, KeyError) as error:
            raise AssertionError(
                f"Ungültige Testaufzeichnung in Zeile {line_number}: {error}"
            ) from error
    return events, state


def replay_timed_fixture(fixture: Path, config: dict[str, Any]) -> tuple[list[str], dict[str, Any]]:
    state = default_runtime_state()
    events: list[str] = []
    for line_number, line in enumerate(fixture.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            status = record.get("status", record)
            fetched_text = str(record.get("fetched_at_utc", ""))
            now_epoch = datetime.fromisoformat(fetched_text.replace("Z", "+00:00")).timestamp()
            valid_status, _, _ = filter_soc(status, state, now_epoch)
            time_info = status_time_info(valid_status, config, now_epoch)
            inferred = maybe_infer_balancing_sleep_completion(
                valid_status, state, config, time_info, now_epoch
            )
            evaluate_charge_state(
                valid_status,
                state,
                config,
                events.append,
                phase_override="complete" if inferred else None,
                now_epoch=now_epoch,
            )
        except (ValueError, TypeError, KeyError) as error:
            raise AssertionError(
                f"Ungültige zeitbasierte Testaufzeichnung in Zeile {line_number}: {error}"
            ) from error
    return events, state


def replay_beta5_terminal_fixture(
    fixture: Path, config: dict[str, Any]
) -> tuple[list[str], dict[str, Any], list[int]]:
    # Reproduce the exact migration condition that exposed the Beta-4 latch:
    # generation 8 was sleep-completed yet persisted as an active session.
    state = migrate_runtime_state({
        "version": 11,
        "initialized": True,
        "charge_session_generation": 8,
        "charge_phase": "complete",
        "session_active": True,
        "start_notified": True,
        "target_notified": True,
        "complete_notified": True,
        "target_soc": 100,
        "target_source": "full_soc_fallback",
        "charge_completion_source": "balancing_sleep_timeout",
        "charge_state_confidence": "inferred",
        "balancing_sleep_completion_contact_epoch": datetime.fromisoformat(
            "2026-08-23T15:58:00+00:00"
        ).timestamp(),
        "last_contact_epoch": datetime.fromisoformat("2026-08-23T15:58:00+00:00").timestamp(),
        "last_valid_soc": 100.0,
    })
    events: list[str] = []
    pulse_generations: list[int] = []
    for line_number, line in enumerate(fixture.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        record = json.loads(line)
        raw = record.get("status", record)
        now_epoch = datetime.fromisoformat(str(record["fetched_at_utc"]).replace("Z", "+00:00")).timestamp()
        valid, _, _ = filter_soc(raw, state, now_epoch)
        time_info = status_time_info(valid, config, now_epoch)
        raw_soc = to_float_or_none(raw.get("soc"))
        shutdown_zero = bool(
            raw_soc is not None and raw_soc <= 0
            and bool(state.get("target_notified", False))
            and (bool(state.get("session_active", False)) or bool(state.get("session_terminal", False)))
            and not to_bool(raw.get("charging"))
        )
        if shutdown_zero:
            generation = int(state.get("charge_session_generation", 0))
            if generation not in pulse_generations:
                pulse_generations.append(generation)
            state["shutdown_zero_pulse_observed"] = True
            state["shutdown_zero_pulse_epoch"] = now_epoch
            state["shutdown_zero_pulse_generation"] = generation
        inferred = maybe_infer_balancing_sleep_completion(valid, state, config, time_info, now_epoch)
        terminal_override = terminal_phase_override(valid, state, config)
        shutdown_override = (
            "complete" if shutdown_zero and bool(state.get("session_active", False))
            and bool(state.get("target_notified", False)) and not bool(state.get("complete_notified", False))
            else None
        )
        if shutdown_override:
            state["charge_completion_source"] = "shutdown_zero_pulse"
            state["charge_state_confidence"] = "confirmed"
        evaluate_charge_state(
            valid, state, config, events.append,
            phase_override=(shutdown_override or terminal_override or ("complete" if inferred else None)),
            now_epoch=now_epoch,
        )
    return events, state, pulse_generations


def replay_real_fixture(config: dict[str, Any]) -> tuple[Path | None, list[str]]:
    fixture = next((path for path in REAL_FIXTURE_CANDIDATES if path.exists()), None)
    if fixture is None:
        return None, []
    events, _ = replay_fixture(fixture, config)
    return fixture, events


def self_test_diagnostics_write_failure() -> dict[str, Any]:
    """Exercise the non-fatal diagnostics path without platform-specific paths."""
    failure_state: dict[str, Any] = {}
    with tempfile.TemporaryDirectory(prefix="zero-connect-diagnostics-selftest-") as temp:
        blocked_path = Path(temp) / "record.jsonl"
        blocked_path.mkdir()
        diag_ok = safe_append_jsonl(
            blocked_path,
            {"test": True},
            failure_state,
        )
    assert diag_ok is False
    assert "Diagnosedaten konnten nicht geschrieben" in failure_state.get(
        "last_diagnostics_error", ""
    )
    return failure_state


def run_self_test() -> None:
    config = copy.deepcopy(DEFAULT_CONFIG)
    # Preserve the historical transport assertions below; Beta-8's canonical
    # single-progress contract is covered in a dedicated production-path block.
    config["aivi"]["mode"] = "legacy"

    normal_sequence = [
        make_test_status(51, 0, 0, 0, "20260801120000"),
        make_test_status(53, 1, 0, 1, "20260801120200", 10),
        make_test_status(65, 1, 1, 1, "20260801121200"),
        make_test_status(65, 0, 1, 1, "20260801122600"),
        make_test_status(65, 0, 0, 0, "20260801123000"),
    ]
    expected_events = ["start", "target", "complete"]
    assert capture_sequence(normal_sequence, config) == expected_events

    full_charge_sequence = [
        make_test_status(97, 0, 0, 0, "20260814171200", 0),
        make_test_status(98, 1, 0, 1, "20260814171440", 2),
        make_test_status(100, 1, 0, 1, "20260814171640", 0),
        make_test_status(100, 1, 0, 1, "20260814172040", 0),
        make_test_status(100, 0, 0, 1, "20260814172623", 0),
        make_test_status(100, 0, 0, 0, "20260814175231", 0),
    ]
    assert capture_sequence(full_charge_sequence, config) == expected_events

    interrupted_before_target = [
        make_test_status(60, 0, 0, 0, "20260814170000"),
        make_test_status(61, 1, 0, 1, "20260814170100", 30),
        make_test_status(62, 0, 0, 1, "20260814170200", 0),
        make_test_status(62, 0, 0, 1, "20260814170230", 0),
    ]
    # A plugged-idle flap is not a physical end. The session stays open until
    # an explicit unplug is observed.
    assert capture_sequence(interrupted_before_target, config) == ["start"]
    explicit_unplug = interrupted_before_target + [
        make_test_status(62, 0, 0, 0, "20260814170300"),
        make_test_status(62, 0, 0, 0, "20260814170330"),
    ]
    assert capture_sequence(explicit_unplug, config) == ["start", "ended"]

    restart_events: list[str] = []
    restart_state = default_runtime_state()
    evaluate_charge_state(
        make_test_status(55, 1, 0, 1, "20260801120600"),
        restart_state,
        config,
        restart_events.append,
    )
    assert restart_events == []

    assert status_fingerprint(
        make_test_status(62, 1, 0, 1, "20260801121200")
    ) != status_fingerprint(
        make_test_status(65, 1, 1, 1, "20260801121200")
    )

    soc_state = default_runtime_state()
    soc_state["last_valid_soc"] = 51.0
    filtered, accepted, note = filter_soc(
        make_test_status(0, 0, 0, 0, "20260801121200"),
        soc_state,
        1000.0,
    )
    assert not accepted and filtered["soc"] == 51.0 and note is not None
    # Counter is intentionally capped at 3/3 in diagnostics.
    for index in range(8):
        filtered, accepted, note = filter_soc(
            make_test_status(0, 0, 0, 0, "20260801121200"),
            soc_state,
            1010.0 + index,
        )
    assert soc_state["zero_candidate_count"] == 3
    assert note is not None and "3/3" in note

    freshness_status = make_test_status(
        45, 0, 0, 0, "20260803085444", actual_timestamp="20260803125011"
    )
    now = zero_timestamp_to_datetime("20260803125511").timestamp()
    info = status_time_info(freshness_status, config, now)
    assert int(info["contact_age_seconds"]) == 300
    assert int(info["measurement_age_seconds"]) > 4 * 60 * 60
    assert is_fresh(freshness_status, config, now)

    deliberate_end = capture_sequence(
        [
            make_test_status(40, 0, 0, 0, "20260801120000"),
            make_test_status(42, 1, 0, 1, "20260801120200", 20),
            make_test_status(48, 0, 0, 0, "20260801120400"),
            make_test_status(48, 0, 0, 0, "20260801120430"),
        ],
        config,
    )
    assert deliberate_end == ["start", "ended"]

    plugged_fault = capture_sequence(
        [
            make_test_status(40, 0, 0, 0, "20260801120000"),
            make_test_status(42, 1, 0, 1, "20260801120200", 20),
            make_test_status(48, 0, 0, 1, "20260801120400"),
            make_test_status(48, 0, 0, 1, "20260801120430"),
        ],
        config,
    )
    assert plugged_fault == ["start"]

    balancing_end = capture_sequence(
        [
            make_test_status(50, 0, 0, 0, "20260801120000"),
            make_test_status(52, 1, 0, 1, "20260801120200", 15),
            make_test_status(65, 1, 1, 1, "20260801121200"),
            make_test_status(65, 0, 0, 0, "20260801121400"),
            make_test_status(65, 0, 0, 0, "20260801121430"),
        ],
        config,
    )
    assert balancing_end == ["start", "target", "ended"]

    balancing_fault = capture_sequence(
        [
            make_test_status(50, 0, 0, 0, "20260801120000"),
            make_test_status(52, 1, 0, 1, "20260801120200", 15),
            make_test_status(65, 1, 1, 1, "20260801121200"),
            make_test_status(65, 0, 0, 1, "20260801121400"),
            make_test_status(65, 0, 0, 1, "20260801121430"),
        ],
        config,
    )
    assert balancing_fault == ["start", "target", "complete"]

    transient = capture_sequence(
        [
            make_test_status(40, 0, 0, 0, "20260801120000"),
            make_test_status(42, 1, 0, 1, "20260801120200", 20),
            make_test_status(42, 0, 0, 0, "20260801120400"),
            make_test_status(43, 1, 0, 1, "20260801120600", 18),
        ],
        config,
    )
    assert transient == ["start"]

    live_state = default_runtime_state()
    live_state["initialized"] = True
    live_state["session_active"] = True
    live_state["charge_session_generation"] = 1
    live_state["session_started_epoch"] = 700.0
    live_state["session_start_soc"] = 40.0
    live_actions: list[tuple[str, dict[str, Any]]] = []
    live_sender = lambda action, payload: live_actions.append((action, payload))
    charging = make_test_status(44, 1, 0, 1, "20260801120200", 16)

    synchronize_live_activity(charging, live_state, config, live_sender, 1000.0)
    start_payload = live_actions[-1][1]
    content = start_payload["content"]
    assert live_actions[-1][0] == "start"
    assert start_payload["state"] == "ONGOING"
    assert content["template"] == "progress"
    assert content["header_left"]["value"] == "44 %"
    assert content["header_right"]["value"] == "16 min"
    assert content["footer_left"]["value"] == "Laden"
    assert content["footer_right"]["value"] == "bis Ladeziel"
    assert content["compact_value"]["value"] == "44 %"
    assert content["progress"]["value"] == 0.44
    assert content["progress"]["color"] == "blue"
    assert content["icon"]["name"] == "motorcycle.fill"
    assert content["icon"]["primary_color"] == "blue"
    assert content["icon"]["rendering_mode"] == "hierarchical"
    assert content["icon"]["color_rendering"] == "gradient"
    assert content["footer_left"]["text_color"] == "gray"
    assert live_state["live_activity_intermediate_due_epoch"] == 1060.0

    retry_state = default_runtime_state()
    retry_state["initialized"] = True
    retry_state["session_active"] = True
    retry_state["charge_session_generation"] = 1
    retry_actions: list[tuple[str, dict[str, Any]]] = []

    def retry_sender(action: str, payload: dict[str, Any]) -> None:
        retry_actions.append((action, payload))
        retry_state["last_live_activity_error"] = ""

    synchronize_live_activity(charging, retry_state, config, retry_sender, 1000.0)
    retry_state["last_live_activity_error"] = "Zeitüberschreitung"
    synchronize_live_activity(
        charging, retry_state, config, retry_sender, 1030.0, source_changed=False
    )
    assert [action for action, _ in retry_actions] == ["start", "update"]

    send_live_intermediate_if_due(live_state, live_sender, 1059.0)
    assert len(live_actions) == 1
    send_live_intermediate_if_due(live_state, live_sender, 1060.0)
    assert len(live_actions) == 1  # unchanged vehicle ETA does not produce a false elapsed-time update
    assert live_state["live_activity_intermediate_due_epoch"] == 1120.0

    updated_charging = make_test_status(44, 1, 0, 1, "20260801120300", 12)
    synchronize_live_activity(
        updated_charging, live_state, config, live_sender, 1120.0, source_changed=True
    )
    assert live_actions[-1][0] == "update"
    assert live_actions[-1][1]["content"]["header_right"]["value"] == "12 min"

    target = make_test_status(65, 1, 1, 1, "20260801121200")
    synchronize_live_activity(target, live_state, config, live_sender, 1600.0)
    target_payload = live_actions[-1][1]
    assert target_payload["content"]["header_left"]["value"] == "65 %"
    assert target_payload["content"]["header_right"]["value"] == "Lädt"
    assert target_payload["content"]["footer_left"]["value"] == "Laden"
    assert target_payload["content"]["footer_right"]["value"] == "bis Ladeziel"
    assert target_payload["content"]["progress"]["color"] != "orange"
    assert target_payload["content"]["icon"]["primary_color"] != "orange"
    assert live_state["live_activity_intermediate_due_epoch"] == 0.0

    complete = make_test_status(65, 0, 1, 1, "20260801122600")
    synchronize_live_activity(complete, live_state, config, live_sender, 2440.0)
    final_payload = live_actions[-1][1]
    assert live_actions[-1][0] == "final"
    assert final_payload["state"] == "ONGOING"
    assert final_payload["content"]["header_right"]["value"] == "Fertig"
    assert final_payload["content"]["footer_left"]["value"] == "Laden abgeschlossen"
    assert final_payload["content"]["footer_right"]["value"] == "Weiterhin angesteckt"
    assert final_payload["content"]["progress"]["color"] == "green"
    assert final_payload["content"]["compact_value"]["value"] == "✓"
    assert live_state["live_activity_idle_due_epoch"] == 2445.0

    send_live_idle_if_due(live_state, live_sender, 2444.0)
    assert live_actions[-1][0] == "final"
    send_live_idle_if_due(live_state, live_sender, 2445.0)
    assert live_actions[-1][0] == "idle"
    assert live_actions[-1][1]["state"] == "IDLE"
    assert not live_state["live_activity_active"]
    assert live_state["live_activity_closed_for_session"]
    assert live_state["live_activity_idle_sent"]

    full_live_state = default_runtime_state()
    full_live_actions: list[tuple[str, dict[str, Any]]] = []
    full_live_sequence = [
        make_test_status(98, 0, 0, 0, "20260814171400", 0),
        make_test_status(98, 1, 0, 1, "20260814171440", 2),
        make_test_status(100, 1, 0, 1, "20260814171640", 0),
        make_test_status(100, 0, 0, 1, "20260814172623", 0),
    ]
    for index, status in enumerate(full_live_sequence):
        evaluate_charge_state(status, full_live_state, config, lambda _event: None)
        synchronize_live_activity(
            status,
            full_live_state,
            config,
            lambda action, payload: full_live_actions.append((action, payload)),
            3000.0 + index * 30,
        )
    assert [action for action, _ in full_live_actions] == ["start", "update", "final"]
    assert full_live_actions[1][1]["content"]["header_right"]["value"] == "Lädt"
    assert full_live_actions[1][1]["content"]["footer_left"]["value"] == "Laden"
    assert full_live_actions[2][1]["content"]["header_right"]["value"] == "Fertig"
    assert full_live_actions[2][1]["content"]["footer_right"]["value"] == "Weiterhin angesteckt"

    ended_state = default_runtime_state()
    ended_actions: list[tuple[str, dict[str, Any]]] = []
    ended_sequence = [
        make_test_status(40, 0, 0, 0, "20260801120000"),
        make_test_status(42, 1, 0, 1, "20260801120200", 20),
        make_test_status(48, 0, 0, 0, "20260801120400"),
        make_test_status(48, 0, 0, 0, "20260801120430"),
    ]
    for index, status in enumerate(ended_sequence):
        evaluate_charge_state(status, ended_state, config, lambda _event: None)
        synchronize_live_activity(
            status,
            ended_state,
            config,
            lambda action, payload: ended_actions.append((action, payload)),
            4000.0 + index * 30,
        )
    ended_payload = ended_actions[-1][1]["content"]
    assert ended_actions[-1][0] == "final"
    assert ended_payload["header_right"]["value"] == "Beendet"
    assert ended_payload["footer_left"]["value"] == "Laden beendet"
    assert ended_payload["footer_right"]["value"] == "Vom Ladepunkt getrennt"
    assert ended_payload["progress"]["color"] == "green"

    balancing_ended_state = default_runtime_state()
    balancing_ended_actions: list[tuple[str, dict[str, Any]]] = []
    balancing_ended_sequence = [
        make_test_status(50, 0, 0, 0, "20260801120000"),
        make_test_status(52, 1, 0, 1, "20260801120200", 15),
        make_test_status(65, 1, 1, 1, "20260801121200"),
        make_test_status(65, 0, 0, 0, "20260801121400"),
        make_test_status(65, 0, 0, 0, "20260801121430"),
    ]
    for index, status in enumerate(balancing_ended_sequence):
        evaluate_charge_state(status, balancing_ended_state, config, lambda _event: None)
        synchronize_live_activity(
            status,
            balancing_ended_state,
            config,
            lambda action, payload: balancing_ended_actions.append((action, payload)),
            5000.0 + index * 30,
        )
    assert balancing_ended_actions[-1][1]["content"]["footer_left"]["value"] == "Laden abgeschlossen"
    assert balancing_ended_actions[-1][1]["content"]["footer_right"]["value"] == "Nicht mehr angesteckt"
    assert balancing_ended_actions[-1][1]["content"]["progress"]["color"] == "green"

    fault_state = default_runtime_state()
    fault_actions: list[tuple[str, dict[str, Any]]] = []
    fault_sequence = [
        make_test_status(40, 0, 0, 0, "20260801120000"),
        make_test_status(42, 1, 0, 1, "20260801120200", 20),
        make_test_status(48, 0, 0, 1, "20260801120400"),
        make_test_status(48, 0, 0, 1, "20260801120430"),
    ]
    for index, status in enumerate(fault_sequence):
        evaluate_charge_state(status, fault_state, config, lambda _event: None)
        synchronize_live_activity(
            status,
            fault_state,
            config,
            lambda action, payload: fault_actions.append((action, payload)),
            6000.0 + index * 30,
        )
    fault_content = fault_actions[-1][1]["content"]
    # A plugged-idle telemetry flap keeps the ongoing activity alive; it is
    # not rendered as a red terminal fault without unplug evidence.
    assert fault_state["charge_phase"] == "plugged_idle"
    assert fault_content["icon"]["primary_color"] != "red"

    stale_status = make_test_status(
        65, 0, 0, 0, "20260801120000", actual_timestamp="20260801120000"
    )
    stale_status["ignition"] = 1
    stale_state = default_runtime_state()
    stale_state["last_status_change_epoch"] = 10_000.0
    assert calculate_poll_interval(stale_status, stale_state, config, now_epoch=20_000.0) == 30

    cap_state = default_runtime_state()
    cap_state["live_activity_active"] = True
    cap_state["live_activity_intermediate_due_epoch"] = 10_010.2
    cap_state["live_activity_idle_due_epoch"] = 10_020.0
    assert cap_interval_for_live_tasks(30, cap_state, 10_000.0) == 11
    assert cap_interval_for_live_tasks(30, cap_state, 10_020.0) == 1

    legacy_state = migrate_runtime_state(
        {
            "version": 8,
            "live_activity_active": True,
            "live_activity_final_sent": True,
            "live_activity_clear_due_epoch": 1000.0,
            "last_ha_notification_title": "Alt",
        }
    )
    assert legacy_state["version"] == 16
    assert legacy_state["charging_sample_sequence_generation"] == -1
    assert legacy_state["charging_sample_sequence_next"] is None
    assert not legacy_state["live_activity_active"]
    assert legacy_state["live_activity_session_generation"] == -1
    assert "live_activity_clear_due_epoch" not in legacy_state
    assert "last_ha_notification_title" not in legacy_state

    beta2_state = migrate_runtime_state(
        {
            "version": 9,
            "session_active": True,
            "charge_phase": "charging",
            "last_live_activity_success_epoch": 12345.0,
            "live_activity_active": True,
            "live_activity_session_generation": 3,
            "last_abrp_success_epoch": 12345.0,
        }
    )
    assert beta2_state["version"] == 16
    assert beta2_state["session_active"]
    assert beta2_state["live_activity_active"]
    assert beta2_state["live_activity_session_generation"] == 3
    assert beta2_state["last_live_activity_success_epoch"] == 0.0
    assert beta2_state["last_abrp_success_epoch"] == 0.0

    class FailingSession:
        def get(self, *_args: Any, **_kwargs: Any) -> Any:
            raise requests.ConnectionError(
                "https://example.invalid/?user=secret-user&pass=secret-pass"
            )

    try:
        request_zero(
            FailingSession(),  # type: ignore[arg-type]
            "get_units", "secret-user", "secret-pass", 1.0,
        )
    except RuntimeError as error:
        safe_message = str(error)
        assert "secret-user" not in safe_message
        assert "secret-pass" not in safe_message
        assert "example.invalid" not in safe_message
    else:
        raise AssertionError("Fehlerhafter Zero-Aufruf wurde nicht abgefangen.")

    retry_poll_state = default_runtime_state()
    retry_poll_state["consecutive_errors"] = 1
    assert calculate_poll_interval(None, retry_poll_state, config) == 30
    retry_poll_state["consecutive_errors"] = 2
    assert calculate_poll_interval(None, retry_poll_state, config) == 60

    invalid_config = copy.deepcopy(config)
    invalid_config["aivi"]["live_activity"]["styles"]["charging"]["progress_color"] = "#42A5F5"
    try:
        validate_config(invalid_config)
    except RuntimeError:
        pass
    else:
        raise AssertionError("Ungültige Aivi-Farbe wurde akzeptiert.")

    invalid_slug = copy.deepcopy(config)
    invalid_slug["aivi"]["activity_slug"] = "ungültig mit leerzeichen"
    try:
        validate_config(invalid_slug)
    except RuntimeError:
        pass
    else:
        raise AssertionError("Ungültiger Aivi-Slug wurde akzeptiert.")

    original_post = requests.post

    class FakeAbrpResponse:
        status_code = 401

        def json(self) -> dict[str, Any]:
            return {"status": "error"}

    def fake_abrp_post(_url: str, **_kwargs: Any) -> FakeAbrpResponse:
        return FakeAbrpResponse()

    requests.post = fake_abrp_post  # type: ignore[assignment]
    try:
        send_to_abrp(
            make_test_status(50, 0, 0, 0, "20260801120000"),
            "secret-abrp-token",
            "secret-abrp-key",
            1.0,
        )
    except RuntimeError as error:
        message = str(error)
        assert "401" in message
        assert "secret-abrp-token" not in message
        assert "secret-abrp-key" not in message
    else:
        raise AssertionError("ABRP HTTP-Fehler wurde nicht abgefangen.")
    finally:
        requests.post = original_post  # type: ignore[assignment]

    original_patch = requests.patch

    class FakeAiviResponse:
        def __init__(self, status_code: int, detail: str = "") -> None:
            self.status_code = status_code
            self._detail = detail

        def json(self) -> dict[str, str]:
            return {"detail": self._detail}

    captured_headers: dict[str, str] = {}
    captured_json: dict[str, Any] = {}

    def fake_success_patch(_url: str, **kwargs: Any) -> FakeAiviResponse:
        captured_headers.update(kwargs.get("headers", {}))
        captured_json.update(kwargs.get("json", {}))
        return FakeAiviResponse(200)

    requests.patch = fake_success_patch  # type: ignore[assignment]
    send_aivi_activity(start_payload, "secret-aivi-token", "zero-srs-test", 1.0)
    assert captured_headers["Authorization"] == "Token secret-aivi-token"
    assert captured_json["state"] == "ONGOING"

    def fake_error_patch(_url: str, **_kwargs: Any) -> FakeAiviResponse:
        return FakeAiviResponse(401, "Could not validate credentials")

    requests.patch = fake_error_patch  # type: ignore[assignment]
    try:
        send_aivi_activity(start_payload, "secret-aivi-token", "zero-srs-test", 1.0)
    except RuntimeError as error:
        message = str(error)
        assert "401" in message
        assert "secret-aivi-token" not in message
    else:
        raise AssertionError("Aivi HTTP-Fehler wurde nicht abgefangen.")
    finally:
        requests.patch = original_patch  # type: ignore[assignment]

    # A network/cloud outage restarts the balancing-sleep evidence window.
    outage_state = default_runtime_state()
    outage_state.update({
        "session_active": True,
        "target_notified": True,
        "target_source": "full_soc_fallback",
        "complete_notified": False,
        "balancing_stale_success_polls": 8,
        "balancing_last_progress_observed_epoch": 1000.0,
    })
    note_balancing_cloud_error(outage_state, 2000.0)
    assert outage_state["balancing_stale_success_polls"] == 0
    assert outage_state["balancing_last_progress_observed_epoch"] == 2000.0

    # Configuration migration must preserve old user choices while adding current defaults.
    migrated = deep_merge(DEFAULT_CONFIG, migrate_config({
        "vehicle_label": "Test Zero",
        "diagnostics": {"retention_days": 30},
        "aivi": {"enabled": True, "activity_slug": "test-slug"},
    }))
    validate_config(migrated)
    assert migrated["schema_version"] == CONFIG_SCHEMA_VERSION
    assert migrated["vehicle_label"] == "Test Zero"
    assert migrated["diagnostics"]["retention_days"] == 30
    assert migrated["diagnostics"]["max_size_mib"] == 2048
    assert migrated["charging"]["balancing_sleep_completion"]["enabled"] is True

    # A diagnostics write failure is deliberately non-fatal on every platform.
    self_test_diagnostics_write_failure()

    fixture, fixture_events = replay_real_fixture(config)
    if fixture is not None:
        assert fixture_events == expected_events, fixture_events

    full_fixture_events: list[str] = []
    full_fixture_state: dict[str, Any] | None = None
    if REAL_100_FIXTURE.exists():
        full_fixture_events, full_fixture_state = replay_fixture(REAL_100_FIXTURE, config)
        assert full_fixture_events == expected_events, full_fixture_events
        assert full_fixture_state["complete_notified"]
        assert full_fixture_state["target_soc"] == 100

    if REAL_100_SLEEP_FIXTURE.exists():
        sleep_events, sleep_state = replay_timed_fixture(REAL_100_SLEEP_FIXTURE, config)
        assert sleep_events == expected_events, sleep_events
        assert sleep_state["complete_notified"]
        assert sleep_state["charge_completion_source"] == "balancing_sleep_timeout"
        assert sleep_state["charge_state_confidence"] == "inferred"
        completion_epoch = float(sleep_state.get("session_completed_epoch", 0.0))
        cloud_confirmation_epoch = datetime.fromisoformat("2026-08-15T17:48:51.788314+00:00").timestamp()
        assert completion_epoch > 0 and completion_epoch < cloud_confirmation_epoch

    if REAL_TARGET90_THEN_100_FIXTURE.exists():
        beta5_events, beta5_state, beta5_pulses = replay_beta5_terminal_fixture(
            REAL_TARGET90_THEN_100_FIXTURE, config
        )
        assert beta5_events == ["start", "target", "complete", "start", "target", "complete"], beta5_events
        assert int(beta5_state.get("charge_session_generation", 0)) == 10
        assert beta5_pulses == [9, 10], beta5_pulses
        assert beta5_state.get("session_terminal") is True

    three_config = copy.deepcopy(config)
    three_config["aivi"]["enabled"] = True
    three_config["aivi"]["mode"] = "three_phase"
    three_config["aivi"]["activity_slug"] = "test-charge"
    three_config["aivi"]["balancing_activity_slug"] = "test-balance"
    three_config["aivi"]["complete_activity_slug"] = "test-complete"
    validate_config(three_config)
    three_state = default_runtime_state()
    three_events: list[str] = []
    sent: list[tuple[str, str, str, str]] = []
    def capture_three(slug: str, action: str, payload: dict[str, Any]) -> None:
        sent.append((slug, action, str(payload.get("state")), str(payload.get("content", {}).get("template"))))
    base = 2_000_000.0
    initial = make_test_status(60, 0, 0, 0, "20260801120000")
    evaluate_charge_state(initial, three_state, three_config, three_events.append, now_epoch=base)
    charging_status = make_test_status(61, 1, 0, 1, "20260801120100", 20)
    evaluate_charge_state(charging_status, three_state, three_config, three_events.append, now_epoch=base+60)
    synchronize_three_phase_activity(charging_status, three_state, three_config, "test-charge", capture_three, base+60)
    target_status = make_test_status(90, 1, 1, 1, "20260801122000", 0)
    evaluate_charge_state(target_status, three_state, three_config, three_events.append, now_epoch=base+1200)
    synchronize_three_phase_activity(target_status, three_state, three_config, "test-charge", capture_three, base+1200)
    complete_status = make_test_status(90, 0, 1, 1, "20260801122500", 0)
    evaluate_charge_state(complete_status, three_state, three_config, three_events.append, now_epoch=base+1500)
    synchronize_three_phase_activity(complete_status, three_state, three_config, "test-charge", capture_three, base+1500)
    send_three_phase_idle_if_due(three_state, capture_three, base+2110)
    assert [item[1] for item in sent] == [
        "start_charging", "update_charging", "idle_charging", "start_complete", "idle_complete"
    ], sent
    assert sent[0][0] == "test-charge" and sent[0][3] == "progress"
    assert sent[3][0] == "test-complete" and sent[3][3] == "monitor"

    # Target status alone must not produce an unsupported balancing stopwatch.
    balance_state = default_runtime_state()
    balance_state["session_balancing_started_epoch"] = base
    b_status = make_test_status(100, 1, 0, 1, "20260801123000", 0)
    b0 = build_balancing_monitor_payload(b_status, balance_state, now_epoch=base + 20)
    b1 = build_balancing_monitor_payload(b_status, balance_state, now_epoch=base + 65)
    assert b0["content"]["right_column"]["value"]["value"] == "angesteckt"
    assert b1["content"]["right_column"]["value"]["value"] == "angesteckt"
    assert "formatter" not in b1["content"]["right_column"]["value"]

    # Beta 6: a new charge generation must close a still-visible completion summary first.
    rollover_state = copy.deepcopy(three_state)
    rollover_state["charge_session_generation"] = int(rollover_state.get("charge_session_generation", 0)) + 1
    rollover_state["charge_phase"] = "charging"
    rollover_state["session_active"] = True
    rollover_sent: list[tuple[str, str, str, str]] = []
    def capture_rollover(slug: str, action: str, payload: dict[str, Any]) -> None:
        rollover_sent.append((slug, action, str(payload.get("state")), str(payload.get("content", {}).get("template"))))
    synchronize_three_phase_activity(charging_status, rollover_state, three_config, "test-charge", capture_rollover, base+2120)
    assert rollover_sent[-1][1] == "start_charging"
    assert rollover_sent[-1][0] == "test-charge"

    # Beta 8: the canonical production path keeps charging, balancing and the
    # completion summary in one Progress activity and delays IDLE for 10 min.
    single_config = copy.deepcopy(DEFAULT_CONFIG)
    single_state = default_runtime_state()
    single_state.update(
        initialized=True,
        session_active=True,
        charge_session_generation=1,
        charge_phase="charging",
        session_start_soc=40.0,
        session_started_epoch=base,
        target_soc=80.0,
    )
    single_sent: list[tuple[str, dict[str, Any]]] = []
    single_sender = lambda action, payload: single_sent.append((action, payload))
    synchronize_live_activity(
        make_test_status(50, 1, 0, 1, "20260801120100", 30),
        single_state, single_config, single_sender, base + 60,
    )
    single_state.update(
        charge_phase="target_reached",
        session_balancing_started_epoch=base + 1200,
    )
    synchronize_live_activity(
        make_test_status(80, 1, 1, 1, "20260801122000", 0),
        single_state, single_config, single_sender, base + 1500,
    )
    single_state.update(charge_phase="complete", session_completed_epoch=base + 3600)
    synchronize_live_activity(
        make_test_status(80, 0, 1, 1, "20260801130000", 0),
        single_state, single_config, single_sender, base + 3600,
    )
    assert [action for action, _ in single_sent] == ["start", "update", "final"]
    assert all(payload["content"]["template"] == "progress" for _, payload in single_sent)
    assert single_sent[1][1]["content"]["progress"]["value"] == 1.0
    assert "40" in single_sent[2][1]["content"]["header_left"]["value"]
    assert single_state["live_activity_idle_due_epoch"] == base + 4200

    print("Selbsttest erfolgreich: Basis-Suite und Regressionstests bestanden.")
    if fixture is None:
        print("Reale 65-%-Aufzeichnung: nicht vorhanden, Test übersprungen.")
    else:
        print("Reale 65-%-Aufzeichnung erfolgreich wiedergegeben: " f"{fixture}")
    if REAL_100_FIXTURE.exists():
        print(
            "Reale 100-%-Aufzeichnung vom 14.08.2026 erfolgreich wiedergegeben: "
            f"{REAL_100_FIXTURE}"
        )
    else:
        print("Reale 100-%-Aufzeichnung: nicht vorhanden, Test übersprungen.")
    if REAL_100_SLEEP_FIXTURE.exists():
        print(
            "Realer 100-%-Schlaf-/Balancing-Fall vom 15.08.2026 erfolgreich wiedergegeben; "
            "Ladeende wird vor der verspäteten Cloud-Bestätigung abgeleitet."
        )
    else:
        print("Realer 100-%-Schlaf-/Balancing-Fall: nicht vorhanden, Test übersprungen.")
    if REAL_TARGET90_THEN_100_FIXTURE.exists():
        print(
            "Realer 24.08.2026 Target-90→97→100-Fall erfolgreich wiedergegeben; "
            "zwei neue Sessions und beide Shutdown-0-%-Signale erkannt."
        )
    else:
        print("Realer 24.08.2026 Target-90→97→100-Fall: nicht vorhanden, Test übersprungen.")
    print(
        "Aivi Live Activity: Single-Progress-Produktion sowie historische "
        "Legacy-/Dreiphasen-Kompatibilität mit IDLE-Handoff geprüft."
    )

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------


_STOP_EVENT = threading.Event()


def _request_shutdown(signum: int, _frame: Any) -> None:
    _STOP_EVENT.set()


def wait_for_first_run() -> bool:
    """Wait for the Web wizard, then continue without requiring systemd access.

    The appliance web process is intentionally unprivileged and cannot restart
    a system unit.  Once the wizard atomically writes valid credentials, the
    already-running observer can leave its first-run wait state safely.
    """
    log("Ersteinrichtung offen: Zero Cloud wird über die lokale Web-UI eingerichtet.")
    while not _STOP_EVENT.wait(2):
        load_dotenv(ENV_FILE, override=True)
        if all(os.getenv(name) for name in ("ZERO_CLOUD_USER", "ZERO_CLOUD_PASSWORD", "ZERO_UNIT_NUMBER")):
            return True
    return False


def main() -> None:
    configure_console_output()
    if "--self-test" in sys.argv:
        run_self_test()
        return

    signal.signal(signal.SIGTERM, _request_shutdown)
    signal.signal(signal.SIGINT, _request_shutdown)
    _STOP_EVENT.clear()

    config = load_config()
    configure_persistent_logging(config)
    load_dotenv(ENV_FILE)

    zero_username = os.getenv("ZERO_CLOUD_USER")
    zero_password = os.getenv("ZERO_CLOUD_PASSWORD")
    selected_unit_number = os.getenv("ZERO_UNIT_NUMBER")
    abrp_token = os.getenv("ABRP_TOKEN")
    abrp_api_key = os.getenv("ABRP_API_KEY")
    aivi_token = os.getenv("AIVI_API_TOKEN")
    aivi_activity_slug = (
        os.getenv("AIVI_ACTIVITY_SLUG")
        or str(config["aivi"].get("activity_slug", "")).strip()
    )

    required_values = {
        "ZERO_CLOUD_USER": zero_username,
        "ZERO_CLOUD_PASSWORD": zero_password,
    }
    missing = [name for name, value in required_values.items() if not value]
    if missing:
        if not wait_for_first_run():
            return
        config = load_config()
        load_dotenv(ENV_FILE, override=True)
        zero_username = os.getenv("ZERO_CLOUD_USER")
        zero_password = os.getenv("ZERO_CLOUD_PASSWORD")
        selected_unit_number = os.getenv("ZERO_UNIT_NUMBER")
        abrp_token = os.getenv("ABRP_TOKEN")
        abrp_api_key = os.getenv("ABRP_API_KEY")
        aivi_token = os.getenv("AIVI_API_TOKEN")
        aivi_activity_slug = os.getenv("AIVI_ACTIVITY_SLUG") or str(config["aivi"].get("activity_slug", "")).strip()

    try:
        DATA_DIR.mkdir(exist_ok=True)
        DATA_DIR.chmod(0o700)
        for directory in (LOG_DIR, POLL_HISTORY_DIR, EVENT_HISTORY_DIR, SESSION_HISTORY_DIR):
            directory.mkdir(parents=True, exist_ok=True)
            directory.chmod(0o700)
    except OSError as error:
        log(f"Warnung: Diagnoseverzeichnisse nicht verfügbar; Kernüberwachung läuft weiter: {error}")

    state = load_runtime_state()
    cleanup_diagnostics_if_due(state, config)
    session = requests.Session()
    timeout_seconds = float(config["request_timeout_seconds"])

    while not _STOP_EVENT.is_set():
        state["last_poll_attempt_epoch"] = time.time()
        try:
            vehicles = request_zero(
                session,
                "get_units",
                str(zero_username),
                str(zero_password),
                timeout_seconds,
            )
            if not isinstance(vehicles, list) or not vehicles:
                raise RuntimeError("Kein Fahrzeug im Zero-Konto gefunden.")
            vehicle = select_account_vehicle(vehicles, selected_unit_number)
            unit_number = str(vehicle["unitnumber"])
            state["last_poll_success_epoch"] = time.time()
            state["consecutive_errors"] = 0
            state["last_error"] = ""
            safe_save_runtime_state(state)
            break
        except (ValueError, KeyError, RuntimeError) as error:
            state["consecutive_errors"] = int(state.get("consecutive_errors", 0)) + 1
            state["last_error"] = str(error)
            interval = calculate_poll_interval(None, state, config)
            state["last_poll_interval_seconds"] = interval
            safe_save_runtime_state(state)
            log(f"Zero Cloud beim Start noch nicht verfügbar: {error}")
            log(f"Neuer Startversuch in {interval} Sekunden.")
            _STOP_EVENT.wait(interval)

    if _STOP_EVENT.is_set():
        state["last_shutdown_epoch"] = time.time()
        state["last_shutdown_reason"] = "Signal während Startphase"
        safe_save_runtime_state(state)
        log("Zero Connect sauber beendet.")
        return

    configured_label = str(config.get("vehicle_label", "")).strip()
    account_vehicle_name = configured_label or vehicle_display_label(vehicle)

    log(
        "Zero Connect 1.0.0-beta.1 gestartet "
        f"(intern v3.0.0-alpha.45): {account_vehicle_name}"
    )
    log(
        "Polling: "
        f"Laden {config['polling']['charging_seconds']} s | "
        f"kürzlich aktiv {config['polling']['recent_seconds']} s | "
        f"Ruhezustand {config['polling']['idle_seconds']} s"
    )
    log(
        "Schutz aktiv: duale Zeitstempelprüfung, Zustands-Fingerprint, "
        "SoC-Plausibilisierung, Ladeunterbrechungs-Entprellung, "
        "Balancing-Sleep-Fallback und Charge-Target-Automat."
    )

    log(
        "Diagnose: persistentes Textlog + Poll-Historie | "
        f"Aufbewahrung {int(config.get('diagnostics', {}).get('retention_days', 180))} Tage"
    )

    aivi_ready = aivi_is_configured(config, aivi_token, aivi_activity_slug)
    if aivi_ready:
        log(
            "Aivi-Integration aktiv | Single Progress | "
            f"Slug: {aivi_activity_slug}"
        )
    elif config["aivi"].get("enabled", False):
        log("Aivi aktiviert, aber API-Token oder Activity-Slug fehlt.")
    else:
        log("Aivi-Integration deaktiviert.")

    if config.get("abrp", {}).get("enabled", False):
        if abrp_token and abrp_api_key:
            log("ABRP-Telemetrie aktiv.")
        else:
            log("ABRP aktiviert, aber Token oder API-Key fehlt.")
    else:
        log("ABRP-Telemetrie deaktiviert.")

    def production_slug_sender(slug: str, action: str, payload: dict[str, Any]) -> None:
        if not aivi_ready:
            return
        try:
            send_aivi_activity(
                payload,
                str(aivi_token),
                str(slug),
                float(config["aivi"]["request_timeout_seconds"]),
            )
        except Exception as error:
            delay = integration_mark_failure(state, "aivi", config, time.time())
            state["last_live_activity_error"] = f"{error} (Retry in {delay} s)"
            raise
        state["last_live_activity_success_epoch"] = time.time()
        state["last_live_activity_action"] = action
        state["last_live_activity_error"] = ""
        integration_mark_success(state, "aivi")
        log(f"Aivi Live Activity | Aktion: {action} | Slug: {slug}")

    def production_live_sender(action: str, payload: dict[str, Any]) -> None:
        production_slug_sender(str(aivi_activity_slug), action, payload)

    latest_status: dict[str, Any] | None = None

    while not _STOP_EVENT.is_set():
        state["last_poll_attempt_epoch"] = time.time()
        try:
            transmissions = request_zero(
                session,
                "get_last_transmit",
                str(zero_username),
                str(zero_password),
                timeout_seconds,
                unitnumber=unit_number,
            )
            if not isinstance(transmissions, list) or not transmissions:
                raise RuntimeError("Kein Fahrzeugdatensatz empfangen.")
            report = transmissions[0]
            if isinstance(report, list) and report:
                report = report[0]  # the raw history has seen the report wrapped once more
            if not isinstance(report, dict):
                raise RuntimeError("Zero Cloud lieferte einen Datensatz in unerwartetem Format.")

            state["last_poll_success_epoch"] = time.time()
            state["consecutive_errors"] = 0
            state["last_error"] = ""
            latest_status = process_status(
                report,
                state,
                config,
                abrp_token,
                abrp_api_key,
                aivi_token,
                aivi_activity_slug,
            )
            if (
                _history_session_eligible(state)
                or _terminal_history_followup_eligible(state, time.time())
            ):
                poll_balancing_history(
                    session,
                    str(zero_username),
                    str(zero_password),
                    unit_number,
                    time.time(),
                    state,
                    config,
                )

        except (requests.RequestException, ValueError, KeyError, RuntimeError) as error:
            state["consecutive_errors"] = int(state.get("consecutive_errors", 0)) + 1
            state["last_error"] = str(error)
            note_balancing_cloud_error(state, time.time())
            log(f"Zero-Abfragefehler: {error}")
        except OSError as error:
            # Full or read-only storage: keep polling and the live integrations running.
            state["last_diagnostics_error"] = f"Daten konnten nicht gespeichert werden: {error}"
            log("Warnung: Daten konnten nicht gespeichert werden; Observer läuft weiter.")

        try:
            evaluate_vehicle_connectivity_notifications(state, time.time())
        except OSError as error:
            state["last_diagnostics_error"] = f"Daten konnten nicht gespeichert werden: {error}"

        if aivi_ready and integration_retry_allowed(state, "aivi", time.time()):
            handoff_ok = True
            try:
                handoff_three_phase_activity(state, production_slug_sender)
            except (requests.RequestException, ValueError, RuntimeError) as error:
                handoff_ok = False
                log(f"Aivi-Migrations-IDLE fehlgeschlagen: {error}")
            if handoff_ok:
                try:
                    send_live_intermediate_if_due(state, production_live_sender)
                except (requests.RequestException, ValueError, RuntimeError) as error:
                    state["live_activity_intermediate_due_epoch"] = time.time() + 30
                    log(f"Aivi-Zwischenupdate fehlgeschlagen: {error}")
                try:
                    send_live_idle_if_due(state, production_live_sender)
                except (requests.RequestException, ValueError, RuntimeError) as error:
                    state["live_activity_idle_due_epoch"] = time.time() + 30
                    log(f"Aivi-IDLE-Handoff fehlgeschlagen: {error}")

        interval = calculate_poll_interval(latest_status, state, config)
        interval = cap_interval_for_live_tasks(interval, state)
        state["last_poll_interval_seconds"] = interval
        safe_save_runtime_state(state)
        log(f"Nächste Abfrage in {interval} Sekunden.")
        _STOP_EVENT.wait(interval)

    state["last_shutdown_epoch"] = time.time()
    state["last_shutdown_reason"] = "SIGTERM/SIGINT"
    safe_save_runtime_state(state)
    log("Zero Connect sauber beendet; Runtime-State gespeichert.")


if __name__ == "__main__":
    main()
