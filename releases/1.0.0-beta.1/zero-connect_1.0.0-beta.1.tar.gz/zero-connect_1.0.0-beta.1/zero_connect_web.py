#!/usr/bin/env python3
"""Local, dependency-light web UI for Zero Connect."""
from __future__ import annotations

import argparse
import base64
import copy
import functools
import hashlib
import io
import json
import math
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
from http.cookies import SimpleCookie
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import requests

import zero_observer as observer
import zero_setup as setup
import zero_remote as remote
import zero_updates as updates
import zero_vehicle_photos as vehicle_photos
import zero_history as history_mod
import zero_vehicle as vehicle
import zero_charging as charging_mod
import zero_functional as functional
import zero_trips as trips
from zero_wifi_setup import WifiSetupManager
from zero_paths import PATHS

try:
    import zero_release_notes as release_notes
except ImportError:  # partial developer uploads may predate release notes
    release_notes = None

PROJECT_DIR = PATHS.program_dir
WEB_ASSETS_DIR = PATHS.web_assets_dir
DATA_DIR = PATHS.data_dir
PIN_FILE = DATA_DIR / "web_admin_pin"
STATE_FILE = DATA_DIR / "runtime_state_v2.json"
VALID_FILE = DATA_DIR / "last_valid_transmit.json"
RAW_FILE = DATA_DIR / "last_raw_transmit.json"
REVISION_FILE = PROJECT_DIR / ".deploy-revision"
LOCATION_FILE = DATA_DIR / "last_known_location.json"
_LOCATION_LOCK = threading.Lock()
PUBLIC_VERSION = "1.0.0-beta.1"
INTERNAL_VERSION = "3.0.0-alpha.45"
OBSERVER_SERVICE = "zero-observer.service"
WEB_SERVICE = "zero-connect-web.service"
MILES_TO_KM = 1.609344
SUPPORTED_VEHICLE_MODELS = setup.SUPPORTED_VEHICLE_MODELS
PIN_MAX_FAILED_ATTEMPTS = 5
PIN_LOCKOUT_SECONDS = 60.0
PIN_FAILURE_WINDOW_SECONDS = 300.0
PIN_FAILURE_TABLE_LIMIT = 1024
ADMIN_SESSION_SECONDS = 20 * 60
SUPPORT_DOWNLOAD_SECONDS = 10 * 60
WEB_MUTATION_LOCK = threading.RLock()
WEB_ACTIVITY_LOCK = threading.Lock()
WEB_ACTIVITY_FILE = DATA_DIR / "web_client_activity.json"
WEB_ACTIVITY_MIN_WRITE_SECONDS = 30.0
WEB_ACTIVITY_IDLE_SECONDS = 300.0


class PersistedRestartError(RuntimeError):
    """Configuration was persisted but applying it through restart failed."""


class SessionHistoryError(RuntimeError):
    def __init__(self, message: str, status: int = HTTPStatus.CONFLICT):
        super().__init__(message)
        self.status = status


def update_vehicle_busy() -> bool:
    """True while a charge/plug episode is active; updates then wait."""
    try:
        with observer.runtime_state_lock():
            state = read_state()
    except Exception:
        return True  # unknown state: do not restart services underneath a possible charge
    return (bool(state.get("session_active")) or bool(state.get("plugged_episode_active"))
            or str(state.get("charge_phase") or "") in {"charging", "target_reached"})


def updates_payload() -> dict[str, Any]:
    return {"ok": True, **updates.status(vehicle_busy=update_vehicle_busy)}


def serialized_web_mutation(function: Any) -> Any:
    @functools.wraps(function)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        with WEB_MUTATION_LOCK:
            return function(*args, **kwargs)

    return wrapped


def read_state() -> dict[str, Any]:
    return observer.sanitize_runtime_types(read_json(STATE_FILE))


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def record_web_client_activity(now_epoch: float | None = None) -> float:
    """Persist only the last interaction time; never retain client identity."""
    now = time.time() if now_epoch is None else float(now_epoch)
    with WEB_ACTIVITY_LOCK:
        previous = read_json(WEB_ACTIVITY_FILE)
        try:
            previous_epoch = float(previous.get("last_activity_epoch", 0.0) or 0.0)
        except (TypeError, ValueError):
            previous_epoch = 0.0
        if now - previous_epoch >= WEB_ACTIVITY_MIN_WRITE_SECONDS:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            _atomic_private_text(WEB_ACTIVITY_FILE, json.dumps({"last_activity_epoch": now}) + "\n")
            return now
        return previous_epoch


def release_notes_payload() -> dict[str, Any]:
    """Release notes of the installed revision; older installs say so instead of guessing."""
    if release_notes is None:
        return {"version": PUBLIC_VERSION, "internal_version": INTERNAL_VERSION, "revision": "unknown",
                "installed_at": None, "documented": False, "groups": [], "user_visible": False, "requests": [],
                "notice": "Für diese frühere Version sind keine vollständigen Release Notes vorhanden."}
    return release_notes.installed_release(PROJECT_DIR, DATA_DIR, version=PUBLIC_VERSION,
                                           internal_version=INTERNAL_VERSION)


def connection_state(*, configured: bool, last_success: Any = None, last_error: Any = None) -> str:
    """Return one consistent user-facing integration state."""
    if not configured:
        return "disabled"
    if str(last_error or "").strip():
        return "failed"
    return "connected" if last_success else "configured"


def connection_statuses(cfg: dict[str, Any], env: dict[str, str], state: dict[str, Any]) -> dict[str, str]:
    cloud_configured = bool(
        env.get("ZERO_CLOUD_USER")
        and env.get("ZERO_CLOUD_PASSWORD")
        and env.get("ZERO_UNIT_NUMBER")
    )
    aivi_cfg = cfg.get("aivi", {}) if isinstance(cfg.get("aivi", {}), dict) else {}
    abrp_cfg = cfg.get("abrp", {}) if isinstance(cfg.get("abrp", {}), dict) else {}
    return {
        "zero_cloud": connection_state(
            configured=cloud_configured,
            last_success=state.get("last_poll_success_epoch") or state.get("last_contact_epoch"),
            last_error=state.get("last_error"),
        ),
        "aivi": connection_state(
            configured=bool(aivi_cfg.get("enabled") and env.get("AIVI_API_TOKEN")),
            last_success=state.get("last_live_activity_success_epoch"),
            last_error=state.get("last_live_activity_error"),
        ),
        "abrp": connection_state(
            configured=bool(abrp_cfg.get("enabled") and env.get("ABRP_TOKEN") and env.get("ABRP_API_KEY")),
            last_success=state.get("last_abrp_success_epoch"),
            last_error=state.get("last_abrp_error"),
        ),
    }


def health_issue_codes(
    observer_active: bool,
    state: dict[str, Any],
    connections: dict[str, str],
) -> list[str]:
    """Return stable, redacted health issue identifiers for the dashboard.

    Persistence failures can be summarized only after their marker reaches the
    state file read by the web process; a failed state-file write itself cannot
    be reported until a later save succeeds.
    """
    issues: list[str] = []
    if not observer_active:
        issues.append("observer_stopped")
    if connections.get("zero_cloud") == "failed":
        issues.append("cloud_error")
    if connections.get("aivi") == "failed":
        issues.append("aivi_error")
    if connections.get("abrp") == "failed":
        issues.append("abrp_error")
    if str(state.get("last_diagnostics_error") or "") or storage_unusable():
        issues.append("persistence_error")
    return issues


STORAGE_MIN_FREE_BYTES = 20 * 1024 * 1024


def storage_unusable() -> bool:
    """Read-only or (nearly) full storage, seen directly: the Observer cannot report it then."""
    try:
        if not DATA_DIR.is_dir():
            return False
        return not os.access(DATA_DIR, os.W_OK) or shutil.disk_usage(DATA_DIR).free < STORAGE_MIN_FREE_BYTES
    except OSError:
        return False


def atomic_pin() -> str:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        DATA_DIR.chmod(0o700)
    except OSError:
        pass
    if PIN_FILE.exists():
        try:
            pin = PIN_FILE.read_text(encoding="utf-8").strip()
            if pin.isdigit() and len(pin) == 6:
                PIN_FILE.chmod(0o600)
                return pin
        except OSError:
            pass
    pin = f"{secrets.randbelow(1_000_000):06d}"
    try:
        return write_admin_pin(pin)
    except OSError:
        # Full or read-only storage must not keep the web UI from starting.
        print("Admin-PIN konnte nicht gespeichert werden; gilt bis zum Neustart.", flush=True)
        return pin


def service_active(name: str) -> bool:
    return setup.service_is_active(name)


def epoch_iso(value: Any) -> str | None:
    try:
        epoch = float(value)
    except (TypeError, ValueError):
        return None
    if epoch <= 0:
        return None
    return datetime.fromtimestamp(epoch, tz=timezone.utc).astimezone().isoformat(timespec="seconds")


def zero_time_iso(value: Any) -> str | None:
    parsed = observer.timestamp_or_none(value)
    if parsed is None:
        return None
    return parsed.astimezone().isoformat(timespec="seconds")


def write_admin_pin(pin: str) -> str:
    pin = str(pin).strip()
    if not (pin.isdigit() and len(pin) == 6):
        raise ValueError("Die Admin-PIN muss genau 6 Ziffern haben.")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _atomic_private_text(PIN_FILE, pin + "\n")
    return pin


def _atomic_private_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.chmod(0o600)
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try: os.fsync(directory_fd)
        finally: os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def dashboard_state(phase: str) -> str:
    """Map observer phases to a stable presentation-only state."""
    return {
        "charging": "charging",
        "target_reached": "completed",
        "complete": "completed",
        "ended": "completed",
        "unplugged": "disconnected",
        "plugged_idle": "connected_idle",
        "interrupted": "interrupted",
    }.get(phase, "unavailable")


def _elapsed(start: Any, end: float) -> float | None:
    try:
        value = float(start)
    except (TypeError, ValueError):
        return None
    return max(0.0, end - value) if value > 0 else None


def _persisted_completed_session(state: dict[str, Any]) -> dict[str, Any] | None:
    """Return a same-generation terminal record with internally consistent timing."""
    try:
        generation = int(state.get("charge_session_generation", 0) or 0)
    except (TypeError, ValueError):
        return None
    if generation <= 0:
        return None
    for row in history_mod.load_sessions():
        try:
            if int(row.get("generation", 0) or 0) != generation:
                continue
        except (TypeError, ValueError):
            continue
        if str(row.get("terminal_event") or "") != "complete":
            continue
        started = _location_timestamp(row.get("started_at_utc"))
        ended = _location_timestamp(row.get("ended_at_utc"))
        duration = observer.to_float_or_none(row.get("duration_seconds"))
        if started is None or ended is None or duration is None or duration < 0:
            continue
        measured_span = (ended - started).total_seconds()
        if measured_span < 0 or abs(measured_span - duration) > max(120, duration * 0.03):
            continue
        return row
    return None


def _connection_state(value: Any) -> str:
    """Return connected/disconnected only for explicit vehicle flag values."""
    if isinstance(value, bool):
        return "connected" if value else "disconnected"
    if isinstance(value, (int, float)) and value in (0, 1):
        return "connected" if value == 1 else "disconnected"
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return "connected"
        if normalized in {"0", "false", "no", "off"}:
            return "disconnected"
    return "unknown"


def _valid_location(status: dict[str, Any]) -> tuple[float, float] | None:
    return observer.vehicle_gps_coordinates(status)


def _location_recorded_at(status: dict[str, Any]) -> str | None:
    measurement = observer.timestamp_or_none(
        status.get("datetime_utc") or status.get("datetime_actual")
    )
    return (
        measurement.astimezone(timezone.utc).isoformat(timespec="seconds")
        if measurement is not None
        else None
    )


def _location_timestamp(value: Any) -> datetime | None:
    """Parse persisted ISO timestamps and Zero's compact UTC timestamps."""
    if value is None:
        return None
    parsed = observer.timestamp_or_none(value)
    if parsed is not None:
        return parsed
    try:
        text = str(value).strip().replace("Z", "+00:00")
        parsed = datetime.fromisoformat(text)
        return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


def _write_last_known_location(location: dict[str, Any]) -> None:
    _atomic_private_text(LOCATION_FILE, json.dumps(location, ensure_ascii=False) + "\n")


def location_payload(
    status: dict[str, Any], cfg: dict[str, Any], *, now_epoch: float | None = None
) -> dict[str, Any]:
    if now_epoch is None:
        now_epoch = time.time()
    point = _valid_location(status)
    source = "current"
    if point:
        latitude, longitude = point
        event_at = _location_recorded_at(status)
        with _LOCATION_LOCK:
            previous = read_json(LOCATION_FILE)
            previous_event = _location_timestamp(previous.get("event_at") or previous.get("recorded_at")) if isinstance(previous, dict) else None
            current_event = _location_timestamp(event_at)
            previous_point = _valid_location({**previous, "gps_valid": True}) if isinstance(previous, dict) else None
            if previous_point and previous_event and current_event and current_event < previous_event:
                record = previous
                point = previous_point
                source = "last_known"
                latitude, longitude = point
            elif previous_point and not current_event and previous_event:
                # An un-timestamped update cannot establish recency. Preserve
                # the timestamped point rather than replacing it ambiguously.
                record = previous
                point = previous_point
                source = "last_known"
                latitude, longitude = point
            else:
                received_at = datetime.fromtimestamp(now_epoch, timezone.utc).isoformat(timespec="seconds")
                record = {"latitude": latitude, "longitude": longitude, "recorded_at": event_at, "event_at": event_at, "received_at": received_at}
                odometer_km = observer.vehicle_odometer_km(status, cfg)
                odometer_raw = observer.to_float_or_none(status.get("mileage"))
                if odometer_km is not None:
                    record["odometer_km"] = round(odometer_km, 1)
                if odometer_raw is not None:
                    record["odometer_raw"] = odometer_raw
                same_event = previous_event and current_event and previous_event == current_event and previous_point == point
                if same_event and isinstance(previous, dict):
                    record["received_at"] = previous.get("received_at") or received_at
                    # A changed odometer with the same GPS event is movement
                    # evidence, so retain the snapshot from that GPS event.
                    # If only calibration changed, equal raw mileage permits
                    # a safe refresh of the derived snapshot.
                    if previous.get("odometer_raw") is not None and odometer_raw != previous.get("odometer_raw"):
                        record["odometer_km"] = previous.get("odometer_km")
                        record["odometer_raw"] = previous.get("odometer_raw")
                    elif record.get("odometer_km") is None and previous.get("odometer_km") is not None:
                        record["odometer_km"] = previous.get("odometer_km")
                try:
                    if not same_event or record.get("odometer_km") != previous.get("odometer_km"):
                        _write_last_known_location(record)
                except OSError:
                    pass
    else:
        record = read_json(LOCATION_FILE)
        point = _valid_location({**record, "gps_valid": True})
        source = "last_known"
        if not point:
            return {"available": False, "privacy": "local_only", "source": "none"}
        latitude, longitude = point
    recorded_at = str(record.get("recorded_at") or "") or None
    measurement = _location_timestamp(record.get("event_at") or recorded_at)
    age = max(0.0, now_epoch - measurement.timestamp()) if measurement else None
    max_age = float(cfg.get("freshness", {}).get("max_contact_age_seconds", 900))
    # Freshness is based on the GPS event timestamp. Vehicle contact time is
    # diagnostic context only and must not make an old coordinate look fresh.
    vehicle_time = observer.timestamp_or_none(
        status.get("datetime_actual") or status.get("datetime_utc")
    )
    vehicle_age = max(0.0, now_epoch - vehicle_time.timestamp()) if vehicle_time else None
    location_odometer = observer.to_float_or_none(record.get("odometer_km"))
    current_odometer = observer.vehicle_odometer_km(status, cfg)
    odometer_delta = (
        round(current_odometer - location_odometer, 1)
        if current_odometer is not None and location_odometer is not None
        else None
    )
    vehicle_current = vehicle_age is not None and vehicle_age <= max_age
    if age is not None and age <= max_age:
        freshness_state = "current"
    elif vehicle_current and (odometer_delta is None or odometer_delta <= 0.1):
        # A connected, stationary vehicle may legitimately have no new GPS
        # fix (for example in a garage or underground car park).
        freshness_state = "known"
    elif vehicle_current and odometer_delta is not None and odometer_delta > 0.1:
        freshness_state = "possibly_stale"
    elif age is None:
        freshness_state = "unknown"
    else:
        freshness_state = "stale"
    stale = freshness_state in {"possibly_stale", "stale"}
    return {
        "available": True,
        "latitude": latitude,
        "longitude": longitude,
        "recorded_at": recorded_at,
        "age_seconds": age,
        "stale": stale,
        "freshness_state": freshness_state,
        "odometer_delta_km": odometer_delta,
        "movement_evidence": "odometer_increased" if odometer_delta is not None and odometer_delta > 0.1 else "none",
        "vehicle_contact_age_seconds": vehicle_age,
        "privacy": "local_only",
        "source": source,
    }


COMPLETION_PRESENTATION_SECONDS = 60 * 60


def dashboard_payload(
    state: dict[str, Any], status: dict[str, Any], now_epoch: float,
    *, current_state: bool = False, freshness_limit: float = 900.0,
) -> dict[str, Any]:
    """Build the charge card.

    ``current_state`` asks for the app's current-vehicle presentation: a
    finished session is shown only briefly after its end and never as the
    permanent vehicle state.  Persisted sessions are never modified.
    """
    phase = str(state.get("charge_phase") or "unknown")
    presentation_state = dashboard_state(phase)
    persisted_session = _persisted_completed_session(state)
    soc = observer.to_float_or_none(status.get("soc"))
    target = observer.to_float_or_none(state.get("target_soc"))
    remaining = observer.rounded_charge_minutes(status)
    started = float(state.get("session_started_epoch", 0.0) or 0.0)
    if bool(state.get("session_start_uncertain", False)):
        started = 0.0
    target_reached = float(state.get("session_target_reached_epoch", 0.0) or 0.0)
    completed = float(
        state.get("session_completed_epoch", 0.0)
        or state.get("session_ended_epoch", 0.0)
        or 0.0
    )
    if phase == "unplugged" and (
        target_reached > 0
        or (bool(state.get("complete_notified", False)) and completed > 0)
    ):
        # Keep the last completed charge visible after the physical connection ends.
        presentation_state = "completed"
    plugged_started = float(
        (state.get("plugged_episode_started_epoch") if state.get("plugged_episode_active") else 0.0)
        or state.get("plugged_started_epoch", 0.0)
        or 0.0
    )
    connection_state = _connection_state(status.get("pluggedin"))
    target_reached_while_charging = (
        phase == "target_reached"
        and persisted_session is None
        and observer.to_bool(status.get("charging"))
    )
    if target_reached_while_charging:
        # Reaching the requested SoC is not a terminal witness while the
        # vehicle still directly reports active charging.
        presentation_state = "charging"
    result: dict[str, Any] = {
        "state": presentation_state,
        "soc": soc,
        "still_connected": connection_state == "connected",
        "connection_state": connection_state,
        "target_soc": None,
        "remaining_minutes": None,
        "elapsed_seconds": None,
        "connected_seconds": None,
        "since_completed_seconds": None,
        "started_at": None,
        "balancing_seconds": None,
        "completion_summary": None,
        "samples": [],
        "sample_rate": None,
        "finish_at": None,
        "milestones": [],
        "start_soc": None,
        "charge_target_soc": None,
        "charge_target_source": None,
    }
    known_target = target if target is not None and 0 < target <= 100 else None
    if presentation_state not in {"charging", "balancing"}:
        # Zero does not report its charge-target setting.  This is the SoC at
        # which the last charge stopped, so it is presented only as an
        # estimate, never as a reported setting.
        result["charge_target_soc"] = known_target
        result["charge_target_source"] = "inferred" if known_target is not None else None
    if result["still_connected"] and plugged_started > 0:
        result["connected_seconds"] = _elapsed(plugged_started, now_epoch)
    if presentation_state == "charging":
        result["target_soc"] = target
        result["remaining_minutes"] = remaining
        result["elapsed_seconds"] = _elapsed(started, now_epoch)
        result["started_at"] = epoch_iso(started)
        if started > 0:
            result["start_soc"] = observer.to_float_or_none(state.get("session_start_soc"))
        samples = observer.load_charging_samples(int(state.get("charge_session_generation", 0) or 0))
        result["samples"] = samples[-120:]
        result["sample_rate"] = charging_mod.smoothed_rate(samples, now_epoch=now_epoch)
        result["milestones"] = charging_mod.milestones(samples, target)
        result["target_reached"] = phase == "target_reached"
        if remaining is not None:
            result["finish_at"] = epoch_iso(now_epoch + max(0, float(remaining)) * 60)
    elif presentation_state == "balancing":
        result["target_soc"] = target or soc
        result["elapsed_seconds"] = _elapsed(started, now_epoch)
        result["started_at"] = epoch_iso(started)
        result["balancing_seconds"] = _elapsed(balancing_started, now_epoch)
    elif presentation_state == "completed":
        persisted_end = _location_timestamp(persisted_session.get("ended_at_utc")) if persisted_session else None
        end_epoch = (
            persisted_end.timestamp() if persisted_end is not None
            else target_reached or completed
        )
        start_soc = observer.to_float_or_none(persisted_session.get("start_soc")) if persisted_session else None
        end_samples = observer.load_charging_sample_rows(
            int(state.get("charge_session_generation", 0) or 0)
        )
        if persisted_session:
            end_soc = charging_mod.session_end_soc(
                persisted_session,
                charging_mod.session_samples_for_record(persisted_session, end_samples),
            )
        else:
            end_soc = charging_mod.observed_soc_at(end_samples, end_epoch)
        persisted_duration = observer.to_float_or_none(persisted_session.get("duration_seconds")) if persisted_session else None
        result["completion_summary"] = {
            "start_soc": start_soc if start_soc is not None else observer.to_float_or_none(state.get("session_start_soc")),
            "end_soc": end_soc,
            "duration_seconds": (
                persisted_duration if persisted_duration is not None
                else _elapsed(started, end_epoch) if end_epoch > 0 else None
            ),
            "balancing_seconds": None,
            "completed_at": epoch_iso(end_epoch) if end_epoch > 0 else None,
        }
        if result["still_connected"] and end_epoch > 0:
            result["since_completed_seconds"] = _elapsed(end_epoch, now_epoch)
        if current_state and _completion_superseded(
            status, now_epoch, end_epoch, end_soc, soc,
            _raw_mileage_at(end_samples, end_epoch), freshness_limit, connection_state,
        ):
            contact_current = _contact_is_current(status, now_epoch, freshness_limit)
            result["state"] = (
                "connected_idle" if contact_current and connection_state == "connected"
                else "disconnected" if contact_current and connection_state == "disconnected"
                else "idle"
            )
            result["completion_summary"] = None
            result["since_completed_seconds"] = None
    return result


def _contact_epoch(status: dict[str, Any]) -> float | None:
    contact = _location_timestamp(status.get("datetime_actual") or status.get("datetime_utc"))
    return contact.timestamp() if contact is not None else None


def _contact_is_current(status: dict[str, Any], now_epoch: float, limit: float) -> bool:
    contact = _contact_epoch(status)
    return contact is not None and 0 <= now_epoch - contact <= limit


def _completion_superseded(
    status: dict[str, Any], now_epoch: float, end_epoch: float,
    end_soc: float | None, soc: float | None, end_mileage: float | None,
    freshness_limit: float, connection_state: str = "unknown",
) -> bool:
    """Whether a finished session is no longer today's vehicle state.

    It expires 60 minutes after its end.  Earlier, only current vehicle data
    measured after the end counts as evidence of a ride: an advanced odometer,
    or a lower SoC while that same data explicitly reports the motorcycle
    unplugged.  A lower SoC while plugged in, or with an unknown plug state,
    proves nothing; neither do stale or pre-completion readings.
    """
    if end_epoch > 0 and now_epoch - end_epoch > COMPLETION_PRESENTATION_SECONDS:
        return True
    contact = _contact_epoch(status)
    if (
        end_epoch <= 0 or contact is None or contact <= end_epoch
        or not _contact_is_current(status, now_epoch, freshness_limit)
    ):
        return False
    if (
        connection_state == "disconnected"
        and end_soc is not None and soc is not None and soc < end_soc
    ):
        return True
    mileage = observer.to_float_or_none(status.get("mileage"))
    return (
        end_mileage is not None and mileage is not None
        and (mileage - end_mileage) * observer.MILES_TO_KM > 0.1
    )


def _raw_mileage_at(samples: list[dict[str, Any]], end_epoch: float) -> float | None:
    """Return Zero's raw mileage from the latest sample at or before an end."""
    best: tuple[float, float] | None = None
    for sample in samples:
        value = observer.to_float_or_none(sample.get("odometer"))
        stamp = _location_timestamp(sample.get("contact_time") or sample.get("timestamp"))
        if value is None or value < 0 or stamp is None or stamp.timestamp() > end_epoch:
            continue
        if best is None or stamp.timestamp() >= best[0]:
            best = (stamp.timestamp(), value)
    return best[1] if best else None


def _rounded_coordinate(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return round(number, 2)


AUX_VOLTAGE_PLAUSIBLE = (5.0, 20.0)   # a 12 V system; anything else is a glitch, not a reading
AUX_VOLTAGE_LOW = 12.0                # below this a 12 V battery is clearly weak, even while the vehicle charges it
AUX_DAYS = 14


def _aux_voltage(value: Any) -> float | None:
    number = observer.to_float_or_none(value)
    if number is None or not math.isfinite(number) or not AUX_VOLTAGE_PLAUSIBLE[0] <= number <= AUX_VOLTAGE_PLAUSIBLE[1]:
        return None
    return round(number, 2)


_AUX_CACHE: dict[str, Any] = {}


def aux_battery_payload(status: dict[str, Any] | None, now_epoch: float) -> dict[str, Any] | None:
    """The 12 V battery as the vehicle reports it (``main_voltage``): the latest value, the last week's range and
    a daily series. Nothing is estimated; without a plausible reading there is no card."""
    voltage = _aux_voltage((status or {}).get("main_voltage"))
    if voltage is None:
        return None
    try:
        stat = observer.RAW_HISTORY_FILE.stat()
        key = (stat.st_mtime_ns, stat.st_size, int(now_epoch // 3600))
    except OSError:
        key = None
    if key is None or _AUX_CACHE.get("key") != key:
        today = int(now_epoch // 86400)
        per_day: dict[int, list[float]] = {}
        for row in trips.read_raw_history(observer.RAW_HISTORY_FILE):
            epoch = trips._epoch(row)
            reading = _aux_voltage(row.get("main_voltage"))
            if epoch is None or reading is None:
                continue
            day = int(epoch // 86400)
            if 0 <= today - day < AUX_DAYS:
                per_day.setdefault(day, []).append(reading)
        week = [value for day, values in per_day.items() if today - day < 7 for value in values]
        series = []
        for offset in range(AUX_DAYS - 1, -1, -1):
            values = sorted(per_day.get(today - offset, []))
            series.append(values[len(values) // 2] if values else None)
        _AUX_CACHE.update(key=key, week=(min(week), max(week)) if week else None, series=series)
    low, high = _AUX_CACHE.get("week") or (voltage, voltage)
    return {"voltage": voltage, "min_7d": min(low, voltage), "max_7d": max(high, voltage), "series": list(_AUX_CACHE.get("series") or []),
            "low": voltage < AUX_VOLTAGE_LOW}


def status_payload() -> dict[str, Any]:
    try:
        cfg = observer.load_config()
    except RuntimeError:
        cfg = copy.deepcopy(observer.DEFAULT_CONFIG)
    state = read_state()
    status = read_json(VALID_FILE) or read_json(RAW_FILE)
    env = setup.load_existing_env()
    setup_info = setup.setup_status(env, cfg)
    soc = observer.to_float_or_none(status.get("soc")) if status else None
    mileage = observer.vehicle_odometer_km(status, cfg) if status else None
    raw_mileage = observer.to_float_or_none(status.get("mileage")) if status else None
    phase = str(state.get("charge_phase") or "unknown")
    target = observer.to_float_or_none(state.get("target_soc"))
    aivi_cfg = cfg.get("aivi", {})
    abrp_cfg = cfg.get("abrp", {})
    connections = connection_statuses(cfg, env, state)
    now_epoch = time.time()
    web_activity = read_json(WEB_ACTIVITY_FILE)
    try:
        last_web_activity_epoch = float(web_activity.get("last_activity_epoch", 0.0) or 0.0)
    except (TypeError, ValueError):
        last_web_activity_epoch = 0.0
    observer_active = service_active(OBSERVER_SERVICE)
    web_active = service_active(WEB_SERVICE)
    freshness_limit = float(cfg.get("freshness", {}).get("max_contact_age_seconds", 900))
    dashboard = dashboard_payload(
        state, status, now_epoch, current_state=True, freshness_limit=freshness_limit,
    )
    location = location_payload(status, cfg, now_epoch=now_epoch)
    abrp_evidence = read_json(observer.ABRP_DIAGNOSTIC_FILE)
    # Diagnostics are deliberately coarse and credential-free.  They let an
    # operator correlate the last accepted ABRP request with the map pipeline
    # without exposing the token or retaining a precise coordinate in reports.
    coordinate_hash = str(abrp_evidence.get("coordinate_hash") or "")
    if not coordinate_hash:
        try:
            if abrp_evidence.get("lat") is not None and abrp_evidence.get("lon") is not None:
                coordinate_hash = observer._coordinate_hash(float(abrp_evidence["lat"]), float(abrp_evidence["lon"]))
        except (TypeError, ValueError):
            coordinate_hash = ""
    abrp_location_evidence = {
        "sent_at_utc": str(abrp_evidence.get("sent_at_utc") or ""),
        "source": str(abrp_evidence.get("source") or ""),
        "lat": _rounded_coordinate(abrp_evidence.get("lat_rounded", abrp_evidence.get("lat"))),
        "lon": _rounded_coordinate(abrp_evidence.get("lon_rounded", abrp_evidence.get("lon"))),
        "coordinate_hash": coordinate_hash,
        "utc": abrp_evidence.get("utc"),
    }
    contact_measurement = observer.timestamp_or_none(status.get("datetime_actual") or status.get("datetime_utc")) if status else None
    contact_age = max(0.0, now_epoch - contact_measurement.timestamp()) if contact_measurement else None
    vehicle_data_state = "missing" if contact_age is None else "current" if contact_age <= freshness_limit else "stale"
    if vehicle_data_state != "current":
        dashboard["still_connected"] = False
        dashboard["connection_state"] = "unknown"
        dashboard["connected_seconds"] = None
        dashboard["since_completed_seconds"] = None
    else:
        location_id = str(state.get("session_location_id") or "")
        place = next((row for row in functional.locations() if str(row.get("id")) == location_id), None)
        rule = place.get("time_limit") if isinstance(place, dict) else None
        if isinstance(rule, dict) and bool(rule.get("enabled")) and dashboard.get("connected_seconds") is not None:
            try:
                limit_minutes = int(rule.get("limit_minutes", 0))
                reminder_minutes = int(rule.get("reminder_minutes", 0))
                remaining = limit_minutes - float(dashboard["connected_seconds"]) / 60
                if limit_minutes >= 60 and reminder_minutes >= 0 and reminder_minutes < limit_minutes:
                    dashboard["time_limit_minutes"] = limit_minutes
                    dashboard["time_limit_remaining_minutes"] = max(0, int(remaining))
                    dashboard["time_limit_state"] = "reached" if remaining <= 0 else "soon" if reminder_minutes > 0 and remaining <= reminder_minutes else "normal"
            except (TypeError, ValueError):
                pass
    # Battery care: the observer measured from real contacts how long the bike has
    # stood almost full or almost empty; shown only while the level still says so.
    care_band = str(state.get("battery_care_band") or "")
    try:
        care_span = float(state.get("battery_care_last_contact_epoch") or 0.0) - float(state.get("battery_care_since_epoch") or 0.0)
    except (TypeError, ValueError):
        care_span = 0.0
    if (care_band and float(state.get("battery_care_since_epoch") or 0.0) > 0
            and care_span >= observer.BATTERY_CARE_DAYS * 86400
            and observer.battery_care_band(observer.to_float_or_none(dashboard.get("soc"))) == care_band):
        dashboard["battery_care"] = {"band": care_band, "days": int(care_span // 86400)}
    # Range from the measured consumption between charges; an estimate, labelled as one.
    dashboard["range"] = trips.range_km(observer.to_float_or_none(dashboard.get("soc")), trips_data()["consumption"])
    vehicle_freshness = vehicle.freshness(contact_age, freshness_limit)
    maintenance_rows = functional.maintenance_status(mileage)
    maintenance_states = [str(row.get("status") or "unknown") for row in maintenance_rows]
    if any(value in {"overdue", "due"} for value in maintenance_states):
        maintenance_state = "due"
    else:
        maintenance_state = "normal"
    context = vehicle.daily_driver_context({
        "vehicle_state": vehicle_data_state,
        "charge_state": dashboard.get("state"),
        "plugged": bool(observer.to_bool(status.get("pluggedin"))) if status else False,
        "still_connected": bool(dashboard.get("still_connected")),
        "time_limit_state": dashboard.get("time_limit_state", "normal"),
        "maintenance_state": maintenance_state,
        "location_stale": bool(location.get("stale", False)),
        "minutes_until_limit": dashboard.get("time_limit_remaining_minutes"),
        "maintenance_remaining_km": min(
            (row["distance_remaining"] for row in maintenance_rows if isinstance(row.get("distance_remaining"), (int, float))),
            default=None,
        ),
    })
    issue_codes = health_issue_codes(observer_active, state, connections)
    try:
        revision = REVISION_FILE.read_text(encoding="utf-8").strip() or "unknown"
    except OSError:
        revision = "unknown"
    return {
        "version": PUBLIC_VERSION,
        "internal_version": INTERNAL_VERSION,
        "revision": revision,
        "vehicle_label": str(cfg.get("vehicle_label", "Zero Motorcycle")),
        "aux_battery": aux_battery_payload(status, now_epoch),
        "vehicle_firmware": str((status or {}).get("software_version") or "") or None,
        "vehicle_model": str(
            cfg.get("vehicle_model") or cfg.get("vehicle_label") or "Zero Motorcycle"
        ),
        "vehicle_color": str(cfg.get("vehicle_color") or ""),
        "vehicle_custom_photo": vehicle_photos.version_for(vehicle_photos.CUSTOM_NAME) or "",
        "observer_active": observer_active,
        "web_active": web_active,
        "free_storage_gib": round(shutil.disk_usage(PROJECT_DIR).free / (1024 ** 3), 1),
        "soc": soc,
        "mileage_km_cloud": round(mileage, 1) if mileage is not None else None,
        "odometer": {
            "value_km": round(mileage, 1) if mileage is not None else None,
            "raw_value": raw_mileage,
            "source_field": "mileage",
            "observed_at": zero_time_iso(status.get("datetime_utc")) if status else None,
        },
        "charge_phase": phase,
        "target_soc": target,
        "confidence": str(state.get("charge_state_confidence") or ""),
        "completion_source": str(state.get("charge_completion_source") or ""),
        "last_poll": epoch_iso(state.get("last_poll_success_epoch")),
        "last_vehicle_contact": zero_time_iso(status.get("datetime_actual") or status.get("datetime_utc")) if status else None,
        "last_vehicle_measurement": zero_time_iso(status.get("datetime_utc")) if status else None,
        "vehicle_data": {
            "state": vehicle_data_state,
            "age_seconds": contact_age,
            "connectivity": vehicle_freshness["state"],
            "quality": vehicle_freshness["quality"],
        },
        "session_generation": int(state.get("charge_session_generation", 0) or 0),
        "session_active": bool(state.get("session_active", False)),
        "session_start_soc": observer.to_float_or_none(state.get("session_start_soc")),
        "session_balancing_started": epoch_iso(state.get("session_balancing_started_epoch")),
        "live_activity_active": bool(state.get("live_activity_active", False)),
        "last_web_client_activity_epoch": last_web_activity_epoch or None,
        "web_client_recently_active": bool(last_web_activity_epoch and now_epoch - last_web_activity_epoch < WEB_ACTIVITY_IDLE_SECONDS),
        "web_heartbeat_supported": True,
        "shutdown_zero_pulse": bool(state.get("shutdown_zero_pulse_observed", False)),
        "aivi": {
            "enabled": bool(aivi_cfg.get("enabled", False)),
            "mode": str(aivi_cfg.get("mode", "legacy")),
            "progress_slug": str(aivi_cfg.get("activity_slug", "")),
            "balancing_slug": str(aivi_cfg.get("balancing_activity_slug", "")),
            "complete_slug": str(aivi_cfg.get("complete_activity_slug", "")),
            "last_success": epoch_iso(state.get("last_live_activity_success_epoch")),
            "last_error": str(state.get("last_live_activity_error") or ""),
            "active_kind": str(state.get("three_phase_active_kind") or ""),
            "runtime_state": (
                "active" if bool(state.get("live_activity_active", False)) and bool(state.get("session_active", False))
                else "recovering" if bool(state.get("session_active", False)) and not bool(state.get("live_activity_active", False))
                else "error" if str(state.get("last_live_activity_error") or "") else "idle"
            ),
        },
        "abrp": {
            "enabled": bool(abrp_cfg.get("enabled", False)),
            "last_success": epoch_iso(state.get("last_abrp_success_epoch")),
            "last_error": str(state.get("last_abrp_error") or ""),
            "last_location_evidence": abrp_location_evidence,
        },
        "connections": connections,
        "dashboard": dashboard,
        "context": context,
        "location": location,
        "functional": {
            "locations": functional_locations(),
            "maintenance": maintenance_rows,
            "push": functional.push_status(),
            "events": functional.notification_events(20),
        },
        "system_health": {
            "status": "attention" if issue_codes else "ok",
            "issue_codes": issue_codes,
            "connections": connections,
        },
        "setup": setup_info,
        "first_run": bool(setup_info["first_run"]),
    }


def masked_email(value: str) -> str:
    if "@" not in value:
        return "gesetzt" if value else ""
    local, domain = value.split("@", 1)
    shown = (local[:2] + "…") if len(local) > 2 else "…"
    return f"{shown}@{domain}"


def config_payload() -> dict[str, Any]:
    cfg = observer.load_config()
    env = setup.load_existing_env()
    state = read_state()
    connections = connection_statuses(cfg, env, state)
    setup_info = setup.setup_status(env, cfg)
    return {
        "vehicle": {
            "label": str(cfg.get("vehicle_label", "Zero Motorcycle")),
            "model": str(cfg.get("vehicle_model", "Zero Motorcycle")),
            "supported_models": list(SUPPORTED_VEHICLE_MODELS),
            "color": str(cfg.get("vehicle_color") or ""),
            "supported_colors": {model: list(colors) for model, colors in setup.VEHICLE_COLORS.items()},
            "account": masked_email(env.get("ZERO_CLOUD_USER", "")),
            "credentials_set": bool(env.get("ZERO_CLOUD_USER") and env.get("ZERO_CLOUD_PASSWORD")),
            "vehicle_selected": bool(env.get("ZERO_UNIT_NUMBER")),
        },
        "aivi": {
            "enabled": bool(cfg.get("aivi", {}).get("enabled", False)),
            "language": str(cfg.get("aivi", {}).get("language", "de")),
            "mode": "single_progress",
            "progress_slug": str(cfg.get("aivi", {}).get("activity_slug", "")),
            "token_set": bool(env.get("AIVI_API_TOKEN")),
        },
        "abrp": {
            "enabled": bool(cfg.get("abrp", {}).get("enabled", False)),
            "credentials_set": bool(env.get("ABRP_TOKEN") and env.get("ABRP_API_KEY")),
        },
        "connections": connections,
        "diagnostics": {
            "retention_days": int(cfg.get("diagnostics", {}).get("retention_days", 180)),
            "export_default_days": int(cfg.get("diagnostics", {}).get("export_default_days", 7)),
            "max_size_mib": int(cfg.get("diagnostics", {}).get("max_size_mib", 2048)),
        },
        "advanced": {
            "charging_seconds": int(cfg.get("polling", {}).get("charging_seconds", 30)),
            "recent_seconds": int(cfg.get("polling", {}).get("recent_seconds", 30)),
            "idle_seconds": int(cfg.get("polling", {}).get("idle_seconds", 30)),
            "max_contact_age_seconds": int(cfg.get("freshness", {}).get("max_contact_age_seconds", 900)),
        },
        "web": {
            "host": str(cfg.get("web", {}).get("host", "0.0.0.0")),
            "port": int(cfg.get("web", {}).get("port", 8080)),
        },
        "setup": setup_info,
    }


def current_maintenance_odometer() -> float | None:
    """Return the canonical odometer used by Observer maintenance reminders."""
    try:
        cfg = observer.load_config()
    except RuntimeError:
        cfg = copy.deepcopy(observer.DEFAULT_CONFIG)
    status = read_json(VALID_FILE) or read_json(RAW_FILE)
    return observer.vehicle_odometer_km(status, cfg) if status else None


def complete_maintenance_from_current_odometer(ident: str) -> dict[str, Any]:
    """Complete a maintenance item using the canonical vehicle odometer."""
    return functional.complete_maintenance(ident, current_maintenance_odometer())


def setup_payload() -> dict[str, Any]:
    cfg = observer.load_config()
    payload = setup.setup_status(setup.load_existing_env(), cfg)
    try:
        payload["wifi"] = WifiSetupManager().plan_hotspot(first_run=bool(payload["first_run"]))
        hostname = socket.gethostname().strip()
        if not re.fullmatch(r"[A-Za-z0-9-]{1,63}", hostname): hostname = "zero-pi"
        payload["wifi"]["continue_url"] = f"http://{hostname}.local:8080/"
    except Exception:
        payload["wifi"] = {
            "hotspot_recommended": False,
            "hardware_validation_required": True,
        }
    return payload


_HISTORY_CACHE: dict[tuple[str, bool], tuple[tuple[Any, ...], list[dict[str, Any]]]] = {}


def _history_inputs() -> tuple[Any, ...] | None:
    """Name, mtime and size of every file the history is derived from.

    The readers themselves are part of the key (compared by identity), so a
    replaced reader, as in tests, is never answered from the cache.
    """
    parts: list[Any] = [history_mod.load_sessions, observer.load_charging_sample_rows_for_generations,
                        observer.load_charging_sample_rows, functional.locations, functional.session_removals,
                        functional.deleted_location_label, charging_mod.session_samples_for_record, charging_mod.session_end_soc]
    for folder in (history_mod.SESSION_DIR, observer.CHARGING_SAMPLE_DIR, functional.FEATURES):
        try:
            entries = sorted(os.scandir(folder), key=lambda entry: entry.name)
        except OSError:
            parts.append((str(folder), None))
            continue
        for entry in entries:
            if entry.name.startswith(".") or entry.name in {"events.json", "subscriptions.json"}:
                continue
            try:
                stat = entry.stat()
            except OSError:
                continue
            if time.time() - stat.st_mtime <= 2.0:
                return None  # changed just now; the coarse file time could hide a second change
            parts.append((entry.path, stat.st_ino, stat.st_mtime_ns, stat.st_size))
    return tuple(parts)


def history_payload(limit: int = 20, language: str = "de", *, include_removed: bool = False, shared: bool = False) -> list[dict[str, Any]]:
    """The charging history; recomputed only when one of its files changed.

    The dashboard asks for it every 30 s (charging places, statistics). With a year
    of sessions a full recomputation takes about a second on a Raspberry Pi 3.
    """
    key = (language, include_removed)
    inputs = _history_inputs()
    cached = _HISTORY_CACHE.get(key)
    if inputs is None or cached is None or cached[0] != inputs:
        cached = (inputs, _compute_history(language, include_removed))
        _HISTORY_CACHE[key] = cached
    # Read-only callers (shared=True) skip the copy; everything handed out further gets its own.
    return cached[1][:limit] if shared else copy.deepcopy(cached[1][:limit])


def _compute_history(language: str, include_removed: bool) -> list[dict[str, Any]]:
    try:
        rows = history_mod.load_sessions(include_removed=include_removed)
    except Exception:
        return []
    # The reader already orders canonical ISO timestamps, including repaired
    # and legacy sessions without an ended_epoch field.
    keep = (
        "generation", "started_at_utc", "ended_at_utc", "duration_seconds",
        "start_soc", "end_soc", "target_soc", "terminal_event", "completion_source",
        "balancing_duration_seconds", "shutdown_zero_pulse", "shutdown_zero_pulse_at_utc",
        "energy_added_kwh", "average_power_kw", "peak_power_kw", "data_quality", "location_id", "location_name",
    )
    places = {str(row.get("id")): row for row in functional.locations()}
    result = []
    generations = {int(row.get("generation", 0) or 0) for row in rows}
    samples_by_generation = observer.load_charging_sample_rows_for_generations(generations)
    for row in rows:
        item = {key: row.get(key) for key in keep}
        item["terminal_label"] = {
            "complete": "Complete" if language == "en" else "Vollständig",
            "ended": "Ended" if language == "en" else "Beendet",
            "interrupted": "Interrupted" if language == "en" else "Unterbrochen",
        }.get(str(row.get("terminal_event") or ""), "Unknown" if language == "en" else "Unbekannt")
        # Legacy values were inferred from target/end timestamps, not an
        # independently observed balancing signal.
        item["balancing_duration_seconds"] = None
        generation = int(row.get("generation", 0) or 0)
        samples = charging_mod.session_samples_for_record(
            row, samples_by_generation.get(generation, [])
        )
        item["end_soc"] = charging_mod.session_end_soc(row, samples)
        start = observer.to_float_or_none(row.get("start_soc")); end = item["end_soc"]
        item.update({
            "delta_soc": round(end - start, 1) if start is not None and end is not None and end >= start else None,
            "average_soc_points_per_hour": charging_mod.session_average_rate(row, samples),
            "sample_count": len(samples),
            "segments": charging_mod.segments(samples),
            "milestones": charging_mod.milestones(samples, row.get("target_soc")),
        })
        item.update(charging_mod.duration_semantics(row, samples))
        place = places.get(str(item.get("location_id") or ""))
        if place:
            item["location_name"] = functional.charging_location_display_name(place, language)
            item["location_display_name"] = functional.charging_location_display_name(place, language)
        elif item.get("location_id"):
            deleted_label = functional.deleted_location_label(str(item["location_id"]), language)
            if deleted_label:
                item["location_name"] = deleted_label
                item["location_display_name"] = deleted_label
        result.append(item)
    return result


TRIPS_FILE = DATA_DIR / "trips.json"


def trips_data() -> dict[str, Any]:
    """Rides and consumption from the raw vehicle reports (cached until the raw history changes)."""
    try:
        offset = float((observer.load_config().get("odometer") or {}).get("offset_km") or 0.0)
    except (TypeError, ValueError, OSError):
        offset = 0.0
    try:
        return trips.load(observer.RAW_HISTORY_FILE, TRIPS_FILE, offset_km=offset)
    except Exception:  # rides are an extra; they must never break the status page
        return {"rides": [], "stretches": [], "consumption": None}


def trips_payload(limit: int = 300) -> dict[str, Any]:
    data = trips_data()
    rides = data["rides"]
    return {"ok": True, "rides": [trips.without_points(ride) for ride in rides[:limit]],
            "months": trips.months(rides, data["stretches"]), "consumption": data["consumption"]}


def filtered_history(query: dict[str, Any] | None = None, language: str = "de") -> list[dict[str, Any]]:
    return functional.filter_sessions(history_payload(limit=1000, language=language), query or {})


def functional_locations(language: str = "de") -> list[dict[str, Any]]:
    rows = history_payload(limit=1000, language=language, shared=True)
    places = functional.locations()
    labels: dict[str, int] = {}
    for place in places:
        label = functional.location_auto_label(place, language)
        if label and not functional._legacy_custom_name(place):
            labels[label.casefold()] = labels.get(label.casefold(), 0) + 1
    result = []
    for index, place in enumerate(places, start=1):
        linked = [r for r in rows if r.get("location_id") == place.get("id")]
        qualified_soc = []
        qualified_durations = []
        for row in linked:
            try:
                start, end = float(row.get("start_soc")), float(row.get("end_soc"))
                if math.isfinite(start) and math.isfinite(end) and 0 <= start <= end <= 100 and end > 0:
                    qualified_soc.append((start, end))
            except (TypeError, ValueError, OverflowError):
                pass
            try:
                duration = float(row.get("duration_seconds"))
                if math.isfinite(duration) and duration > 0:
                    qualified_durations.append(duration)
            except (TypeError, ValueError, OverflowError):
                pass
        summary_sessions = len(qualified_soc)
        duration_sessions = len(qualified_durations)
        automatic = functional.location_auto_label(place, language)
        display = functional.charging_location_display_name(place, language)
        if automatic and labels.get(automatic.casefold(), 0) > 1 and not functional._legacy_custom_name(place):
            details = functional.location_auto_place(place, language)
            detail = next((candidate.strip() for candidate in (details.get("road"), details.get("suburb"))
                           if isinstance(candidate, str) and candidate.strip()
                           and not candidate.strip().isdigit()
                           and candidate.strip().casefold() not in automatic.casefold()), None)
            display = f"{automatic} · {detail}" if detail else f"{automatic} · {str(place.get('name') or f'Ladeort {index}') }"
        result.append({
            **place,
            "custom_name": functional._legacy_custom_name(place),
            "display_name": display,
            "auto_location_label": automatic or None,
            "auto_location_language": language if automatic else None,
            "auto_location_label_expired": functional.location_auto_label_expired(place, language),
            "auto_location_place": functional.location_auto_place(place, language),
            "sessions": len(linked),
            "total_duration_seconds": sum(int(duration) for duration in qualified_durations),
            "average_session_duration_seconds": round(sum(qualified_durations) / duration_sessions) if duration_sessions else None,
            "duration_summary_sessions": duration_sessions,
            "last_used": linked[0].get("ended_at_utc") if linked else None,
            "soc_summary_sessions": summary_sessions,
            "average_start_soc": round(sum(start for start, _ in qualified_soc) / summary_sessions, 1) if summary_sessions else None,
            "average_end_soc": round(sum(end for _, end in qualified_soc) / summary_sessions, 1) if summary_sessions else None,
        })
    return result


def resolve_next_location_label(
    places: list[dict[str, Any]], language: str, skip_ids: set[str]
) -> dict[str, Any]:
    """Queue at most one missing charging-location label per API pass."""
    candidate = next((row for row in places
                      if str(row.get("id") or "") not in skip_ids
                      and (not functional.location_auto_label(row, language)
                           or functional.location_auto_label_expired(row, language))), None)
    if candidate is None:
        return {"pending": False, "updated": False, "attempted_id": None, "more": False}
    location_id = str(candidate.get("id") or "")
    try:
        latitude, longitude = float(candidate["latitude"]), float(candidate["longitude"])
    except (KeyError, TypeError, ValueError):
        excluded = set(skip_ids) | {location_id}
        more = any(str(row.get("id") or "") not in excluded
                   and (not functional.location_auto_label(row, language)
                        or functional.location_auto_label_expired(row, language))
                   for row in places)
        return {"pending": False, "updated": False, "attempted_id": location_id or None, "more": more}
    outcome = functional.request_place_label(latitude, longitude, language=language,
                                             location_id=location_id)
    pending = outcome.get("state") == "pending"
    updated = outcome.get("state") == "ready"
    attempted_id = location_id if outcome.get("state") == "unavailable" else None
    excluded = set(skip_ids)
    if attempted_id:
        excluded.add(attempted_id)
    elif updated:
        excluded.add(location_id)
    more = pending or any(
        str(row.get("id") or "") not in excluded
        and (not functional.location_auto_label(row, language)
             or functional.location_auto_label_expired(row, language))
        for row in places
    )
    return {"pending": pending, "updated": updated, "attempted_id": attempted_id, "more": more}


_ANALYTICS_ROWS: list[Any] = [None, []]


def analytics_payload() -> dict[str, Any]:
    inputs = _history_inputs()
    if inputs is None or _ANALYTICS_ROWS[0] != inputs:
        _ANALYTICS_ROWS[:] = [inputs, _analytics_rows()]
    rows = copy.deepcopy(_ANALYTICS_ROWS[1])
    return _analytics_from_rows(rows)


def _analytics_rows() -> list[dict[str, Any]]:
    try:
        stored_rows = history_mod.load_sessions()
        generations = {int(row.get("generation", 0) or 0) for row in stored_rows}
        samples_by_generation = observer.load_charging_sample_rows_for_generations(generations)
        rows = []
        for row in stored_rows:
            generation = int(row.get("generation", 0) or 0)
            samples = charging_mod.session_samples_for_record(
                row, samples_by_generation.get(generation, [])
            )
            rows.append({
                **row,
                "end_soc": charging_mod.session_end_soc(row, samples),
            })
    except Exception:
        rows = []
    return rows


def _analytics_from_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    result = vehicle.analytics(rows, time.time())
    result["monthly"] = charging_mod.monthly(rows)
    targets = [observer.to_float_or_none(r.get("target_soc")) for r in rows]
    targets = [int(round(v)) for v in targets if v is not None and 0 <= v <= 100]
    qualified = [r for r in rows if observer.to_float_or_none(r.get("start_soc")) is not None and observer.to_float_or_none(r.get("end_soc")) is not None]
    full = [r for r in qualified if observer.to_float_or_none(r.get("end_soc")) == 100]
    result["target_statistics"] = {str(k): targets.count(k) for k in sorted(set(targets))}
    result["full_statistics"] = {"sessions": len(full), "qualified_sessions": len(qualified), "share": round(len(full) / len(qualified), 3) if qualified else None}
    result["habits"] = charging_habits(rows)
    result["odometer"] = odometer_analytics(rows)
    return result


def odometer_analytics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    ordered = sorted(rows, key=lambda r: str(r.get("ended_at_utc", "")))
    distances: list[float] = []
    previous: float | None = None
    for row in ordered:
        value = observer.to_float_or_none(row.get("end_odometer") or row.get("odometer_end"))
        if value is None: continue
        if previous is not None and value >= previous: distances.append(round(value - previous, 1))
        previous = value
    total = sum(distances)
    return {"distances_km": distances, "average_km": round(total / len(distances), 1) if distances else None, "charges_per_1000_km": round(len(distances) / (total / 1000), 2) if total > 0 else None}


def charging_habits(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if len(rows) < 3:
        return {"available": False, "reason": "mindestens drei Sessions erforderlich"}
    times = []
    weekdays: dict[str, int] = {}
    buckets = {"morgens": 0, "mittags": 0, "abends": 0, "nachts": 0}
    for row in rows:
        stamp = history_mod.parse_time(row.get("started_at_utc"))
        if stamp is None: continue
        local = stamp.astimezone(); hour = local.hour; times.append(hour)
        weekdays[local.strftime("%A")] = weekdays.get(local.strftime("%A"), 0) + 1
        buckets["morgens" if 6 <= hour < 11 else "mittags" if 11 <= hour < 17 else "abends" if 17 <= hour < 23 else "nachts"] += 1
    return {"available": bool(times), "most_common_hour": round(sum(times) / len(times)) if times else None, "most_common_period": max(buckets, key=buckets.get) if times else None, "weekday_counts": weekdays}


def session_detail_payload(generation: int, language: str = "de") -> dict[str, Any] | None:
    if generation in functional.session_removals():
        return None
    rows = [r for r in history_mod.load_sessions() if int(r.get("generation", 0) or 0) == generation]
    if not rows: return None
    row = rows[0]
    samples = charging_mod.session_samples_for_record(
        row, observer.load_charging_sample_rows(generation)
    )
    item = next((r for r in history_payload(limit=1000, language=language) if r.get("generation") == generation), {})
    projected_record = {**row, "end_soc": item.get("end_soc")}
    return {"session": item, "samples": samples, "segments": charging_mod.segments(samples), "timeline": charging_mod.milestones(samples, row.get("target_soc")), "quality_issues": charging_mod.validate_session(projected_record, samples)}


def removed_session_payload(language: str = "de") -> list[dict[str, Any]]:
    removed = set(functional.session_removals())
    return [row for row in history_payload(limit=1000, language=language, include_removed=True)
            if int(row.get("generation", 0) or 0) in removed]


def update_session_history(generation: int, *, removed: bool) -> bool:
    """Safely hide or restore one uniquely identified completed session."""
    if generation <= 0:
        raise SessionHistoryError("Diese ältere Sitzung kann nicht eindeutig zugeordnet werden.")
    raw_rows = [row for row in history_mod.load_sessions(include_removed=True)
                if int(row.get("generation", 0) or 0) == generation]
    if not raw_rows:
        raise SessionHistoryError("Session nicht gefunden.", HTTPStatus.NOT_FOUND)
    row = raw_rows[0]
    terminal = str(row.get("terminal_event") or "")
    if (terminal not in {"complete", "ended", "interrupted"}
            or not row.get("ended_at_utc")):
        raise SessionHistoryError("Nur abgeschlossene Ladesitzungen können aus dem Verlauf entfernt werden.")
    with observer.runtime_state_lock():
        state = read_state()
        active_now = (
            bool(state.get("session_active")) or bool(state.get("plugged_episode_active"))
            or str(state.get("charge_phase") or "") in {"charging", "target_reached"}
        )
        try:
            state_generation = int(state.get("charge_session_generation", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            state_generation = 0
        if active_now and state_generation <= 0:
            raise SessionHistoryError("Aktiver Ladezustand ohne eindeutige Generation; Änderung wurde angehalten.")
        if active_now and state_generation == generation:
            raise SessionHistoryError("Diese Ladesitzung ist noch aktiv und kann nicht entfernt werden.")
        return functional.set_session_removed(generation, removed)


@serialized_web_mutation
def restart_observer(
    *,
    reset_aivi: bool = False,
    reset_abrp: bool = False,
    preserve_legacy_aivi_handoff: bool = False,
) -> tuple[bool, str]:
    def run_action(action: str) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                PATHS.service_command(action, OBSERVER_SERVICE),
                capture_output=True,
                text=True,
                check=False,
                timeout=30,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return False, str(exc)
        return result.returncode == 0, result.stderr.strip()

    reset_error: Exception | None = None
    if reset_aivi or reset_abrp:
        stopped, detail = run_action("stop")
        if not stopped:
            return False, detail or "Observer konnte vor dem Runtime-Reset nicht gestoppt werden."
        try:
            reset_kwargs = {"aivi": reset_aivi, "abrp": reset_abrp}
            if preserve_legacy_aivi_handoff:
                reset_kwargs["preserve_legacy_aivi_handoff"] = True
            setup.reset_integration_runtime_state(**reset_kwargs)
        except Exception as exc:
            reset_error = exc
        started, detail = run_action("start")
    else:
        started, detail = run_action("restart")
    if not started:
        # The web service is deliberately unprivileged and cannot restart a
        # system unit. During first-run completion the observer is already
        # active in its credential-wait loop and now notices the atomically
        # persisted credentials; treat that bounded handoff as success.
        if not (reset_aivi or reset_abrp):
            try:
                if service_active(OBSERVER_SERVICE) and setup.is_first_run(setup.load_existing_env(), setup.load_config()):
                    return True, "Observer läuft und übernimmt die neue Ersteinrichtung."
            except (RuntimeError, OSError, ValueError):
                pass
        return False, detail or "Observer konnte nicht neu gestartet werden."
    try:
        active = service_active(OBSERVER_SERVICE)
    except RuntimeError as exc:
        return False, str(exc)
    if not active:
        return False, "Observer wurde gestartet, ist aber nicht aktiv."
    if reset_error is not None:
        return (
            False,
            f"Runtime-Reset fehlgeschlagen: {reset_error} "
            "Observer wurde kontrolliert wieder gestartet.",
        )
    return True, "Observer neu gestartet."


def require_observer_restart(
    *,
    reset_aivi: bool = False,
    reset_abrp: bool = False,
    preserve_legacy_aivi_handoff: bool = False,
) -> None:
    ok, message = restart_observer(
        reset_aivi=reset_aivi,
        reset_abrp=reset_abrp,
        preserve_legacy_aivi_handoff=preserve_legacy_aivi_handoff,
    )
    if not ok:
        raise PersistedRestartError(
            f"Konfiguration gespeichert, aber die Datenabfrage ließ sich nicht neu starten: {message}"
        )


@serialized_web_mutation
def save_setup_step(body: dict[str, Any]) -> dict[str, Any]:
    step = str(body.get("step", "")).strip()
    cfg = setup.load_config()
    env = setup.load_existing_env()
    if step == "complete":
        # Do not expose the normal UI until the persisted configuration can be
        # consumed by an active observer.  A restart error intentionally leaves
        # first-run open and retryable instead of creating a half-completed run.
        setup.prepare_setup_completion(env, cfg)
        require_observer_restart()
        return setup.mark_setup_completed(env, cfg)
    return setup.apply_setup_step(step, body, env, cfg)


@serialized_web_mutation
def reopen_setup() -> dict[str, Any]:
    cfg = setup.load_config()
    setup.reopen_wizard(cfg)
    setup.write_config(cfg)
    return setup.setup_status(setup.load_existing_env(), cfg)


@serialized_web_mutation
def cancel_setup() -> dict[str, Any]:
    return setup.cancel_reopened_wizard(setup.load_config())


@serialized_web_mutation
def previous_setup_step() -> dict[str, Any]:
    cfg = setup.load_config()
    return setup.previous_setup_step(cfg)


@serialized_web_mutation
def scan_setup_wifi() -> dict[str, Any]:
    cfg = setup.load_config()
    if not setup.is_first_run(setup.load_existing_env(), cfg):
        raise ValueError("WLAN-Ersteinrichtung ist nur während der Ersteinrichtung verfügbar.")
    return {"networks": WifiSetupManager().scan_networks()}


@serialized_web_mutation
def connect_setup_wifi(body: dict[str, Any]) -> dict[str, Any]:
    cfg = setup.load_config()
    if not setup.is_first_run(setup.load_existing_env(), cfg):
        raise ValueError("WLAN-Ersteinrichtung ist nur während der Ersteinrichtung verfügbar.")
    manager = WifiSetupManager()
    manager.apply_network(str(body.get("ssid", "")), str(body.get("password", "")))
    # The root helper owns the complete single-radio transaction, including
    # verification and recovery.  A second web-side NM action would race it.
    hostname = socket.gethostname().strip()
    if not re.fullmatch(r"[A-Za-z0-9-]{1,63}", hostname): hostname = "zero-pi"
    return {"connected": True, "continue_url": f"http://{hostname}.local:8080/"}


@serialized_web_mutation
def save_diagnostics(body: dict[str, Any]) -> str:
    cfg = setup.load_config()
    diag = cfg.setdefault("diagnostics", {})
    retention = int(body.get("retention_days", diag.get("retention_days", 180)))
    export_days = int(body.get("export_default_days", diag.get("export_default_days", 7)))
    max_size = int(body.get("max_size_mib", diag.get("max_size_mib", 2048)))
    if not 7 <= retention <= 3650:
        raise ValueError("Aufbewahrung muss zwischen 7 und 3650 Tagen liegen.")
    if not 1 <= export_days <= retention:
        raise ValueError("Exportzeitraum muss zwischen 1 Tag und der Aufbewahrungszeit liegen.")
    if not observer.DIAGNOSTICS_MIN_SIZE_MIB <= max_size <= observer.DIAGNOSTICS_MAX_SIZE_MIB:
        raise ValueError(
            "Diagnose-Speicherlimit muss zwischen "
            f"{observer.DIAGNOSTICS_MIN_SIZE_MIB} und "
            f"{observer.DIAGNOSTICS_MAX_SIZE_MIB} MiB liegen."
        )
    diag.update(retention_days=retention, export_default_days=export_days, max_size_mib=max_size)
    setup.write_config(cfg)
    require_observer_restart()
    return "Diagnoseeinstellungen gespeichert."


@serialized_web_mutation
def save_advanced(body: dict[str, Any]) -> str:
    allowed = {
        "charging_seconds",
        "recent_seconds",
        "idle_seconds",
        "max_contact_age_seconds",
    }
    unknown = set(body) - allowed
    if unknown:
        raise ValueError("Unbekannte erweiterte Einstellung.")
    cfg = setup.load_config()
    polling = cfg.setdefault("polling", {})
    freshness = cfg.setdefault("freshness", {})
    for key in ("charging_seconds", "recent_seconds", "idle_seconds"):
        if key in body:
            polling[key] = int(body[key])
    if "max_contact_age_seconds" in body:
        freshness["max_contact_age_seconds"] = int(body["max_contact_age_seconds"])
    observer.validate_config(cfg)
    setup.write_config(cfg)
    require_observer_restart()
    return "Erweiterte Einstellungen gespeichert."


@serialized_web_mutation
def save_abrp(body: dict[str, Any]) -> str:
    cfg = setup.load_config()
    env = setup.load_existing_env()
    enabled = bool(body.get("enabled", False))
    cfg.setdefault("abrp", {})["enabled"] = enabled
    if enabled:
        token = str(body.get("token") or env.get("ABRP_TOKEN", "")).strip()
        api_key = str(body.get("api_key") or env.get("ABRP_API_KEY", "")).strip()
        if not token or not api_key:
            raise ValueError("Für ABRP sind User Token und API-Key erforderlich.")
        env["ABRP_TOKEN"] = token
        env["ABRP_API_KEY"] = api_key
    else:
        env.pop("ABRP_TOKEN", None)
        env.pop("ABRP_API_KEY", None)
    setup.persist_config_and_env(env, cfg)
    require_observer_restart(reset_abrp=True)
    return "ABRP-Konfiguration gespeichert."


@serialized_web_mutation
def save_aivi(body: dict[str, Any]) -> str:
    cfg = setup.load_config()
    env = setup.load_existing_env()
    aivi = cfg.setdefault("aivi", {})
    language = str(body.get("language", aivi.get("language", "de"))).strip().lower()
    if language not in {"de", "en"}:
        raise ValueError("Aivi-Sprache muss Deutsch oder Englisch sein.")
    aivi["language"] = language
    enabled = bool(body.get("enabled", False))
    if not enabled:
        aivi["enabled"] = False
        aivi["mode"] = "single_progress"
        env.pop("AIVI_API_TOKEN", None)
        env.pop("AIVI_ACTIVITY_SLUG", None)
        setup.persist_config_and_env(env, cfg)
        require_observer_restart(reset_aivi=True)
        return "Aivi deaktiviert."
    previous_enabled = bool(aivi.get("enabled", False))
    previous_progress = str(aivi.get("activity_slug", "")).strip()
    supplied_token = str(body.get("token") or "").strip()
    token = str(supplied_token or env.get("AIVI_API_TOKEN", "")).strip()
    progress = str(body.get("progress_slug") or aivi.get("activity_slug", "")).strip()
    if not token or not progress:
        raise ValueError("Aivi API-Token und Progress-Slug sind erforderlich.")
    if not previous_enabled or progress != previous_progress or supplied_token:
        timeout = float(aivi.get("request_timeout_seconds", 15))
        setup.test_aivi(token, progress, timeout, "progress")
    aivi.update(enabled=True, mode="single_progress", activity_slug=progress)
    env["AIVI_API_TOKEN"] = token
    env["AIVI_ACTIVITY_SLUG"] = progress
    setup.persist_config_and_env(env, cfg)
    require_observer_restart(
        reset_aivi=True,
        preserve_legacy_aivi_handoff=True,
    )
    return "Aivi-Konfiguration geprüft und gespeichert."


@serialized_web_mutation
def save_vehicle(body: dict[str, Any]) -> str:
    cfg = setup.load_config()
    env = setup.load_existing_env()
    username = str(body.get("username") or env.get("ZERO_CLOUD_USER", "")).strip()
    password = str(body.get("password") or env.get("ZERO_CLOUD_PASSWORD", "")).strip()
    label = str(body.get("label") or cfg.get("vehicle_label", "Zero Motorcycle")).strip()
    requested_unit = str(body.get("unit_number") or env.get("ZERO_UNIT_NUMBER", "")).strip()
    if not username or not password:
        raise ValueError("Zero-Cloud E-Mail und Passwort sind erforderlich.")
    session = requests.Session()
    vehicles = observer.request_zero(session, "get_units", username, password, float(cfg["request_timeout_seconds"]))
    usable = [v for v in vehicles if isinstance(v, dict) and str(v.get("unitnumber", "")).strip()]
    if not usable:
        raise ValueError("Zero Cloud erreichbar, aber kein verwendbares Fahrzeug gefunden.")
    selected = next((v for v in usable if str(v.get("unitnumber", "")).strip() == requested_unit), usable[0])
    unit = str(selected.get("unitnumber", "")).strip()
    # Verify that the selected vehicle can be read before persisting anything.
    observer.request_zero(session, "get_last_transmit", username, password,
                          float(cfg["request_timeout_seconds"]), unitnumber=unit)
    env["ZERO_CLOUD_USER"] = username
    env["ZERO_CLOUD_PASSWORD"] = password
    env["ZERO_UNIT_NUMBER"] = unit
    cfg["vehicle_label"] = label or observer.vehicle_display_label(selected)
    requested_model = str(body.get("vehicle_model") or "").strip()
    current_model = str(cfg.get("vehicle_model") or "").strip()
    if requested_model in SUPPORTED_VEHICLE_MODELS:
        cfg["vehicle_model"] = requested_model
    elif current_model not in SUPPORTED_VEHICLE_MODELS:
        cfg["vehicle_model"] = observer.vehicle_model_label(selected)
    setup.persist_config_and_env(env, cfg)
    require_observer_restart()
    return "Zero Cloud geprüft und Fahrzeugkonfiguration gespeichert."


@serialized_web_mutation
def save_vehicle_model(body: dict[str, Any]) -> str:
    selected = str(body.get("vehicle_model") or "").strip()
    if selected not in SUPPORTED_VEHICLE_MODELS:
        raise ValueError("Unbekanntes Fahrzeugmodell.")
    colors = setup.VEHICLE_COLORS.get(selected, ())
    color = str(body.get("vehicle_color") or "").strip()
    if color == vehicle_photos.CUSTOM_NAME:
        if not vehicle_photos.has_custom():
            raise ValueError("Es wurde noch kein eigenes Foto hochgeladen.")
        colors = (*colors, color)
    if color and color not in colors:
        raise ValueError("Unbekannte Fahrzeugfarbe.")
    cfg = setup.load_config()
    cfg["vehicle_model"] = selected
    if color:
        cfg["vehicle_color"] = color
    elif str(cfg.get("vehicle_color") or "") not in (*colors, *( (vehicle_photos.CUSTOM_NAME,) if vehicle_photos.has_custom() else ())):
        cfg.pop("vehicle_color", None)
    observer.validate_config(cfg)
    setup.write_config(cfg)
    return "Fahrzeugmodell gespeichert."


_VEHICLE_ASSET_VERSIONS: dict[str, tuple[int, int, str]] = {}
VEHICLE_IMAGE_CACHE_CONTROL = "public, max-age=31536000, immutable"
ICON_CACHE_CONTROL_VERSIONED = "public, max-age=31536000, immutable"
ICON_CACHE_CONTROL = "public, max-age=86400"
# Paths iOS/Android probe when a page has no usable icon link.
ICON_ALIASES = {"/apple-touch-icon.png": "zero-connect-home-180.png", "/apple-touch-icon-precomposed.png": "zero-connect-home-180.png",
                "/apple-touch-icon-180x180.png": "zero-connect-home-180.png", "/favicon.ico": "zero-connect-home-96.png"}


def vehicle_asset_version(relative: str) -> str | None:
    """Return a short content hash for a bundled vehicle image.

    The hash changes whenever the image changes, so a long-lived browser
    cache is refreshed automatically by a new URL without manual bumps.
    """
    candidate = WEB_ASSETS_DIR / relative
    try:
        stat = candidate.stat()
    except OSError:
        name = relative.removeprefix("vehicles/")
        return vehicle_photos.version_for(name) if "/" not in name else None
    cached = _VEHICLE_ASSET_VERSIONS.get(relative)
    if cached is not None and cached[:2] == (stat.st_mtime_ns, stat.st_size):
        return cached[2]
    try:
        version = hashlib.sha256(candidate.read_bytes()).hexdigest()[:12]
    except OSError:
        return None
    _VEHICLE_ASSET_VERSIONS[relative] = (stat.st_mtime_ns, stat.st_size, version)
    return version


def versioned_model_assets(data: bytes) -> bytes:
    """Add content versions to every vehicle image URL in the model map."""
    try:
        mapping = json.loads(data)
    except ValueError:
        return data

    def visit(value: Any) -> Any:
        if isinstance(value, dict):
            return {key: visit(item) for key, item in value.items()}
        if isinstance(value, list):
            return [visit(item) for item in value]
        if isinstance(value, str) and value.startswith("/assets/vehicles/") and "?" not in value:
            version = vehicle_asset_version(value.removeprefix("/assets/"))
            return f"{value}?v={version}" if version else value
        return value

    return json.dumps(visit(mapping), ensure_ascii=False).encode("utf-8")


def icon_data_uri(name: str) -> str:
    return "data:image/png;base64," + base64.b64encode((WEB_ASSETS_DIR / "icons" / name).read_bytes()).decode("ascii")


# iOS (26/27) can fetch the home-screen icon successfully and still show a letter tile;
# an icon embedded in the page and manifest is used without a separate fetch.
HOME_ICON_DATA_URIS = {size: icon_data_uri(f"zero-connect-home-{size}.png") for size in (180, 192)}


def manifest_with_embedded_icons(data: bytes) -> bytes:
    manifest = json.loads(data)
    embedded = [{"src": uri, "sizes": f"{size}x{size}", "type": "image/png", "purpose": "any"}
                for size, uri in HOME_ICON_DATA_URIS.items()]
    manifest["icons"] = embedded + list(manifest.get("icons") or [])
    return json.dumps(manifest, ensure_ascii=False).encode("utf-8")


INDEX_HTML = (
    (WEB_ASSETS_DIR / "index.html").read_text(encoding="utf-8")
    .replace("__HOME_ICON_180_DATA_URI__", HOME_ICON_DATA_URIS[180])
    .replace("__DIAGNOSTICS_MIN_SIZE_MIB__", str(observer.DIAGNOSTICS_MIN_SIZE_MIB))
    .replace("__DIAGNOSTICS_MAX_SIZE_MIB__", str(observer.DIAGNOSTICS_MAX_SIZE_MIB))
)


def observe_request_duration(method):
    """Rare slow-read signals contain duration only, never path, client or payload."""
    @functools.wraps(method)
    def measured(self):
        started = time.monotonic()
        try:
            return method(self)
        finally:
            elapsed = time.monotonic() - started
            if elapsed >= 5:
                self.log_message("slow_request duration_ms=%d", round(elapsed * 1000))
    return measured


class Handler(BaseHTTPRequestHandler):
    def handle(self) -> None:
        try:
            super().handle()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # Navigating away may close the socket during headers, body or error
            # response. End this connection; genuine handler errors remain visible.
            self.close_connection = True


    server_version = "ZeroConnectWeb/1.0.0-beta.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[web] " + (fmt % args) + "\n")

    def headers_common(self, content_type: str, *, cache_control: str = "no-store") -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", cache_control)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self' https://tile.openstreetmap.org data:; connect-src 'self'; object-src 'none'; "
            "base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
        )

    def send_vehicle_photo(self, name: str) -> bool:
        """Photos that are not bundled: the owner's own picture or the cached manufacturer photo."""
        if name == vehicle_photos.CUSTOM_NAME:
            path = vehicle_photos.custom_path()
        elif (WEB_ASSETS_DIR / "vehicles" / name).is_file():
            return False  # a bundled drawing (e.g. the neutral SVGs) is served by the normal path
        else:
            path = vehicle_photos.fetch(name)
        if path is None:
            return False
        try:
            data = path.read_bytes()
        except OSError:
            return False
        requested = (parse_qs(urlparse(self.path).query).get("v") or [""])[0]
        long_lived = bool(requested) and requested == vehicle_photos.version_for(name)
        self.send_response(200)
        self.headers_common(vehicle_photos.content_type(path), cache_control=VEHICLE_IMAGE_CACHE_CONTROL if long_lived else "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return True

    def send_asset(self, request_path: str) -> bool:
        decoded = unquote(request_path)
        if not decoded.startswith("/assets/"):
            return False
        relative = decoded.removeprefix("/assets/").replace("\\", "/")
        if not relative or any(part in {"", ".", ".."} for part in relative.split("/")):
            return False
        if relative.startswith("vehicles/") and relative.count("/") == 1 and self.send_vehicle_photo(relative.removeprefix("vehicles/")):
            return True
        root = WEB_ASSETS_DIR.resolve()
        candidate = (root / relative).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            return False
        allowed = {".html", ".css", ".js", ".json", ".svg", ".png", ".webp", ".webmanifest"}
        if candidate.suffix.lower() not in allowed or not candidate.is_file():
            return False
        content_type = mimetypes.types_map.get(candidate.suffix.lower(), "application/octet-stream")
        if candidate.suffix.lower() == ".svg":
            content_type = "image/svg+xml"
        elif candidate.suffix.lower() == ".webmanifest":
            content_type = "application/manifest+json"
        data = candidate.read_bytes()
        cache_control = "no-store"
        if relative == "model-assets.json":
            data = versioned_model_assets(data)
        elif relative == "manifest.webmanifest":
            data = manifest_with_embedded_icons(data)
        elif relative.startswith("icons/"):
            # Home-screen / favicon / push icons: iOS and Android keep their own copy, and
            # "no-store" can make the Add-to-Home-Screen sheet fall back to a letter tile.
            versioned = bool((parse_qs(urlparse(self.path).query).get("v") or [""])[0])
            cache_control = ICON_CACHE_CONTROL_VERSIONED if versioned else ICON_CACHE_CONTROL
        elif relative.startswith("vehicles/"):
            # Only an exact content-versioned URL may be cached long-term;
            # unversioned or outdated references always revalidate.
            requested = (parse_qs(urlparse(self.path).query).get("v") or [""])[0]
            if requested and requested == vehicle_asset_version(relative):
                cache_control = VEHICLE_IMAGE_CACHE_CONTROL
        self.send_response(200)
        self.headers_common(
            content_type + ("; charset=utf-8" if candidate.suffix.lower() in {".html", ".css", ".js", ".json", ".svg"} else ""),
            cache_control=cache_control,
        )
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return True

    def send_json(
        self,
        value: Any,
        status: int = 200,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status); self.headers_common("application/json; charset=utf-8")
        for key, header_value in (extra_headers or {}).items():
            self.send_header(key, header_value)
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def do_HEAD(self) -> None:
        """Answer HEAD like GET without the body (some clients probe icons and pages this way)."""
        real, buffer = self.wfile, io.BytesIO()
        self.wfile = buffer  # type: ignore[assignment]
        try:
            self.do_GET()
        finally:
            self.wfile = real
        head = buffer.getvalue().partition(b"\r\n\r\n")[0]
        real.write(head + b"\r\n\r\n")
        real.flush()

    @observe_request_duration
    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            if path in ICON_ALIASES and self.send_asset(f"/assets/icons/{ICON_ALIASES[path]}"):
                return
            if path == "/":
                data = INDEX_HTML.encode("utf-8")
                self.send_response(200); self.headers_common("text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if path == "/sw.js":
                data = (WEB_ASSETS_DIR / "sw.js").read_bytes()
                self.send_response(200); self.headers_common("application/javascript; charset=utf-8")
                self.send_header("Cache-Control", "no-cache"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if path.startswith("/assets/"):
                if self.send_asset(path):
                    return
                self.send_json({"error": "Nicht gefunden."}, 404)
                return
            if path == "/api/health": self.send_json({"ok": True, "version": PUBLIC_VERSION}); return
            if path == "/api/release-notes": self.send_json(release_notes_payload()); return
            if path == "/api/status":
                payload = status_payload()
                if parse_qs(urlparse(self.path).query).get("include_location") != ["1"]:
                    public_location = dict(payload.get("location", {}))
                    public_location.pop("latitude", None)
                    public_location.pop("longitude", None)
                    payload["location"] = public_location
                self.send_json(payload)
                return
            if path == "/api/location":
                self.send_json({"ok": True, "location": status_payload()["location"]})
                return
            if path == "/api/location-place":
                record = read_json(LOCATION_FILE)
                point = observer.vehicle_gps_coordinates({**record, "gps_valid": True}) if isinstance(record, dict) else None
                if not point:
                    self.send_json({"ok": True, "state": "unavailable", "place": None}); return
                requested_language = (parse_qs(urlparse(self.path).query).get("language") or [""])[0].lower()
                result = functional.request_place_label(*point,
                    language="en" if requested_language == "en" or (not requested_language and self.headers.get("Accept-Language", "").lower().startswith("en")) else "de")
                self.send_json({"ok": True, **result}); return
            if path == "/api/functional/preferences":
                self.send_json({"ok": True, "preferences": functional.preferences()}); return
            if path == "/api/functional/locations":
                requested_language = (parse_qs(urlparse(self.path).query).get("language") or [""])[0].lower()
                language = "en" if requested_language == "en" or (not requested_language and self.headers.get("Accept-Language", "").lower().startswith("en")) else "de"
                places = functional_locations(language)
                labels_pending = False
                labels_updated = False
                label_attempted_id = None
                labels_more = False
                skip_ids: set[str] = set()
                if parse_qs(urlparse(self.path).query).get("resolve_next") == ["1"]:
                    query = parse_qs(urlparse(self.path).query)
                    skip_ids = {value for value in (query.get("skip_location_ids") or [""])[0].split(",") if value}
                    resolution = resolve_next_location_label(places, language, skip_ids)
                    labels_pending = bool(resolution["pending"])
                    labels_updated = bool(resolution["updated"])
                    label_attempted_id = resolution["attempted_id"]
                    labels_more = bool(resolution["more"])
                if labels_updated:
                    places = functional_locations(language)
                self.send_json({"ok": True, "locations": places,
                                "location_labels_pending": labels_pending,
                                "location_labels_more": labels_more,
                                "location_label_attempted_id": label_attempted_id}); return
            if path == "/api/functional/maintenance":
                odometer = current_maintenance_odometer()
                self.send_json({"ok": True, "odometer": odometer,
                                "maintenance": functional.maintenance_status(odometer)}); return
            if path == "/api/functional/odometer-milestones":
                self.send_json({"ok": True, "milestones": functional.odometer_milestones()}); return
            if path == "/api/functional/events":
                self.send_json({"ok": True, "events": functional.notification_events()}); return
            if path == "/api/functional/push-status":
                endpoint = (parse_qs(urlparse(self.path).query).get("endpoint") or [None])[0]
                self.send_json({"ok": True, **functional.push_status(endpoint)}); return
            if path == "/api/trips": self.send_json(trips_payload()); return
            if path.startswith("/api/trips/"):
                ride_id = unquote(path.rsplit("/", 1)[-1])
                ride = next((row for row in trips_data()["rides"] if row.get("id") == ride_id), None)
                if ride is None:
                    self.send_json({"ok": False, "error": "Fahrt nicht gefunden."}, status=404); return
                self.send_json({"ok": True, "ride": ride}); return
            if path == "/api/history/export.csv":
                query = parse_qs(urlparse(self.path).query)
                language = (query.get("lang") or ["de"])[0]
                data = functional.export_csv(filtered_history(query, language), language)
                self.send_response(200); self.headers_common("text/csv; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="zero-connect-history.csv"'); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if path == "/api/history/export.json":
                data = json.dumps(functional.analytics_export(filtered_history(parse_qs(urlparse(self.path).query))), ensure_ascii=False, indent=2).encode("utf-8")
                self.send_response(200); self.headers_common("application/json; charset=utf-8")
                self.send_header("Content-Disposition", 'attachment; filename="zero-connect-history.json"'); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if path == "/api/functional/backup":
                raw_history = history_mod.load_sessions(include_removed=True)
                data = functional.backup(raw_history, PUBLIC_VERSION, raw_history=raw_history)
                self.send_response(200); self.headers_common("application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="zero-connect-backup.zip"'); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            if path.startswith("/api/support-download/"):
                token = path.rsplit("/", 1)[-1]
                downloads = getattr(self.server, "support_downloads", {})  # type: ignore[attr-defined]
                with WEB_MUTATION_LOCK:
                    for old_token, (_, expiry) in list(downloads.items()):
                        if float(expiry) <= time.monotonic():
                            downloads.pop(old_token, None)
                    item = downloads.get(token)
                if not item:
                    self.send_json({"error": "Supportpaket nicht gefunden oder abgelaufen."}, 404)
                    return
                archive_path, _expiry = item
                archive_path = Path(archive_path).resolve()
                if not archive_path.is_file():
                    self.send_json({"error": "Supportpaket nicht mehr verfügbar."}, 404)
                    return
                data = archive_path.read_bytes()
                self.send_response(200)
                self.headers_common("application/gzip")
                self.send_header("Content-Disposition", 'attachment; filename="zero-connect-support.tar.gz"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            if path == "/api/config": self.send_json(config_payload()); return
            if path == "/api/updates": self.send_json(updates_payload()); return
            if path == "/api/remote": self.send_json({"ok": True, **remote.status()}); return
            if path == "/api/setup": self.send_json(setup_payload()); return
            if path == "/api/history":
                query = parse_qs(urlparse(self.path).query)
                requested_language = (query.get("language") or [""])[0].lower()
                language = "en" if requested_language == "en" or (not requested_language and self.headers.get("Accept-Language", "").lower().startswith("en")) else "de"
                items = filtered_history(query, language)
                self.send_json({"items": items[:50]}); return
            if path == "/api/history/removed":
                query = parse_qs(urlparse(self.path).query)
                language = "en" if (query.get("language") or [""])[0].lower() == "en" else "de"
                self.send_json({"items": removed_session_payload(language)}); return
            if path == "/api/analytics": self.send_json(analytics_payload()); return
            if path == "/api/history/compare":
                query = parse_qs(urlparse(self.path).query)
                try: left_id = int((query.get("left") or [""])[0]); right_id = int((query.get("right") or [""])[0])
                except ValueError: self.send_json({"error": "Zwei gültige Sessions erforderlich."}, 400); return
                rows = {int(r.get("generation", 0) or 0): r for r in history_payload(limit=1000)}
                if left_id not in rows or right_id not in rows: self.send_json({"error": "Session nicht gefunden."}, 404); return
                self.send_json({"left": rows[left_id], "right": rows[right_id], "comparison": functional.compare_sessions(rows[left_id], rows[right_id])}); return
            if path.startswith("/api/history/"):
                try: generation = int(path.rsplit("/", 1)[-1])
                except ValueError: self.send_json({"error": "Ungültige Session."}, 400); return
                query = parse_qs(urlparse(self.path).query)
                requested_language = (query.get("language") or [""])[0].lower()
                language = "en" if requested_language == "en" or (not requested_language and self.headers.get("Accept-Language", "").lower().startswith("en")) else "de"
                detail = session_detail_payload(generation, language)
                self.send_json(detail or {"error": "Session nicht gefunden."}, 200 if detail else 404); return
            self.send_json({"error": "Nicht gefunden."}, 404)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True
        except Exception as exc:
            self.send_json({"error": f"Interner Fehler: {exc}"}, 500)

    def read_body(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length < 0 or length > 128 * 1024:
            raise ValueError("Ungültige Anfragegröße.")
        raw = self.rfile.read(length) if length else b"{}"
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON-Objekt erwartet.")
        return value

    def session_token(self) -> str:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except Exception:
            return ""
        return cookie.get("zero_admin_session").value if cookie.get("zero_admin_session") else ""

    def session_authorized(self) -> bool:
        token = self.session_token()
        sessions = getattr(self.server, "admin_sessions", {})  # type: ignore[attr-defined]
        if not token:
            return False
        now = time.monotonic()
        with self.server.auth_lock:  # type: ignore[attr-defined]
            expiry = sessions.get(token)
            if not expiry:
                return False
            if float(expiry) <= now:
                sessions.pop(token, None)
                return False
            return True

    def issue_admin_session(self) -> str:
        token = secrets.token_urlsafe(32)
        sessions = getattr(self.server, "admin_sessions", {})  # type: ignore[attr-defined]
        with self.server.auth_lock:  # type: ignore[attr-defined]
            now = time.monotonic()
            for old_token, expiry in list(sessions.items()):
                if float(expiry) <= now:
                    sessions.pop(old_token, None)
            sessions[token] = now + ADMIN_SESSION_SECONDS
        return token

    def session_cookie_header(self, token: str) -> str:
        return (
            f"zero_admin_session={token}; Max-Age={ADMIN_SESSION_SECONDS}; Path=/; "
            "HttpOnly; SameSite=Strict"
        )

    def receive_vehicle_photo(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > vehicle_photos.MAX_UPLOAD_BYTES:
            self.send_json({"error": "Das Foto ist leer oder zu groß.", "error_code": "photo_size"}, HTTPStatus.BAD_REQUEST)
            return
        try:
            vehicle_photos.save_custom(self.rfile.read(length))
        except ValueError:
            self.send_json({"error": "Bitte ein JPEG- oder PNG-Foto wählen.", "error_code": "photo_type"}, HTTPStatus.BAD_REQUEST)
            return
        self.send_json({"ok": True, "version": vehicle_photos.version_for(vehicle_photos.CUSTOM_NAME)})

    def handle_updates(self, path: str, body: dict[str, Any]) -> None:
        try:
            if path == "/api/updates/check":
                updates.check(force=bool(body.get("force", True)))
            elif path == "/api/updates/channel":
                updates.set_channel(str(body.get("channel") or ""), return_to_stable=bool(body.get("return_to_stable")))
            elif path == "/api/updates/beta":
                updates.redeem_beta_code(str(body.get("code") or ""))
            elif path == "/api/updates/install":
                # Only a bundle whose signature and checksum verify can be staged,
                # and nothing is staged while a charge is running.
                updates.stage_install(vehicle_busy=update_vehicle_busy)
            elif path == "/api/updates/schedule":
                updates.schedule_install(bool(body.get("enabled", True)))
            elif path == "/api/updates/auto":
                updates.set_auto_install(bool(body.get("enabled")))
            else:
                self.send_json({"error": "Unbekannt.", "error_code": "not_found"}, HTTPStatus.NOT_FOUND)
                return
        except updates.UpdateError as exc:
            self.send_json({"error": str(exc), "error_code": f"update_{exc.code}"}, HTTPStatus.BAD_REQUEST)
            return
        self.send_json(updates_payload())

    def authorization_result(self, body: dict[str, Any]) -> tuple[bool, int]:
        if self.session_authorized():
            return True, 0
        supplied = str(self.headers.get("X-Zero-Connect-PIN") or body.get("pin") or "").strip()
        now = time.monotonic()
        client = str(self.client_address[0])
        lock = self.server.auth_lock  # type: ignore[attr-defined]
        failures = self.server.auth_failures  # type: ignore[attr-defined]
        max_failures = int(
            getattr(self.server, "pin_max_failures", PIN_MAX_FAILED_ATTEMPTS)
        )
        lockout_seconds = float(
            getattr(self.server, "pin_lockout_seconds", PIN_LOCKOUT_SECONDS)
        )
        failure_window = float(
            getattr(
                self.server,
                "pin_failure_window_seconds",
                PIN_FAILURE_WINDOW_SECONDS,
            )
        )
        table_limit = max(
            1,
            int(
                getattr(
                    self.server,
                    "pin_failure_table_limit",
                    PIN_FAILURE_TABLE_LIMIT,
                )
            ),
        )
        with lock:
            for failure_client, failure_record in list(failures.items()):
                failure_blocked_until = float(
                    failure_record.get("blocked_until", 0.0) or 0.0
                )
                failure_last = float(
                    failure_record.get("last_failure", 0.0) or 0.0
                )
                expired = (
                    failure_blocked_until <= now
                    if failure_blocked_until > 0
                    else now - failure_last > failure_window
                )
                if expired:
                    failures.pop(failure_client, None)
            record = failures.get(client, {})
            blocked_until = float(record.get("blocked_until", 0.0) or 0.0)
            if blocked_until > now:
                return False, max(1, int(blocked_until - now + 0.999))
            if bool(supplied) and secrets.compare_digest(supplied, self.server.admin_pin):  # type: ignore[attr-defined]
                failures.pop(client, None)
                return True, 0
            last_failure = float(record.get("last_failure", 0.0) or 0.0)
            count = int(record.get("count", 0) or 0) if now - last_failure <= failure_window else 0
            count += 1
            if client not in failures and len(failures) >= table_limit:
                return False, max(1, int(lockout_seconds + 0.999))
            if count >= max_failures:
                failures[client] = {
                    "count": count,
                    "last_failure": now,
                    "blocked_until": now + lockout_seconds,
                }
                return False, max(1, int(lockout_seconds + 0.999))
            failures[client] = {
                "count": count,
                "last_failure": now,
                "blocked_until": 0.0,
            }
            return False, 0

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/api/vehicle-photo":
                self.receive_vehicle_photo(); return
            body = self.read_body()
            if path == "/api/remote/connect":
                self.send_json({"ok": True, **remote.connect()}); return
            if path == "/api/config/remote-url":
                cfg = setup.load_config()
                url = remote.normalize_url(str(body.get("url") or ""))
                if url:
                    cfg["remote_url"] = url
                else:
                    cfg.pop("remote_url", None)
                observer.validate_config(cfg)
                setup.write_config(cfg)
                self.send_json({"ok": True, **remote.status()}); return
            if path == "/api/vehicle-photo/remove":
                removed = vehicle_photos.remove_custom()
                cfg = setup.load_config()
                if cfg.get("vehicle_color") == vehicle_photos.CUSTOM_NAME:
                    cfg.pop("vehicle_color", None)
                    setup.write_config(cfg)
                self.send_json({"ok": True, "removed": removed}); return
            if path == "/api/client-heartbeat":
                if body:
                    self.send_json({"error": "Heartbeat darf keine Nutzdaten enthalten."}, HTTPStatus.BAD_REQUEST)
                    return
                record_web_client_activity()
                self.send_json({"ok": True})
                return
            if path == "/api/auth/unlock":
                authorized, retry_after = self.authorization_result(body)
                if not authorized:
                    if retry_after:
                        self.send_json(
                            {"error": "Zu viele falsche Admin-PIN-Versuche; Zugriff vorübergehend gesperrt.", "error_code": "auth_rate_limited"},
                            HTTPStatus.TOO_MANY_REQUESTS,
                            {"Retry-After": str(retry_after)},
                        )
                    else:
                        self.send_json({"error": "Admin-PIN falsch oder fehlt.", "error_code": "auth_required"}, HTTPStatus.UNAUTHORIZED)
                    return
                token = self.issue_admin_session()
                self.send_json(
                    {"ok": True, "message_code": "admin_unlocked"},
                    200,
                    {"Set-Cookie": self.session_cookie_header(token)},
                )
                return
            if path == "/api/setup":
                self.send_json(
                    {"ok": True, "setup": save_setup_step(body), "message_code": "setup_saved"}
                )
                return
            if path == "/api/setup/reopen":
                self.send_json(
                    {"ok": True, "setup": reopen_setup(), "message_code": "setup_reopened"}
                )
                return
            if path == "/api/setup/cancel":
                self.send_json({"ok": True, "setup": cancel_setup(), "message_code": "setup_cancelled"})
                return
            if path == "/api/setup/back":
                self.send_json({"ok": True, "setup": previous_setup_step(), "message_code": "setup_back"})
                return
            if path == "/api/setup/wifi/scan":
                self.send_json({"ok": True, **scan_setup_wifi()})
                return
            if path == "/api/setup/wifi/connect":
                self.send_json({"ok": True, **connect_setup_wifi(body)})
                return
            if path.startswith("/api/updates/"):
                self.handle_updates(path, body); return
            if path == "/api/restart":
                ok, msg = restart_observer(); self.send_json({"ok": ok, "message": msg, "message_code": "restart_done" if ok else "restart_failed", **({} if ok else {"error": msg, "error_code": "restart_failed"})}, 200 if ok else 500); return
            if path == "/api/location":
                self.send_json({"ok": True, "location": status_payload()["location"]})
                return
            if path == "/api/doctor":
                result = subprocess.run(
                    [sys.executable, str(PROJECT_DIR / "zero_doctor.py")],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=60,
                )
                self.send_json(
                    {
                        "ok": result.returncode == 0,
                        "output": (result.stdout or "") + (result.stderr or ""),
                    }
                )
                return
            if path == "/api/support-export":
                result = subprocess.run(
                    [sys.executable, str(PROJECT_DIR / "zero_diagnostics.py"), "export"],
                    capture_output=True, text=True, check=False, timeout=120,
                )
                output = (result.stdout or "") + (result.stderr or "")
                found = ""
                for line in output.splitlines():
                    if line.startswith("Diagnosepaket erstellt:"):
                        found = line.split(":", 1)[1].strip()
                if result.returncode:
                    raise RuntimeError(output.strip() or "Supportexport fehlgeschlagen.")
                if not found:
                    raise RuntimeError("Supportpaket wurde ohne gültigen Dateipfad erstellt.")
                archive_path = Path(found).resolve()
                if not archive_path.is_file():
                    raise RuntimeError("Supportpaket wurde nicht gefunden.")
                token = secrets.token_urlsafe(24)
                downloads = getattr(self.server, "support_downloads", {})  # type: ignore[attr-defined]
                with WEB_MUTATION_LOCK:
                    downloads[token] = (str(archive_path), time.monotonic() + SUPPORT_DOWNLOAD_SECONDS)
                self.send_json({"ok": True, "message": "Supportpaket erstellt.", "message_code": "export_done", "download_url": f"/api/support-download/{token}"}); return
            if path == "/api/functional/preferences":
                self.send_json({"ok": True, "preferences": functional.save_preferences(body)}); return
            if path == "/api/functional/locations":
                self.send_json({"ok": True, "location": functional.upsert_location(body)}); return
            if path == "/api/functional/locations/delete":
                functional.delete_location(str(body.get("id") or "")); self.send_json({"ok": True}); return
            if path == "/api/functional/maintenance":
                self.send_json({"ok": True, "maintenance": functional.upsert_maintenance(body)}); return
            if path == "/api/functional/maintenance/complete":
                odometer = observer.to_float_or_none(body.get("odometer"))
                maintenance = (functional.complete_maintenance(str(body.get("id") or ""), odometer)
                               if odometer is not None else complete_maintenance_from_current_odometer(str(body.get("id") or "")))
                self.send_json({"ok": True, "maintenance": maintenance}); return
            if path == "/api/functional/maintenance/delete":
                functional.delete_maintenance(str(body.get("id") or "")); self.send_json({"ok": True}); return
            if path == "/api/functional/odometer-milestones":
                self.send_json({"ok": True, "milestone": functional.upsert_odometer_milestone(body)}); return
            if path == "/api/functional/odometer-milestones/delete":
                functional.delete_odometer_milestone(str(body.get("id") or "")); self.send_json({"ok": True}); return
            if path == "/api/functional/subscriptions":
                self.send_json({"ok": True, **functional.save_subscription(body)}); return
            if path == "/api/functional/subscriptions/status":
                self.send_json({"ok": True, **functional.push_status(str(body.get("endpoint") or ""))}); return
            if path == "/api/functional/subscriptions/delete":
                functional.remove_subscription(str(body.get("endpoint") or "")); self.send_json({"ok": True}); return
            if path == "/api/functional/events":
                kind = str(body.get("kind") or "").strip(); self.send_json({"ok": True, "recorded": functional.record_event(kind, body.get("payload") if isinstance(body.get("payload"), dict) else {}, str(body.get("dedup_key") or "") or None)}); return
            if path == "/api/functional/push-test":
                self.send_json({"ok": True, **functional.send_push("Testbenachrichtigung", "Benachrichtigungen funktionieren.", "/settings/notifications")}); return
            if path == "/api/functional/restore":
                authorized, retry_after = self.authorization_result(body)
                if not authorized:
                    self.send_json({"error": "Admin-PIN falsch oder fehlt.", "error_code": "auth_required"}, HTTPStatus.UNAUTHORIZED, {"Retry-After": str(retry_after)} if retry_after else None)
                    return
                encoded = str(body.get("backup_base64") or "")
                if not encoded: raise ValueError("Backup fehlt.")
                raw_backup = base64.b64decode(encoded, validate=True)
                with observer.runtime_state_lock():
                    state = read_state()
                    try:
                        active_generation = int(state.get("charge_session_generation", 0) or 0)
                    except (TypeError, ValueError, OverflowError):
                        active_generation = 0
                    active_now = (
                        bool(state.get("session_active")) or bool(state.get("plugged_episode_active"))
                        or str(state.get("charge_phase") or "") in {"charging", "target_reached"}
                    )
                    if active_now and active_generation <= 0:
                        raise SessionHistoryError("Aktiver Ladezustand ohne eindeutige Generation; Wiederherstellung wurde angehalten.")
                    protected_generations = {active_generation} if active_now else set()
                    restored = functional.restore_backup(
                        raw_backup,
                        protected_session_generations=protected_generations,
                    )
                self.send_json({"ok": True, **restored}); return
            session_action = re.fullmatch(r"/api/history/(\d+)/(remove|restore)", path)
            if session_action:
                generation = int(session_action.group(1))
                removed = session_action.group(2) == "remove"
                changed = update_session_history(generation, removed=removed)
                self.send_json({"ok": True, "changed": changed}); return
            if path == "/api/config/web-pin":
                authorized, retry_after = self.authorization_result(body)
                if not authorized:
                    self.send_json({"error": "Admin-PIN falsch oder fehlt.", "error_code": "auth_required"}, HTTPStatus.UNAUTHORIZED, {"Retry-After": str(retry_after)} if retry_after else None)
                    return
                new_pin = str(body.get("new_pin") or "").strip()
                confirm = str(body.get("confirm_pin") or "").strip()
                if new_pin != confirm:
                    raise ValueError("Die beiden neuen PIN-Eingaben stimmen nicht überein.")
                with WEB_MUTATION_LOCK:
                    self.server.admin_pin = write_admin_pin(new_pin)  # type: ignore[attr-defined]
                self.send_json({"ok": True, "message": "Admin-PIN geändert.", "message_code": "pin_changed"}); return
            mapping = {
                "/api/config/vehicle": save_vehicle,
                "/api/config/vehicle-model": save_vehicle_model,
                "/api/config/aivi": save_aivi,
                "/api/config/abrp": save_abrp,
                "/api/config/diagnostics": save_diagnostics,
                "/api/config/advanced": save_advanced,
            }
            func = mapping.get(path)
            if func:
                self.send_json({"ok": True, "message": func(body), "message_code": "config_saved"}); return
            self.send_json({"error": "Nicht gefunden."}, 404)
        except PersistedRestartError as exc:
            self.send_json(
                {
                    "error": str(exc),
                    "persisted": True,
                    "restart_failed": True,
                    "error_code": "restart_failed",
                },
                HTTPStatus.SERVICE_UNAVAILABLE,
            )
        except setup.PersistenceError as exc:
            self.send_json(
                {
                    "error": str(exc),
                    "persistence_failed": True,
                    "persisted": bool(exc.partially_persisted),
                    "partially_persisted": bool(exc.partially_persisted),
                    "error_code": "persistence_failed",
                },
                HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        except SessionHistoryError as exc:
            self.send_json({"error": str(exc), "error_code": "session_history_conflict"}, exc.status)
        except observer.ZeroRequestError as exc:
            # Wrong login, no internet or a Zero Cloud hiccup each get their own explanation.
            code = {"api_error": "cloud_rejected", "connection": "cloud_unreachable", "timeout": "cloud_timeout"}.get(exc.category, "cloud_unavailable")
            self.send_json({"error": str(exc), "error_code": code}, 400)
        except setup.SetupError as exc:
            self.send_json({"error": str(exc), "error_code": exc.code}, 400)
        except (ValueError, RuntimeError, requests.RequestException) as exc:
            self.send_json({"error": str(exc), "error_code": "validation_failed"}, 400)
        except subprocess.TimeoutExpired:
            self.send_json({"error": "Aktion hat zu lange gedauert.", "error_code": "timeout"}, 504)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True
        except Exception as exc:
            self.send_json({"error": f"Interner Fehler: {exc}"}, 500)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Zero Connect lokale Web-Oberfläche")
    parser.add_argument("--host", help="Bind-Adresse; Standard aus zero_config.json")
    parser.add_argument("--port", type=int, help="Port; Standard aus zero_config.json")
    return parser


UPDATE_TICK_SECONDS = 300


def update_background_loop(stop: threading.Event) -> None:
    """Daily update check and the planned overnight install; failures never touch the web UI."""
    while not stop.wait(UPDATE_TICK_SECONDS):
        try:
            updates.run_background(vehicle_busy=update_vehicle_busy)
        except Exception as exc:  # noqa: BLE001 - a broken update source must not stop anything else
            print(f"Update-Hintergrundjob: {type(exc).__name__}", flush=True)


def main() -> None:
    args = build_parser().parse_args()
    setup.ensure_config_backup()
    cfg = observer.load_config()
    web = cfg.get("web", {})
    host = args.host or str(web.get("host", "0.0.0.0"))
    port = args.port or int(web.get("port", 8080))
    if not 1 <= int(port) <= 65535:
        raise SystemExit("Ungültiger Web-Port.")
    # The restricted root helper itself rechecks first-run and connectivity.
    # Failure is non-fatal: the normal UI remains available on known networks.
    try:
        initial = setup.setup_status(setup.load_existing_env(), cfg)
        if initial["first_run"]:
            WifiSetupManager().activate_hotspot(first_run=True)
    except RuntimeError:
        print("Setup-WLAN konnte noch nicht aktiviert werden.", flush=True)
    pin = atomic_pin()
    server = ThreadingHTTPServer((host, int(port)), Handler)
    server.admin_pin = pin  # type: ignore[attr-defined]
    server.auth_failures = {}  # type: ignore[attr-defined]
    server.admin_sessions = {}  # type: ignore[attr-defined]
    server.support_downloads = {}  # type: ignore[attr-defined]
    server.auth_lock = threading.Lock()  # type: ignore[attr-defined]
    server.pin_max_failures = PIN_MAX_FAILED_ATTEMPTS  # type: ignore[attr-defined]
    server.pin_lockout_seconds = PIN_LOCKOUT_SECONDS  # type: ignore[attr-defined]
    server.pin_failure_window_seconds = PIN_FAILURE_WINDOW_SECONDS  # type: ignore[attr-defined]
    server.pin_failure_table_limit = PIN_FAILURE_TABLE_LIMIT  # type: ignore[attr-defined]
    print(f"Zero Connect Web-UI {PUBLIC_VERSION} auf {host}:{port}", flush=True)
    stop_updates = threading.Event()
    threading.Thread(target=update_background_loop, args=(stop_updates,), daemon=True, name="update-background").start()
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        stop_updates.set()
        server.server_close()


if __name__ == "__main__":
    main()
