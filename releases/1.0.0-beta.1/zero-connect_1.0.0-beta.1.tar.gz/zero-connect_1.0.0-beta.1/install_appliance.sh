#!/usr/bin/env bash
# Staging installer: --root only writes static target files, never host runtime.
set -Eeuo pipefail
SOURCE_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"; ROOT=""; WIFI_DEVICE=wlan0
while (($#)); do case "$1" in --appliance|--upgrade) ;; --root) ROOT=$2; shift;; --root=*) ROOT=${1#*=};; --wifi-device=*) WIFI_DEVICE=${1#*=};; *) exit 2;; esac; shift; done
[[ -n "$ROOT" ]] || { echo 'Use --root for static appliance staging.' >&2; exit 2; }; ROOT="$(realpath -e "$ROOT")"; [[ "$ROOT" != / ]] || exit 2
t(){ printf '%s%s' "$ROOT" "$1"; }; APP=$(t /opt/zero-connect); ETC=$(t /etc/zero-connect); UNIT=$(t /etc/systemd/system)
install -d -m0755 "$APP" "$UNIT" "$(t /usr/lib/sysusers.d)" "$(t /etc/tmpfiles.d)" "$(t /etc/systemd/resolved.conf.d)" "$(t /usr/lib/zero-connect)" "$(t /usr/local/bin)"
install -d -m0750 "$ETC"
printf 'zero-connect-appliance-v1\n' > "${ETC}/install-layout"
chmod 0640 "${ETC}/install-layout"
install -d -m0700 "$(t /var/lib/zero-connect)" "$(t /etc/NetworkManager/system-connections)"
printf 'u zero-connect - "Zero Connect appliance" /nonexistent /usr/sbin/nologin\n' > "$(t /usr/lib/sysusers.d/zero-connect.conf)"
printf 'd /etc/zero-connect 1770 root zero-connect -\nd /var/lib/zero-connect 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/logs 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/polls 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/events 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/sessions 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/exports 0700 zero-connect zero-connect -\nd /var/lib/zero-connect/update-staging 0750 zero-connect zero-connect -\nd /run/zero-connect 0710 root zero-connect -\nz /etc/zero-connect/secrets.env 0640 zero-connect zero-connect -\nz /etc/zero-connect/zero_config.json 0640 zero-connect zero-connect -\nz /etc/zero-connect/dnsmasq-setup.conf 0640 root root -\n' > "$(t /etc/tmpfiles.d/zero-connect.conf)"
for f in zero_observer.py zero_status.py zero_setup.py zero_doctor.py zero_connect_cli.py zero_connect_web.py zero_wifi_setup.py zero_network_helper.py zero_captive_portal.py zero_diagnostics.py zero_history.py zero_vehicle.py zero_charging.py zero_functional.py aivi_live_test.py zero_paths.py zero_release_notes.py zero_updates.py zero_vehicle_photos.py zero_trips.py zero_remote.py zero_release_verify.py zero_appliance_update.py zero_postboot_verify.py VERSION.json release_notes.json requirements.txt; do install -m0644 "$SOURCE_DIR/$f" "$APP/$f"; done
cp -R --no-preserve=ownership "$SOURCE_DIR/web_assets" "$APP/"
find "$APP/web_assets" -type d -exec chmod 0755 {} +
find "$APP/web_assets" -type f -exec chmod 0644 {} +
install -m0644 "$SOURCE_DIR/zero_config.json" "$ETC/zero_config.json"; : > "$ETC/secrets.env"; chmod 0640 "$ETC"/*
install -m0755 "$SOURCE_DIR/zero_network_helper.py" "$(t /usr/lib/zero-connect/zero_network_helper.py)"; install -m0644 "$SOURCE_DIR/zero_paths.py" "$(t /usr/lib/zero-connect/zero_paths.py)"; install -m0755 "$SOURCE_DIR/zero_captive_portal.py" "$(t /usr/lib/zero-connect/zero_captive_portal.py)"
grep -v '^#' "$SOURCE_DIR/release-public-key.pub" > "$ETC/release-public-key"; chmod 0644 "$ETC/release-public-key"
install -m0755 "$SOURCE_DIR/zero_update_launcher.py" "$(t /usr/lib/zero-connect/zero_appliance_update.py)"; install -d -m0750 "$(t /var/lib/zero-connect/update-staging)" "$(t /var/lib/zero-connect/app-backups)"
install -m0644 "$SOURCE_DIR/zero_release_verify.py" "$(t /usr/lib/zero-connect/zero_release_verify.py)"
install -m0755 "$SOURCE_DIR/zero_root_resize.sh" "$(t /usr/lib/zero-connect/zero_root_resize.sh)"
printf 'zero-connect\n' > "$(t /etc/hostname)"
printf 'port=53\nbind-dynamic\ninterface=%s\nexcept-interface=lo\nlisten-address=10.42.0.1\ndhcp-authoritative\ndhcp-range=10.42.0.10,10.42.0.100,255.255.255.0,12h\ndhcp-option=option:router,10.42.0.1\ndhcp-option=option:dns-server,10.42.0.1\ndhcp-leasefile=/run/zero-connect/dnsmasq/dnsmasq.leases\npid-file=/run/zero-connect/dnsmasq/dnsmasq.pid\nno-resolv\nno-hosts\nlocal=/#/\naddress=/#/10.42.0.1\n' "$WIFI_DEVICE" > "$ETC/dnsmasq-setup.conf"
chmod 0640 "$ETC/dnsmasq-setup.conf"
printf '[Resolve]\nMulticastDNS=no\nLLMNR=no\n' > "$(t /etc/systemd/resolved.conf.d/zero-connect-mdns.conf)"
cat > "$UNIT/zero-connect-provision.service" <<'EOF'
[Unit]
After=systemd-sysusers.service
Requires=zero-connect-root-resize.service
After=zero-connect-root-resize.service
Before=zero-observer.service zero-connect-web.service
[Service]
Type=oneshot
ExecStart=/usr/bin/systemd-tmpfiles --create /etc/tmpfiles.d/zero-connect.conf
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
EOF
cat > "$UNIT/zero-connect-root-resize.service" <<'EOF'
[Unit]
Description=Expand Zero Connect root partition on first boot
After=local-fs.target systemd-udev-settle.service
Before=multi-user.target zero-connect-provision.service zero-observer.service zero-connect-web.service
[Service]
Type=oneshot
ExecStart=/usr/lib/zero-connect/zero_root_resize.sh
RemainAfterExit=yes
TimeoutStartSec=180
[Install]
WantedBy=multi-user.target default.target
EOF
cat > "$UNIT/zero-connect-update.service" <<'EOF'
[Unit]
After=network-online.target
[Service]
Type=oneshot
User=root
ExecStart=/usr/lib/zero-connect/zero_appliance_update.py
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/opt /var/lib/zero-connect
EOF
cat > "$UNIT/zero-connect-update.path" <<'EOF'
[Path]
PathChanged=/var/lib/zero-connect/update-staging/incoming.tar.gz
Unit=zero-connect-update.service
[Install]
WantedBy=multi-user.target
EOF
for svc in observer web; do user=zero-connect; script="zero_${svc}.py"; [[ $svc == observer ]] || script=zero_connect_web.py; cat > "$UNIT/zero-${svc/observer/observer}.service" <<EOF
[Unit]
After=network-online.target zero-connect-provision.service
Requires=zero-connect-provision.service
[Service]
User=zero-connect
Group=zero-connect
SupplementaryGroups=systemd-journal
WorkingDirectory=/opt/zero-connect
Environment=ZERO_CONNECT_MODE=appliance
ExecStart=/usr/bin/python3 /opt/zero-connect/$script
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/zero-connect /etc/zero-connect /run/zero-connect
[Install]
WantedBy=multi-user.target
EOF
done
mv "$UNIT/zero-web.service" "$UNIT/zero-connect-web.service"
# The app user may drive Tailscale (sign-in, HTTPS address) without root; set on every boot, harmless when absent.
cat > "$UNIT/zero-connect-tailscale-operator.service" <<'EOF'
[Unit]
ConditionPathExists=/usr/bin/tailscale
After=tailscaled.service
Requires=tailscaled.service
[Service]
Type=oneshot
ExecStart=/usr/bin/tailscale set --operator=zero-connect
[Install]
WantedBy=multi-user.target
EOF
cat > "$UNIT/zero-connect-postboot-verify.service" <<'EOF'
[Unit]
Description=Zero Connect post-boot production verification
After=network-online.target zero-observer.service zero-connect-web.service
Wants=network-online.target
Requires=zero-observer.service zero-connect-web.service
[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /opt/zero-connect/zero_postboot_verify.py
[Install]
WantedBy=multi-user.target
EOF
cat > "$UNIT/zero-connect-captive-dns.service" <<'EOF'
[Unit]
After=NetworkManager.service
StartLimitIntervalSec=0
[Service]
ExecStart=/usr/sbin/dnsmasq --keep-in-foreground --conf-file=/etc/zero-connect/dnsmasq-setup.conf
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
RuntimeDirectory=zero-connect/dnsmasq
RuntimeDirectoryMode=0750
ReadWritePaths=/run/zero-connect/dnsmasq
EOF
cat > "$UNIT/zero-connect-captive-portal.service" <<'EOF'
[Unit]
After=NetworkManager.service
StartLimitIntervalSec=0
[Service]
ExecStart=/usr/lib/zero-connect/zero_captive_portal.py --host 10.42.0.1 --port 80
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
EOF
cat > "$UNIT/zero-connect-network.socket" <<'EOF'
[Socket]
ListenStream=/run/zero-connect/network.sock
Accept=true
SocketMode=0660
SocketUser=root
SocketGroup=zero-connect
[Install]
WantedBy=sockets.target
EOF
cat > "$UNIT/zero-connect-network@.service" <<EOF
[Unit]
After=NetworkManager.service zero-connect-provision.service
Requires=NetworkManager.service zero-connect-provision.service
[Service]
User=root
Environment=ZERO_CONNECT_MODE=appliance
ExecStart=/usr/lib/zero-connect/zero_network_helper.py --project-dir /opt/zero-connect --wifi-device=$WIFI_DEVICE
StandardInput=socket
StandardOutput=socket
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/etc/NetworkManager/system-connections /run/zero-connect
EOF
cat > "$UNIT/zero-connect-network-watch.service" <<EOF
[Unit]
After=NetworkManager.service zero-connect-provision.service
Requires=NetworkManager.service zero-connect-provision.service
[Service]
User=root
Environment=ZERO_CONNECT_MODE=appliance
ExecStart=/usr/lib/zero-connect/zero_network_helper.py --watch --project-dir /opt/zero-connect --wifi-device=$WIFI_DEVICE
Restart=always
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/etc/NetworkManager/system-connections /run/zero-connect
[Install]
WantedBy=multi-user.target
EOF
printf '#!/bin/sh\nexec /usr/bin/python3 /opt/zero-connect/zero_connect_cli.py "$@"\n' > "$(t /usr/local/bin/zero-connect)"; chmod 0755 "$(t /usr/local/bin/zero-connect)"
for u in zero-connect-root-resize.service zero-connect-provision.service zero-observer.service zero-connect-web.service zero-connect-postboot-verify.service zero-connect-network-watch.service zero-connect-tailscale-operator.service zero-connect-update.path; do
  for target in multi-user.target default.target; do
    install -d "$(t /etc/systemd/system/$target.wants)"
    ln -sfn "../$u" "$(t /etc/systemd/system/$target.wants/$u)"
  done
done
install -d "$(t /etc/systemd/system/sockets.target.wants)"; ln -sfn ../zero-connect-network.socket "$(t /etc/systemd/system/sockets.target.wants/zero-connect-network.socket)"
echo 'Static appliance RootFS staged. Target packages: python3-requests python3-dotenv python3-cryptography NetworkManager dnsmasq-base avahi-daemon.'
