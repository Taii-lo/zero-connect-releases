# Unreleased

- 1.0.0-beta.8 (intern v3.0.0-alpha.45): Beta 8: Update zeigt den Fortschritt an und folgt ihm bis zum Neustart; geführte Einrichtung aus Beta 7.
- 1.0.0-beta.7 (intern v3.0.0-alpha.45): Setup guides the Wi-Fi handover; 12 V curve with dates
- 1.0.0-beta.6 (intern v3.0.0-alpha.45): First version for friends: 12 V battery, beta by switch, guarded way back to stable
- 1.0.0-beta.5 (intern v3.0.0-alpha.45): Entwicklungsablauf: Gerätemodus, Kundenstand für den Testgerät-Pi, Übersicht.
- 1.0.0-beta.4 (intern v3.0.0-alpha.45): Oberflächen-Runden: Benachrichtigungen aktivierbar, Orte, Verbindungen, Einstellungen, Assistent.
- 1.0.0-beta.3 (intern v3.0.0-alpha.45): updater ships inside the signed bundle; update path fixes.
- 1.0.0-beta.2 (intern v3.0.0-alpha.45): update area with overnight install, natural wording in German and English, calmer battery graphic.
- 1.0.0-beta.1 (intern v3.0.0-alpha.45): first beta – private encrypted beta channel, signed update channels, own vehicle photo, photos fetched on demand.

## Release metadata and changelog

- Every work item adds one structured entry (category, description, motivation, areas, `req-*` id) to `release_notes.json`, shipped with the release. See `docs/RELEASE_NOTES.md`.
- Settings › Über Zero Connect shows "Neu in dieser Version" for the installed release; revision and requests are in collapsible technical details. Older releases say that no complete release notes exist.
- `zero-autopilot changes` (`--last`, `--history`) shows the installed release; every successful Production deploy records a persistent release entry with gates, work items and request inclusion.
- New files: `release_notes.json`, `zero_release_notes.py` (bundle and installers), device file `release_history.json`. No configuration schema or appliance/image baseline change.

## Current vehicle state and Battery view

- The Overview and the Battery tab (formerly "Laden") show today's vehicle state. A finished charging session is presented for at most 60 minutes after its end, or less once current vehicle data measured after the end shows a lower SoC or an advanced odometer. Stale or pre-completion readings never end it early. History and persisted sessions are unchanged; this affects only the `/api/status` presentation.
- `/api/status` `dashboard` adds `start_soc` (active sessions with a certain start) and `charge_target_soc` (last vehicle-reported target outside a session). After the completion window `state` becomes `connected_idle`, `disconnected` or `idle`; connection is only claimed from current vehicle data. `dashboard_payload()` keeps its previous behaviour unless called with `current_state=True`.
- Battery view: the SoC fill and target marker, plus a qualitative energy-flow animation while charging. The animation has a fixed tempo, respects reduced motion and implies no power, current, voltage, energy or battery-health values.
- Vehicle images are served with content-hash URLs (`?v=<sha256 prefix>`) from `model-assets.json`; only exact versioned URLs are cached immutably. The client shows the last image from the browser cache before the API responds and drops the hint if the image fails.
- The Overview location card no longer repeats "Standort"; it shows the place name and "Letzter Standort · date/time".
- No configuration schema, persistence or appliance/image baseline change.

## Battery view honesty follow-up

- The charge target outside a session is labelled "Ladeziel vermutlich … (geschätzt)" / "Charge target probably …% (estimated)": Zero does not report the setting, the value is the SoC where the last charge stopped. `/api/status` `dashboard` adds `charge_target_source: "inferred"` next to `charge_target_soc`.
- A lower SoC ends the completed-session presentation early only when the same current vehicle data explicitly reports the motorcycle unplugged. While plugged in or with an unknown plug state it stays until odometer progress or the 60-minute expiry.
- The energy-flow animation and "Energie fließt in die Batterie" appear only with current vehicle data; stale data shows the last update time instead.

# Zero Connect 0.9.0-beta.45

Internal version: 3.0.0-alpha.45

## Charging experience and browser activity

- Browser activity is represented by a rate-limited timestamp with no client identifier or location data.
- Active charging Live Activity and dashboard display the vehicle-provided time to target. Balancing elapsed time remains tied to the balancing start.
- No configuration schema or appliance/image baseline change.

## Round 12B — duplicate place-label disambiguation
- Prefer distinct usable road context for colliding automatic charging-location labels.
- Appliance/image baseline remains beta.36.

# Zero Connect 0.9.0-beta.43

Internal version: 3.0.0-alpha.43

## Round 12B — lazy place-label lifecycle fix

- Start the existing bounded charging-location label backfill when the routed Ladeorte page is visible; the route rehomes the content section, so its original disclosure wrapper is not present there.
- Resolve at most one place per API pass. Cache/provider failures skip only that location for the current page visit and allow the next location to be tried after the existing delay.
- Preserve the one-at-a-time provider queue, persisted rate limiter, fallback names and user-entered custom names. Appliance baseline remains beta.36.

# Zero Connect 0.9.0-beta.42

Internal version: 3.0.0-alpha.42

## Round 12B — location UX polish

- Removed the duplicate route action and technical-coordinate disclosure from the Overview location card; the expanded map remains the navigation entry point.
- Charging-location rows now show automatic place labels, retain custom names with geographic context, and keep numbered names only as fallback. Existing IDs, clusters and session associations are unchanged.
- Selecting a list row or map pin now synchronizes the map, selected marker and list disclosure. Last-used dates omit year and seconds in the compact list.
- The existing cache-backed, one-at-a-time charging-location label resolution is reused; provider failures leave fallback names intact. Appliance baseline remains beta.36.

# Zero Connect 0.9.0-beta.41

- Round 12: human-readable vehicle and charging locations, private browser “My location”, fit-both and Google Maps navigation, per-language cached place labels, charging-place names/notes and map summaries. Appliance image baseline remains beta.36.


Internal version: 3.0.0-alpha.41

## Beta 39 charging experience polish

- Aivi charging time now means elapsed charging-session time; balancing duration and completed session duration keep their own timestamp bases. Uncertain starts do not display invented elapsed time. Choose German or English Live Activity text in Aivi settings; old configurations default to German without migration loss.
- A single SOC sample crossing several enabled milestones records every threshold but sends only the highest newly crossed threshold.
- Current charge rate is a fresh, same-generation SOC %/h estimate shown only while active charging. Historical average rate requires explicit measured active duration; no electrical power is inferred.
- Same-day Zero-provided finish estimates use local time only. Notification and balancing copy is clearer in DE/EN.
- Appliance/SD image baseline remains Beta 36; no image build or appliance baseline change is included.

## Beta 38 proactive daily-driver intelligence

- Added a read-only daily-driver context projection to the existing status response. Charging, balancing, completed-while-plugged, location-limit, maintenance, offline and normal states now resolve through one deterministic priority model.
- Added optional post-charge still-plugged and charging-not-started reminders. Both remain off by default, use explicit user-selected delays, require fresh vehicle evidence, persist deduplication through the existing event router, and avoid attributing a cause to the charger or vehicle.
- Added a persisted plug-episode clock based on advancing vehicle contact timestamps. A single false plug sample no longer resets the displayed connected duration or a location time-limit reminder; startup with unknown plug age stays unknown.
- Charging location summaries show average start/end SOC only after at least three linked sessions. No rates, costs, battery health or other unavailable telemetry are inferred.
- Added DE/EN copy for the new context and reminder settings. Appliance/SD image baseline remains Beta 36; this is an app release only and does not include an image build.

## Beta 37 system intelligence and charging

- The Overview gives a current charging phase priority over routine data freshness, distinguishes session duration, connected time and time since completion, and keeps unknown target details out of the hero.
- SOC milestone notifications now detect opted-in 50/60/70/80/90 crossings once per physical session, including jumps and fresh-session recovery without replaying historical crossings.
- A numerical user target is never inferred from Zero's internal phase flag. `100% reached` is sent on the first observed 100% SOC; charging completion remains a separate event.
- Charging locations can save an optional connected-time limit, reminder lead and limit-reached notification. The Observer persists the plug edge, reconciles after restart and deduplicates each stage without asserting a fee.
- Push delivery outcomes now carry the effective preference and are distinct from an explicit Push test. Shared feature-store updates use cross-process locking and atomic durable writes.
- Added a redacted regression fixture from the real 21 September 40→100% session. It contains charging samples and semantic evidence only, without location or identifiers.

## Beta 36 canonical hardware-test SSH key

- Pinned hardware-test image builds and final-image audits to the canonical
  development public key and recorded its fingerprint in build metadata.
- A different local public key now fails before image generation.

## Beta 35 real Pi 3 B+ setup-network validation

- Fixed the two real fresh-setup DHCP blockers found on the Pi 3 B+: the
  captive helper no longer treats `systemctl reset-failed` rejecting an
  inactive static unit as a start failure, and dnsmasq now stores both its
  transient lease database and PID file beneath its explicitly writable,
  strict-sandbox runtime directory.
- Revalidated the complete real AP path with a second WLAN client: wlan0-only
  DHCP assigned 10.42.0.22/24 with router/DNS 10.42.0.1, wildcard captive DNS
  answered locally, and the portal served the UI/API and redirected Apple,
  Android, Windows and arbitrary-host HTTP probes without a loop.
- Confirmed live failed-start recovery and AP handover rollback without
  releasing the hardware-test SSH management channel.

# Zero Connect 0.9.0-beta.34

## Beta 34 hardware-test image stabilization

- Moved temporary setup-AP leases to the dedicated
  `/run/zero-connect/dnsmasq/dnsmasq.leases` path while retaining
  `ProtectSystem=strict`; completed the wlan0-only DHCP, gateway, DNS and
  captive-answer configuration and made failed-service retries recoverable.
- Hardened captive HTTP routing for Apple, Android and Windows probes,
  arbitrary hosts and local API/assets while preserving the existing
  single-radio AP-to-client handover and deterministic Ethernet-first setup.
- Made Avahi the sole mDNS publisher by disabling systemd-resolved mDNS/LLMNR;
  `libnss-mdns` remains intentionally absent because external discovery does
  not require local NSS resolution.
- Corrected RootFS UID/GID 1000 leakage caused by ownership-preserving upstream
  overlays and application asset copies, added a completed-image ownership and
  secrets audit, and protected root-owned dnsmasq policy from the writable
  application configuration path.
- Finalized the opt-in hardware-test profile as Ed25519 key-only SSH with full
  NOPASSWD diagnostic sudo, while keeping the release profile free of the key,
  SSH override and sudo rule.
- Expanded real HTTP, DNS syntax, First-Run, ownership, bundle appliance and
  root-resize command-flow regressions; image builds now require clean pinned
  commits and validate the raw image before compression and hashing.

## Beta 30 image-ready appliance architecture

- Added a separate appliance path layout, system-service installer scaffold,
  explicit factory reset and signed release metadata verification foundation.

## Beta 29 functional first-run cleanup

- Fixed the wizard form-handler overlap that submitted a successful Zero Cloud,
  Wi-Fi or optional-integration action a second time to an invalid generic
  configuration endpoint. Successful transitions now clear stale feedback;
  errors remain bounded and are shown only for actual failed actions.
- Kept the single-radio Wi-Fi handover transport-safe: a browser disconnect
  waits for the existing non-secret recovery status, while a confirmed failed
  handover remains visible.
- Completing First Run now invalidates wizard bootstrap data, fetches the
  normal dashboard immediately, and continues transition-scoped refreshes
  until observer vehicle data is available.

Backlog (not part of Beta 29): visual setup polish, Wi-Fi scan spinner/search
icon, richer progress animation, the pre-selection motorcycle placeholder and
icon/microinteraction work.

## Beta 28 single-radio Wi-Fi handover

- Serialized every privileged NetworkManager mutation with a root-owned
  cross-process lock, so the event watcher cannot preempt an in-progress
  `wlan0` switch from the setup AP to the selected home Wi-Fi.
- The complete handover now stops captive services before switching, verifies
  the exact target profile on the managed Wi-Fi device, removes failed target
  profiles, and restores AP, DNS and portal as one recovery transaction.
- Added a non-secret runtime handover result so a recovered captive session can
  explain a failed password attempt without retaining an SSID or password.
- Made captive service start/stop failure-safe and added final-archive runtime
  gates for handover serialization and partial captive-service failures.
- Fixed iOS wizard layout so hidden steps cannot be reintroduced by CSS, added
  explicit single-radio transition guidance, and replaced the false hardware
  warning with an actionable home-Wi-Fi prompt.
- Upgrades now accept a complete First Run installation without `.env`, retain
  its setup state without inventing credentials, and reject partial trees using
  an installation completion marker plus a strict Beta-27 compatibility check.

## Beta 27 loopback-safe first-run hotspot

- Replaced connection-name based uplink detection with one shared
  `DEVICE,TYPE,STATE,CONNECTION` policy. Only connected normal Wi-Fi or
  Ethernet devices count; loopback, Wi-Fi P2P and the setup AP do not.
- Bound the NetworkManager hotspot profile and dnsmasq to the same validated
  managed Wi-Fi device, including migration of Beta 26 wildcard profiles.
- Moved `CollectMode` to the valid `[Unit]` section and added
  `systemd-analyze verify` plus a loopback-only reboot simulation to the final
  extracted-archive release gate.
- Added a bounded boot autoconnect grace and made privileged rollback restore
  the prior unit states and hotspot profile while stopping captive processes.

## First-run network recovery

- Corrected the accepted-socket activation semantics and added a root-owned,
  NetworkManager-event-driven first-run recovery watcher for the setup AP.

## Release packaging repair

- The fresh-install payload check and copy path now include the root-owned
  NetworkManager helper and captive-portal helper.
- Release validation extracts the final archive into an isolated HOME and runs
  the fresh installer with harmless system-command shims. Missing installer
  inputs or accidental checkout dependencies fail the release gate.

## Minimal-system network provisioning

- Fresh installs provision NetworkManager and the `dnsmasq-base` executable if
  absent, create every Zero Connect system configuration directory explicitly,
  and verify that NetworkManager is active before installing the socket.

## First run and Wi-Fi setup

- The first run is a one-screen-at-a-time mobile wizard with clear back/next navigation and no bottom navigation overlay.
- A selected canonical motorcycle model remains authoritative after Zero Cloud discovery; technical unit identifiers are not used as a display name.
- Completion now uses a restart-safe two-phase marker: an observer restart must succeed before first run is visibly completed.
- Dashboard refresh no longer reports the whole local UI unavailable merely because a non-critical concurrent data request temporarily fails.
- NetworkManager-backed WLAN scanning, connection attempt and retry recovery are available only while the initial setup is active.

## UX/UI

- Mobile Bottom-Navigation mit feiner Akzent-Indicator-Line statt großflächigem aktivem Tab.
- Mobile Header mit zusätzlichem, Safe-Area-aware Abstand für Safari und PWA.
- `zero-deploy` installiert nach vollständig grünem Sicherheitscheck automatisch;
  `--check` prüft ohne Installation und `--force` erlaubt dieselbe Version erneut.
- Blaues, fahrzeugbezogenes Theme mit zentralen Tokens; Warnungen bleiben gelb/orange und Fehler rot.
- Vereinfachte Fahrzeug-, Standort-, Einstellungs- und Systemansichten ohne doppelte Kontakt- oder Erklärungstexte.
- Übersicht mit klarer Fahrzeugdaten-Frische, gemeinsamer System- und Verbindungskachel sowie überarbeiteter iPhone-Navigation.
- Letzte gültige Fahrzeugposition wird lokal persistent als letzter bekannter Standort bewahrt.
- Alltagsfunktionen der lokalen Oberfläche benötigen keine Admin-PIN mehr; die PIN bleibt nur als optionale Experten-API erhalten.
- Neue lokale Zero-Connect-Logo- und PWA-Icon-Familie.

## Beta 16 homescreen web app

- Added a local PWA manifest with standalone launch at the existing overview,
  matching dark theme colors, and local 192 px/512 px Android plus 180 px Apple
  Homescreen icons.
- Added Apple standalone/status-bar metadata while retaining the existing
  viewport-fit and safe-area-aware mobile navigation; no browser-only UI path
  or first-run behavior changed.
- Manifest and icon assets are served with the expected content types and are
  included in the explicit release allowlist and installer completeness check.
- Deliberately added no Service Worker or offline cache. Normal HTTP browser
  access remains supported, while reliable installability on Chromium requires
  HTTPS (or localhost); no Tailscale or HTTPS setup is configured automatically.

## Beta 15 overview polish

- Replaced the generic motorcycle placeholder with a fixed neutral loading
  state; only the three locally bundled SR/S, SR/F and DSR/X product images
  appear after successful loading.
- Replaced the location placeholder with a locally bundled Leaflet map using
  direct OpenStreetMap standard tiles, visible attribution, last-known/stale
  presentation and resilient tile-error handling.
- Precise location and map access now require the existing Admin-PIN session;
  the public status payload continues to expose only timestamp and staleness.
- Documented that OSM tile requests can reveal the requested map area and
  client IP while sending no vehicle or account data as request parameters.
- Tightened map dimensions, safe-area spacing and card behavior for narrow
  mobile viewports without changing observer or integration behavior.

## Beta 14 faster balancing completion

- Added a bounded, overlapping read-only Zero History poll during balancing;
  history events are deduplicated and rate-limit failures back off without
  interrupting the normal Observer loop.
- Qualified `reason=5`/ignition-off events from both Last Transmit and History
  now share a 60-second confirmation window. The Aivi balancing duration freezes
  at that evidence timestamp; charging-off and shutdown-0 remain stronger, and
  undocumented reason codes remain diagnostic-only.
- History failures now record a secret-safe request window, error category and
  HTTP/response metadata for the next field test while retaining backoff.
- Completion summaries distinguish the real balancing-end timestamp from the
  later detection time, and the six-minute sleep fallback now also covers
  confirmed partial targets.

## Beta 12 UI/UX polish

- Enlarged the last-known-location card and kept technical coordinates behind a
  closed local details disclosure; the location is available without PIN and is
  explicitly timestamped as old when stale.
- Added a server-side 20-minute Admin-PIN session with an inline accessible
  dialog, consistent integration states and state-dependent Manage/Set up labels.
- Added a real support-package download flow with opaque short-lived URLs and a
  fixed privacy-safe filename; restart and export feedback now reflects progress.
- Added a compact mobile bottom navigation with all five areas and tightened
  mobile settings/system cards while preserving the desktop tab layout.

## Beta 11 first-run and release hardening

- Added a persistent German/English Web first-run wizard for vehicle, Zero
  Cloud, optional Aivi and optional ABRP setup; secrets are never returned in
  setup responses and the wizard can be reopened from System.
- Fresh installs now prepare safe defaults and start the Web UI without asking
  for credentials on the command line; setup completes in the browser.
- Added an explicit release allowlist builder that uses the updater's manifest
  validator and rejects extra files in a bundle.
- Added hardware-gated Wi-Fi setup orchestration. Hotspot activation remains a
  Raspberry Pi/network-manager validation item and is never automatic merely
  because the module is present.
- Human-readable technical timestamps now use local date/time formatting; raw
  ISO values remain available only in raw technical data.

## Beta 10 tabbed dashboard

- Reorganized the local Web UI into Overview, Charging, History, Settings and
  System tabs on desktop and mobile without changing charging, session or
  integration behavior.
- Replaced the large hero with a compact vehicle card: local model image, SoC,
  state, recent vehicle contact and active charging facts are visible together.
- Added a dedicated charging view with start time, progress, target, balancing
  and visible Aivi Single-Progress context, plus a concise last-session summary.
- Kept normal settings separate from technical diagnostics and system actions;
  all existing protected actions, local assets and German/English texts remain.

## Beta 9 dashboard density and vehicle assets

- Integrated the supplied local Zero SR/S blue, Zero SR/F black and Zero DSR/X
  white vehicle images without external runtime dependencies or duplicate
  source files in the release bundle.
- Added a persistent normal-settings vehicle-model selector with a generic
  local fallback for unknown or unset values.
- Compacted the desktop hero, location, system-health, connection, history and
  advanced-settings cards while retaining the touch-sized mobile controls.
- Added a compact location empty state and a human-readable technical overview;
  raw diagnostic JSON is now behind a second closed disclosure.
- Kept the German/English translation resource as the source for all Beta-9 UI
  labels and preserved the Beta-8 charging and Aivi behavior.

## Beta 8 dashboard and lifecycle

- Rebuilt the local dashboard around a responsive vehicle card, state-specific
  charging information, simple connection health and a separate advanced area.
- Added centralized German/English translations with browser-language detection
  and a persistent manual language switch.
- Added local allowlisted motorcycle assets with a neutral fallback and no
  external image, map, tile or geocoding dependencies.
- Added an always-visible last-known-location card. Exact coordinates remain
  local and are available in the dashboard without external map services.
- Kept recent charging history and Admin-PIN changes available as secondary,
  non-technical dashboard functions.
- Added touch-friendly explanations for balancing, Aivi, ABRP, diagnostics,
  polling/freshness and PIN security in both languages.
- Replaced the production three-activity Aivi flow with one repeatable Progress
  activity covering charging, balancing and the completion summary.
- Added schema-4 to schema-5 migration while preserving historical Monitor slugs
  for a retryable IDLE handoff during upgrade.
- Installer backup, rollback, exact-manifest verification and installation now
  include the complete local `web_assets` tree.

## Beta 7 hardening

- Configuration mutations are serialized across Web requests and report persisted restart failures as service errors.
- Runtime integration resets are atomic, explicit about failures and clear integration-local transport state while preserving charging sessions.
- Admin-only Web actions require the PIN, with bounded lockout tracking for repeated failures.
- Support exports use privacy-focused structured output and omit unsafe raw log content by default.
- Diagnostics limits are shared across setup, validation, Web API and HTML.
- Observer self-tests and failure probes run consistently on Windows and Linux.

## Aivi lifecycle

- Repeatable three-phase Aivi lifecycle: Charging Progress -> Balancing Monitor -> Completion Monitor.
- `zero-connect aivi-test reset` and `zero-connect aivi-test idle` now reset every configured Aivi activity, not only the Progress activity.
- Synthetic Aivi tests reset all activities before starting and perform best-effort cleanup after Ctrl+C.
- Completion summary lifetime is now controlled by Zero Connect (`complete_summary_seconds`, default 600 s). Recommended Aivi Dismissal Delay for all three activities is therefore **immediate**.
- A new charging session immediately closes a still-active completion summary before starting the new Progress activity.
- Balancing elapsed time is displayed minute-by-minute instead of using a second-ticking stopwatch.
- Balancing Monitor layout simplified to Ladeziel + Balancing duration.

## Web UI / UX

- Completely refreshed responsive local Web UI.
- German human-readable charge-state labels instead of internal phase codes.
- Proper local timestamps and relative-age displays.
- Clearer dashboard for battery, charge state, integrations, active session and system health.
- Improved charging history and German completion-source labels.
- Aivi Monitor slugs are preserved even while Legacy Progress mode is selected.
- Aivi UI explains three-phase setup and immediate Dismissal Delay recommendation.
- Admin PIN can be changed from the Web UI.
- Admin PIN is cached only in the current browser page memory after unlocking, reducing repeated prompts.
- Secret values remain write-only and are never returned to the browser.

## Configuration

- Configuration schema 5.
- Added `aivi.complete_summary_seconds` (default 600).
- Added `aivi.balancing_update_seconds` (default 60).
- Existing schema-3 installations migrate automatically without losing credentials or Aivi slugs.

## Regression / safety

- Existing real 65 %, 100 %, balancing-sleep and 24.08.2026 Target-90 -> 97 -> 100 fixtures retained.
- Added checks for minute-granular balancing display and new-session rollover while a completion summary is still active.
- Installer backup and rollback path retained.

- Redeploy of the reviewed cumulative candidate abef64b after the first Production attempt failed only because the controller lacked the browser-smoke interpreter (fixed in 58df3c5).
