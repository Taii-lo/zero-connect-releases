#!/usr/bin/env python3
"""Interactive first-run and targeted reconfiguration wizard for Zero Connect."""

from __future__ import annotations

import argparse
import copy
import getpass
import io
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any

import requests
from dotenv import dotenv_values

import zero_observer as observer
from zero_paths import PATHS

PROJECT_DIR = PATHS.program_dir
ENV_FILE = PATHS.secrets_file
CONFIG_FILE = PATHS.config_file
RUNTIME_STATE_FILE = PATHS.data_dir / "runtime_state_v2.json"
PUBLIC_VERSION = "1.0.0-beta.8"
INTERNAL_VERSION = "3.0.0-alpha.45"
SUPPORTED_VEHICLE_MODELS = ("Zero SR/S", "Zero SR/F", "Zero SR", "Zero S", "Zero DS", "Zero DSR", "Zero DSR/X")
# Colors with a photo per model; the first entry is the default. Keys stay stable
# once shipped (they are saved in the config); the visible names live in i18n.json.
VEHICLE_COLORS = {
    "Zero SR/S": ("blue", "riviera", "asphalt", "steelblue", "thermal", "skyline", "aileron"),
    "Zero SR/F": ("black", "thermal", "jetblack", "silver", "mint", "red", "jetblackgold"),
    "Zero SR": ("thermal", "graphite"),
    "Zero S": ("jetblack", "white", "silver", "twilight"),
    "Zero DS": ("quicksand", "orange"),
    "Zero DSR": ("graphite", "silver", "black", "blackforest"),
    "Zero DSR/X": ("white", "silver", "sand", "blue", "sage", "blackeffect", "blackforest"),
}
# The wizard asks only what everybody needs. Aivi and ABRP live in Settings -> Connections;
# their steps are still accepted from older clients and saved wizard states.
SETUP_STEPS = ("welcome", "vehicle", "zero_cloud", "complete")
LEGACY_SETUP_STEPS = ("aivi", "abrp")


class SetupError(ValueError):
    """A setup problem the user can fix; ``code`` selects the translated message in the app."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class SetupCancelled(RuntimeError):
    """A configuration section was cancelled without modifying persisted data."""


class PersistenceError(RuntimeError):
    """A configuration write failed, optionally leaving a partial new state."""

    def __init__(self, message: str, *, partially_persisted: bool = False) -> None:
        super().__init__(message)
        self.partially_persisted = partially_persisted


def env_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def load_existing_env() -> dict[str, str]:
    if not ENV_FILE.exists():
        return {}
    # Undecodable bytes (a damaged sector) must not stop the web UI; intact lines still count.
    text = ENV_FILE.read_bytes().decode("utf-8", errors="replace")
    return {str(k): str(v or "") for k, v in dotenv_values(stream=io.StringIO(text)).items()}


def has_valid_zero_cloud_config(env: dict[str, str]) -> bool:
    return bool(
        str(env.get("ZERO_CLOUD_USER", "")).strip()
        and str(env.get("ZERO_CLOUD_PASSWORD", "")).strip()
        and str(env.get("ZERO_UNIT_NUMBER", "")).strip()
    )


def is_first_run(env: dict[str, str], config: dict[str, Any]) -> bool:
    setup_cfg = config.get("setup", {}) if isinstance(config.get("setup", {}), dict) else {}
    if bool(setup_cfg.get("forced", False)):
        return True
    if bool(setup_cfg.get("wizard_started", False)) and not bool(setup_cfg.get("completed", False)):
        return True
    # A pre-Beta-11 installation with a valid cloud contract is already set up.
    return not has_valid_zero_cloud_config(env)


def setup_status(env: dict[str, str], config: dict[str, Any]) -> dict[str, Any]:
    setup_cfg = config.get("setup", {}) if isinstance(config.get("setup", {}), dict) else {}
    cloud = has_valid_zero_cloud_config(env)
    completed = bool(setup_cfg.get("completed", False)) and cloud and not bool(setup_cfg.get("forced", False))
    return {
        "first_run": is_first_run(env, config),
        "completed": completed,
        "wizard_open": is_first_run(env, config),
        "step": current_setup_step(setup_cfg),
        "vehicle_model": str(config.get("vehicle_model", "Zero Motorcycle")),
        "vehicle_color": str(config.get("vehicle_color", "")),
        "vehicle_label": str(config.get("vehicle_label", "Zero Motorcycle")),
        "zero_cloud": {"connected": cloud, "credentials_set": cloud},
        "aivi": {
            "enabled": bool(config.get("aivi", {}).get("enabled", False)) and bool(env.get("AIVI_API_TOKEN")),
            "configured": bool(env.get("AIVI_API_TOKEN") and env.get("AIVI_ACTIVITY_SLUG")),
        },
        "abrp": {
            "enabled": bool(config.get("abrp", {}).get("enabled", False)) and bool(env.get("ABRP_TOKEN")),
            "configured": bool(env.get("ABRP_TOKEN") and env.get("ABRP_API_KEY")),
        },
        "supported_models": list(SUPPORTED_VEHICLE_MODELS),
        # A wizard reopened from Settings on a working device can be left again.
        "can_cancel": bool(setup_cfg.get("reopened", False)) and cloud and is_first_run(env, config),
    }


def current_setup_step(setup_cfg: dict[str, Any]) -> str:
    step = str(setup_cfg.get("step", "welcome"))
    if step in LEGACY_SETUP_STEPS:
        return "complete"
    return step if step in SETUP_STEPS else "welcome"


def reopen_wizard(config: dict[str, Any]) -> None:
    setup_cfg = config.setdefault("setup", {})
    setup_cfg.update(completed=False, forced=True, wizard_started=True, step="welcome", reopened=True)


def cancel_reopened_wizard(config: dict[str, Any]) -> dict[str, Any]:
    """Leave a wizard reopened from Settings; the existing connection stays as it was."""
    env = load_existing_env()
    if not (bool(config.get("setup", {}).get("reopened", False)) and has_valid_zero_cloud_config(env)):
        raise SetupError("cancel_unavailable", "Die Einrichtung kann erst nach der Zero-Cloud-Verbindung beendet werden.")
    config.setdefault("setup", {}).update(completed=True, forced=False, wizard_started=True, step="complete", reopened=False)
    write_config(config)
    return setup_status(env, config)


def previous_setup_step(config: dict[str, Any]) -> dict[str, Any]:
    """Move within an already started wizard without altering credentials."""
    current = current_setup_step(config.get("setup", {}))
    index = SETUP_STEPS.index(current)
    setup_cfg = config.setdefault("setup", {})
    setup_cfg.update(wizard_started=True, completed=False, step=SETUP_STEPS[max(0, index - 1)])
    write_config(config)
    return setup_status(load_existing_env(), config)


def verify_zero_cloud(
    username: str,
    password: str,
    unit_number: str = "",
    timeout: float = 30,
) -> dict[str, str]:
    if not username or not password:
        raise SetupError("cloud_missing", "Zero-Cloud E-Mail und Passwort sind erforderlich.")
    session = requests.Session()
    vehicles = observer.request_zero(session, "get_units", username, password, timeout)
    usable = [v for v in vehicles if isinstance(v, dict) and str(v.get("unitnumber", "")).strip()]
    if not usable:
        raise SetupError("cloud_no_vehicle", "Zero Cloud erreichbar, aber kein verwendbares Fahrzeug gefunden.")
    selected = next(
        (vehicle for vehicle in usable if str(vehicle.get("unitnumber", "")).strip() == unit_number.strip()),
        usable[0],
    )
    selected_unit = str(selected.get("unitnumber", "")).strip()
    observer.request_zero(
        session, "get_last_transmit", username, password, timeout, unitnumber=selected_unit
    )
    return {
        "unit_number": selected_unit,
        "vehicle_model": observer.vehicle_model_label(selected),
        "vehicle_label": observer.vehicle_display_label(selected),
    }


def test_abrp(token: str, api_key: str, timeout: float = 15) -> None:
    if not token or not api_key:
        raise SetupError("abrp_missing", "ABRP User Token und API-Key sind erforderlich.")
    try:
        response = requests.get(
            observer.ABRP_API_URL,
            params={"token": token, "api_key": api_key},
            timeout=timeout,
        )
    except requests.RequestException as exc:
        raise SetupError("abrp_unreachable", "ABRP ist nicht erreichbar.") from exc
    if response.status_code in {401, 403}:
        raise SetupError("abrp_rejected", "ABRP-Zugangsdaten wurden abgelehnt.")
    if response.status_code >= 500:
        raise SetupError("abrp_unavailable", "ABRP ist derzeit nicht verfügbar.")


def apply_setup_step(
    step: str,
    body: dict[str, Any],
    env: dict[str, str],
    config: dict[str, Any],
) -> dict[str, Any]:
    if step not in SETUP_STEPS + LEGACY_SETUP_STEPS:
        raise ValueError("Unbekannter Einrichtungs-Schritt.")
    setup_cfg = config.setdefault("setup", {})
    setup_cfg.update(wizard_started=True, forced=False)
    if step == "vehicle":
        model = str(body.get("vehicle_model", "")).strip()
        if model not in SUPPORTED_VEHICLE_MODELS:
            raise SetupError("vehicle_required", "Bitte ein unterstütztes Fahrzeugmodell auswählen.")
        config["vehicle_model"] = model
        config["vehicle_label"] = model
        setup_cfg["step"] = "zero_cloud"
    elif step == "zero_cloud":
        username = str(body.get("username", "")).strip()
        password = str(body.get("password", ""))
        result = verify_zero_cloud(
            username,
            password,
            str(body.get("unit_number", "")).strip(),
            float(config.get("request_timeout_seconds", 30)),
        )
        env.update(
            ZERO_CLOUD_USER=username,
            ZERO_CLOUD_PASSWORD=password,
            ZERO_UNIT_NUMBER=result["unit_number"],
        )
        # The model selected in the previous wizard screen is authoritative.
        # Cloud payloads can contain a generic model or an internal identifier;
        # neither may replace the user-facing model choice.
        selected_model = str(config.get("vehicle_model", "")).strip()
        if selected_model not in SUPPORTED_VEHICLE_MODELS:
            detected_model = str(result.get("vehicle_model", "")).strip()
            config["vehicle_model"] = (
                detected_model if detected_model in SUPPORTED_VEHICLE_MODELS else "Zero SR/S"
            )
        config["vehicle_label"] = str(config["vehicle_model"])
        setup_cfg["step"] = "complete"
    elif step == "aivi":
        enabled = bool(body.get("enabled", False))
        aivi = config.setdefault("aivi", {})
        if enabled:
            token = str(body.get("token", "")).strip()
            slug = str(body.get("progress_slug", aivi.get("activity_slug", "zero-connect"))).strip()
            if not token or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", slug):
                raise SetupError("aivi_missing", "Aivi-Token und ein gültiger Progress-Name sind erforderlich.")
            test_aivi(token, slug, float(aivi.get("request_timeout_seconds", 15)), "progress")
            env["AIVI_API_TOKEN"] = token
            env["AIVI_ACTIVITY_SLUG"] = slug
            aivi.update(enabled=True, mode="single_progress", activity_slug=slug)
        else:
            env.pop("AIVI_API_TOKEN", None)
            env.pop("AIVI_ACTIVITY_SLUG", None)
            aivi.update(enabled=False, mode="single_progress")
        setup_cfg["step"] = "complete"
    elif step == "abrp":
        enabled = bool(body.get("enabled", False))
        abrp = config.setdefault("abrp", {})
        if enabled:
            token = str(body.get("token", "")).strip()
            api_key = str(body.get("api_key", "")).strip()
            test_abrp(token, api_key, float(config.get("request_timeout_seconds", 30)))
            env["ABRP_TOKEN"] = token
            env["ABRP_API_KEY"] = api_key
            abrp["enabled"] = True
        else:
            env.pop("ABRP_TOKEN", None)
            env.pop("ABRP_API_KEY", None)
            abrp["enabled"] = False
        setup_cfg["step"] = "complete"
    elif step == "complete":
        if not has_valid_zero_cloud_config(env):
            raise SetupError("cloud_missing", "Bitte zuerst die Zero-Cloud-Verbindung einrichten.")
        setup_cfg.update(completed=True, forced=False, wizard_started=True, step="complete", reopened=False)
    else:
        setup_cfg["step"] = "vehicle"
    persist_config_and_env(env, config)
    return setup_status(env, config)


def prepare_setup_completion(env: dict[str, str], config: dict[str, Any]) -> None:
    """Persist a restart-safe pre-completion state without ending first run."""
    if not has_valid_zero_cloud_config(env):
        raise SetupError("cloud_missing", "Bitte zuerst die Zero-Cloud-Verbindung einrichten.")
    setup_cfg = config.setdefault("setup", {})
    setup_cfg.update(completed=False, forced=False, wizard_started=True, step="complete")
    persist_config_and_env(env, config)


def mark_setup_completed(env: dict[str, str], config: dict[str, Any]) -> dict[str, Any]:
    """Commit the visible completion marker only after all required work succeeded."""
    setup_cfg = config.setdefault("setup", {})
    setup_cfg.update(completed=True, forced=False, wizard_started=True, step="complete", reopened=False)
    persist_config_and_env(env, config)
    return setup_status(env, config)


def write_env(values: dict[str, str]) -> None:
    order = [
        "ZERO_CLOUD_USER",
        "ZERO_CLOUD_PASSWORD",
        "ZERO_UNIT_NUMBER",
        "AIVI_API_TOKEN",
        "AIVI_ACTIVITY_SLUG",
        "ABRP_TOKEN",
        "ABRP_API_KEY",
    ]
    lines = [f"{key}={env_string(values[key])}" for key in order if values.get(key)]
    _durable_write(ENV_FILE.with_name(".env.tmp"), ENV_FILE, "\n".join(lines).rstrip() + "\n")


def load_config() -> dict[str, Any]:
    return observer.load_config(CONFIG_FILE)


def _durable_write(temporary: Path, target: Path, text: str) -> None:
    """Write via a temporary file that reaches the disk before it replaces the target,
    so a power loss right after saving cannot leave an empty file behind."""
    with temporary.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.chmod(0o600)
    temporary.replace(target)
    target.chmod(0o600)
    try:
        directory = os.open(target.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except OSError:
        pass


def write_config(config: dict[str, Any]) -> None:
    config = observer.deep_merge(observer.DEFAULT_CONFIG, observer.migrate_config(config))
    observer.validate_config(config)
    text = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
    backup = observer.config_backup_path(CONFIG_FILE)
    # The intact copy goes first: whichever write a power loss interrupts, one file is whole.
    try:
        _durable_write(backup.with_name(backup.name + ".tmp"), backup, text)
    except OSError:
        pass
    _durable_write(CONFIG_FILE.with_suffix(".json.tmp"), CONFIG_FILE, text)


def ensure_config_backup() -> None:
    """Older installs have no intact copy yet; create it from a configuration that loads."""
    backup = observer.config_backup_path(CONFIG_FILE)
    if backup.exists() or not CONFIG_FILE.exists():
        return
    try:
        observer._parse_config_file(CONFIG_FILE)
        _durable_write(backup.with_name(backup.name + ".tmp"), backup, CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, RuntimeError):
        pass


def _read_persisted_bytes(path: Path) -> bytes | None:
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise PersistenceError(
            f"Bestehende Konfiguration konnte nicht gelesen werden: {exc}"
        ) from exc


def _restore_persisted_bytes(path: Path, content: bytes | None) -> None:
    temporary = path.with_name(path.name + ".rollback.tmp")
    try:
        if content is None:
            path.unlink(missing_ok=True)
            return
        temporary.write_bytes(content)
        temporary.chmod(0o600)
        temporary.replace(path)
        path.chmod(0o600)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def persist_config_and_env(existing: dict[str, str], config: dict[str, Any]) -> None:
    original_config = _read_persisted_bytes(CONFIG_FILE)
    original_env = _read_persisted_bytes(ENV_FILE)
    backup = observer.config_backup_path(CONFIG_FILE)
    original_backup = _read_persisted_bytes(backup)
    try:
        write_config(config)
        write_env(existing)
    except Exception as exc:
        try:
            _restore_persisted_bytes(CONFIG_FILE, original_config)
            _restore_persisted_bytes(ENV_FILE, original_env)
            _restore_persisted_bytes(backup, original_backup)
        except OSError as rollback_exc:
            raise PersistenceError(
                "Konfiguration konnte nicht vollständig gespeichert werden; "
                f"auch das Zurücksetzen des alten Stands ist fehlgeschlagen: {rollback_exc}",
                partially_persisted=True,
            ) from exc
        for temporary in (
            CONFIG_FILE.with_suffix(".json.tmp"),
            ENV_FILE.with_name(".env.tmp"),
        ):
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        raise PersistenceError(
            "Konfiguration konnte nicht vollständig gespeichert werden; "
            f"der alte Stand wurde zurückgesetzt: {exc}"
        ) from exc


def persist(existing: dict[str, str], config: dict[str, Any]) -> None:
    persist_config_and_env(existing, config)
    print("[✓] Konfiguration gespeichert (.env 600)")


def ask_secret(label: str, existing: str = "") -> str:
    suffix = " [Enter = vorhanden behalten]" if existing else ""
    value = getpass.getpass(label + suffix + ": ").strip()
    return value or existing


def ask_int(prompt: str, default: int, minimum: int, maximum: int) -> int:
    while True:
        answer = input(f"{prompt} [{default}]: ").strip()
        if not answer:
            return default
        try:
            value = int(answer)
        except ValueError:
            value = minimum - 1
        if minimum <= value <= maximum:
            return value
        print(f"Bitte eine Zahl zwischen {minimum} und {maximum} eingeben.")


def choose_menu(title: str, entries: list[tuple[str, str]], default: str) -> str:
    """Return the key of a compact numbered menu."""
    print(title)
    for key, label in entries:
        marker = " (Standard)" if key == default else ""
        print(f"  {key}. {label}{marker}")
    valid = {key for key, _ in entries}
    while True:
        answer = input(f"Auswahl [{default}]: ").strip() or default
        if answer in valid:
            return answer
        print("Bitte eine der angezeigten Optionen wählen.")


def reset_integration_runtime_state(
    *,
    aivi: bool = False,
    abrp: bool = False,
    preserve_legacy_aivi_handoff: bool = False,
) -> bool:
    if not (aivi or abrp):
        return True
    try:
        state = json.loads(RUNTIME_STATE_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return True
    except OSError as exc:
        raise RuntimeError(f"Runtime-State konnte nicht gelesen werden: {exc}") from exc
    except ValueError as exc:
        raise RuntimeError(f"Runtime-State enthält ungültiges JSON: {exc}") from exc
    if not isinstance(state, dict):
        raise RuntimeError("Runtime-State enthält kein JSON-Objekt.")
    if aivi:
        aivi_reset = {
            "last_live_activity_success_epoch": 0.0,
            "last_live_activity_action": "",
            "last_live_activity_error": "",
            "live_activity_real_update_count": 0,
            "live_activity_intermediate_update_count": 0,
            "aivi_consecutive_errors": 0,
            "aivi_next_retry_epoch": 0.0,
            "live_activity_active": False,
            "live_activity_session_generation": -1,
            "live_activity_last_payload_fingerprint": "",
            "live_activity_last_phase": "",
            "live_activity_last_update_epoch": 0.0,
            "live_activity_final_sent": False,
            "live_activity_idle_due_epoch": 0.0,
            "live_activity_idle_payload": None,
            "live_activity_idle_sent": False,
            "live_activity_intermediate_due_epoch": 0.0,
            "live_activity_intermediate_payload": None,
            "live_activity_intermediate_session_generation": -1,
            "live_activity_balancing_display_bucket": -1,
            "three_phase_active_kind": "",
            "three_phase_active_slug": "",
            "three_phase_active_payload": None,
            "three_phase_session_generation": -1,
            "three_phase_complete_started_generation": -1,
            "three_phase_idle_due_epoch": 0.0,
            "three_phase_idle_payload": None,
            "three_phase_idle_slug": "",
            "three_phase_idle_sent": False,
            "three_phase_balancing_display_bucket": -1,
            "live_activity_closed_for_session": False,
        }
        if preserve_legacy_aivi_handoff:
            for key in tuple(aivi_reset):
                if key.startswith("three_phase_"):
                    aivi_reset.pop(key)
        for key, value in aivi_reset.items():
            state[key] = value
    if abrp:
        for key, value in {
            "last_abrp_send_epoch": 0.0,
            "last_abrp_fingerprint": "",
            "last_abrp_success_epoch": 0.0,
            "last_abrp_error": "",
            "abrp_consecutive_errors": 0,
            "abrp_next_retry_epoch": 0.0,
        }.items():
            state[key] = value
    temporary = RUNTIME_STATE_FILE.with_suffix(".json.tmp")
    try:
        temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.chmod(0o600)
        temporary.replace(RUNTIME_STATE_FILE)
        RUNTIME_STATE_FILE.chmod(0o600)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise RuntimeError(f"Runtime-State konnte nicht geschrieben werden: {exc}") from exc
    return True


def service_is_active(name: str = "zero-observer.service") -> bool:
    try:
        result = subprocess.run(
            PATHS.service_command("is-active", name),
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(f"Observer-Status konnte nicht geprüft werden: {exc}") from exc
    state = result.stdout.strip().lower()
    error = result.stderr.strip()
    if result.returncode == 0 and state == "active" and not error:
        return True
    if state in {"inactive", "failed"} and not error:
        return False
    detail = error or state or f"Exit-Code {result.returncode} ohne Statusausgabe"
    raise RuntimeError(f"Observer-Status konnte nicht zuverlässig geprüft werden: {detail}")


def run_observer_service_action(action: str) -> bool:
    labels = {
        "stop": "gestoppt",
        "start": "gestartet",
        "restart": "neu gestartet",
    }
    if action not in labels:
        raise ValueError(f"Unbekannte Observer-Serviceaktion: {action}")
    try:
        result = subprocess.run(
            PATHS.service_command(action, "zero-observer.service"),
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(f"Observer konnte nicht {labels[action]} werden: {exc}") from exc
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        suffix = f": {detail}" if detail else "."
        raise RuntimeError(f"Observer konnte nicht {labels[action]} werden{suffix}")
    return True


def apply_runtime_reset_and_restart(
    *,
    aivi: bool = False,
    abrp: bool = False,
    configuration_persisted: bool = False,
    preserve_legacy_aivi_handoff: bool = False,
) -> bool:
    def operation_error(message: str) -> RuntimeError:
        if configuration_persisted:
            return RuntimeError(f"Konfiguration wurde gespeichert, aber {message}")
        return RuntimeError(message)

    try:
        was_active = service_is_active()
    except RuntimeError as exc:
        raise operation_error(str(exc)) from exc
    if was_active and (aivi or abrp):
        try:
            run_observer_service_action("stop")
        except RuntimeError as exc:
            raise operation_error(str(exc)) from exc
    try:
        reset_kwargs = {"aivi": aivi, "abrp": abrp}
        if preserve_legacy_aivi_handoff:
            reset_kwargs["preserve_legacy_aivi_handoff"] = True
        reset_succeeded = reset_integration_runtime_state(**reset_kwargs)
        if not reset_succeeded:
            raise RuntimeError("Runtime-Reset meldete keinen Erfolg.")
    except RuntimeError as exc:
        if was_active:
            try:
                run_observer_service_action("start")
                if not service_is_active():
                    raise RuntimeError("Observer ist nach dem Recovery-Start nicht aktiv.")
            except RuntimeError as recovery_exc:
                raise operation_error(
                    f"Runtime-Reset fehlgeschlagen: {exc} "
                    f"Recovery-Start fehlgeschlagen: {recovery_exc}"
                ) from exc
            raise operation_error(
                f"Runtime-Reset fehlgeschlagen: {exc} "
                "Observer wurde kontrolliert wieder gestartet."
            ) from exc
        raise operation_error(f"Runtime-Reset fehlgeschlagen: {exc}") from exc
    if was_active:
        action = "start" if (aivi or abrp) else "restart"
        try:
            run_observer_service_action(action)
            if not service_is_active():
                raise RuntimeError("Observer ist nach dem Start nicht aktiv.")
        except RuntimeError as exc:
            raise operation_error(str(exc)) from exc
        print("[✓] Observer neu gestartet")
    return True


def vehicle_details(vehicle: dict[str, Any], index: int) -> str:
    label = observer.vehicle_display_label(vehicle, index)
    unit = str(vehicle.get("unitnumber", "")).strip() or "?"
    vin = ""
    for key in ("vin", "VIN", "vehiclevin"):
        value = str(vehicle.get(key, "")).strip()
        if value:
            vin = value
            break
    detail = f"{label} · Unit {unit}"
    if vin:
        detail += f" · VIN …{vin[-6:]}"
    return detail


def choose_vehicle(vehicles: list[Any], existing_unit: str) -> dict[str, Any]:
    usable = [v for v in vehicles if isinstance(v, dict) and str(v.get("unitnumber", "")).strip()]
    if not usable:
        raise RuntimeError("Im Zero-Konto wurde kein verwendbares Fahrzeug gefunden.")
    if len(usable) == 1:
        print(f"[✓] Fahrzeug erkannt: {vehicle_details(usable[0], 1)}")
        return usable[0]

    print(f"[✓] {len(usable)} Fahrzeuge im Zero-Konto gefunden:")
    default_index = 1
    for index, vehicle in enumerate(usable, start=1):
        marker = ""
        if str(vehicle.get("unitnumber", "")).strip() == existing_unit:
            default_index = index
            marker = "  ← aktuell"
        print(f"    {index}. {vehicle_details(vehicle, index)}{marker}")
    while True:
        answer = input(f"Fahrzeug auswählen [{default_index}]: ").strip()
        if not answer:
            return usable[default_index - 1]
        try:
            selected = int(answer)
        except ValueError:
            selected = 0
        if 1 <= selected <= len(usable):
            return usable[selected - 1]
        print("Ungültige Auswahl.")


def print_zero_help() -> None:
    print("\nZero Cloud")
    print("  Verwende die E-Mail-Adresse und das Passwort deines Zero-Kontos.")
    print("  Die Zugangsdaten werden nur lokal in ~/zero-connect/.env mit Dateirechten 600 gespeichert.")
    print("  Erst nach erfolgreicher Anmeldung wird eine geänderte Konfiguration übernommen.\n")


def zero_session_and_vehicle(
    existing: dict[str, str], config: dict[str, Any], prompt_credentials: bool
) -> tuple[requests.Session, dict[str, Any], str, str]:
    existing_user = existing.get("ZERO_CLOUD_USER", "")
    existing_password = existing.get("ZERO_CLOUD_PASSWORD", "")

    while True:
        if prompt_credentials or not existing_user or not existing_password:
            prompt = f"Zero-Cloud E-Mail [{existing_user}]: " if existing_user else "Zero-Cloud E-Mail: "
            username = input(prompt).strip() or existing_user
            password = ask_secret("Zero-Cloud Passwort", existing_password)
        else:
            username, password = existing_user, existing_password

        if not username or not password:
            print("[✗] E-Mail-Adresse und Passwort sind erforderlich.")
        else:
            print("Zero Cloud wird geprüft …")
            session = requests.Session()
            try:
                vehicles = observer.request_zero(
                    session,
                    "get_units",
                    username,
                    password,
                    float(config["request_timeout_seconds"]),
                )
                if not isinstance(vehicles, list) or not vehicles:
                    raise RuntimeError("Zero Cloud erreichbar, aber kein Fahrzeug gefunden.")
                vehicle = choose_vehicle(vehicles, existing.get("ZERO_UNIT_NUMBER", ""))
                print("[✓] Zero Cloud verbunden")
                return session, vehicle, username, password
            except (RuntimeError, requests.RequestException) as error:
                print(f"[✗] Zero Cloud konnte nicht verbunden werden: {error}")

        if not prompt_credentials:
            raise SetupCancelled("Zero-Cloud-Prüfung abgebrochen.")
        entries = [("1", "Erneut versuchen"), ("2", "Hilfe"), ("3", "Abbrechen")]
        choice = choose_menu("Wie möchtest du fortfahren?", entries, "1")
        if choice == "2":
            print_zero_help()
            continue
        if choice == "3":
            raise SetupCancelled("Bestehende Zero-Konfiguration wurde nicht verändert.")


def fetch_current_status(
    session: requests.Session,
    username: str,
    password: str,
    unit_number: str,
    config: dict[str, Any],
) -> dict[str, Any] | None:
    try:
        transmit = observer.request_zero(
            session,
            "get_last_transmit",
            username,
            password,
            float(config["request_timeout_seconds"]),
            unitnumber=unit_number,
        )
        if isinstance(transmit, list) and transmit and isinstance(transmit[0], dict):
            status = transmit[0]
            soc = observer.to_float_or_none(status.get("soc"))
            suffix = f" · SoC {soc:.0f} %" if soc is not None else ""
            print(f"[✓] Fahrzeugdaten abrufbar{suffix}")
            return status
    except RuntimeError as error:
        print(f"[!] Letzter Fahrzeugdatensatz momentan nicht abrufbar: {error}")
    return None


def configure_vehicle(
    existing: dict[str, str], config: dict[str, Any], prompt_credentials: bool = True
) -> dict[str, Any] | None:
    session, vehicle, username, password = zero_session_and_vehicle(existing, config, prompt_credentials)
    unit_number = str(vehicle["unitnumber"]).strip()
    detected_label = observer.vehicle_display_label(vehicle)
    current_label = str(config.get("vehicle_label", "")).strip()
    default_label = current_label if current_label and current_label != "Zero Motorcycle" else detected_label
    label = input(f"Anzeigename [{default_label}]: ").strip() or default_label

    # Only mutate the candidate configuration after the credentials have been verified.
    existing["ZERO_CLOUD_USER"] = username
    existing["ZERO_CLOUD_PASSWORD"] = password
    existing["ZERO_UNIT_NUMBER"] = unit_number
    config["vehicle_label"] = label
    config["vehicle_model"] = observer.vehicle_model_label(vehicle)
    return fetch_current_status(session, username, password, unit_number, config)


def best_effort_current_status(existing: dict[str, str], config: dict[str, Any]) -> dict[str, Any] | None:
    username = existing.get("ZERO_CLOUD_USER", "")
    password = existing.get("ZERO_CLOUD_PASSWORD", "")
    unit_number = existing.get("ZERO_UNIT_NUMBER", "")
    if not username or not password or not unit_number:
        return None
    try:
        session = requests.Session()
        transmit = observer.request_zero(
            session,
            "get_last_transmit",
            username,
            password,
            float(config["request_timeout_seconds"]),
            unitnumber=unit_number,
        )
        if isinstance(transmit, list) and transmit and isinstance(transmit[0], dict):
            return transmit[0]
    except RuntimeError:
        pass
    return None


def print_aivi_help() -> None:
    print("\nAivi Live Activity")
    print("  Lege in Aivi genau eine Activity mit dem Template Progress an.")
    print("  Zero Connect verwendet sie durchgehend für Laden, Balancing und")
    print("  die Abschlusszusammenfassung. Stelle den Dismissal Delay in Aivi")
    print("  auf 'sofort'; Zero Connect steuert die Anzeigedauer selbst.\n")


def print_abrp_help() -> None:
    print("\nABRP-Telemetrie")
    print("  ABRP (A Better Routeplanner) kann aktuelle Fahrzeugdaten für Planung")
    print("  und Live-Telemetrie erhalten. Die aktuelle Beta verwendet dafür manuell")
    print("  bereitgestellten User Token + Telemetry API-Key; das sind keine normalen")
    print("  ABRP-Login-Daten. Du kannst ABRP jederzeit später mit")
    print("  'zero-connect configure abrp' einrichten.\n")


def test_aivi(token: str, slug: str, timeout: float, template: str = "progress") -> None:
    if template == "monitor":
        payload = {
            "state": "IDLE",
            "content": {
                "template": "monitor",
                "icon": "checkmark.circle.fill",
                "left_column": {
                    "header": "ZERO CONNECT",
                    "value": {"value": "Bereit", "text_color": "green"},
                    "footer": "Verbindung geprüft",
                },
                "primary_column": "left",
            },
        }
    else:
        payload = {
            "state": "IDLE",
            "content": {
                "template": "progress",
                "icon": {
                    "name": "checkmark.circle.fill",
                    "rendering_mode": "hierarchical",
                    "primary_color": "green",
                    "color_rendering": "gradient",
                },
                "header_left": {"value": "✓", "text_color": "green"},
                "header_right": {"value": "Bereit"},
                "progress": {"style": "simple", "value": 0.0, "color": "green"},
                "footer_left": {"value": "Zero Connect verbunden", "text_color": "gray"},
                "footer_right": {"value": "", "text_color": "gray"},
                "compact_value": {"value": "✓"},
            },
        }
    observer.send_aivi_activity(payload, token, slug, timeout)


def print_aivi_dismissal_hint() -> None:
    print(
        "[i] Empfehlung: Dismissal Delay in Aivi bei allen verwendeten Activities "
        "auf 'sofort' stellen; Zero Connect steuert die Abschlussanzeige selbst."
    )


def configure_aivi(
    existing: dict[str, str],
    config: dict[str, Any],
    current_status: dict[str, Any] | None = None,
) -> bool:
    aivi_cfg = config.setdefault("aivi", {})
    old_enabled = bool(aivi_cfg.get("enabled", False))
    old_token = existing.get("AIVI_API_TOKEN", "")
    old_env_slug = existing.get("AIVI_ACTIVITY_SLUG", "")
    old_slug = old_env_slug or str(aivi_cfg.get("activity_slug", ""))
    old_mode = str(aivi_cfg.get("mode", "single_progress"))

    while True:
        if old_enabled:
            choice = choose_menu(
                "Aivi Live Activity:",
                [("1", "Beibehalten / neu einrichten"), ("2", "Deaktivieren"), ("3", "Hilfe")],
                "1",
            )
        else:
            choice = choose_menu(
                "Aivi Live Activity (optional):",
                [("1", "Jetzt einrichten"), ("2", "Später"), ("3", "Hilfe")],
                "2",
            )
        if choice == "3":
            print_aivi_help()
            continue
        if choice == "2":
            aivi_cfg["enabled"] = False
            existing.pop("AIVI_API_TOKEN", None)
            existing.pop("AIVI_ACTIVITY_SLUG", None)
            if old_enabled or old_token or old_env_slug:
                print("[✓] Aivi deaktiviert; gespeicherte Aivi-Zugangsdaten entfernt")
            else:
                print("[-] Aivi wird später eingerichtet")
            return old_enabled or bool(old_token) or bool(old_env_slug)
        break

    while True:
        token = ask_secret("Aivi API-Token", old_token)
        default_slug = old_slug or "zero-connect"
        slug = input(f"Progress-Slug für Laden [{default_slug}]: ").strip() or default_slug
        if not token:
            error = "kein API-Token angegeben"
        elif not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", slug or ""):
            error = "Slugs dürfen nur Buchstaben, Zahlen, - und _ enthalten"
        else:
            error = ""

        if not error:
            if current_status is None:
                current_status = best_effort_current_status(existing, config)
            current_phase = observer.classify_charge_phase(current_status, None, config) if current_status else "unknown"
            try:
                if current_phase in {"charging", "target_reached"}:
                    print("[!] Aktive Ladesitzung: Verbindungstest wird übersprungen.")
                else:
                    print("Aivi wird geprüft …")
                    timeout = float(aivi_cfg["request_timeout_seconds"])
                    test_aivi(token, slug, timeout, "progress")
                aivi_cfg["enabled"] = True
                aivi_cfg["activity_slug"] = slug
                aivi_cfg["mode"] = "single_progress"
                existing["AIVI_API_TOKEN"] = token
                existing["AIVI_ACTIVITY_SLUG"] = slug
                print("[✓] Aivi konfiguriert · eine Progress-Aktivität")
                print_aivi_dismissal_hint()
                return (
                    (not old_enabled) or token != old_token or slug != old_slug
                    or old_mode != "single_progress"
                )
            except (RuntimeError, requests.RequestException) as exc:
                error = str(exc)

        print(f"[✗] Aivi konnte nicht eingerichtet werden: {error}")
        action = choose_menu(
            "Wie möchtest du fortfahren?",
            [("1", "Erneut versuchen"), ("2", "Später einrichten"), ("3", "Hilfe")],
            "1",
        )
        if action == "3":
            print_aivi_help()
            continue
        if action == "2":
            if old_enabled and old_token and old_slug:
                aivi_cfg["enabled"] = True
                aivi_cfg["activity_slug"] = old_slug
                aivi_cfg["mode"] = "single_progress"
                existing["AIVI_API_TOKEN"] = old_token
                existing["AIVI_ACTIVITY_SLUG"] = old_slug
                print("[✓] Bisherige Aivi-Konfiguration bleibt unverändert")
                return False
            aivi_cfg["enabled"] = False
            existing.pop("AIVI_API_TOKEN", None)
            existing.pop("AIVI_ACTIVITY_SLUG", None)
            print("[-] Aivi übersprungen")
            return False


def configure_abrp(existing: dict[str, str], config: dict[str, Any]) -> bool:
    abrp_cfg = config.setdefault("abrp", {})
    old_enabled = bool(abrp_cfg.get("enabled", False))
    old_token = existing.get("ABRP_TOKEN", "")
    old_key = existing.get("ABRP_API_KEY", "")

    while True:
        if old_enabled:
            choice = choose_menu(
                "ABRP-Telemetrie:",
                [("1", "Beibehalten / neu einrichten"), ("2", "Deaktivieren"), ("3", "Hilfe")],
                "1",
            )
        else:
            choice = choose_menu(
                "ABRP-Telemetrie (optional):",
                [("1", "Jetzt einrichten"), ("2", "Später"), ("3", "Hilfe")],
                "2",
            )
        if choice == "3":
            print_abrp_help()
            continue
        if choice == "2":
            abrp_cfg["enabled"] = False
            existing.pop("ABRP_TOKEN", None)
            existing.pop("ABRP_API_KEY", None)
            if old_enabled or old_token or old_key:
                print("[✓] ABRP deaktiviert; gespeicherte ABRP-Zugangsdaten entfernt")
            else:
                print("[-] ABRP wird später eingerichtet")
            return old_enabled or bool(old_token) or bool(old_key)
        break

    while True:
        token = ask_secret("ABRP User Token", old_token)
        api_key = ask_secret("ABRP API-Key", old_key)
        if token and api_key:
            abrp_cfg["enabled"] = True
            existing["ABRP_TOKEN"] = token
            existing["ABRP_API_KEY"] = api_key
            print("[✓] ABRP konfiguriert; der erste echte Datensatz prüft die Übertragung.")
            return (not old_enabled) or token != old_token or api_key != old_key

        print("[✗] ABRP benötigt User Token und API-Key.")
        action = choose_menu(
            "Wie möchtest du fortfahren?",
            [("1", "Erneut versuchen"), ("2", "Später einrichten"), ("3", "Hilfe")],
            "1",
        )
        if action == "3":
            print_abrp_help()
            continue
        if action == "2":
            if old_enabled and old_token and old_key:
                abrp_cfg["enabled"] = True
                existing["ABRP_TOKEN"] = old_token
                existing["ABRP_API_KEY"] = old_key
                print("[✓] Bisherige ABRP-Konfiguration bleibt unverändert")
                return False
            abrp_cfg["enabled"] = False
            existing.pop("ABRP_TOKEN", None)
            existing.pop("ABRP_API_KEY", None)
            print("[-] ABRP übersprungen")
            return False


def configure_diagnostics(config: dict[str, Any]) -> None:
    diag = config.setdefault("diagnostics", {})
    retention = int(diag.get("retention_days", 180))
    export_days = int(diag.get("export_default_days", 7))
    max_size = int(diag.get("max_size_mib", 2048))
    print("Diagnosedaten helfen, Lade- und Cloudprobleme später nachzuvollziehen.")
    diag["retention_days"] = ask_int("Wie lange Diagnosedaten speichern (Tage)", retention, 7, 3650)
    diag["export_default_days"] = ask_int(
        "Wie viele vergangene Tage standardmäßig exportieren", export_days, 1, 3650
    )
    diag["max_size_mib"] = ask_int(
        "Maximaler Speicher für Diagnosedaten (MiB)",
        max_size,
        observer.DIAGNOSTICS_MIN_SIZE_MIB,
        observer.DIAGNOSTICS_MAX_SIZE_MIB,
    )
    diag.setdefault("cleanup_interval_hours", 24)
    diag.setdefault("persistent_text_log", True)
    diag.setdefault("poll_history", True)
    diag.setdefault("event_history", True)
    print(f"[✓] Diagnose: {diag['retention_days']} Tage · max. {diag['max_size_mib']} MiB")


def configure_all() -> None:
    print()
    print(f"🏍️  Zero Connect Setup · {PUBLIC_VERSION}")
    print("────────────────────────────────────────")
    print("Zero Cloud ist erforderlich; Aivi und ABRP sind optional und können später eingerichtet werden.\n")
    existing = load_existing_env()
    config = load_config()

    try:
        current_status = configure_vehicle(existing, config, prompt_credentials=True)
    except SetupCancelled as exc:
        raise SystemExit(str(exc)) from None

    aivi_changed = configure_aivi(existing, config, current_status)
    abrp_changed = configure_abrp(existing, config)
    configure_diagnostics(config)
    persist(existing, config)
    restart_kwargs = {
        "aivi": aivi_changed,
        "abrp": abrp_changed,
        "configuration_persisted": True,
    }
    if aivi_changed and bool(config.get("aivi", {}).get("enabled", False)):
        restart_kwargs["preserve_legacy_aivi_handoff"] = True
    apply_runtime_reset_and_restart(**restart_kwargs)

    print()
    print(f"[✓] Bereit: {config['vehicle_label']}")
    if config.get("aivi", {}).get("enabled", False):
        print_aivi_dismissal_hint()
    print("Status:   zero-connect status")
    print("Prüfung:  zero-connect doctor")
    print()


def prepare_first_run() -> None:
    """Create safe defaults; credentials are entered later in the Web-UI."""
    config = load_config()
    config.setdefault("setup", {}).update(
        completed=False, forced=False, wizard_started=False, step="welcome"
    )
    write_config(config)
    print("[✓] Ersteinrichtung vorbereitet · Zugangsdaten werden später in der Web-UI abgefragt")


def factory_reset_first_run() -> None:
    """Explicit developer/factory reset; never touches NetworkManager profiles."""
    config = load_config()
    env = load_existing_env()
    for key in ("ZERO_CLOUD_USER", "ZERO_CLOUD_PASSWORD", "ZERO_UNIT_NUMBER", "AIVI_API_TOKEN", "AIVI_ACTIVITY_SLUG", "ABRP_TOKEN", "ABRP_API_KEY"):
        env.pop(key, None)
    config.setdefault("setup", {}).update(completed=False, forced=False, wizard_started=False, step="welcome")
    config.setdefault("aivi", {}).update(enabled=False, activity_slug="zero-connect")
    config.setdefault("abrp", {}).update(enabled=False)
    persist_config_and_env(env, config)
    print("[✓] Factory-Reset vorbereitet · Cloud- und optionale Integrationszugänge entfernt · WLAN unverändert")


def configure_section(section: str) -> None:
    if section == "all":
        configure_all()
        return

    print()
    print(f"⚙️  Zero Connect Configure · {section}")
    print("──────────────────────────────────────")
    original_env = load_existing_env()
    original_config = load_config()
    existing = copy.deepcopy(original_env)
    config = copy.deepcopy(original_config)

    aivi_changed = False
    abrp_changed = False
    try:
        if section == "vehicle":
            configure_vehicle(existing, config, prompt_credentials=True)
        elif section == "aivi":
            aivi_changed = configure_aivi(existing, config)
        elif section == "abrp":
            abrp_changed = configure_abrp(existing, config)
        elif section == "diagnostics":
            configure_diagnostics(config)
        else:
            raise SetupCancelled(f"Unbekannter Konfigurationsbereich: {section}")
    except (SetupCancelled, KeyboardInterrupt) as exc:
        message = str(exc).strip() or "Änderung abgebrochen."
        print(f"[-] {message}")
        print("[✓] Bestehende Konfiguration bleibt unverändert")
        return

    persist(existing, config)
    restart_kwargs = {
        "aivi": aivi_changed,
        "abrp": abrp_changed,
        "configuration_persisted": True,
    }
    if aivi_changed and bool(config.get("aivi", {}).get("enabled", False)):
        restart_kwargs["preserve_legacy_aivi_handoff"] = True
    apply_runtime_reset_and_restart(**restart_kwargs)
    print("[✓] Änderung abgeschlossen")
    if section == "aivi" and config.get("aivi", {}).get("enabled", False):
        print_aivi_dismissal_hint()
    print()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Zero Connect konfigurieren")
    parser._optionals.title = "Optionen"
    parser.add_argument(
        "--section",
        choices=("all", "vehicle", "aivi", "abrp", "diagnostics"),
        default="all",
        help="Konfigurationsbereich ändern (Standard: all)",
    )
    parser.add_argument("--factory-reset", action="store_true", help="expliziter Entwickler-/Factory-Reset ohne WLAN-Änderung")
    parser.add_argument("--confirm-factory-reset", action="store_true", help="Bestätigung für --factory-reset")
    parser.add_argument(
        "--prepare-first-run",
        action="store_true",
        help="sichere Defaults für die Web-Ersteinrichtung vorbereiten",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.prepare_first_run:
        prepare_first_run()
        return
    if args.factory_reset:
        if not args.confirm_factory_reset:
            raise SystemExit("--factory-reset benötigt --confirm-factory-reset.")
        factory_reset_first_run()
        return
    configure_section(args.section)


if __name__ == "__main__":
    main()
