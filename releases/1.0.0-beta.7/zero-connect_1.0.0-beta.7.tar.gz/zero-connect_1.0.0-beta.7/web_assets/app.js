'use strict';

let lastClientHeartbeat = 0;
function sendClientHeartbeat() {
  const now = Date.now();
  if (now - lastClientHeartbeat < 30000) return;
  lastClientHeartbeat = now;
  fetch('/api/client-heartbeat', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: '{}',
    credentials: 'omit',
    cache: 'no-store',
    keepalive: true,
  }).catch(() => {});
}
document.addEventListener('pointerdown', sendClientHeartbeat, {passive: true});
document.addEventListener('keydown', sendClientHeartbeat, {passive: true});
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) sendClientHeartbeat();
});
if (!document.hidden) sendClientHeartbeat();
window.setInterval(() => {
  if (!document.hidden) sendClientHeartbeat();
}, 60000);

const state = {translations: {}, assets: null, language: 'de', status: null, config: null, history: null, analytics: null, comparison: null, setup: null, functionalLocationCount: 0, functionalSettingsPromise: null, locationDetails: null, locationMap: null, locationMapMarkers: [], selectedLocationId: null, locationMapHasFit: false, locationMarker: null, mapHasCentered: false, expandedMap: null, expandedMarker: null, expandedMapHasCentered: false, lastLocation: null, placeLookupKey: '', placeLookupTimer: null, userLocation: null, userAccuracy: null, userLocationCapturedAt: 0, userLocationExpiryTimer: null, userLocationRequestId: 0, userMarker: null, userAccuracyCircle: null, locationBackfillTimer: null, locationBackfillActive: false, locationBackfillGeneration: 0, setupCompletionPending: false, setupRefreshTimer: null, refreshInFlight: false, vehiclePick: null, vehicleSaving: false, vehicleDirty: false};
const MAP_TILE_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const MAP_ATTRIBUTION_URL = 'https://www.openstreetmap.org';
const DONATE_URL = 'https://www.paypal.me/thiloschyroki';
const $ = id => document.getElementById(id);
// The server versions vehicle image URLs by content, so the last shown image
// can be displayed from the browser cache before any API response arrives.
const VEHICLE_IMAGE_HINT_KEY = 'zero-connect-vehicle-image';
function warmStartVehicleImage() {
  let asset = null;
  try { asset = localStorage.getItem(VEHICLE_IMAGE_HINT_KEY); } catch (_) { return; }
  if (!asset?.startsWith('/assets/vehicles/') || !$('vehicleImage')) return;
  showVehicleAsset('vehicleImage', 'vehicleImageSkeleton', asset);
}
const CONFIG_FORMS = '#vehicleModelForm, #vehicleForm, #aiviForm, #abrpForm, #diagnosticsForm, #advancedForm';
// Legacy selector contract retained for static compatibility; routed forms are
// now bound by their canonical IDs after hydration.
// document.querySelectorAll('#simpleSettings form, #advancedSettings form')
function lockForm(form, locked) { form.querySelectorAll('input,select,button').forEach(input => { input.disabled = locked; }); }

function selectedLanguage() {
  const stored = localStorage.getItem('zero-connect-language');
  if (stored === 'de' || stored === 'en') return stored;
  return String(navigator.language || 'de').toLowerCase().startsWith('en') ? 'en' : 'de';
}

function t(key, values = {}) {
  let result = state.translations[state.language]?.[key] || state.translations.de?.[key] || key;
  for (const [name, value] of Object.entries(values)) result = result.replaceAll(`{${name}}`, String(value));
  return result;
}

function featureText(de, en) { return state.language === 'en' ? en : de; }

function formatOdometerDistance(value) {
  const number = Number(value);
  const formatter = new Intl.NumberFormat(state.language === 'en' ? 'en' : 'de-DE', {maximumFractionDigits: 2});
  if (Number.isFinite(number) && number !== 0 && Math.abs(number) < 0.01) return `<${formatter.format(0.01)}`;
  return formatter.format(number);
}

function translateFeatureContent() {
  const dynamic = {
    '#locationList > p': ['location.emptyHelp', 'Ladeorte werden beim Laden automatisch erkannt. Du kannst sie anschließend benennen.', 'Charging locations are detected while charging and can then be named.'],
    '#maintenanceList > p': ['maintenance.empty', 'Hier kannst du eigene Wartungen vormerken.', 'Add your own maintenance reminders here.'],
    '#milestoneList > p': ['milestones.empty', 'Keine Meilensteine angelegt.', 'No milestones added.'],
    '.restore-disclosure > summary': ['feature.backup', 'Backup wiederherstellen', 'Restore backup'],
  };
  for (const [selector, [key, de, en]] of Object.entries(dynamic)) {
    const node = document.querySelector(selector);
    if (node && (node.textContent === de || node.textContent === en || !node.dataset.i18n)) { node.dataset.i18n = key; node.textContent = t(key) === key ? featureText(de, en) : t(key); }
  }
  document.querySelectorAll('#detail-locations button,#detail-maintenance button,#detail-milestones button').forEach(button => { const values={Umbenennen:featureText('Umbenennen','Rename'), 'In Karten öffnen':featureText('In Karten öffnen','Open in maps'), Löschen:featureText('Löschen','Delete'), Bearbeiten:featureText('Bearbeiten','Edit'), Erledigt:featureText('Erledigt','Complete')}; if(values[button.textContent])button.textContent=values[button.textContent]; });
  updateChargingLocationLabels();
  updateChargingLocationMapPopups();
  document.querySelectorAll('#detail-maintenance article span').forEach(node => { node.textContent=node.textContent.replace(' · fällig',featureText(' · fällig',' · due')).replace(' · noch ',' · '+featureText('noch ','remaining ')); });
}

function updateChargingLocationLabels() {
  document.querySelectorAll('#locationList article').forEach(item => {
    const title = item.querySelector('summary strong');
    const detail = item.querySelector('summary span');
    if (title?.dataset.locationName != null) {
      title.textContent = title.dataset.locationName;
    }
    if (detail?.dataset.lastUsed != null) {
      const date = detail.dataset.lastUsed ? new Date(detail.dataset.lastUsed) : null;
      const formatted = date && !Number.isNaN(date.getTime()) ? formatChargingLocationDate(date) : '–';
      const count = Number(detail.dataset.sessions || 0);
      const countText = count === 1 ? t('location.sessionsOne') : t('location.sessionsMany', {value:count});
      const extra = [];
      const socSessions = Number(detail.dataset.socSummarySessions || 0);
      const start = Number(detail.dataset.averageStart); const end = Number(detail.dataset.averageEnd);
      if (socSessions >= 3 && Number.isFinite(start) && Number.isFinite(end)) extra.push(t('location.avgSoc', {start:Math.round(start), end:Math.round(end)}));
      const durationSessions = Number(detail.dataset.durationSummarySessions || 0);
      const average = Number(detail.dataset.averageDuration);
      if (durationSessions >= 3 && Number.isFinite(average) && average > 0) extra.push(t('location.avgTime', {value:duration(average)}));
      detail.textContent = `${countText} · ${t('location.lastUsed')} ${formatted}`;
      let averages = item.querySelector('.location-averages');
      if (extra.length) {
        if (!averages) { averages = document.createElement('p'); averages.className = 'location-averages muted'; item.querySelector('details')?.querySelector('summary')?.after(averages); }
        averages.textContent = extra.join(' · ');
      } else averages?.remove();
    }
  });
  const summary = $('locationSummary');
  if (summary) summary.textContent = state.functionalLocationCount ? t('location.summaryCount', {value: state.functionalLocationCount}) : t('location.summaryEmpty');
}

function formatChargingLocationDate(date) {
  return new Intl.DateTimeFormat(state.language === 'en' ? 'en-GB' : 'de-DE', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  }).format(date);
}

function applyLanguage() {
  document.documentElement.lang = state.language;
  $('languageSwitch').value = state.language;
  $('wizardLanguageSwitch').value = state.language;
  document.querySelectorAll('[data-i18n]').forEach(node => { node.textContent = t(node.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach(node => { node.setAttribute('aria-label', t(node.dataset.i18nAria)); });
  document.querySelectorAll('[data-i18n-alt]').forEach(node => { node.setAttribute('alt', t(node.dataset.i18nAlt)); });
  localizeMapZoomControls();
  if (state.status) renderStatus(state.status);
  if (state.config) renderConfig(state.config);
  if (state.history) renderHistory(state.history, false);
  if (state.lastSession !== undefined) renderLastSession(state.lastSession);
  if (state.analytics) renderAnalytics(state.analytics);
  if (state.comparison) renderComparison(state.comparison);
  if (state.setup) renderWizard(state.setup);
  if (detailPages.size) localizeFunctionalUi();
  localizeHistoryUi();
  refreshRemovedSessions();
  const detailTitles = {about:'settings.aboutSection', 'zero-cloud':'connection.zeroCloud', aivi:'aivi.title', abrp:'connection.abrp', diagnostics:'diagnostics.title', polling:'advanced.polling', 'system-actions':'settings.actions', technical:'technical.summary', notifications:'feature.notifications', locations:'feature.locations', maintenance:'feature.maintenance', milestones:'feature.milestones', backup:'feature.backup'};
  for (const [key, titleKey] of Object.entries(detailTitles)) {
    const page = detailPages.get(key)?.page;
    if (page) { const heading = page.querySelector('.detail-heading h2'); if (heading) heading.textContent = t(titleKey); }
  }
}

function localizeHistoryUi() {
  const removedTitle = $('removedHistorySection')?.querySelector('h3'); if (removedTitle) removedTitle.textContent = featureText('Aus Verlauf entfernt', 'Removed from history');
  const removedHelp = $('removedHistorySection')?.querySelector('p'); if (removedHelp) removedHelp.textContent = featureText('Diese Ladevorgänge zählen nicht mehr zu Verlauf und Auswertungen. Die Daten selbst bleiben erhalten.', 'These sessions no longer count in history or statistics. Their raw records are retained.');
  const summary=$('historyFilters')?.querySelector('.filter-detail > summary'); if(summary)summary.textContent=t('common.filter');
  const labels=$('historyFilters')?.querySelectorAll('.filter-fields label span'); if(labels) ['Charge target','Completion','Location'].forEach((en,i)=>{if(labels[i])labels[i].textContent=featureText(['Ladeziel','Abschluss','Ort'][i],en);});
  const searchLabel=$('historyQuery')?.closest('label')?.querySelector('span'); if(searchLabel)searchLabel.textContent=featureText('Suche','Search');
  const filterButtons=$('historyFilters')?.querySelectorAll('.filter-fields button'); if(filterButtons?.length===2){filterButtons[0].textContent=featureText('Anwenden','Apply');filterButtons[1].textContent=featureText('Zurücksetzen','Reset');}
  const opts=$('historyTarget')?.options; if(opts)opts[0].textContent=featureText('Alle','All');
  const reason=$('historyReason')?.options; if(reason){reason[0].textContent=featureText('Alle','All');reason[1].textContent=featureText('Beendet','Ended');reason[2].textContent=featureText('Vollständig','Complete');reason[3].textContent=featureText('Unterbrochen','Interrupted');}
  const compare=$('comparisonForm'); if(compare){const summary=compare.closest('details')?.querySelector('summary');if(summary)summary.textContent=t('common.compare');const button=compare.querySelector('button');if(button)button.textContent=t('common.compare');compare.left?.setAttribute('aria-label',featureText('Erster Ladevorgang','First session'));compare.right?.setAttribute('aria-label',featureText('Zweiter Ladevorgang','Second session'));}
  const exportLinks=document.querySelectorAll('.history-export a'); if(exportLinks.length){exportLinks[0].textContent='CSV';exportLinks[1].textContent='JSON';exportLinks[2].textContent=t('feature.backup');}
  renderHistoryFilterChips();
}

function renderHistoryFilterChips() {
  const chips = $('activeFilterChips');
  if (!chips) return;
  chips.replaceChildren();
  for (const [id, key] of [['historyTarget','comparison.target'],['historyReason','history.filterCompletion'],['historyLocation','history.filterLocation']]) {
    const input = $(id);
    if (!input?.value) continue;
    const button = document.createElement('button'); button.type = 'button';
    const value = input.tagName === 'SELECT' ? input.selectedOptions?.[0]?.textContent || input.value : input.value;
    button.textContent = `${t(key)}: ${value} ×`;
    button.onclick = () => { input.value = ''; filterHistory(); };
    chips.append(button);
  }
  const summary = document.querySelector('.filter-detail > summary');
  if (summary) summary.textContent = chips.children.length ? `${t('common.filter')} · ${chips.children.length}` : t('common.filter');
}

function tidyNotificationsForm() {
  const form = $('detail-notifications')?.querySelector('form');
  if (!form || form.dataset.tidy) return;
  form.querySelector('[name=target_reached]')?.closest('label')?.remove();
  $('targetNotificationHelp')?.remove();
  const threshold = form.elements.offline_threshold_minutes?.closest('label');
  const onlineAgain = form.elements.online_again?.closest('label');
  if (threshold && onlineAgain) onlineAgain.after(threshold);
  form.querySelectorAll('label').forEach(label => { if (!label.classList.contains('settings-toggle-row') && label.querySelector('select')) label.classList.add('settings-select-row'); });
  form.dataset.tidy = '1';
}

function localizeFunctionalUi() {
  const title = $('detail-notifications')?.querySelector('.push-hero strong'); if (title) title.textContent = t('push.title');
  const group = $('detail-notifications')?.querySelector('form');
  if (group) {
    const headings = group.querySelectorAll('h3'); ['Ladevorgang','Fahrzeug','Wartung'].forEach((fallback, i) => { if (headings[i]) headings[i].textContent = state.language === 'en' ? ['Charging','Vehicle','Maintenance'][i] : fallback; });
    const labels = {charging_started: state.language === 'en' ? 'Charging started':'Laden gestartet', soc_milestone: state.language === 'en' ? 'Charge level steps (50 to 90%)':'Ladestand-Schritte (50 bis 90 %)', target_reached: state.language === 'en' ? 'Charging phase ended':'Ladephase beendet', full_reached: state.language === 'en' ? '100% reached':'100 % erreicht', charging_completed: state.language === 'en' ? 'Charging complete':'Ladevorgang abgeschlossen', post_charge_reminder: t('notifications.postCharge'), charging_not_started: t('notifications.notStarted'), battery_care: t('notifications.batteryCare'), theft_alert: t('notifications.theft'), tipover_alert: t('notifications.tipover'), firmware_changed: t('notifications.firmware'), offline: state.language === 'en' ? 'Vehicle offline for longer':'Fahrzeug länger offline', online_again: state.language === 'en' ? 'Vehicle online again':'Fahrzeug wieder online', maintenance: state.language === 'en' ? 'Maintenance reminders':'Wartungserinnerungen', odometer_milestone: state.language === 'en' ? 'Odometer milestones':'Kilometer-Meilensteine'};
    const unsupportedTarget = group.elements?.target_reached; if (unsupportedTarget) unsupportedTarget.disabled = true;
    for (const input of group.querySelectorAll('input[type=checkbox]')) { const label = input.closest('label'); const text = label?.querySelector('span') || [...(label?.childNodes || [])].find(n => n.nodeType === Node.TEXT_NODE); if (text) { if (text.nodeType === Node.TEXT_NODE) text.textContent = ` ${labels[input.name] || input.name}`; else text.textContent = labels[input.name] || input.name; } }
  const threshold = group.elements?.offline_threshold_minutes?.closest('label'); if (threshold) threshold.firstChild.textContent = state.language === 'en' ? 'Report offline after ' : 'Offline melden nach ';
  const thresholdOptions = group.elements?.offline_threshold_minutes?.options; if (thresholdOptions) thresholdOptions[0].textContent = state.language === 'en' ? 'Off' : 'Aus';
  const setOptions = (name, labels) => { const options = group.elements?.[name]?.options; if (options) [...options].forEach((option, index) => { if (labels[index]) option.textContent = labels[index]; }); };
  setOptions('post_charge_reminder_minutes', state.language === 'en' ? ['Off','10 min','30 min','1 hr'] : ['Aus','10 min','30 min','1 h']);
  setOptions('charging_not_started_minutes', state.language === 'en' ? ['Off','5 min','10 min','15 min'] : ['Aus','5 min','10 min','15 min']);
  setOptions('evening_reminder_soc', [t('notifications.off'), ...[30, 50, 70].map(value => t('notifications.eveningBelow', {value}))]);
  const eveningHour = group.elements?.evening_reminder_hour?.closest('label'); if (eveningHour) eveningHour.hidden = group.elements.evening_reminder_soc.value === '0';
    const diag = group.querySelector('details:not(.experimental-notifications) > summary'); if (diag) diag.textContent = state.language === 'en' ? 'Technical push diagnostics' : 'Diagnose der Benachrichtigungen';
  }
  tidyNotificationsForm();
  const staticText = [['#showMaintenanceForm', 'Wartung hinzufügen', 'Add maintenance'], ['#showMilestoneForm','Meilenstein hinzufügen','Add milestone'], ['#restoreBackup','', '']];
  const maintenanceForm = $('maintenanceForm');
  if (maintenanceForm) { const names = {name:['z. B. Kette prüfen','e.g. check chain'], due_odometer:['z. B. 12000','e.g. 12000'], repeat_km:['z. B. 6000 (optional)','e.g. 6000 (optional)'], note:['Optional','Optional']}; for (const [name, pair] of Object.entries(names)) { const input = maintenanceForm.elements[name]; if (input) input.placeholder = state.language === 'en' ? pair[1] : pair[0]; } }
  const milestoneForm = $('milestoneForm');
  if (milestoneForm?.elements.name) milestoneForm.elements.name.placeholder = featureText('z. B. 10.000 km erreicht','e.g. 10,000 km reached');
  if (milestoneForm?.elements.target_odometer) milestoneForm.elements.target_odometer.placeholder = featureText('z. B. 10000','e.g. 10000');
  for (const form of [maintenanceForm, milestoneForm]) { form?.querySelectorAll('button[type=submit]').forEach(button => button.textContent = t('common.save')); form?.querySelectorAll('[data-i18n]').forEach(node => { node.textContent = t(node.dataset.i18n); }); }
  for (const [selector,de,en] of staticText) { const node=document.querySelector(selector); if (node && selector !== '#restoreBackup') node.textContent = state.language === 'en' ? en : de; }
  const search=$('historyQuery'); if(search) search.placeholder=t('common.searchPlaceholder'); const loc=$('historyLocation'); if(loc) loc.placeholder=t('common.locationPlaceholder');
  const navCopy = {
    notifications:['feature.notifications','feature.notificationsHelp'], locations:['feature.locations','feature.locationsHelp'], maintenance:['feature.maintenance','feature.maintenanceHelp'], milestones:['feature.milestones','feature.milestonesHelp'], backup:['feature.backup','feature.backupHelp'],
    'zero-cloud':['connection.zeroCloud',null], aivi:['aivi.title',null], abrp:['connection.abrp',null], diagnostics:['diagnostics.title','settings.diagnosticsHelp'], polling:['advanced.polling','settings.pollingHelp'], 'system-actions':['settings.actions','settings.actionsHelp'], technical:['technical.summary','technical.summary']
  };
  document.querySelectorAll('.settings-nav-row').forEach(row => { const keys=navCopy[row.dataset.detail]; if (!keys) return; const strong=row.querySelector('strong') || document.createElement('strong'); strong.textContent=t(keys[0]); if (!strong.parentNode) row.querySelector('span')?.prepend(strong); const small=row.querySelector('small'); if (small && keys[1]) small.textContent=t(keys[1]); });
  const sectionTitle=$('featuresSectionTitle'); if(sectionTitle)sectionTitle.textContent=t('settings.featuresSection');
  for (const [key, name] of [['notifications','feature.notifications'],['locations','feature.locations'],['maintenance','feature.maintenance'],['milestones','feature.milestones'],['backup','feature.backup']]) { const heading=detailPages.get(key)?.page.querySelector('.detail-heading h2'); if(heading)heading.textContent=t(name); }
  const test=$('pushTest'); if(test)test.textContent=t('push.test');
  const setButtons = (selector, labels) => { const buttons=[...document.querySelectorAll(selector)]; buttons.forEach((button,i)=>{if(labels[i])button.textContent=labels[i];}); };
  setButtons('#detail-locations article button', [t('common.rename'), t('location.routeHere'), t('common.delete')]);
  setButtons('#detail-maintenance article button', [t('common.edit'), t('common.complete'), t('common.delete')]);
  setButtons('#detail-milestones article button, #detail-milestones p button', [t('common.delete')]);
  document.querySelectorAll('.detail-page form button[type=submit]').forEach(button => button.textContent=t('common.save'));
  const systemActionRow = detailPages.get('system-actions')?.page.querySelector('.settings-action-row');
  if (systemActionRow && !systemActionRow.dataset.explained) {
    const help = [
      ['Prüft Dienste und Konfiguration', 'Checks services and configuration'],
      ['Erstellt ein Diagnosepaket ohne Zugangsdaten', 'Creates a diagnostic package without credentials'],
      ['', ''],
      ['Nur bei Problemen erforderlich', 'Only needed when troubleshooting'],
      ['Öffnet den Einrichtungsassistenten', 'Opens the setup assistant'],
    ];
    [...systemActionRow.children].forEach((control, index) => {
      const wrapper = document.createElement('div'); wrapper.className = 'system-action';
      const text = document.createElement('small'); text.className = 'system-action-help'; text.dataset.helpDe = help[index]?.[0] || ''; text.dataset.helpEn = help[index]?.[1] || '';
      control.replaceWith(wrapper); wrapper.append(control); if (text.dataset.helpDe) wrapper.append(text);
    });
    systemActionRow.dataset.explained = 'true';
  }
  const aboutSummary=document.querySelector('.about-section summary'); if(aboutSummary)aboutSummary.textContent=state.language==='en'?'About Zero Connect':'Über Zero Connect';
  document.querySelectorAll('#functionalSettings [data-i18n]').forEach(node => { node.textContent = t(node.dataset.i18n); });
  translateFeatureContent();
  document.querySelectorAll('.system-action-help').forEach(node => { node.textContent = state.language === 'en' ? node.dataset.helpEn : node.dataset.helpDe; });
}

function duration(seconds) {
  if (seconds == null) return '–';
  const minutes = Math.max(0, Math.round(Number(seconds) / 60));
  if (minutes < 1) return t('time.now');
  if (minutes === 1) return t('time.minute');
  if (minutes < 60) return t('time.minutes', {value: minutes});
  const hours = Math.floor(minutes / 60);
  // "4 days" reads better than "105 h 29 min".
  if (hours >= 24) { const days = Math.floor(hours / 24); return days === 1 ? t('time.day') : t('time.days', {value: days}); }
  const rest = minutes % 60;
  return t('time.hoursMinutes', {hours, minutes: String(rest).padStart(2, '0')});
}

function localTimestamp(value) {
  if (!value) return '–';
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? String(value) : new Intl.DateTimeFormat(state.language, {dateStyle: 'medium', timeStyle: 'short'}).format(parsed);
}

function localEtaTimestamp(value) {
  if (!value) return '–';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value);
  const now = new Date();
  const sameLocalDay = parsed.getFullYear() === now.getFullYear()
    && parsed.getMonth() === now.getMonth()
    && parsed.getDate() === now.getDate();
  return new Intl.DateTimeFormat(state.language, sameLocalDay
    ? {timeStyle: 'short'}
    : {dateStyle: 'medium', timeStyle: 'short'}).format(parsed);
}

function fact(text) {
  const item = document.createElement('span');
  item.className = 'fact';
  item.textContent = text;
  return item;
}

function updateText(node, value, {pulse = false} = {}) {
  const next = String(value);
  if (node.textContent === next) return false;
  const hadValue = node.textContent.trim() && node.textContent.trim() !== '–';
  node.textContent = next;
  if (pulse && hadValue) {
    node.classList.remove('value-updated');
    void node.offsetWidth;
    node.classList.add('value-updated');
  }
  return true;
}

function setRefreshIndicator(active) {
  const indicator = $('refreshIndicator');
  if (!indicator) return;
  indicator.hidden = !active;
  indicator.classList.toggle('is-refreshing', active);
  $('main')?.setAttribute('aria-busy', String(active));
}

function renderChargeFacts(container, card) {
  container.replaceChildren();
  container.classList.remove('tiles');
  if (card.time_limit_state === 'soon') {
    const alert = fact(t('fact.timeLimitSoon', {value: card.time_limit_remaining_minutes ?? 0})); alert.classList.add('time-limit-soon'); container.append(alert);
  } else if (card.time_limit_state === 'reached') {
    const alert = fact(t('fact.timeLimitReached')); alert.classList.add('time-limit-reached'); container.append(alert);
  }
  if (card.state === 'charging') {
    if (card.remaining_minutes != null) container.append(fact(t('fact.remaining', {value: card.remaining_minutes})));
    if (card.target_soc != null) container.append(fact(t('fact.target', {value: Math.round(card.target_soc)})));
    if (card.connected_seconds != null) container.append(fact(t('fact.connectedDuration', {value: duration(card.connected_seconds)})));
    if (card.elapsed_seconds != null) container.append(fact(t('fact.elapsed', {value: duration(card.elapsed_seconds)})));
  } else if (card.state === 'balancing') {
    if (card.target_soc != null) container.append(fact(t('fact.target', {value: Math.round(card.target_soc)})));
    if (card.balancing_seconds != null) container.append(fact(t('fact.balancing', {value: duration(card.balancing_seconds)})));
    if (card.connected_seconds != null) container.append(fact(t('fact.connectedDuration', {value: duration(card.connected_seconds)})));
  } else if (card.state === 'connected_idle') {
    if (card.connected_seconds != null) container.append(fact(t('fact.connectedDuration', {value: duration(card.connected_seconds)})));
  } else if (card.state === 'completed' && card.completion_summary) {
    const summary = card.completion_summary;
    container.append(fact(t('fact.completedRange', {start: summary.start_soc ?? '–', end: summary.end_soc ?? '–'})));
    if (summary.duration_seconds != null) container.append(fact(t('fact.sessionDuration', {value: duration(summary.duration_seconds)})));
    if (summary.balancing_seconds != null) container.append(fact(t('fact.balancingDuration', {value: duration(summary.balancing_seconds)})));
    if (card.still_connected && card.connected_seconds != null) container.append(fact(t('fact.connectedDuration', {value: duration(card.connected_seconds)})));
    else if (card.connection_state === 'disconnected') container.append(fact(t('fact.completedUnplugged')));
    else if (card.connection_state === 'unknown') container.append(fact(t('fact.connectionUnknown')));
    if (card.since_completed_seconds != null) container.append(fact(t('fact.sinceComplete', {value: duration(card.since_completed_seconds)})));
  }
  if (card.state === 'charging' && card.sample_rate != null) {
    const rate = fact(t('fact.rate', {value: Number(card.sample_rate).toLocaleString(state.language, {maximumFractionDigits: 1})}));
    rate.title = t('fact.rateHelp');
    rate.setAttribute('aria-description', t('fact.rateHelp'));
    container.append(rate);
  }
  if (card.finish_at) container.append(fact(t('fact.finish', {value: localEtaTimestamp(card.finish_at)})));
}

// Tiles are narrow: "25 Min." and "1:13 h" instead of the long sentence form.
function tileDuration(seconds) {
  if (seconds == null) return '–';
  const minutes = Math.max(0, Math.round(Number(seconds) / 60));
  if (minutes < 60) return t('tile.minutes', {value: minutes});
  return t('tile.hoursMinutes', {hours: Math.floor(minutes / 60), minutes: String(minutes % 60).padStart(2, '0')});
}

function chargeTile(label, value) {
  const tile = document.createElement('div');
  tile.className = 'charge-tile';
  const name = document.createElement('small'); name.textContent = label;
  const text = document.createElement('b'); text.textContent = value;
  tile.append(name, text);
  return tile;
}

// Battery tab while charging, balancing or just finished: a few labelled tiles
// instead of a list of sentences. Returns false for states that keep the facts.
function renderChargeTiles(container, card) {
  const rows = [];
  const start = () => {
    if (!card.started_at) return;
    rows.push([t('tile.start'), card.start_soc != null
      ? t('tile.startValue', {soc: Math.round(card.start_soc), time: localEtaTimestamp(card.started_at)})
      : localEtaTimestamp(card.started_at)]);
  };
  if (card.state === 'charging') {
    if (card.elapsed_seconds != null) rows.push([t('tile.elapsed'), tileDuration(card.elapsed_seconds)]);
    if (card.sample_rate != null) rows.push([t('tile.rate'), t('tile.rateValue', {value: Number(card.sample_rate).toLocaleString(state.language, {maximumFractionDigits: 0})})]);
    start();
    if (card.finish_at) rows.push([t('tile.finish'), localEtaTimestamp(card.finish_at)]);
    else if (card.remaining_minutes != null) rows.push([t('tile.remaining'), tileDuration(card.remaining_minutes * 60)]);
    if (card.target_soc != null) rows.push([t('tile.target'), t('tile.percent', {value: Math.round(card.target_soc)})]);
  } else if (card.state === 'balancing') {
    rows.push([t('tile.targetReached'), t('tile.percent', {value: Math.round(card.target_soc ?? card.soc)})]);
    if (card.balancing_seconds != null) rows.push([t('tile.balancing'), tileDuration(card.balancing_seconds)]);
    start();
    if (card.connected_seconds != null) rows.push([t('tile.connected'), tileDuration(card.connected_seconds)]);
  } else if (card.state === 'completed' && card.completion_summary) {
    const summary = card.completion_summary;
    rows.push([t('tile.charged'), t('tile.range', {start: summary.start_soc ?? '–', end: summary.end_soc ?? '–'})]);
    if (summary.duration_seconds != null) rows.push([t('tile.duration'), tileDuration(summary.duration_seconds)]);
    if (card.since_completed_seconds != null) rows.push([t('tile.sinceComplete'), tileDuration(card.since_completed_seconds)]);
    if (card.still_connected) rows.push([t('tile.plug'), t('tile.plugConnected')]);
    else if (card.connection_state === 'disconnected') rows.push([t('tile.plug'), t('tile.plugDisconnected')]);
  } else {
    return false;
  }
  container.replaceChildren();
  container.classList.add('tiles');
  if (card.time_limit_state === 'soon' || card.time_limit_state === 'reached') {
    const soon = card.time_limit_state === 'soon';
    const alert = fact(soon ? t('fact.timeLimitSoon', {value: card.time_limit_remaining_minutes ?? 0}) : t('fact.timeLimitReached'));
    alert.classList.add(soon ? 'time-limit-soon' : 'time-limit-reached');
    container.append(alert);
  }
  for (const [label, value] of rows) {
    const tile = chargeTile(label, value);
    if (label === t('tile.rate')) { tile.title = t('fact.rateHelp'); tile.setAttribute('aria-description', t('fact.rateHelp')); }
    container.append(tile);
  }
  return true;
}

// Overview: one quiet line under the battery level that says something the
// big number does not (when it will be done, how far it came).
function renderOverviewLine(container, card) {
  container.replaceChildren();
  let text = '';
  if (card.state === 'charging') {
    const finish = card.finish_at ? localEtaTimestamp(card.finish_at) : null;
    if (finish && card.target_soc != null) text = t('overview.finishTarget', {time: finish, value: Math.round(card.target_soc)});
    else if (finish && card.remaining_minutes != null) text = t('overview.finishRemaining', {time: finish, value: duration(card.remaining_minutes * 60)});
    else if (finish) text = t('overview.finish', {time: finish});
    else if (card.start_soc != null && card.elapsed_seconds != null) text = t('overview.progress', {start: Math.round(card.start_soc), soc: Math.round(card.soc), value: duration(card.elapsed_seconds)});
    else if (card.remaining_minutes != null) text = t('fact.remaining', {value: card.remaining_minutes});
  } else if (card.state === 'balancing') {
    const target = Math.round(card.target_soc ?? card.soc);
    text = card.balancing_seconds != null ? t('overview.targetReachedSince', {value: target, duration: duration(card.balancing_seconds)}) : t('overview.targetReached', {value: target});
  } else if (card.state === 'completed' && card.completion_summary) {
    const summary = card.completion_summary;
    text = summary.duration_seconds != null
      ? t('overview.completed', {start: summary.start_soc ?? '–', end: summary.end_soc ?? '–', value: duration(summary.duration_seconds)})
      : t('fact.completedRange', {start: summary.start_soc ?? '–', end: summary.end_soc ?? '–'});
  } else if (card.state === 'connected_idle' && card.connected_seconds != null) {
    text = t('fact.connectedDuration', {value: duration(card.connected_seconds)});
  }
  if (!text && card.battery_care) text = t(`care.${card.battery_care.band}Short`, {value: card.battery_care.days});
  if (!text && card.range) text = t('overview.range', {value: card.range.km});
  if (text) container.append(fact(text));
}

function renderChargingEvidence(card) {
  const curve = $('chargingCurve'); const timeline = $('chargingTimeline');
  curve.replaceChildren(); timeline.replaceChildren();
  const samples = Array.isArray(card.samples) ? card.samples : [];
  if (samples.length >= 2) {
    const svg = document.createElementNS(`http${':'}//www.w3.org/2000/svg`, 'svg'); svg.setAttribute('viewBox', '0 0 320 88'); svg.setAttribute('aria-label', t('charging.curveLabel'));
    const start = new Date(samples[0].timestamp).getTime(); const end = new Date(samples[samples.length - 1].timestamp).getTime();
    const span = Math.max(1, end - start); const points = samples.map(s => `${((new Date(s.timestamp).getTime() - start) / span) * 300 + 10},${78 - (Math.max(0, Math.min(100, Number(s.soc))) * .62)}`).join(' ');
    const line = document.createElementNS(`http${':'}//www.w3.org/2000/svg`, 'polyline'); line.setAttribute('points', points); line.setAttribute('pathLength', '100'); line.classList.add('curve-line'); line.setAttribute('fill', 'none'); line.setAttribute('stroke', 'var(--vehicle-accent-strong)'); line.setAttribute('stroke-width', '3'); line.setAttribute('stroke-linecap', 'round'); svg.append(line); curve.append(svg);
  }
  for (const event of card.milestones || []) { const item = document.createElement('li'); item.textContent = `${localTimestamp(event.timestamp)} · ${event.soc} %`; timeline.append(item); }
  curve.hidden = samples.length < 2; timeline.hidden = !(card.milestones || []).length;
}

function assetForModel(model, color) {
  if (color === 'custom' && state.customPhoto) return `/assets/vehicles/custom?v=${encodeURIComponent(state.customPhoto)}`;
  const normalized = String(model || '').toLowerCase();
  const match = state.assets.models.find(entry => entry.featured
    && (entry.patterns.some(pattern => normalized.includes(pattern)) || (entry.exact || []).includes(normalized)));
  if (!match) return null;
  return match.colors?.[color] || match.colors?.[match.default_color] || match.asset || null;
}

function showVehicleAsset(imageId, skeletonId, asset) {
  const image = $(imageId);
  const skeleton = $(skeletonId);
  image.dataset.asset = asset;
  image.closest('.vehicle-visual')?.classList.toggle('custom-photo', asset.includes('/vehicles/custom'));
  const preload = new Image();
  preload.decoding = 'async';
  preload.onload = () => {
    if (image.dataset.asset !== asset) return;
    image.src = asset;
    image.hidden = false;
    skeleton.hidden = true;
    if (imageId === 'vehicleImage') performance.mark?.('zero-vehicle-image-visible');
  };
  preload.onerror = () => {
    if (image.dataset.asset !== asset) return;
    // A neutral skeleton is preferable to a broken image; a later render
    // may retry, and the warm-start hint must not repeat the failure.
    delete image.dataset.asset;
    image.hidden = true;
    image.removeAttribute('src');
    skeleton.hidden = false;
    try { if (localStorage.getItem(VEHICLE_IMAGE_HINT_KEY) === asset) localStorage.removeItem(VEHICLE_IMAGE_HINT_KEY); } catch (_) { /* optional hint */ }
  };
  preload.src = asset;
}

function renderLocalVehicleImage(imageId, skeletonId, model, color) {
  const image = $(imageId);
  const skeleton = $(skeletonId);
  const asset = assetForModel(model, color);
  if (imageId === 'vehicleImage') {
    try {
      if (asset) localStorage.setItem(VEHICLE_IMAGE_HINT_KEY, asset);
      else localStorage.removeItem(VEHICLE_IMAGE_HINT_KEY);
    } catch (_) { /* storage is optional; it only speeds up the next start */ }
  }
  // Already shown or loading (for example from the warm start): no reload.
  if (asset && image.dataset.asset === asset) return;
  image.hidden = true;
  image.removeAttribute('src');
  // The setup shows nothing, and no loading animation, until a model is chosen.
  const waiting = imageId === 'wizardVehicleImage' && !asset;
  skeleton.hidden = waiting;
  const wizardVisual = image.closest('.wizard-vehicle-visual');
  if (wizardVisual) wizardVisual.hidden = waiting;
  delete image.dataset.asset;
  if (!asset) return;
  showVehicleAsset(imageId, skeletonId, asset);
}

// A model/color the owner just picked wins over older server responses for a short time,
// so a refresh that was already in flight cannot flip the picture back.
function activeVehiclePick() {
  const pick = state.vehiclePick;
  if (pick && Date.now() > pick.expires) state.vehiclePick = null;
  return state.vehiclePick;
}

function renderVehicle(payload) {
  const card = payload.dashboard || {};
  updateText($('vehicleName'), payload.vehicle_label || t('vehicle.modelUnknown'));
  updateText($('vehicleSoc'), card.soc == null ? '–' : Math.round(card.soc), {pulse: true});
  const dataState = payload.vehicle_data?.state || 'missing';
  const vehicleState = $('vehicleState');
  state.customPhoto = payload.vehicle_custom_photo || '';
  const pick = activeVehiclePick();
  renderLocalVehicleImage('vehicleImage', 'vehicleImageSkeleton', pick ? pick.model : payload.vehicle_model, pick ? pick.color : payload.vehicle_color);
  const chargeStates = ['charging', 'balancing', 'completed', 'connected_idle', 'interrupted'];
  const freshnessState = payload.vehicle_data?.state || 'missing';
  const isUnavailable = freshnessState !== 'current';
  const context = payload.context || {kind: chargeStates.includes(card.state) ? card.state : 'normal'};
  const contextKeys = {
    charging: 'state.charging', balancing: 'state.balancing', charge_complete_plugged: 'state.completed',
    plugged_not_charging: 'state.connected_idle', normal: 'state.ready',
    offline: 'daily.offline', location_stale: 'daily.locationStale',
    time_limit_soon: 'daily.timeLimitSoon', time_limit_reached: 'daily.timeLimitReached',
    maintenance_soon: 'daily.maintenanceSoon', maintenance_due: 'daily.maintenanceDue'
  };
  let label;
  if (isUnavailable) label = freshnessState === 'stale' ? t('daily.offline', {value: duration(payload.vehicle_data?.age_seconds)}) : t('vehicleData.missing');
  else if (context.kind === 'time_limit_soon') label = t('daily.timeLimitSoon', {value: context.minutes_until_limit ?? '–'});
  else if (context.kind === 'maintenance_soon') label = t(contextKeys[context.kind], {value: context.maintenance_remaining_km ?? '–'});
  else if (context.kind === 'maintenance_due') label = Number(context.maintenance_remaining_km) < 0
    ? t('daily.maintenanceOverdue', {value: formatOdometerDistance(Math.abs(context.maintenance_remaining_km))})
    : t(contextKeys[context.kind]);
  else label = t(contextKeys[context.kind] || (chargeStates.includes(card.state) ? `state.${card.state}` : 'state.ready'));
  const chargeHero = chargeStates.includes(card.state) && !isUnavailable;
  updateText(vehicleState, label);
  vehicleState.className = `state vehicle-charge-state${chargeHero ? ` state-${card.state}` : ''} attention-${context.attention || 'normal'}${isUnavailable ? ' is-unavailable' : ''}`;
  const secondary = $('vehicleSecondary');
  const secondaryKeys = {charging:'state.charging', balancing:'state.balancing', charge_complete_plugged:'state.completed', plugged_not_charging:'state.connected_idle', time_limit_soon:'daily.timeLimitSoon'};
  if (secondary) {
    secondary.hidden = isUnavailable || !context.secondary || !secondaryKeys[context.secondary];
    secondary.textContent = secondary.hidden ? '' : context.secondary === 'time_limit_soon'
      ? t(secondaryKeys[context.secondary], {value: context.minutes_until_limit ?? '–'})
      : t(secondaryKeys[context.secondary]);
  }
  const freshness = $('vehicleFreshness');
  const freshnessLabel = freshnessState === 'current' ? t('vehicleData.current') : freshnessState === 'stale' ? t('vehicleData.stale', {value: duration(payload.vehicle_data?.age_seconds)}) : t('vehicleData.missing');
  updateText(freshness, freshnessLabel);
  freshness.hidden = isUnavailable;
  freshness.className = `vehicle-freshness vehicle-data-state-${dataState}`;
  const vehicleCard = $('vehicleCard');
  vehicleCard.classList.toggle('is-charging', chargeHero && ['charging', 'balancing'].includes(card.state));
  // The bike's outline glows only while charging (blue), balancing (amber) or done (green).
  if (chargeHero && ['charging', 'balancing', 'completed'].includes(card.state)) vehicleCard.dataset.charge = card.state;
  else delete vehicleCard.dataset.charge;
  renderOverviewLine($('vehicleFacts'), card);
}

// Schematic Z-Force pack (front view). One light line fills from left to right
// along the top and bottom rails; the six light-line outlines and the cooling
// fins between them light up behind the same front. The only number it shows
// is the real state of charge; colour and motion express state (charging,
// complete, low, old data), never power or energy.
function paintBatteryPack(soc, known, target) {
  const clip = $('packLitClip');
  if (!clip) return;
  const left = 78, width = 256;
  const fill = known ? Math.max(0, Math.min(100, soc)) / 100 * width : 0;
  clip.setAttribute('width', String(fill));
  const front = $('packFront');
  if (known && fill > 2 && fill < width - 2) {
    front.setAttribute('x1', String(left + fill)); front.setAttribute('x2', String(left + fill)); front.removeAttribute('hidden');
  } else {
    front.setAttribute('hidden', '');
  }
  const marker = $('chargingTargetMarker');
  const showTarget = known && target > 0 && target < 100;
  if (showTarget) {
    const x = String(left + target / 100 * width);
    marker.setAttribute('x1', x); marker.setAttribute('x2', x); marker.removeAttribute('hidden');
  } else {
    marker.setAttribute('hidden', '');
  }
  $('chargingCard').classList.toggle('pack-low', known && soc <= 15);
}

// Smooth state-of-charge changes: the number and the light line move together.
// The very first render and reduced motion jump straight to the value.
function animatePack(soc, known, target) {
  const packAnimation = state.packAnimation ??= {soc: null, frame: 0};
  const node = $('chargingSoc');
  const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  cancelAnimationFrame?.(packAnimation.frame);
  const from = packAnimation.soc;
  packAnimation.soc = known ? soc : null;
  const show = value => { node.textContent = known ? String(Math.round(value)) : '–'; paintBatteryPack(value, known, target); };
  if (!known || from == null || reduce || typeof requestAnimationFrame !== 'function' || Math.abs(from - soc) < 0.5) { show(soc); return; }
  const started = performance.now(), duration = 700;
  const step = now => {
    const progress = Math.min(1, (now - started) / duration);
    show(from + (soc - from) * (1 - Math.pow(1 - progress, 3)));
    if (progress < 1) packAnimation.frame = requestAnimationFrame(step);
  };
  packAnimation.frame = requestAnimationFrame(step);
}

// Replay the fill when the Battery tab is opened.
function replayPack() {
  const card = state.status?.dashboard;
  if (!card || card.soc == null || typeof requestAnimationFrame !== 'function') return;
  (state.packAnimation ??= {soc: null, frame: 0}).soc = 0;
  animatePack(Math.max(0, Math.min(100, Number(card.soc))), true, Number(card.state === 'charging' || card.state === 'balancing' ? card.target_soc : card.charge_target_soc));
}

// The vehicle's 12 V battery as reported (voltage only): latest value, last week's range and a small daily curve.
function renderAuxBattery(aux) {
  const card = $('auxCard');
  if (!card) return;
  card.hidden = !aux;
  if (!aux) return;
  const volts = value => Number(value).toLocaleString(state.language === 'en' ? 'en-US' : 'de-DE', {minimumFractionDigits: 1, maximumFractionDigits: 1});
  $('auxVoltage').textContent = volts(aux.voltage);
  $('auxRange').textContent = volts(aux.min_7d) === volts(aux.max_7d) ? t('aux.rangeSame', {value: volts(aux.min_7d)}) : t('aux.range', {min: volts(aux.min_7d), max: volts(aux.max_7d)});
  card.title = t('aux.help');
  const note = $('auxNote');
  note.hidden = !aux.low;
  note.textContent = aux.low ? t('aux.low') : '';
  card.classList.toggle('is-low', Boolean(aux.low));
  const points = (aux.series || []).map((value, index, all) => ({x: index / Math.max(1, all.length - 1) * 120, value})).filter(point => point.value != null);
  const line = card.querySelector('.aux-spark-line');
  const dot = card.querySelector('.aux-spark-dot');
  const series = aux.series || [];
  const first = new Date(); first.setDate(first.getDate() - (series.length - 1));
  $('auxFrom').textContent = points.length >= 2 ? first.toLocaleDateString(state.language === 'en' ? 'en-US' : 'de-DE', {day: 'numeric', month: 'short'}) : '';
  $('auxTo').textContent = points.length >= 2 ? t('aux.today') : '';
  if (points.length < 2) { line.setAttribute('points', ''); dot.hidden = true; return; }
  const lo = Math.min(...points.map(point => point.value), aux.min_7d), hi = Math.max(...points.map(point => point.value), aux.max_7d);
  const span = Math.max(0.6, hi - lo);  // a calm battery stays a calm line
  const y = value => 32 - (value - lo) / span * 28;
  line.setAttribute('points', points.map(point => `${point.x.toFixed(1)},${y(point.value).toFixed(1)}`).join(' '));
  const last = points[points.length - 1];
  dot.setAttribute('cx', last.x.toFixed(1)); dot.setAttribute('cy', y(last.value).toFixed(1)); dot.hidden = false;
}

function renderCharging(payload) {
  // The Battery tab always shows today's battery.  Charging is one of its
  // states; a finished session is shown only while the server still
  // presents it as recent, and History keeps every past session.
  const card = payload.dashboard || {};
  const active = card.state === 'charging' || card.state === 'balancing';
  const completed = card.state === 'completed';
  const current = payload.vehicle_data?.state === 'current';
  const chargingCard = $('chargingCard');
  chargingCard.classList.toggle('is-empty', card.soc == null && !active);
  chargingCard.classList.remove('state-charging', 'state-balancing', 'state-completed');
  chargingCard.classList.add(`state-${card.state || 'idle'}`);
  // The energy flow animates only on current vehicle data, never on old data.
  chargingCard.classList.toggle('is-live', current);
  // Grey only after a very long silence (more than two days); a vehicle in the
  // garage reports every couple of hours and its last state is still meaningful.
  const contact = payload.last_vehicle_contact ? Date.parse(payload.last_vehicle_contact) : NaN;
  const veryOld = Number.isFinite(contact) && Date.now() - contact > 48 * 3600 * 1000;
  chargingCard.classList.toggle('pack-old', veryOld);
  const tintSoc = card.soc == null ? 100 : Number(card.soc);
  document.body.dataset.pack = veryOld ? 'old' : (tintSoc <= 15 && !active) ? 'low' : (card.state === 'balancing' ? 'charging' : (card.state || 'idle'));
  $('liveBadge').hidden = !current;
  updateText($('chargingTitle'), active || completed ? t(`state.${card.state}`) : t(current || !veryOld ? 'battery.level' : 'battery.lastKnown'));
  const help = $('chargingStateHelp');
  const updated = payload.last_vehicle_contact ? t('battery.updated', {value: localTimestamp(payload.last_vehicle_contact)}) : '';
  // The title already says "Charging"; the line below only carries the age of old data.
  help.textContent = (active || completed) && current ? '' : updated;
  help.classList.toggle('battery-updated', !((active || completed) && current));
  const soc = card.soc == null ? 0 : Math.max(0, Math.min(100, Number(card.soc)));
  const targetValue = active ? card.target_soc : card.charge_target_soc;
  animatePack(soc, card.soc != null, Number(targetValue));
  renderChargingEvidence(card);
  renderAuxBattery(payload.aux_battery);
  $('balancingInfo').hidden = card.state !== 'balancing';
  const facts = $('chargingFacts');
  // Active and finished sessions use tiles (start SOC and time included); other states keep the facts.
  if (!renderChargeTiles(facts, card)) renderChargeFacts(facts, card);
  // Zero does not report its target setting; the server infers it from where
  // the last charge stopped, so it is always labelled as an estimate.
  if (!active && !completed && card.charge_target_soc != null) facts.append(fact(t('fact.targetEstimated', {value: Math.round(card.charge_target_soc)})));
  // Plugged-in status only from current vehicle data; old data stays silent.
  if (!active && !completed && card.state !== 'connected_idle' && payload.vehicle_data?.state === 'current' && card.connection_state === 'connected') facts.append(fact(t('battery.connected')));
  if (card.range && !active && !completed) {
    const range = fact(t('battery.range', {value: card.range.km, full: card.range.full_km}));
    range.title = t('battery.rangeHelp', {value: card.range.distance_km});
    facts.append(range);
  }
  if (card.battery_care && !active) {
    const care = fact(t(`care.${card.battery_care.band}`, {value: card.battery_care.days}));
    care.classList.add('charge-notice');
    facts.append(care);
  }
  // The Live Activity is mentioned only when it needs attention; a running one is not news.
  const runtime = payload.aivi?.runtime_state;
  if (active && payload.aivi?.enabled && payload.aivi?.mode === 'single_progress' && (runtime === 'recovering' || runtime === 'error')) {
    const notice = fact(t(runtime === 'error' ? 'charging.aiviError' : 'charging.aiviRecovering'));
    notice.classList.add('charge-notice');
    facts.append(notice);
  }
}

function renderLocation(location) {
  state.lastLocation = location;
  const status = $('locationStatus');
  const map = $('localMap');
  const empty = $('locationEmpty');
  const privacy = $('locationMapPrivacy');
  const notice = $('locationMapNotice');
  const placeNode = $('locationPlaceLabel');
  notice.hidden = true;
  const available = Boolean(location?.available);
  const precise = available && location.latitude != null && location.longitude != null && Number.isFinite(Number(location.latitude)) && Number.isFinite(Number(location.longitude));
  map.hidden = !precise;
  $('mapExpand').hidden = !precise;
  empty.hidden = available;
  // Attribution remains on the map; the privacy explanation belongs behind
  // the info action and must not compete with the vehicle status on Overview.
  privacy.hidden = true;
  if (!available) { status.hidden = true; placeNode.hidden = true; return; }
  status.hidden = false;
  const freshness = location.freshness_state || (location.stale ? 'stale' : 'current');
  status.className = `location-status ${freshness === 'possibly_stale' || freshness === 'stale' ? 'location-status-stale' : 'muted'}`;
  const timestamp = localTimestamp(location.recorded_at);
  // The place name is the headline; this line only says when it was seen.
  const measurement = freshness === 'possibly_stale'
    ? t('location.possiblyStale')
    : t('location.stale', {value: timestamp});
  status.textContent = measurement;
  if (!precise) return;
  const lookupKey = `${Number(location.latitude).toFixed(3)},${Number(location.longitude).toFixed(3)}:${state.language}`;
  if (location.place_label?.label) { state.userVehiclePlace = location.place_label; state.userVehiclePlaceKey = lookupKey; }
  placeNode.textContent = state.userVehiclePlaceKey === lookupKey ? (location.place_label?.label || state.userVehiclePlace?.label || '') : '';
  placeNode.hidden = !placeNode.textContent;
  if (lookupKey !== state.placeLookupKey) {
    state.placeLookupKey = lookupKey;
    if (!location.place_label?.label) lookupVehiclePlace(lookupKey, 0);
  }
  renderLocationMap(location);
  if (state.expandedMap && $('mapDialog').open) renderExpandedMap(location);
}

async function lookupVehiclePlace(key, attempt) {
  try {
    const result = await api(`/api/location-place?language=${encodeURIComponent(state.language)}`);
    if (key !== state.placeLookupKey) return;
    if (result.state === 'ready' && result.place?.label) {
      state.userVehiclePlace = result.place;
      state.userVehiclePlaceKey = key;
      const label = $('locationPlaceLabel'); label.textContent = result.place.label; label.hidden = false;
      return;
    }
    if (result.state === 'pending' && attempt < 4) {
      clearTimeout(state.placeLookupTimer);
      state.placeLookupTimer = setTimeout(() => lookupVehiclePlace(key, attempt + 1), 1500);
    }
  } catch (_) { /* Place labels are optional; the coordinate map remains usable. */ }
}

function renderExpandedMap(location) {
  if (!window.L || !location?.available || location.latitude == null || location.longitude == null) return;
  const element = $('expandedMap');
  const point = [Number(location.latitude), Number(location.longitude)];
  if (!state.expandedMap) {
    state.expandedMap = L.map(element, {zoomControl: true, attributionControl: true, scrollWheelZoom: true, minZoom: 3, maxZoom: 19, tap: true});
    localizeMapZoomControls(element);
    L.tileLayer(MAP_TILE_URL, {minZoom: 3, maxZoom: 19, attribution: `&copy; <a href="${MAP_ATTRIBUTION_URL}/copyright">OpenStreetMap</a> contributors`}).addTo(state.expandedMap);
  }
  if (!state.expandedMarker) state.expandedMarker = L.marker(point, {icon: mapMarkerIcon(Boolean(location.stale)), title: t('location.lastKnown'), alt: t('location.lastKnown'), keyboard: false, interactive: false}).addTo(state.expandedMap);
  else state.expandedMarker.setLatLng(point).setIcon(mapMarkerIcon(Boolean(location.stale)));
  // Non-visible evidence is written only after Leaflet accepted the point.
  element.dataset.markerLatitude = point[0].toFixed(5);
  element.dataset.markerLongitude = point[1].toFixed(5);
  if (!state.expandedMapHasCentered) { state.expandedMap.setView(point, 15, {animate: false}); state.expandedMapHasCentered = true; }
  const freshness = location.freshness_state || (location.stale ? 'stale' : 'current');
  updateText($('expandedMapStatus'), `${t(freshness === 'possibly_stale' ? 'location.possiblyStale' : freshness === 'stale' ? 'location.stale' : 'location.recorded', {value: localTimestamp(location.recorded_at)})}${location.age_seconds == null ? '' : ` · ${t('location.age', {value: duration(location.age_seconds)})}`}`);
  $('recenterVehicle').textContent = freshness === 'stale' || freshness === 'possibly_stale' ? t('location.recenterLast') : t('location.recenter');
  $('recenterVehicle').setAttribute('aria-label', freshness === 'stale' || freshness === 'possibly_stale' ? t('location.recenterLastA11y') : t('location.recenter'));
  $('routeFromMap').textContent = freshness === 'stale' || freshness === 'possibly_stale' ? t('location.routeLast') : t('location.route');
  refreshMapDirections();
  renderUserLocation();
  requestAnimationFrame(() => state.expandedMap?.invalidateSize({pan: false}));
}

function openMapDialog() {
  if (!state.lastLocation?.available || $('mapExpand').hidden) return;
  openSheet($('mapDialog'));
  renderExpandedMap(state.lastLocation);
}

function mapMarkerIcon(stale) {
  return L.divIcon({className: `last-known-marker${stale ? ' is-stale' : ''}`, iconSize: [22, 22], iconAnchor: [11, 11]});
}

function localizeMapZoomControls(root = document) {
  root.querySelectorAll('.leaflet-control-zoom-in').forEach(control => {
    control.setAttribute('aria-label', t('location.zoomIn'));
    control.setAttribute('title', t('location.zoomIn'));
  });
  root.querySelectorAll('.leaflet-control-zoom-out').forEach(control => {
    control.setAttribute('aria-label', t('location.zoomOut'));
    control.setAttribute('title', t('location.zoomOut'));
  });
}

function googleMapsDirectionsUrl(destination, origin = null) {
  const lat = Number(destination?.latitude); const lon = Number(destination?.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return '';
  const params = new URLSearchParams({api: '1', destination: `${lat},${lon}`});
  if (origin && Number.isFinite(Number(origin.latitude)) && Number.isFinite(Number(origin.longitude))) params.set('origin', `${Number(origin.latitude)},${Number(origin.longitude)}`);
  return `https://www.google.com/maps/dir/?${params.toString()}`;
}

function refreshMapDirections() {
  const link = $('routeFromMap');
  if (link && state.lastLocation?.available) link.href = googleMapsDirectionsUrl(state.lastLocation, usableUserLocation());
}

function openDirections(destination, origin = null) {
  const url = googleMapsDirectionsUrl(destination, origin);
  if (url) window.open(url, '_blank', 'noopener,noreferrer');
}

function reducedMotionPreferred() { return window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches || false; }

function haversineDistanceMeters(a, b) {
  const rad = n => n * Math.PI / 180; const radius = 6371000;
  const dLat = rad(Number(b.latitude) - Number(a.latitude)); const dLon = rad(Number(b.longitude) - Number(a.longitude));
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(Number(a.latitude))) * Math.cos(rad(Number(b.latitude))) * Math.sin(dLon / 2) ** 2;
  return radius * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(Math.max(0, 1 - x)));
}

function renderUserLocation() {
  const map = state.expandedMap; const vehicle = state.lastLocation;
  const userLocation = freshUserLocation();
  if (!map || !userLocation || !vehicle?.available) return;
  const point = [userLocation.latitude, userLocation.longitude];
  if (!state.userMarker) state.userMarker = L.circleMarker(point, {radius: 8, color: '#ffffff', weight: 2, fillColor: '#1687ff', fillOpacity: 1, interactive: false}).addTo(map);
  else state.userMarker.setLatLng(point);
  if (state.userAccuracy > 0 && state.userAccuracy <= 2000) {
    if (!state.userAccuracyCircle) state.userAccuracyCircle = L.circle(point, {radius: state.userAccuracy, color: '#1687ff', weight: 1, fillColor: '#1687ff', fillOpacity: .12, interactive: false}).addTo(map);
    else state.userAccuracyCircle.setLatLng(point).setRadius(state.userAccuracy);
  } else if (state.userAccuracyCircle) { map.removeLayer(state.userAccuracyCircle); state.userAccuracyCircle = null; }
  const both = $('fitBothLocations'); both.hidden = false;
  const distance = $('locationDistance');
  if (state.userAccuracy <= 150) {
    const meters = haversineDistanceMeters(vehicle, userLocation);
    const value = meters < 1000 ? `${Math.round(meters / 50) * 50} m` : `${(Math.round(meters / 100) / 10).toLocaleString(state.language, {minimumFractionDigits: 1, maximumFractionDigits: 1})} km`;
    const staleVehicle = ['stale', 'possibly_stale'].includes(vehicle.freshness_state) || vehicle.stale;
    distance.textContent = t(staleVehicle ? 'location.distanceLast' : 'location.distance', {value}); distance.hidden = false;
  } else { distance.hidden = true; distance.textContent = ''; }
  const status = $('geoFeedback'); status.textContent = t('location.geoShown'); status.hidden = false;
  refreshMapDirections();
}

function showMyLocation() {
  const feedback = $('geoFeedback');
  if (!navigator.geolocation) { feedback.textContent = t('location.geoUnavailable'); feedback.hidden = false; return; }
  clearUserLocation();
  if (state.expandedMap && state.userMarker) { state.expandedMap.removeLayer(state.userMarker); state.userMarker = null; }
  if (state.expandedMap && state.userAccuracyCircle) { state.expandedMap.removeLayer(state.userAccuracyCircle); state.userAccuracyCircle = null; }
  $('fitBothLocations').hidden = true; $('locationDistance').hidden = true;
  feedback.textContent = t('location.geoLoading'); feedback.hidden = false;
  $('geoPrivacy').hidden = false;
  const requestId = ++state.userLocationRequestId;
  navigator.geolocation.getCurrentPosition(position => {
    if (requestId !== state.userLocationRequestId) return;
    const latitude = Number(position.coords.latitude); const longitude = Number(position.coords.longitude); const accuracy = Number(position.coords.accuracy);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180 || !Number.isFinite(accuracy) || accuracy < 0) { clearUserLocation(); feedback.textContent = t('location.geoUnavailable'); feedback.hidden = false; return; }
    state.userLocation = {latitude, longitude};
    state.userAccuracy = accuracy;
    state.userLocationCapturedAt = Date.now();
    state.userLocationExpiryTimer = setTimeout(expireUserLocation, 5 * 60 * 1000);
    renderUserLocation();
    const point = [state.userLocation.latitude, state.userLocation.longitude];
    if (state.expandedMap && !reducedMotionPreferred()) state.expandedMap.flyTo(point, Math.max(state.expandedMap.getZoom(), 14), {duration: .45});
    else state.expandedMap?.setView(point, Math.max(state.expandedMap.getZoom(), 14), {animate: false});
  }, error => {
    if (requestId !== state.userLocationRequestId) return;
    clearUserLocation();
    feedback.textContent = error.code === 1 ? t('location.geoDenied') : t('location.geoUnavailable');
    feedback.hidden = false;
  }, {enableHighAccuracy: false, maximumAge: 30000, timeout: 15000});
}

function usableUserLocation() {
  const current = freshUserLocation();
  if (!current) return null;
  return state.userAccuracy <= 150 ? state.userLocation : null;
}

function freshUserLocation() {
  if (!state.userLocation || !state.userLocationCapturedAt) return null;
  if (Date.now() - state.userLocationCapturedAt > 5 * 60 * 1000) { expireUserLocation(); return null; }
  return state.userLocation;
}

function clearUserLocation() {
  state.userLocationRequestId++;
  clearTimeout(state.userLocationExpiryTimer); state.userLocationExpiryTimer = null;
  state.userLocation = null; state.userAccuracy = null; state.userLocationCapturedAt = 0;
  if (state.expandedMap && state.userMarker) state.expandedMap.removeLayer(state.userMarker);
  if (state.expandedMap && state.userAccuracyCircle) state.expandedMap.removeLayer(state.userAccuracyCircle);
  state.userMarker = null; state.userAccuracyCircle = null;
  $('fitBothLocations').hidden = true; $('locationDistance').hidden = true;
  refreshMapDirections();
}

function expireUserLocation() {
  clearUserLocation();
  const feedback = $('geoFeedback');
  if (feedback) { feedback.textContent = t('location.geoExpired'); feedback.hidden = false; }
}

function fitBothLocations() {
  const userLocation = freshUserLocation();
  if (!state.expandedMap || !state.lastLocation?.available || !userLocation) return;
  const bounds = L.latLngBounds([[Number(state.lastLocation.latitude), Number(state.lastLocation.longitude)], [userLocation.latitude, userLocation.longitude]]);
  if (reducedMotionPreferred()) state.expandedMap.fitBounds(bounds, {padding: [36, 36], maxZoom: 15, animate: false});
  else state.expandedMap.flyToBounds(bounds, {padding: [36, 36], maxZoom: 15, duration: .45});
}

function recenterVehicle() {
  const location = state.lastLocation; if (!state.expandedMap || !location?.available) return;
  const point = [Number(location.latitude), Number(location.longitude)];
  if (reducedMotionPreferred()) state.expandedMap.setView(point, 15, {animate: false});
  else state.expandedMap.flyTo(point, 15, {duration: .45});
}

function renderLocationMap(location) {
  const element = $('localMap');
  if (!window.L) {
    $('locationMapNotice').textContent = t('location.mapUnavailable');
    $('locationMapNotice').hidden = false;
    return;
  }
  const point = [Number(location.latitude), Number(location.longitude)];
  const pointKey = `${point[0]},${point[1]}`;
  const stale = Boolean(location.stale);
  const mapCreated = !state.locationMap;
  if (!state.locationMap) {
    state.locationMap = L.map(element, {zoomControl: true, attributionControl: true, scrollWheelZoom: false, minZoom: 3, maxZoom: 19, tap: true});
    localizeMapZoomControls(element);
    L.tileLayer(MAP_TILE_URL, {
      minZoom: 3, maxZoom: 19, attribution: `&copy; <a href="${MAP_ATTRIBUTION_URL}/copyright">OpenStreetMap</a> contributors`,
    }).on('tileerror', () => {
      $('locationMapNotice').textContent = t('location.mapUnavailable');
      $('locationMapNotice').hidden = false;
    }).addTo(state.locationMap);
    element.addEventListener('pointerdown', () => state.locationMap?.scrollWheelZoom.enable(), {once: true});
  }
  if (state.locationMapPointKey !== pointKey) {
    if (!state.locationMarker) state.locationMarker = L.marker(point, {icon: mapMarkerIcon(stale), title: t('location.lastKnown'), alt: t('location.lastKnown'), keyboard: false, interactive: false}).addTo(state.locationMap);
    else state.locationMarker.setLatLng(point);
    element.dataset.markerLatitude = point[0].toFixed(5);
    element.dataset.markerLongitude = point[1].toFixed(5);
    if (!state.mapHasCentered) {
      state.locationMap.setView(point, 15, {animate: false});
      state.mapHasCentered = true;
    } else if (!state.locationMap.getBounds().contains(point)) {
      state.locationMap.panTo(point, {animate: false});
    }
    state.locationMapPointKey = pointKey;
  }
  if (state.locationMarker && state.locationMapStale !== stale) {
    if (state.locationMapStale !== undefined) state.locationMarker.setIcon(mapMarkerIcon(stale));
    state.locationMapStale = stale;
  }
  if (mapCreated) requestAnimationFrame(() => state.locationMap?.invalidateSize({pan: false}));
}

function refreshLocationMapSize() {
  if (state.locationMap && !$('localMap').hidden) requestAnimationFrame(() => state.locationMap?.invalidateSize({pan: false}));
}

function renderHealth(health) {
  const summary = $('healthSummary');
  const issues = $('healthIssues');
  issues.replaceChildren();
  const codes = Array.isArray(health?.issue_codes) ? health.issue_codes : [];
  summary.textContent = t(codes.length ? 'health.attention' : 'connection.allConnected');
  summary.className = codes.length ? '' : 'health-ok';
  const connections = health?.connections || {};
  const connectionSummary = $('connectionSummary');
  connectionSummary.replaceChildren();
  const connectionIssueCodes = {zero_cloud: 'cloud_error', aivi: 'aivi_error', abrp: 'abrp_error'};
  const values = Object.values(connections);
  const allConnected = values.length > 0 && values.every(value => value === 'connected');
  const allQuietStates = values.length > 0 && values.every(value => ['connected', 'disabled'].includes(value));
  const quietNormal = allQuietStates && !codes.length;
  $('systemConnectionsCard').hidden = quietNormal;
  // Keep a fully healthy summary quiet; show details only when they add
  // information or need attention.
  summary.hidden = Boolean(values.length && !allConnected && !codes.length);
  if (!allConnected) {
    for (const [name, value] of Object.entries(connections)) {
      if (value === 'failed' && codes.includes(connectionIssueCodes[name])) continue;
      const item = document.createElement('div');
      item.className = `connection-status connection-${value}`;
      const label = {zero_cloud: 'connection.zeroCloud', aivi: 'aivi.title', abrp: 'connection.abrp'}[name] || name;
      const stateKey = value === 'connected' ? 'connection.connected' : value === 'failed' ? 'connection.failed' : value === 'configured' ? 'connection.configured' : 'connection.disabled';
      const title = document.createElement('span'); title.textContent = t(label);
      const stateText = document.createElement('strong'); stateText.textContent = t(stateKey);
      item.append(title, stateText); connectionSummary.append(item);
    }
  }
  for (const code of codes) {
    const item = document.createElement('li');
    const key = `health.${code}`;
    item.textContent = t(key) === key ? t('health.unknown') : t(key);
    issues.append(item);
  }
}

function renderLastSession(session) {
  const last = $('lastSession');
  if (!session) {
    last.textContent = t('history.empty');
    return;
  }
  last.replaceChildren();
  const range = document.createElement('strong'); range.className = 'hi-range';
  range.textContent = `${session.start_soc ?? '–'} → ${session.end_soc ?? '–'} %`;
  const meta = document.createElement('span'); meta.className = 'hi-meta';
  meta.textContent = `${localTimestamp(session.started_at_utc)} · ${duration(session.session_duration_seconds ?? session.duration_seconds)}`;
  const main = document.createElement('div'); main.className = 'hi-main'; main.append(range, meta);
  if (session.location_name) { const place = document.createElement('span'); place.className = 'hi-place'; place.textContent = session.location_name; main.append(place); }
  last.append(main);
  const from = Number(session.start_soc), to = Number(session.end_soc);
  if (Number.isFinite(from) && Number.isFinite(to) && to >= from) {
    const bar = document.createElement('span'); bar.className = 'hi-bar'; bar.setAttribute('aria-hidden', 'true');
    const fill = document.createElement('i'); const lo = Math.max(0, Math.min(100, from));
    fill.style.marginLeft = `${lo}%`; fill.style.width = `${Math.max(2, Math.min(100, to) - lo)}%`;
    bar.append(fill); last.append(bar);
  }
}

function renderHistory(items, updateLastSession = true) {
  items = Array.isArray(items) ? items.filter(item => item && typeof item === 'object') : [];
  state.history = items;
  if (updateLastSession) state.lastSession = items[0] || null;
  const list = $('historyList');
  list.replaceChildren();
  if (updateLastSession) renderLastSession(state.lastSession);
  if (!Array.isArray(items) || !items.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.className = 'empty-state';
    empty.innerHTML = `<strong>${t('history.emptyTitle')}</strong><span>${t('history.empty')}</span>`;
    list.append(empty);
    populateComparison();
    return;
  }
  for (const [index, session] of items.entries()) {
    const entry = document.createElement('details');
    entry.className = 'history-item';
    entry.addEventListener('toggle', () => { if (entry.open) loadHistoryDetail(entry, session); }, {once:true});
    const heading = document.createElement('summary');
    const main = document.createElement('div'); main.className = 'hi-main';
    const range = document.createElement('strong'); range.className = 'hi-range';
    range.textContent = `${session.start_soc ?? '–'} → ${session.end_soc ?? '–'} %`;
    const started = localTimestamp(session.started_at_utc);
    const meta = document.createElement('span'); meta.className = 'hi-meta';
    meta.textContent = `${started} · ${duration(session.session_duration_seconds ?? session.duration_seconds)}`;
    main.append(range, meta);
    if (session.location_name) { const place = document.createElement('span'); place.className = 'hi-place'; place.textContent = session.location_name; main.append(place); }
    heading.append(main);
    const from = Number(session.start_soc), to = Number(session.end_soc);
    if (Number.isFinite(from) && Number.isFinite(to) && to >= from) {
      const bar = document.createElement('span'); bar.className = 'hi-bar'; bar.setAttribute('aria-hidden', 'true');
      const fill = document.createElement('i'); fill.style.marginLeft = `${Math.max(0, Math.min(100, from))}%`; fill.style.width = `${Math.max(2, Math.min(100, to) - Math.max(0, Math.min(100, from)))}%`;
      bar.append(fill); heading.append(bar);
    }
    const content = document.createElement('div'); content.className = 'history-item-detail';
    const hint = document.createElement('p'); hint.className = 'muted'; hint.textContent = state.language === 'en' ? 'Loading session details.' : 'Details werden geladen.';
    content.append(hint);
    entry.append(heading, content);
    list.append(entry);
  }
  populateComparison();
}

async function loadHistoryDetail(entry, session) {
  const content = entry.querySelector('.history-item-detail');
  if (!content || content.dataset.loaded) return;
  content.dataset.loaded = 'true';
  try {
    const value = await api(`/api/history/${encodeURIComponent(session.generation)}?language=${encodeURIComponent(state.language)}`);
    const record = value.session || {};
    content.replaceChildren();
    const summary = document.createElement('p');
    summary.textContent = `${featureText('Ladeziel','Target')}: ${record.target_soc ?? '–'} % · ${featureText('Ergebnis','Result')}: ${record.terminal_label || '–'} · ${featureText('Messpunkte','Samples')}: ${record.sample_count ?? 0}`;
    const action = document.createElement('button'); action.type = 'button'; action.className = 'secondary';
    action.textContent = featureText('Aus Verlauf entfernen', 'Remove from history');
    action.setAttribute('aria-label', featureText('Diesen Ladevorgang aus Verlauf und Auswertungen entfernen', 'Remove this charging session from history and analytics'));
    action.addEventListener('click', async () => {
      const confirmation = featureText(
        'Dieser Ladevorgang wird aus Verlauf, Vergleichen und Auswertungen entfernt. Die gespeicherten Daten bleiben erhalten, und du kannst ihn später wiederherstellen. Fortfahren?',
        'This session will leave history, comparisons, and all statistics. Its stored raw data will remain and you can restore it later. Continue?'
      );
      if (!window.confirm(confirmation)) return;
      try {
        await api(`/api/history/${encodeURIComponent(session.generation)}/remove`, {method:'POST'});
        await filterHistory();
        await refreshRemovedSessions();
        await refreshLastSession();
        const analytics = await api('/api/analytics'); state.analytics = analytics; renderAnalytics(analytics);
        setMessage(featureText('Ladevorgang aus dem Verlauf entfernt. Unten kannst du ihn wiederherstellen.', 'Session removed from history. You can restore it below.'));
      } catch (error) { setMessage(error.payload?.error || errorMessage(error.payload), true); }
    });
    content.append(summary, action);
  } catch (error) {
    content.dataset.loaded = '';
    content.firstElementChild.textContent = error.payload?.error || errorMessage(error.payload);
  }
}

async function refreshLastSession() {
  const value = await api(`/api/history?language=${encodeURIComponent(state.language)}`);
  state.lastSession = value.items?.[0] || null;
  renderLastSession(state.lastSession);
}

async function refreshRemovedSessions() {
  const section = $('removedHistorySection'); const list = $('removedHistoryList');
  if (!section || !list) return;
  try {
    const value = await api(`/api/history/removed?language=${encodeURIComponent(state.language)}`);
    const items = Array.isArray(value.items) ? value.items : [];
    section.hidden = items.length === 0; list.replaceChildren();
    for (const session of items) {
      const row = document.createElement('div'); row.className = 'removed-history-item';
      const text = document.createElement('span'); text.textContent = `${localTimestamp(session.started_at_utc)} · ${session.start_soc ?? '–'} → ${session.end_soc ?? '–'} %`;
      const restore = document.createElement('button'); restore.type = 'button'; restore.textContent = featureText('Wiederherstellen', 'Restore');
      restore.setAttribute('aria-label', featureText('Diesen Ladevorgang wieder in Verlauf und Auswertungen aufnehmen', 'Restore this session to history and statistics'));
      restore.addEventListener('click', async () => {
        try {
          await api(`/api/history/${encodeURIComponent(session.generation)}/restore`, {method:'POST'});
          await filterHistory();
          await refreshRemovedSessions();
          await refreshLastSession();
          const analytics = await api('/api/analytics'); state.analytics = analytics; renderAnalytics(analytics);
          setMessage(featureText('Ladevorgang wiederhergestellt.', 'Session restored.'));
        } catch (error) { setMessage(error.payload?.error || errorMessage(error.payload), true); }
      });
      row.append(text, restore); list.append(row);
    }
  } catch (_) { /* Normal history remains available if the archive projection fails. */ }
}

function renderAnalytics(payload) {
  const root = $('historyAnalytics');
  if (!root) return;
  const periods = payload?.periods || {};
  const labels = { '7d': t('analytics.sevenDays'), '30d': t('analytics.thirtyDays'), all: t('analytics.all') };
  if (!root.dataset.ready) {
    root.dataset.ready = '1';
    root.innerHTML = `<details class="analytics-disclosure"><summary>${t('analytics.title')}</summary><div class="analytics-segments" role="group" aria-label="${featureText('Zeitraum','Period')}"></div><div class="analytics-values"></div><details class="analytics-behaviour"><summary>${t('analytics.behaviour')}</summary><div class="analytics-secondary"></div></details></details>`;
  }
  const selected = root.dataset.period || (periods['30d']?.sessions ? '30d' : periods['7d']?.sessions ? '7d' : 'all');
  root.dataset.period = selected;
  const segments = root.querySelector('.analytics-segments'); segments.replaceChildren();
  for (const key of ['7d', '30d', 'all']) {
    const button = document.createElement('button'); button.type = 'button'; button.textContent = labels[key]; button.setAttribute('aria-pressed', String(key === selected));
    button.onclick = () => { root.dataset.period = key; renderAnalytics(payload); }; segments.append(button);
  }
  const values = root.querySelector('.analytics-values'); values.replaceChildren();
  const period = periods[selected];
  if (period?.sessions) {
    for (const [label, value] of [[featureText('Ladevorgänge','Sessions'), period.sessions], [featureText('Zeit am Kabel','Connected time'), period.duration_seconds == null ? null : duration(period.duration_seconds)], [featureText('Ø Start','Average start'), period.average_start_soc == null ? null : `${period.average_start_soc} %`], [featureText('Ø Ende','Average end'), period.average_end_soc == null ? null : `${period.average_end_soc} %`]]) {
      if (value == null) continue; const row = document.createElement('span'); row.textContent = label; const strong = document.createElement('strong'); strong.textContent = value; row.append(strong); values.append(row);
    }
  } else { values.textContent = t('analytics.noData'); }
  const secondary = root.querySelector('.analytics-secondary'); secondary.replaceChildren();
  const list = document.createElement('dl'); list.className = 'analytics-list';
  const addRow = (label, value) => { const row = document.createElement('div'); const dt = document.createElement('dt'); dt.textContent = label; const dd = document.createElement('dd'); dd.textContent = value; row.append(dt, dd); list.append(row); };
  const sessionsText = n => `${n} ${n === 1 ? featureText('Ladevorgang','session') : featureText('Ladevorgänge','sessions')}`;
  const targets = payload.target_statistics || {};
  for (const [target, n] of Object.entries(targets)) addRow(`${featureText('Ladeziel','Charge target')} ${target} %`, sessionsText(n));
  if (payload.full_statistics?.qualified_sessions) addRow(featureText('Bis 100 % geladen','Charged to 100%'), featureText(`${payload.full_statistics.sessions} von ${payload.full_statistics.qualified_sessions}`, `${payload.full_statistics.sessions} of ${payload.full_statistics.qualified_sessions}`));
  if (payload.habits?.available && payload.habits.most_common_period) addRow(featureText('Häufigste Tageszeit','Most common time'), payload.habits.most_common_period);
  const months = Object.entries(payload.monthly || {});
  if (list.children.length) secondary.append(list);
  if (months.length) {
    const heading = document.createElement('h4'); heading.textContent = featureText('Monate','Months');
    const monthList = document.createElement('dl'); monthList.className = 'analytics-list';
    for (const [month, item] of months) {
      const [year, number] = month.split('-').map(Number);
      const row = document.createElement('div'); const dt = document.createElement('dt'); const dd = document.createElement('dd');
      dt.textContent = year && number ? new Date(year, number - 1, 1).toLocaleDateString(state.language, {month: 'short', year: 'numeric'}) : month;
      dd.textContent = sessionsText(item.sessions); const time = document.createElement('small'); time.textContent = duration(item.duration_seconds); dd.append(time);
      row.append(dt, dd); monthList.append(row);
    }
    secondary.append(heading, monthList);
  }
  root.querySelector('.analytics-behaviour').hidden = !secondary.children.length;
}

function renderReleaseNotes(payload) {
  const body = $('releaseNotesBody');
  if (!body) return;
  const paragraph = (text, className) => { const node = document.createElement('p'); node.textContent = text; if (className) node.className = className; return node; };
  const nodes = [];
  const date = payload.installed_at ? new Date(payload.installed_at) : null;
  const dateText = date && !Number.isNaN(date.getTime()) ? date.toLocaleDateString(state.language, {day: '2-digit', month: '2-digit', year: 'numeric'}) : null;
  nodes.push(paragraph([payload.version, dateText ? t('releaseNotes.installed', {date: dateText}) : null].filter(Boolean).join(' · '), 'release-notes-meta'));
  for (const group of payload.groups || []) {
    const section = document.createElement('section');
    section.className = 'release-notes-group';
    const heading = document.createElement('h4');
    heading.textContent = t(`releaseNotes.${group.category}`);
    const list = document.createElement('ul');
    for (const item of group.items || []) {
      const row = document.createElement('li');
      const title = document.createElement('strong'); title.textContent = item.title;
      row.append(title);
      if (item.description) { const text = document.createElement('small'); text.textContent = item.description; row.append(text); }
      list.append(row);
    }
    section.append(heading, list);
    nodes.push(section);
  }
  if (!payload.documented) nodes.push(paragraph(t('releaseNotes.legacy'), 'release-notes-notice'));
  else if (!(payload.groups || []).length) nodes.push(paragraph(t('releaseNotes.undocumented'), 'release-notes-notice'));
  else if (!payload.user_visible) nodes.push(paragraph(t('releaseNotes.noVisible'), 'release-notes-notice'));
  const technical = document.createElement('details');
  technical.className = 'release-notes-technical';
  const summary = document.createElement('summary'); summary.textContent = t('releaseNotes.technical');
  const rows = [[t('settings.build'), payload.internal_version], [t('settings.revision'), payload.revision],
    ...(payload.requests || []).map(row => [row.id, t(`releaseNotes.inclusion.${row.inclusion}`)])];
  technical.append(summary, ...rows.filter(([, value]) => value).map(([label, value]) => paragraph(`${label}: ${value}`)));
  nodes.push(technical);
  body.replaceChildren(...nodes);
}

// After an update, show once per device what changed (only items meant for users).
// The first visit just remembers the version; browser storage is a convenience here.
const SEEN_VERSION_KEY = 'zero-connect-seen-version';
async function maybeShowWhatsNew(version) {
  if (!version || state.whatsNewChecked) return;
  state.whatsNewChecked = true;
  let seen = null;
  try { seen = localStorage.getItem(SEEN_VERSION_KEY); localStorage.setItem(SEEN_VERSION_KEY, version); } catch (_) { return; }
  if (!seen || seen === version) return;
  let payload;
  try { payload = await api('/api/release-notes'); } catch (_) { return; }
  const items = (payload.groups || []).flatMap(group => group.items || []).filter(item => item.user_visible !== false);
  if (!items.length || !$('whatsNew')) return;
  $('whatsNewVersion').textContent = `Zero Connect ${payload.version || version}`;
  $('whatsNewList').replaceChildren(...items.map(item => {
    const row = document.createElement('li');
    const title = document.createElement('strong'); title.textContent = item.title;
    row.append(title);
    if (item.description) { const text = document.createElement('small'); text.textContent = item.description; row.append(text); }
    return row;
  }));
  openSheet($('whatsNew'));
}

// Rides: a second view of the History tab, loaded the first time it is opened.
function rideDistance(km) { return t('rides.km', {value: Number(km).toLocaleString(state.language, {maximumFractionDigits: 1})}); }

function renderRides(payload) {
  state.rides = payload.rides || [];
  const summary = $('ridesSummary');
  summary.replaceChildren();
  if (payload.consumption) {
    const line = document.createElement('p'); line.className = 'rides-consumption';
    line.textContent = t('rides.consumption', {value: Number(payload.consumption.percent_per_100km).toLocaleString(state.language, {maximumFractionDigits: 0}), full: Math.round(100 / payload.consumption.percent_per_100km * 100 / 5) * 5});
    summary.append(line);
  }
  const months = (payload.months || []).slice(0, 3);
  if (months.length) {
    const grid = document.createElement('div'); grid.className = 'facts charging-facts tiles';
    for (const month of months) {
      const [year, number] = month.month.split('-').map(Number);
      const label = new Date(year, number - 1, 1).toLocaleDateString(state.language, {month: 'long', year: 'numeric'});
      const tile = chargeTile(label, rideDistance(month.distance_km));
      const sub = document.createElement('small'); sub.className = 'tile-sub';
      sub.textContent = [t('rides.monthRides', {value: month.rides}), month.percent_per_100km != null ? t('rides.per100', {value: Math.round(month.percent_per_100km)}) : null].filter(Boolean).join(' · ');
      tile.append(sub);
      grid.append(tile);
    }
    summary.append(grid);
  }
  state.ridesShown = 30;
  renderRideList();
}

function renderRideList() {
  const list = $('ridesList');
  list.replaceChildren();
  const rides = state.rides || [];
  if (!rides.length) {
    const empty = document.createElement('p'); empty.className = 'empty-state';
    empty.innerHTML = `<strong>${t('rides.emptyTitle')}</strong><span>${t('rides.empty')}</span>`;
    list.append(empty);
  }
  for (const ride of rides.slice(0, state.ridesShown)) {
    const entry = document.createElement('details'); entry.className = 'history-item ride-item';
    const heading = document.createElement('summary');
    const main = document.createElement('div'); main.className = 'hi-main';
    const title = document.createElement('strong'); title.className = 'hi-range';
    title.textContent = `${rideDistance(ride.distance_km)} · ${tileDuration(ride.duration_seconds)}`;
    const meta = document.createElement('span'); meta.className = 'hi-meta';
    const used = ride.start_soc != null && ride.end_soc != null ? ` · ${Math.round(ride.start_soc)} → ${Math.round(ride.end_soc)} %` : '';
    meta.textContent = `${localTimestamp(ride.started_at_utc)}${used}`;
    main.append(title, meta);
    if (ride.in_progress) { const live = document.createElement('span'); live.className = 'hi-place'; live.textContent = t('rides.inProgress'); main.append(live); }
    heading.append(main);
    const content = document.createElement('div'); content.className = 'history-item-detail';
    entry.append(heading, content);
    entry.addEventListener('toggle', () => { if (entry.open) renderRideDetail(content, ride); }, {once: true});
    list.append(entry);
  }
  $('ridesMore').hidden = rides.length <= state.ridesShown;
}

async function renderRideDetail(content, ride) {
  const tiles = document.createElement('div'); tiles.className = 'facts charging-facts tiles';
  const rows = [
    [t('rides.average'), ride.average_speed_kmh != null ? t('rides.speed', {value: ride.average_speed_kmh}) : null],
    [t('rides.top'), ride.top_speed_kmh != null ? t('rides.speed', {value: ride.top_speed_kmh}) : null],
    [t('rides.used'), ride.soc_used != null && ride.soc_used >= 0 ? t('tile.percent', {value: Math.round(ride.soc_used)}) : null],
    [t('rides.climb'), ride.climb_m != null ? t('rides.meters', {value: ride.climb_m}) : null],
  ].filter(([, value]) => value != null);
  for (const [label, value] of rows) tiles.append(chargeTile(label, value));
  content.append(tiles);
  if (!ride.has_route || !window.L) return;
  try {
    const detail = await api(`/api/trips/${encodeURIComponent(ride.id)}`);
    const points = detail.ride?.points || [];
    if (points.length < 2) return;
    const box = document.createElement('div'); box.className = 'local-map ride-map';
    content.append(box);
    const map = window.L.map(box, {zoomControl: false, attributionControl: true, scrollWheelZoom: false, dragging: true, tap: true});
    window.L.tileLayer(MAP_TILE_URL, {attribution: `© <a href="${MAP_ATTRIBUTION_URL}/copyright">OpenStreetMap</a> contributors`}).addTo(map);
    const line = window.L.polyline(points, {color: '#5a9bea', weight: 4, opacity: .9}).addTo(map);
    map.fitBounds(line.getBounds(), {padding: [18, 18]});
  } catch (_) { /* the numbers stay useful without the map */ }
}

async function loadRides() {
  try { renderRides(await api('/api/trips')); }
  catch (_) { const node = document.createElement('p'); node.className = 'muted'; node.textContent = t('rides.unavailable'); $('ridesList').replaceChildren(node); }
}

function setupHistorySwitch() {
  const buttons = document.querySelectorAll('[data-history-view]');
  for (const button of buttons) button.addEventListener('click', () => {
    const rides = button.dataset.historyView === 'rides';
    for (const other of buttons) { const active = other === button; other.classList.toggle('is-active', active); other.setAttribute('aria-pressed', String(active)); }
    $('historySection').hidden = rides;
    $('ridesSection').hidden = !rides;
    if (rides && !state.ridesLoaded) { state.ridesLoaded = true; loadRides(); }
  });
  $('ridesMore')?.addEventListener('click', () => { state.ridesShown += 30; renderRideList(); });
}

async function loadReleaseNotes() {
  const body = $('releaseNotesBody');
  if (!body) return;
  try { renderReleaseNotes(await api('/api/release-notes')); }
  catch (_) { const node = document.createElement('p'); node.textContent = t('releaseNotes.unavailable'); body.replaceChildren(node); }
}

function renderStatus(payload) {
  state.status = payload;
  updateText($('aboutVersion'), payload.version || '–');
  const aboutSub = document.querySelector('.settings-nav-row[data-detail="about"] small'); if (aboutSub) aboutSub.textContent = payload.version ? `${t('system.version')} ${payload.version}` : t('system.version');
  updateText($('aboutBuild'), payload.internal_version || '–');
  updateText($('aboutRevision'), payload.revision || '–');
  if ($('aboutRevision')) {
    const revision = String(payload.revision || '–');
    $('aboutRevision').textContent = revision.length > 8 ? revision.slice(0, 8) : revision;
    $('aboutRevision').title = revision;
    $('aboutRevision').setAttribute('aria-label', revision);
  }
  renderVehicle(payload);
  maybeShowWhatsNew(payload.version);
  if ($('aboutFirmwareRow')) { $('aboutFirmwareRow').hidden = !payload.vehicle_firmware; updateText($('aboutFirmware'), payload.vehicle_firmware || '–'); }
  renderCharging(payload);
  renderLocation(payload.location);
  renderHealth(payload.system_health);
  const technicalRows = [
    ['system.version', payload.version || '–'],
    ['system.observer', payload.observer_active ? t('system.active') : t('system.inactive')],
    ['system.web', payload.web_active ? t('system.active') : t('system.inactive')],
    ['system.lastPoll', localTimestamp(payload.last_poll)],
    ['system.lastContact', localTimestamp(payload.last_vehicle_contact)],
    ['system.aivi', payload.aivi?.enabled ? t('system.active') : t('system.inactive')],
    ['system.abrp', payload.abrp?.enabled ? t('system.active') : t('system.inactive')],
  ];
  const summary = $('technicalSummary');
  summary.replaceChildren();
  for (const [label, value] of technicalRows) {
    const row = document.createElement('div');
    row.className = 'technical-row';
    const name = document.createElement('span');
    name.textContent = t(label);
    const content = document.createElement('strong');
    content.textContent = value;
    row.append(name, content);
    summary.append(row);
  }
  $('rawTechnicalDetails').textContent = JSON.stringify({version: payload.version, observer_active: payload.observer_active, web_active: payload.web_active, last_poll: payload.last_poll, last_vehicle_contact: payload.last_vehicle_contact, aivi: payload.aivi, abrp: payload.abrp}, (key, value) => /^(lat|lon|latitude|longitude|coordinate_hash)$/i.test(key) ? undefined : value, 2);
}

function renderWizard(payload) {
  state.setup = payload || {};
  const active = Boolean(state.setup.first_run);
  document.body.classList.toggle('first-run', active);
  $('setupWizard').hidden = !active;
  $('wizardCancel').hidden = !state.setup.can_cancel;
  if (!active) return;
  const step = state.setup.step || 'welcome';
  document.querySelectorAll('[data-wizard-step]').forEach(node => { node.hidden = node.dataset.wizardStep !== step; });
  const steps = ['welcome', 'vehicle', 'zero_cloud', 'complete'];
  const stepNumber = Math.max(1, steps.indexOf(step) + 1);
  $('wizardProgress').textContent = t('wizard.progress', {step: stepNumber, total: steps.length});
  $('wizardProgress').style.setProperty('--wizard-progress', `${Math.round(stepNumber / steps.length * 100)}%`);
  const needsWifi = Boolean(state.setup.wifi?.hotspot_recommended);
  $('wizardWifi').hidden = !needsWifi;
  $('wizardWelcomeNext').hidden = needsWifi;  // the home Wi-Fi comes first; "Weiter" appears at the new address
  const wifiPhase = state.setup.wifi?.transition?.phase || 'idle';
  if (wifiPhase === 'failed') { showWifiForm(); $('wizardWifiStatus').textContent = t('wizard.wifiFailed'); }
  else if (wifiPhase === 'connected') showWifiHandover(state.setup.wifi?.continue_url, true);
  const select = $('wizardVehicleModel');
  if (!select.options.length) {
    // No preselection on a new device: a visible prompt instead of an empty-looking field.
    const prompt = document.createElement('option'); prompt.value = ''; prompt.textContent = t('wizard.chooseModel'); prompt.disabled = true; prompt.selected = true; select.append(prompt);
    for (const model of (state.setup.supported_models || [])) {
      const option = document.createElement('option'); option.value = model; option.textContent = modelLabel(model); select.append(option);
    }
    // Without this the browser silently picks the first model.
    select.selectedIndex = 0;
  }
  // A new device reports the generic "Zero Motorcycle", which is not in the list: show the prompt then.
  if ([...select.options].some(option => option.value && option.value === state.setup.vehicle_model)) select.value = state.setup.vehicle_model;
  else if (!select.value) select.selectedIndex = 0;
  if (state.assets) {
    const model = select.value || state.setup.vehicle_model;
    renderLocalVehicleImage('wizardVehicleImage', 'wizardVehicleImageSkeleton', model);
  }
  const summary = $('wizardSummary');
  if (summary) {
    summary.replaceChildren();
    const rows = [
      [t('wizard.summaryVehicle'), (state.setup.supported_models || []).includes(state.setup.vehicle_model) ? modelLabel(state.setup.vehicle_model) : '–'],
      [t('wizard.summaryCloud'), state.setup.zero_cloud?.connected ? t('connection.connected') : t('connection.missing')],
    ];
    for (const [label, value] of rows) { const dt = document.createElement('dt'); dt.textContent = label; const dd = document.createElement('dd'); dd.textContent = value; summary.append(dt, dd); }
  }
}

function modelLabel(model) {
  return model || t('vehicle.modelUnknown');
}

function colorLabel(model, color) {
  const specific = `vehicle.color.${String(model).toLowerCase().replace(/[^a-z]/g, '')}.${color}`;
  return t(specific) === specific ? t(`vehicle.color.${color}`) : t(specific);
}

function renderColorOptions(model, selected) {
  const colors = state.config?.vehicle?.supported_colors?.[model] || [];
  const select = $('vehicleColorSelect');
  select.replaceChildren();
  for (const color of colors) {
    const option = document.createElement('option');
    option.value = color; option.textContent = colorLabel(model, color);
    select.append(option);
  }
  if (state.customPhoto) {
    const option = document.createElement('option');
    option.value = 'custom'; option.textContent = t('vehicle.customPhoto');
    select.append(option);
  }
  const available = [...colors, ...(state.customPhoto ? ['custom'] : [])];
  select.value = available.includes(selected) ? selected : (available[0] || '');
  $('vehicleColorRow').hidden = available.length < 2;
  $('vehiclePhotoRemove').hidden = !state.customPhoto;
}

function renderConfig(config) {
  state.config = config;
  const statuses = config.connections || {
    zero_cloud: config.vehicle.credentials_set ? 'configured' : 'disabled',
    aivi: config.aivi.enabled ? 'configured' : 'disabled',
    abrp: config.abrp.enabled ? 'configured' : 'disabled',
  };
  const statusText = value => t(value === 'connected' ? 'connection.connected' : value === 'failed' ? 'connection.failed' : value === 'configured' ? 'connection.configured' : 'connection.disabled');
  const zeroStatus = statusText(statuses.zero_cloud);
  const aiviStatus = statusText(statuses.aivi);
  const abrpStatus = statusText(statuses.abrp);
  $('zeroSettingsConnection').textContent = zeroStatus;
  $('aiviSettingsConnection').textContent = aiviStatus;
  $('abrpSettingsConnection').textContent = abrpStatus;
  const connectionActions = document.querySelectorAll('#simpleSettings .settings-detail > summary > .settings-action');
  if (connectionActions[0]) connectionActions[0].textContent = actionText(statuses.zero_cloud);
  if (connectionActions[1]) connectionActions[1].textContent = actionText(statuses.aivi);
  if (connectionActions[2]) connectionActions[2].textContent = actionText(statuses.abrp);
  const systemActions = document.querySelectorAll('#advancedSettings .settings-detail > summary > .settings-action');
  if (systemActions[0]) systemActions[0].textContent = t('action.open');
  if (systemActions[1]) systemActions[1].textContent = t('action.adjust');
  if (systemActions[2]) systemActions[2].textContent = t('action.open');
  const modelSelect = $('vehicleModelSelect');
  const supported = Array.isArray(config.vehicle.supported_models) ? config.vehicle.supported_models : [];
  modelSelect.replaceChildren();
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = t('vehicle.selectPlaceholder');
  modelSelect.append(placeholder);
  for (const model of supported) {
    const option = document.createElement('option');
    option.value = model;
    option.textContent = modelLabel(model);
    modelSelect.append(option);
  }
  const pick = activeVehiclePick();
  modelSelect.value = supported.includes(pick ? pick.model : config.vehicle.model) ? (pick ? pick.model : config.vehicle.model) : '';
  renderColorOptions(modelSelect.value, pick ? pick.color : config.vehicle.color);
  if (typeof refreshSettingsSummaries === 'function' && $('sum-cat-motorcycle')) refreshSettingsSummaries();
  document.querySelector('#vehicleForm [name=label]').value = config.vehicle.label || '';
  document.querySelector('#aiviForm [name=enabled]').checked = Boolean(config.aivi.enabled);
  document.querySelector('#aiviForm [name=progress_slug]').value = config.aivi.progress_slug || '';
  document.querySelector('#aiviForm [name=language]').value = ['de', 'en'].includes(config.aivi.language) ? config.aivi.language : 'de';
  document.querySelector('#abrpForm [name=enabled]').checked = Boolean(config.abrp.enabled);
  $('retentionDays').value = config.diagnostics.retention_days;
  $('exportDays').value = config.diagnostics.export_default_days;
  $('maxSize').value = config.diagnostics.max_size_mib;
  $('pollCharging').value = config.advanced.charging_seconds;
  $('pollRecent').value = config.advanced.recent_seconds;
  $('pollIdle').value = config.advanced.idle_seconds;
  $('freshnessAge').value = config.advanced.max_contact_age_seconds;
  for (const [id, saved, detailStatus] of [['vehicleForm', config.vehicle.credentials_set, zeroStatus], ['aiviForm', config.aivi.token_set, aiviStatus], ['abrpForm', config.abrp.credentials_set, abrpStatus]]) {
    const form = $(id);
    let hint = form.querySelector('.stored-configuration');
    if (!hint) { hint = document.createElement('p'); hint.className = 'stored-configuration muted'; form.prepend(hint); }
    hint.textContent = `${detailStatus} · ${t(saved ? 'settings.credentialsSaved' : 'settings.credentialsMissing')}`;
    form.querySelectorAll('input[type=password]').forEach(input => { input.placeholder = t(saved ? 'settings.secretSaved' : 'settings.secretNew'); });
  }
  document.querySelectorAll(CONFIG_FORMS).forEach(form => {
    form.dataset.hydrated = 'true';
    form.onsubmit = submitConfig;
    lockForm(form, false);
  });
  $('vehicleModelSelect').onchange = () => { renderColorOptions($('vehicleModelSelect').value, ''); saveVehicleModel(); };
  $('vehicleColorSelect').onchange = saveVehicleModel;
}

async function api(path, options = {}) {
  let response;
  try { response = await fetch(path, options); }
  catch (_) { const error = new Error('transport'); error.kind = 'transport'; throw error; }
  let value;
  try { value = await response.json(); }
  catch (_) { const error = new Error('response'); error.kind = 'response'; throw error; }
  if (!response.ok) {
    const error = new Error(t('error.generic'));
    error.payload = value;
    error.kind = 'response';
    throw error;
  }
  return value;
}

function errorMessage(payload) {
  const key = `error.${payload?.error_code || 'generic'}`;
  const translated = t(key);
  return translated === key ? t('error.generic') : translated;
}

function setMessage(text, isError = false) {
  $('message').textContent = text;
  $('message').style.color = isError ? 'var(--bad)' : 'var(--text)';
  clearTimeout(setMessage.timer);
  if (text) setMessage.timer = setTimeout(() => { $('message').textContent = ''; }, isError ? 8000 : 5000);
}

function clearMessage() {
  clearTimeout(setMessage.timer);
  $('message').textContent = '';
}

function invalidateSetupBootstrap() {
  state.status = null;
  state.config = null;
  state.history = null;
  state.setup = null;
}

async function loadDashboard(options = {}) {
  if (state.refreshInFlight) return;
  const full = options.full !== false;
  const previousPhase = state.status?.dashboard?.state;
  state.refreshInFlight = true;
  setRefreshIndicator(true);
  try {
    const requests = [api(full ? '/api/status?include_location=1' : '/api/status')];
    if (full) requests.push(api('/api/config'), api(`/api/history?language=${encodeURIComponent(state.language)}`), api('/api/setup'), api('/api/analytics'));
    const [statusResult, configResult, historyResult, setupResult, analyticsResult] = await Promise.allSettled(requests);
    const status = statusResult.status === 'fulfilled' ? statusResult.value : null;
    const setupPayload = full && setupResult?.status === 'fulfilled' ? setupResult.value : null;
    if (status && !full && state.status?.location) status.location = state.status.location;
    let renderFailed = false;
    const render = (result, fn) => { if (result.status === 'fulfilled') { try { fn(result.value); } catch (_) { renderFailed = true; } } };
    render(statusResult, renderStatus);
    if (full) {
      render(configResult, renderConfig);
      render(historyResult, value => { renderHistory(value.items); refreshRemovedSessions(); /* renderHistory(history.items) contract */ });
      render(analyticsResult, value => { state.analytics = value; renderAnalytics(value); });
      render(setupResult, renderWizard);
    }
    const results = full ? [statusResult, configResult, historyResult, setupResult, analyticsResult] : [statusResult];
    if (!full && status && status.dashboard?.state === 'completed' && previousPhase !== 'completed') {
      const [historyRefresh, analyticsRefresh] = await Promise.allSettled([api(`/api/history?language=${encodeURIComponent(state.language)}`), api('/api/analytics')]);
      render(historyRefresh, value => { renderHistory(value.items); refreshRemovedSessions(); });
      render(analyticsRefresh, value => { state.analytics = value; renderAnalytics(value); });
      results.push(historyRefresh, analyticsRefresh);
    }
    const failed = results.filter(result => result.status === 'rejected');
    if (renderFailed) { const error = new Error('render'); error.kind = 'render'; throw error; }
    if (failed.length) {
      const error = new Error('partial');
      error.kind = failed.length === results.length && failed.every(r => r.reason?.kind === 'transport') ? 'transport' : 'response';
      throw error;
    }
    if (state.dashboardError) { clearMessage(); state.dashboardError = false; }
    const vehicleReady = ['current', 'stale'].includes(status.vehicle_data?.state);
    if (state.setupCompletionPending) {
      if (setupPayload?.first_run || vehicleReady) {
        state.setupCompletionPending = false;
        clearTimeout(state.setupRefreshTimer);
        state.setupRefreshTimer = null;
      }
    }
  } catch (error) { state.dashboardError = true; setMessage(t(error.kind === 'transport' ? 'error.network' : error.kind === 'render' ? 'error.render' : 'error.response'), true); }
  finally {
    state.refreshInFlight = false;
    setRefreshIndicator(false);
    if (state.dashboardRefreshQueued && !document.hidden) {
      state.dashboardRefreshQueued = false;
      void loadDashboard({full: false});
    }
  }
}

function scheduleDashboardRefresh() {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    if (state.refreshInFlight) {
      state.dashboardRefreshQueued = true;
      return;
    }
    state.dashboardRefreshQueued = false;
    void loadDashboard({full: false});
  });
  window.setInterval(() => {
    if (!document.hidden) void loadDashboard({full: false});
  }, 30000);
}

async function submitWizardStep(step, body = {}) {
  // Checking the Zero Cloud login can take a few seconds: show it and prevent double submits.
  const buttons = [...document.querySelectorAll(`[data-wizard-step="${step}"] button:not([data-wizard-back])`)];
  const labels = buttons.map(button => button.textContent);
  buttons.forEach(button => { button.disabled = true; });
  const primary = buttons.find(button => button.matches('form button, [data-wizard-submit]'));
  if (primary) primary.textContent = t('wizard.checking');
  try {
    const value = await api('/api/setup', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({step, ...body})});
    document.querySelectorAll('#setupWizard input[type=password]').forEach(input => { input.value = ''; });
    renderWizard(value.setup);
    clearMessage();
    if (step === 'complete' && !value.setup.first_run) {
      invalidateSetupBootstrap();
      state.setupCompletionPending = true;
      await loadDashboard();
      scheduleSetupCompletionRefresh();
    }
  } catch (error) {
    setMessage(errorMessage(error.payload), true);
  } finally {
    buttons.forEach((button, index) => { button.disabled = false; button.textContent = labels[index]; });
  }
}

function scheduleSetupCompletionRefresh() {
  clearTimeout(state.setupRefreshTimer);
  if (!state.setupCompletionPending) return;
  state.setupRefreshTimer = setTimeout(async () => {
    await loadDashboard();
    scheduleSetupCompletionRefresh();
  }, 2000);
}

function wifiAddress(url) {
  // "zero-connect.local:8080" is what a friend types; strip scheme and path from the server's address.
  return String(url || '').replace(/^[a-z]+:\/\//i, '').replace(/\/.*$/, '') || 'zero-connect.local:8080';
}

function showWifiHandover(url, switching = false) {
  $('wizardWifiForm').hidden = true;
  $('wizardWifiScan').hidden = true;
  $('wizardWifiStatus').textContent = '';
  $('wizardHandoverUrl').textContent = wifiAddress(url || state.setup?.wifi?.continue_url);
  $('wizardHandover').hidden = false;
  $('wizardWifi').classList.add('is-handover');
  const go = $('wizardHandoverGo');
  go.disabled = switching || !state.wifiAddressCopied;
  $('wizardHandoverBack').hidden = switching;
  $('wizardHandoverNote').textContent = t(switching ? 'wizard.handoverSwitching' : (state.wifiAddressCopied ? 'wizard.handoverReady' : 'wizard.handoverNote'));
  document.querySelector('[data-wizard-step="welcome"] .wizard-hero')?.setAttribute('hidden', '');
}

function showWifiForm() {
  state.pendingWifi = null; state.wifiAddressCopied = false;
  $('wizardHandover').hidden = true;
  $('wizardWifi').classList.remove('is-handover');
  $('wizardWifiScan').hidden = false;
  document.querySelector('[data-wizard-step="welcome"] .wizard-hero')?.removeAttribute('hidden');
  $('wizardWifiForm').hidden = !$('wizardWifiSsid').options.length;
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* plain http is not a secure context */ }
  const area = document.createElement('textarea');
  area.value = text; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.opacity = '0';
  document.body.append(area); area.select();
  let done = false;
  try { done = document.execCommand('copy'); } catch (_) { done = false; }
  area.remove();
  return done;
}

async function pollWifiRecovery() {
  for (let attempt = 0; attempt < 15; attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 2000));
    try {
      const value = await api('/api/setup');
      renderWizard(value);
      const phase = value.wifi?.transition?.phase;
      if (phase === 'failed') {
        showWifiForm();
        $('wizardWifiStatus').textContent = t('wizard.wifiFailed');
        setMessage(t('wizard.wifiFailed'), true);
        return false;
      }
      if (phase === 'connected') {
        showWifiHandover(value.wifi?.continue_url, true);
        clearMessage();
        return true;
      }
    } catch (_error) { /* The AP is still returning; retry at low frequency. */ }
  }
  return false;
}

async function connectHomeWifi() {
  const pending = state.pendingWifi;
  if (!pending || !state.wifiAddressCopied) return;
  state.pendingWifi = null;
  showWifiHandover(null, true);
  try {
    const value = await api('/api/setup/wifi/connect', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(pending)});
    showWifiHandover(value.continue_url, true);
  } catch (error) {
    // On a Pi with one Wi-Fi radio, losing this HTTP connection is the expected handover signal, not proof of failure.
    // A recovered hotspot reports the definitive failure through the next /api/setup status response.
    if (error.payload) { showWifiForm(); $('wizardWifiStatus').textContent = t('wizard.wifiFailed'); setMessage(t('wizard.wifiFailed'), true); }
    else void pollWifiRecovery();
  }
}

function bindWizard() {
  $('wizardLanguageSwitch').addEventListener('change', event => { state.language = event.target.value; localStorage.setItem('zero-connect-language', state.language); applyLanguage(); });
  $('wizardVehicleModel').addEventListener('change', event => renderLocalVehicleImage('wizardVehicleImage', 'wizardVehicleImageSkeleton', event.target.value));
  document.querySelectorAll('[data-wizard-next]').forEach(button => button.addEventListener('click', () => submitWizardStep('welcome')));
  document.querySelectorAll('[data-wizard-submit]').forEach(button => button.addEventListener('click', () => {
    const step = button.dataset.wizardSubmit;
    if (step === 'vehicle') submitWizardStep(step, {vehicle_model: $('wizardVehicleModel').value});
    else submitWizardStep(step);
  }));
  $('wizardCloudForm').addEventListener('submit', event => { event.preventDefault(); submitWizardStep('zero_cloud', Object.fromEntries(new FormData(event.currentTarget).entries())); });
  $('wizardCancel').addEventListener('click', async () => {
    try { const value = await api('/api/setup/cancel', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'}); clearMessage(); renderWizard(value.setup); await loadDashboard(); }
    catch (error) { setMessage(errorMessage(error.payload), true); }
  });
  document.querySelectorAll('[data-wizard-back]').forEach(button => button.addEventListener('click', async () => {
    try { const value = await api('/api/setup/back', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'}); clearMessage(); renderWizard(value.setup); }
    catch (error) { setMessage(errorMessage(error.payload), true); }
  }));
  $('wizardHandoverCopy').addEventListener('click', async event => {
    const button = event.currentTarget;
    await copyText($('wizardHandoverUrl').textContent);
    // Even where the phone refuses to copy, the address stays on screen; the friend has seen and used the button.
    state.wifiAddressCopied = true;
    button.textContent = t('action.copied');
    showWifiHandover(null);
  });
  $('wizardHandoverBack').addEventListener('click', () => showWifiForm());
  $('wizardHandoverGo').addEventListener('click', () => connectHomeWifi());
  $('wizardWifiScan').addEventListener('click', async () => {
    const button = $('wizardWifiScan');
    const status = $('wizardWifiStatus');
    button.disabled = true;
    button.querySelector('.wizard-spinner').hidden = false;
    $('wizardWifiScanLabel').textContent = t('wizard.wifiScanning');
    status.textContent = '';
    try {
      const value = await api('/api/setup/wifi/scan', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'});
      const select = $('wizardWifiSsid'); select.replaceChildren();
      for (const ssid of value.networks || []) { const option = document.createElement('option'); option.value = ssid; option.textContent = ssid; select.append(option); }
      const found = (value.networks || []).length;
      $('wizardWifiForm').hidden = !found;
      status.textContent = found ? t('wizard.wifiFound', {count: found}) : t('wizard.wifiNone');
    } catch (error) { setMessage(errorMessage(error.payload), true); }
    finally {
      button.disabled = false;
      button.querySelector('.wizard-spinner').hidden = true;
      $('wizardWifiScanLabel').textContent = t('wizard.wifiScanAgain');
    }
  });
  $('wizardWifiForm').addEventListener('submit', event => {
    event.preventDefault(); const form = event.currentTarget;
    // Nothing is changed on the Pi yet: the friend first gets the address, then switches on purpose.
    state.pendingWifi = Object.fromEntries(new FormData(form).entries());
    state.wifiAddressCopied = false;
    form.querySelector('[name=password]').value = '';
    $('wizardHandoverCopy').textContent = t('action.copy');
    showWifiHandover(null);
  });
}

async function submitConfig(event) {
  event.preventDefault();
  const form = event.currentTarget;
  if (form.dataset.hydrated !== 'true') return;
  const endpoints = {vehicleModelForm: 'vehicle-model', vehicleForm: 'vehicle', aiviForm: 'aivi', abrpForm: 'abrp', diagnosticsForm: 'diagnostics', advancedForm: 'advanced'};
  const body = Object.fromEntries(new FormData(form).entries());
  form.querySelectorAll('input[type=checkbox]').forEach(input => { body[input.name] = input.checked; });
  try {
    await api(`/api/config/${endpoints[form.id]}`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
    form.querySelectorAll('input[type=password]').forEach(input => { input.value = ''; });
    setMessage(t('message.saved')); await loadDashboard();
  } catch (error) {
    setMessage(error.payload?.persisted ? t('message.restartFailed') : t('message.requestFailed'), true);
  }
}

async function loadFunctionalSettings() {
  const form = $('notificationPreferencesForm');
  if (!form) return;
  const value = await api('/api/functional/preferences');
  const prefs = value.preferences || {};
  const notifications = prefs.notifications || {};
  form.querySelectorAll('input[type=checkbox]').forEach(input => { input.checked = Boolean(notifications[input.name]); });
  form.elements.offline_threshold_minutes.value = String(prefs.offline_threshold_minutes || 0);
  form.elements.post_charge_reminder_minutes.value = String(prefs.post_charge_reminder_minutes || 0);
  form.elements.charging_not_started_minutes.value = String(prefs.charging_not_started_minutes || 0);
  form.elements.evening_reminder_soc.value = String(prefs.evening_reminder_soc || 0);
  form.elements.evening_reminder_hour.value = String(prefs.evening_reminder_hour || 20);
  form.elements.evening_reminder_hour.closest('label').hidden = form.elements.evening_reminder_soc.value === '0';
  form.querySelectorAll('select').forEach(select => { select.dataset.previousValue = select.value; });
  form.dataset.threshold = form.elements.offline_threshold_minutes.value;
  form.dataset.hydrated = 'true';
  form.onsubmit = saveNotificationPreferences;
  form.onchange = autoSaveNotifications;
  lockForm(form, false);
  if (form.elements.target_reached) form.elements.target_reached.disabled = true;
  // Push capability probing must not block hydration of functional settings
  // or their language-reactive empty states.
  refreshPushStatus().catch(() => null);
  await loadFunctionalData();
}

function ensureFunctionalSettings() {
  if (state.functionalSettingsPromise) return state.functionalSettingsPromise;
  state.functionalSettingsPromise = loadFunctionalSettings().catch(error => {
    state.functionalSettingsPromise = null;
    setMessage(t('error.preferences'), true);
    throw error;
  });
  return state.functionalSettingsPromise;
}

function presentPushState(result) {
  const registered = result.state === 'REGISTERED';
  const unsupported = result.state === 'UNSUPPORTED';
  const blocked = result.state === 'PERMISSION_DENIED';
  const initial = result.state === 'PERMISSION_NOT_REQUESTED';
  // Push needs HTTPS: on the plain local address point to the secure remote address instead of blaming the browser.
  const text = registered ? t('push.active') : unsupported ? t(window.isSecureContext ? 'push.unavailable' : 'push.needsSecure') : blocked ? t('push.blocked') : initial ? t('push.off') : t('push.incomplete');
  $('pushStatus').textContent = text;
  $('pushSummary').textContent = registered ? featureText('Aktiv','Active') : initial ? t('push.off') : text;
  // The form lock disabled these buttons before they moved into the push hero; nothing re-enabled them.
  $('enablePush').disabled = false; $('disablePush').disabled = false;
  $('enablePush').hidden = registered || unsupported || blocked;
  $('enablePush').textContent = initial ? t('push.enable') : t('push.setup');
  $('pushTest').hidden = !registered; $('pushTest').disabled = !registered;
  $('disablePush').hidden = !result.subscription;
  $('pushDiagnostics').textContent = `Zustand: ${result.state} · Berechtigung: ${typeof Notification === 'undefined' ? 'nicht verfügbar' : Notification.permission} · Browser-Abonnement: ${Boolean(result.subscription)} · Server: ${Boolean(result.backend?.registered)}`;
  return result;
}

async function refreshPushStatus() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window) || !window.isSecureContext) return presentPushState({state:'UNSUPPORTED'});
  if (Notification.permission === 'denied') return presentPushState({state:'PERMISSION_DENIED'});
  if (Notification.permission !== 'granted') return presentPushState({state:'PERMISSION_NOT_REQUESTED'});
  try {
    const registration = await navigator.serviceWorker.getRegistration('/');
    if (!registration?.active) return presentPushState({state:'PERMISSION_GRANTED_NO_SERVICE_WORKER'});
    const subscription = await registration.pushManager.getSubscription();
    if (!subscription) return presentPushState({state:'PERMISSION_GRANTED_NO_SUBSCRIPTION'});
    const endpoint = subscription.endpoint;
    let backend = await api('/api/functional/subscriptions/status', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({endpoint})});
    if (!backend.registered) return presentPushState({state:'SUBSCRIBED_LOCAL', subscription, backend});
    return presentPushState({state:'REGISTERED',subscription,backend});
  } catch (error) {
    const result = presentPushState({state:'SUBSCRIPTION_STALE'});
    $('pushDiagnostics').textContent += ` · ${featureText('Status konnte nicht geprüft werden.', 'Status could not be checked.')}`;
    return result;
  }
}

async function updatePushLanguage() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  try {
    const registration = await navigator.serviceWorker.getRegistration('/');
    const subscription = await registration?.pushManager.getSubscription();
    if (!subscription) return;
    await api('/api/functional/subscriptions', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...subscription.toJSON(), language:state.language})});
  } catch (_) { /* language changes must not block the interface */ }
}

function buildFunctionalControls() {
  const panel = $('functionalSettings');
  if (!panel || panel.dataset.built) return;
  panel.dataset.built = '1';
  panel.insertAdjacentHTML('beforeend', `<details class="settings-detail functional-detail"><summary><span><strong data-i18n="feature.locations">Ladeorte</strong><small id="locationSummary">Automatisch erkannte Orte</small></span></summary><section class="settings-section"><div id="chargingLocationsMap" class="local-map" hidden></div><div id="locationList" class="settings-group"><p class="muted">Noch keine Ladeorte erkannt.</p></div></section></details><details class="settings-detail functional-detail"><summary><span><strong data-i18n="feature.maintenance">Wartung</strong><small data-i18n="feature.maintenanceHelp">Erinnerungen nach Kilometerstand</small></span></summary><section class="settings-section"><div id="maintenanceList" class="settings-group"><p class="muted">Keine Wartungen angelegt.</p></div><button id="showMaintenanceForm" type="button">Wartung hinzufügen</button><form id="maintenanceForm" class="settings-group" hidden><label><span data-i18n="maintenance.name">Name</span><input name="name" placeholder="Name" required></label><label><span data-i18n="maintenance.dueAt">Due at km</span><input name="due_odometer" type="number" min="0" step="1" placeholder="Fällig bei km" required></label><label><span data-i18n="maintenance.repeat">Repeat every km</span><input name="repeat_km" type="number" min="0" step="1" placeholder="Wiederholung km"></label><label><span data-i18n="maintenance.note">Note</span><input name="note" placeholder="Notiz"></label><button type="submit">Speichern</button></form></section></details><details class="settings-detail functional-detail"><summary><span><strong data-i18n="feature.milestones">Kilometer-Meilensteine</strong><small data-i18n="feature.milestonesHelp">Eigene Erinnerungen</small></span></summary><section class="settings-section"><div id="milestoneList" class="settings-group"></div><button id="showMilestoneForm" type="button">Meilenstein hinzufügen</button><form id="milestoneForm" class="settings-group" hidden><label><span data-i18n="milestones.name">Name</span><input name="name" placeholder="Name" required></label><label><span data-i18n="milestones.target">Odometer</span><input name="target_odometer" type="number" min="0" step="1" placeholder="Kilometerstand" required></label><label class="check"><input name="notify" type="checkbox"><span data-i18n="milestones.notify">Benachrichtigen</span></label><button type="submit">Speichern</button></form></section></details><details class="settings-detail functional-detail"><summary><span><strong data-i18n="feature.backup">Daten &amp; Backup</strong><small data-i18n="feature.backupHelp">Export, Sicherung und Wiederherstellung</small></span></summary><section class="settings-section"><p><a href="/api/history/export.csv">CSV exportieren</a> · <a href="/api/history/export.json">JSON exportieren</a></p><a class="button" href="/api/functional/backup">Backup erstellen</a><label>Backup wiederherstellen <input id="restoreBackup" type="file" accept=".zip,application/zip"></label></section></details>`);
}

async function loadFunctionalData({resolveNext = false, locationsOnly = false, skipLocationIds = []} = {}) {
  const skipQuery = skipLocationIds.length ? `&skip_location_ids=${encodeURIComponent(skipLocationIds.join(','))}` : '';
  const value = await api(`/api/functional/locations?language=${encodeURIComponent(state.language)}${resolveNext ? '&resolve_next=1' : ''}${resolveNext ? skipQuery : ''}`);
  const list = $('locationList');
  const openArticle = list?.querySelector('article details[open]')?.closest('article');
  const previouslyOpenId = openArticle?.dataset.locationId || null;
  if (list) {
    list.replaceChildren();
    const built = [];
    for (const row of value.locations || []) {
      const index = (value.locations || []).indexOf(row);
      const item = document.createElement('article'); item.className = 'settings-group'; item.id = `charging-location-${index}`; item.dataset.locationId = String(row.id);
      const title = document.createElement('strong'); title.dataset.locationName = row.display_name || row.name;
      const detail = document.createElement('span'); detail.dataset.lastUsed = row.last_used || ''; detail.dataset.sessions = String(row.sessions || 0); detail.dataset.averageStart = row.average_start_soc ?? ''; detail.dataset.averageEnd = row.average_end_soc ?? ''; detail.dataset.averageDuration = row.average_session_duration_seconds ?? ''; detail.dataset.socSummarySessions = String(row.soc_summary_sessions || 0); detail.dataset.durationSummarySessions = String(row.duration_summary_sessions || 0);
      const rename = document.createElement('button'); rename.type = 'button'; rename.textContent = featureText('Umbenennen','Rename');
      rename.onclick = async () => { const name = window.prompt(t('location.customName'), row.custom_name || ''); if (name !== null) { await api('/api/functional/locations', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({...row, custom_name:name.trim() || null, name:name.trim() || row.name})}); await loadFunctionalData(); } };
      const maps = document.createElement('button'); maps.type = 'button'; maps.textContent = t('location.routeHere'); maps.onclick = () => openDirections({latitude:row.latitude,longitude:row.longitude});
      const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger-action'; remove.textContent = t('common.delete');
      remove.onclick = async () => { const confirmation = state.language === 'en' ? `Delete charging location?\n${row.name} will be removed. Existing sessions will remain.` : `Ladeort löschen?\n${row.name} wird entfernt. Bestehende Ladevorgänge bleiben erhalten.`; if (window.confirm(confirmation)) { await api('/api/functional/locations/delete', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: row.id})}); await loadFunctionalData(); } };
      const disclosure = document.createElement('details'); const summary = document.createElement('summary'); summary.append(title, detail);
      const autoLabel = document.createElement('small'); autoLabel.className = 'location-auto-label'; autoLabel.textContent = row.custom_name && row.auto_location_label ? row.auto_location_label : '';
      disclosure.addEventListener('toggle', () => { if (disclosure.open) selectChargingLocation(row.id); });
      disclosure.append(summary);
      const ruleForm = document.createElement('form'); ruleForm.className = 'location-time-limit settings-group'; ruleForm.dataset.locationRule = 'true';
      const enabledLabel = document.createElement('label'); enabledLabel.className = 'check settings-toggle-row';
      const enabled = document.createElement('input'); enabled.type = 'checkbox'; enabled.name = 'time_limit_enabled'; enabled.checked = Boolean(row.time_limit?.enabled);
      const enabledText = document.createElement('span'); enabledText.dataset.i18n = 'location.timeLimitEnable'; enabledText.textContent = t('location.timeLimitEnable'); enabledLabel.append(enabled, enabledText);
      const ruleFields = document.createElement('div'); ruleFields.className = 'location-rule-fields'; ruleFields.hidden = !enabled.checked;
      const limitLabel = document.createElement('label'); const limitText = document.createElement('span'); limitText.dataset.i18n = 'location.timeLimit'; limitText.textContent = t('location.timeLimit');
      const limit = document.createElement('input'); limit.type = 'number'; limit.name = 'time_limit_hours'; limit.min = '1'; limit.max = '48'; limit.step = '1'; limit.required = true; limit.value = Math.max(1, Math.round(Number(row.time_limit?.limit_minutes || 240) / 60)); limitLabel.append(limitText, limit);
      const reminderLabel = document.createElement('label'); const reminderText = document.createElement('span'); reminderText.dataset.i18n = 'location.remindBefore'; reminderText.textContent = t('location.remindBefore');
      const reminder = document.createElement('input'); reminder.type = 'number'; reminder.name = 'time_reminder_minutes'; reminder.min = '0'; reminder.max = '2879'; reminder.step = '5'; reminder.value = String(row.time_limit?.reminder_minutes ?? 30); reminderLabel.append(reminderText, reminder);
      const reachedLabel = document.createElement('label'); reachedLabel.className = 'check'; const reached = document.createElement('input'); reached.type = 'checkbox'; reached.name = 'time_limit_notify_at_limit'; reached.checked = row.time_limit?.notify_at_limit !== false; const reachedText = document.createElement('span'); reachedText.dataset.i18n = 'location.notifyAtLimit'; reachedText.textContent = t('location.notifyAtLimit'); reachedLabel.append(reached, reachedText);
      const noteLabel = document.createElement('label'); const noteTitle = document.createElement('span'); noteTitle.textContent = t('location.note'); const note = document.createElement('input'); note.name = 'note'; note.maxLength = 240; note.value = row.note || ''; note.placeholder = featureText('z. B. Parkhaus Ebene 2','e.g. parking level 2'); noteLabel.append(noteTitle,note);
      const saveRule = document.createElement('button'); saveRule.type = 'submit'; saveRule.dataset.i18n = 'common.save'; saveRule.textContent = t('common.save');
      ruleFields.append(limitLabel, reminderLabel, reachedLabel);
      ruleForm.append(enabledLabel, ruleFields, noteLabel, saveRule);
      enabled.addEventListener('change', () => { ruleFields.hidden = !enabled.checked; });
      ruleForm.onsubmit = async event => {
        event.preventDefault();
        const hours = Number(limit.value); const lead = Number(reminder.value);
        if (!Number.isInteger(hours) || hours < 1 || hours > 48 || !Number.isInteger(lead) || lead < 0 || lead >= hours * 60) { setMessage(t('error.validation'), true); return; }
        await api('/api/functional/locations', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...row, custom_name:row.custom_name, note:note.value.trim(), time_limit_enabled:enabled.checked, time_limit_minutes:hours*60, time_reminder_minutes:lead, time_limit_notify_at_limit:reached.checked})});
        setMessage(t('message.saved')); await loadFunctionalData();
      };
      const actions = document.createElement('div'); actions.className = 'location-row-actions'; actions.append(rename,maps,remove);
      disclosure.append(actions,ruleForm); item.append(disclosure);
      if (autoLabel.textContent) item.append(autoLabel);
      built.push({item, row});
      if (previouslyOpenId && String(row.id) === String(previouslyOpenId)) disclosure.open = true;
    }
    // Frequently used places first; places seen only once (and not renamed) go into a collapsed group.
    built.sort((a, b) => (b.row.sessions || 0) - (a.row.sessions || 0) || String(b.row.last_used || '').localeCompare(String(a.row.last_used || '')));
    const once = built.filter(({row}) => (row.sessions || 0) < 2 && !row.custom_name);
    const regular = built.filter(entry => !once.includes(entry));
    for (const {item} of (regular.length ? regular : once)) list.append(item);
    if (regular.length && once.length) {
      const group = document.createElement('details'); group.className = 'location-once';
      const label = document.createElement('summary'); label.textContent = t('location.onceGroup', {value: once.length});
      const body = document.createElement('div'); body.className = 'location-once-list';
      for (const {item} of once) body.append(item);
      group.append(label, body);
      if (previouslyOpenId && once.some(({row}) => String(row.id) === String(previouslyOpenId))) group.open = true;
      list.append(group);
    }
  }
  renderChargingLocationsMap(value.locations || []);
  if (previouslyOpenId && (value.locations || []).some(row => String(row.id) === String(previouslyOpenId))) {
    selectChargingLocation(previouslyOpenId, {moveMap:false});
  }
  state.functionalLocationCount = value.locations?.length || 0;
  updateChargingLocationLabels();
  if (!value.locations?.length) list.innerHTML = `<div class="empty-state"><strong data-i18n="location.emptyTitle">${t('location.emptyTitle')}</strong><span data-i18n="location.emptyHelp">${t('location.emptyHelp')}</span></div>`;
  if (locationsOnly) return {locations:value.locations || [], labelsPending:Boolean(value.location_labels_pending), labelsMore:Boolean(value.location_labels_more), attemptedId:value.location_label_attempted_id || null};
  const maintenance = await api('/api/functional/maintenance');
  maintenance.maintenance?.sort((a,b) => Number(a.due_odometer) - Number(b.due_odometer));
  const maintenanceRows = maintenance.maintenance || [];
  const formatMaintenanceKm = formatOdometerDistance;
  const maintenanceSummary = detailPages.get('maintenance').nav.querySelector('small');
  maintenanceSummary.textContent = `${t('maintenance.entryCount', {count: maintenanceRows.length})} · ${maintenance.odometer == null ? t('maintenance.odometerUnavailable') : t('maintenance.odometer', {value: formatMaintenanceKm(maintenance.odometer)})}`;
  const maintenanceList = $('maintenanceList');
  if (maintenanceList) {
    maintenanceList.replaceChildren();
    for (const row of maintenanceRows) {
      const item = document.createElement('article'); item.className = 'settings-group';
      const text = document.createElement('span');
      const remaining = row.distance_remaining;
      const context = row.status === 'overdue' && remaining != null ? t('maintenance.overdueBy', {value: formatMaintenanceKm(Math.abs(remaining))})
        : row.status === 'due' ? t('maintenance.dueNow')
        : row.status === 'upcoming' && remaining != null ? t('maintenance.upcoming', {value: formatMaintenanceKm(remaining)})
        : t('maintenance.unknown');
      text.textContent = `${row.name} · ${formatMaintenanceKm(row.due_odometer)} km · ${context}${row.note ? ` · ${row.note}` : ''}`;
      const done = document.createElement('button'); done.type = 'button'; done.textContent = 'Erledigt'; done.onclick = async () => { await api('/api/functional/maintenance/complete', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: row.id})}); await loadFunctionalData(); };
      const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Bearbeiten'; edit.onclick = () => { const form = $('maintenanceForm'); form.hidden = false; for (const key of ['id', 'name', 'due_odometer', 'repeat_km', 'note']) { let input = form.elements[key]; if (!input && key === 'id') { input = document.createElement('input'); input.type = 'hidden'; input.name = 'id'; form.append(input); } if (input) input.value = row[key] ?? ''; } form.elements.name.focus(); };
      const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger-action'; remove.textContent = 'Löschen'; remove.onclick = async () => { if (window.confirm('Wartung löschen?')) { await api('/api/functional/maintenance/delete', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: row.id})}); await loadFunctionalData(); } };
      const disclosure = document.createElement('details'); const summary = document.createElement('summary'); summary.append(text); disclosure.append(summary, edit, done, remove); item.append(disclosure); maintenanceList.append(item);
    }
  }
  const comparison = $('comparisonForm');
  if (comparison) populateComparison();
  await loadMilestones();
  if (!maintenance.maintenance?.length) maintenanceList.innerHTML = `<div class="empty-state"><strong data-i18n="maintenance.emptyTitle">${t('maintenance.emptyTitle')}</strong><span data-i18n="maintenance.empty">${t('maintenance.empty')}</span></div>`;
  localizeFunctionalUi();
  document.body.dataset.functionalReady = 'true';
  return value.locations || [];
}

async function backfillChargingLocationLabels() {
  if (state.locationBackfillActive) return;
  state.locationBackfillActive = true;
  const generation = ++state.locationBackfillGeneration;
  const skippedLocationIds = new Set();
  // The route may start before the first functional payload hydrates the count.
  // A fixed ceiling avoids cutting off an initial visit with many unlabeled places.
  const maxAttempts = 64;
  try {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      if (generation !== state.locationBackfillGeneration) break;
      if (location.hash !== '#settings/locations' || $('detail-locations')?.hidden !== false) break;
      const backfill = await loadFunctionalData({resolveNext:true, locationsOnly:true, skipLocationIds:[...skippedLocationIds]});
      if (generation !== state.locationBackfillGeneration) break;
      if (backfill.attemptedId) skippedLocationIds.add(String(backfill.attemptedId));
      if (!backfill.labelsPending && !backfill.labelsMore) break;
      if (attempt < maxAttempts - 1) await new Promise(resolve => { state.locationBackfillTimer = setTimeout(resolve, 1800); });
    }
  } catch (_) { /* Optional labels never interrupt the existing location list. */ }
  finally { if (generation === state.locationBackfillGeneration) state.locationBackfillActive = false; }
}

function cancelLocationLabelBackfill() {
  state.locationBackfillGeneration++;
  state.locationBackfillActive = false;
}

async function loadMilestones() {
  const value = await api('/api/functional/odometer-milestones'); const list = $('milestoneList');
  if (!list) return; list.replaceChildren();
  detailPages.get('milestones').nav.querySelector('small').textContent = value.milestones?.length ? `${value.milestones.filter(r => !r.notified).length} aktiv` : 'Keine Meilensteine';
  for (const row of value.milestones || []) { const item = document.createElement('p'); item.textContent = `${row.name} · ${row.target_odometer} km${row.notified ? ' · erreicht' : ''}`; const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = 'Löschen'; remove.onclick = async () => { await api('/api/functional/odometer-milestones/delete', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: row.id})}); await loadMilestones(); }; item.append(' ', remove); list.append(item); }
  if (!value.milestones?.length) list.innerHTML = `<div class="empty-state"><strong data-i18n="milestones.emptyTitle">${t('milestones.emptyTitle')}</strong><span data-i18n="milestones.empty">${t('milestones.empty')}</span></div>`;
  localizeFunctionalUi();
}

function openExternalMap(latitude, longitude) {
  const lat = Number(latitude); const lon = Number(longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
  openDirections({latitude:lat,longitude:lon});
}

function renderChargingLocationsMap(rows) {
  const root = $('chargingLocationsMap');
  if (!root || !rows.length || !window.L) { if (root) root.hidden = true; return; }
  root.hidden = false;
  state.locationDetails = rows;
  let map = root._leafletMap;
  if (!map) {
    map = window.L.map(root, {zoomControl:true,attributionControl:true,scrollWheelZoom:false,tap:true});
    localizeMapZoomControls(root);
    window.L.tileLayer(MAP_TILE_URL, {attribution: `© <a href="${MAP_ATTRIBUTION_URL}/copyright">OpenStreetMap</a> contributors`}).addTo(map);
    root._leafletMap = map;
  }
  for (const item of state.locationMapMarkers) map.removeLayer(item.marker);
  state.locationMapMarkers = [];
  rows.forEach((row,index) => {
    const selected = String(row.id) === String(state.selectedLocationId);
    const marker = window.L.circleMarker([row.latitude, row.longitude], {radius:selected?10:8,color:selected?'#ffd27a':'#ffffff',weight:selected?3:2,fillColor:selected?'#f4b942':'#5a9bea',fillOpacity:1}).addTo(map);
    marker.on('click', () => selectChargingLocation(row.id, {fromMap:true,scroll:true}));
    state.locationMapMarkers.push({marker,row});
  });
  const points=rows.map(row=>[Number(row.latitude),Number(row.longitude)]).filter(point=>point.every(Number.isFinite));
  if (!state.locationMapHasFit) {
    if(points.length===1) map.setView(points[0],15,{animate:false});
    else if(points.length>1) map.fitBounds(window.L.latLngBounds(points),{padding:[24,24],maxZoom:14,animate:false});
    state.locationMapHasFit = points.length > 0;
  }
  requestAnimationFrame(()=>map.invalidateSize({pan:false}));
  updateChargingLocationMapPopups();
}

function selectChargingLocation(locationId, {fromMap=false,scroll=false,moveMap=true}={}) {
  const id = String(locationId || '');
  const row = (state.locationDetails || []).find(item => String(item.id) === id);
  if (!row) return;
  state.selectedLocationId = id;
  document.querySelectorAll('#locationList article.location-selected').forEach(item => item.classList.remove('location-selected'));
  const article = [...document.querySelectorAll('#locationList article[data-location-id]')]
    .find(item => item.dataset.locationId === id);
  const disclosure = article?.querySelector('details');
  const summary = disclosure?.querySelector('summary');
  article?.classList.add('location-selected');
  if (fromMap && disclosure) disclosure.open = true;
  if (scroll && article) {
    article.scrollIntoView({behavior:reducedMotionPreferred()?'auto':'smooth',block:'center'});
    summary?.focus({preventScroll:true});
  }
  for (const entry of state.locationMapMarkers || []) {
    const selected = String(entry.row.id) === id;
    entry.marker.setStyle({radius:selected?10:8,color:selected?'#ffd27a':'#ffffff',weight:selected?3:2,fillColor:selected?'#f4b942':'#5a9bea'});
  }
  const map = $('chargingLocationsMap')?._leafletMap;
  const latitude = Number(row.latitude); const longitude = Number(row.longitude);
  if (moveMap && map && Number.isFinite(latitude) && Number.isFinite(longitude)) {
    map.setView([latitude,longitude],16,{animate:!reducedMotionPreferred()});
  }
}

function updateChargingLocationMapPopups() {
  for (const [index, {marker, row}] of (state.locationMapMarkers || []).entries()) {
    const popup = document.createElement('div'); popup.className='location-map-popup';
    const name = document.createElement('strong'); name.textContent=row.display_name||row.name;
    const count = document.createElement('span'); count.textContent=Number(row.sessions)===1?t('location.sessionsOne'):t('location.sessionsMany',{value:Number(row.sessions)||0});
    popup.append(name,count);
    if (row.last_used) { const last=document.createElement('span'); const date=new Date(row.last_used); last.textContent=`${t('location.lastUsed')} ${Number.isNaN(date.getTime())?'–':formatChargingLocationDate(date)}`; popup.append(last); }
    const detail=document.createElement('button'); detail.type='button'; detail.className='text-action'; detail.textContent=t('location.openDetails'); detail.addEventListener('click',()=>{selectChargingLocation(row.id,{fromMap:true,scroll:true});marker.closePopup();}); popup.append(detail);
    marker.bindPopup(popup);
  }
}

async function submitLocation(event) { event.preventDefault(); const form = event.currentTarget; await api('/api/functional/locations', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))}); form.reset(); form.elements.id?.remove(); form.hidden = true; await loadFunctionalData(); }
async function submitMaintenance(event) { event.preventDefault(); const form = event.currentTarget; await api('/api/functional/maintenance', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))}); form.reset(); form.elements.id?.remove(); form.hidden = true; await loadFunctionalData(); }
async function submitMilestone(event) { event.preventDefault(); const form = event.currentTarget; const body = Object.fromEntries(new FormData(form).entries()); body.notify = form.elements.notify.checked; await api('/api/functional/odometer-milestones', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)}); form.reset(); form.hidden = true; await loadMilestones(); }
async function restoreBackup(event) { const file = event.target.files?.[0]; if (!file || !window.confirm(featureText('Backup prüfen und deine aktuellen Daten damit wiederherstellen?', 'Validate the backup and restore existing user data?'))) return; const pin = window.prompt(featureText('Admin-PIN', 'Admin PIN')); if (!pin) return; const bytes = new Uint8Array(await file.arrayBuffer()); let binary = ''; for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); await api('/api/functional/restore', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({backup_base64: btoa(binary), pin})}); setMessage(featureText('Backup wiederhergestellt.', 'Backup restored.')); }
async function compareSessions(event) {
  event.preventDefault();
  const form = event.currentTarget; const button = form.querySelector('button'); button.disabled = true;
  try {
    const value = await api(`/api/history/compare?left=${encodeURIComponent(form.left.value)}&right=${encodeURIComponent(form.right.value)}`);
    state.comparison = value;
    renderComparison(value);
  } finally { button.disabled = false; }
}

function renderComparison(value) {
    const root = $('comparisonResult'); if (!root) return; root.replaceChildren();
    const sessions = [value.left, value.right];
    for (const [index, session] of sessions.entries()) {
      const card = document.createElement('article'); card.className = 'comparison-card';
      const title = document.createElement('h3'); title.textContent = t('comparison.session', {value: index+1}); card.append(title);
      const date = document.createElement('p'); date.textContent = localTimestamp(session.started_at_utc); card.append(date);
      const fields = [[t('comparison.socRange'),`${session.start_soc ?? '–'} → ${session.end_soc ?? '–'} %`],[t('comparison.elapsedSessionTime'),duration(session.session_duration_seconds ?? session.duration_seconds)], [t('history.activeCharging'),session.active_charging_duration_seconds == null ? t('history.unknown') : duration(session.active_charging_duration_seconds)],[t('comparison.target'), session.target_soc == null ? '–' : `${session.target_soc} %`],[t('comparison.distance'),session.distance_since_previous_charge == null ? '–' : `${session.distance_since_previous_charge} km`]];
      const values = document.createElement('dl');
      for (const [label,text] of fields) { const term = document.createElement('dt'); term.textContent = label; const detail = document.createElement('dd'); detail.textContent = text; values.append(term,detail); }
      card.append(values); root.append(card);
    }
    const summary = document.createElement('section'); summary.className = 'comparison-differences';
    summary.setAttribute('aria-label', t('comparison.differencesDirection'));
    const heading = document.createElement('h3'); heading.textContent = t('comparison.differencesDirection'); summary.append(heading);
    const firstDuration = sessions[0].session_duration_seconds ?? sessions[0].duration_seconds;
    const secondDuration = sessions[1].session_duration_seconds ?? sessions[1].duration_seconds;
    const difference = (first, second, kind) => {
      const valid = value => typeof value === 'number' && Number.isFinite(value) && (kind !== 'soc' || (value >= 0 && value <= 100)) && (kind !== 'time' || value >= 0);
      return valid(first) && valid(second) ? first - second : null;
    };
    const fields = [
      [t('comparison.startSocDifference'), difference(sessions[0].start_soc, sessions[1].start_soc, 'soc'), 'soc'],
      [t('comparison.endSocDifference'), difference(sessions[0].end_soc, sessions[1].end_soc, 'soc'), 'soc'],
      [t('comparison.elapsedTimeDifference'), difference(firstDuration, secondDuration, 'time'), 'time'],
    ];
    const values = document.createElement('dl');
    for (const [label, delta, kind] of fields) {
      const term = document.createElement('dt'); term.textContent = label;
      const detail = document.createElement('dd');
      if (delta == null) detail.textContent = '–';
      else if (kind === 'soc') detail.textContent = `${delta > 0 ? '+' : delta < 0 ? '−' : ''}${Math.abs(delta)} ${t(Math.abs(delta) === 1 ? 'comparison.percentagePoint' : 'comparison.percentagePoints')}`;
      else if (delta === 0) detail.textContent = t('comparison.zeroTimeDifference');
      else if (Math.abs(delta) < 60) detail.textContent = `${delta < 0 ? '−' : '+'}${t('comparison.subMinuteTimeDifference')}`;
      else detail.textContent = `${delta < 0 ? '−' : '+'}${duration(Math.abs(delta))}`;
      values.append(term, detail);
    }
    summary.append(values); root.append(summary);
}

function pushHint() {
  const hint = document.createElement('p'); hint.className = 'muted push-hint'; hint.dataset.i18n = 'push.iosHint';
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent); const standalone = (typeof matchMedia === 'function' && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  hint.textContent = t('push.iosHint'); hint.hidden = !(ios && !standalone); return hint;
}

function setPushFeedback(text, error = false) {
  const feedback = $('pushFeedback');
  if (feedback) { feedback.textContent = text; feedback.hidden = !text; feedback.dataset.error = String(error); }
}

async function enablePush() {
  setPushFeedback('');
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) { setPushFeedback(t('push.unsupported'), true); return; }
  // Ask for permission first: iOS only allows the prompt directly inside the tap.
  const permission = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
  if (permission !== 'granted') { setPushFeedback(t('push.permissionDenied'), true); return; }
  try {
    const registration = await navigator.serviceWorker.ready;
    const status = await api('/api/functional/push-status');
    if (!status.public_key) { setPushFeedback(t('push.keyUnavailable'), true); return; }
    const decode = value => Uint8Array.from(atob(value.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - value.length % 4) % 4)), c => c.charCodeAt(0));
    const subscription = await registration.pushManager.getSubscription() || await registration.pushManager.subscribe({userVisibleOnly: true, applicationServerKey: decode(status.public_key)});
    const result = await api('/api/functional/subscriptions', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({...subscription.toJSON(), language: state.language})});
    if (!result.registered) throw new Error(t('push.registrationFailed'));
    setPushFeedback(t('push.saved')); await loadFunctionalSettings();
  } catch (error) {
    setPushFeedback(`${t('push.registrationFailed')} (${error?.name || 'Fehler'}${error?.message ? ': ' + String(error.message).slice(0, 80) : ''})`, true);
  }
}

async function disablePush() {
  const registration = await navigator.serviceWorker.ready; const subscription = await registration.pushManager.getSubscription();
  if (subscription) { await api('/api/functional/subscriptions/delete', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({endpoint: subscription.endpoint})}); await subscription.unsubscribe(); }
  setMessage(featureText('Browser-Benachrichtigungen wurden deaktiviert.', 'Browser notifications were disabled.')); await loadFunctionalSettings();
}

async function sendPushTest() {
  const setFeedback = setPushFeedback;
  const current = await refreshPushStatus();
  if (!current || current.state !== 'REGISTERED') { setFeedback(t('push.notRegistered'), true); return; }
  try {
    const result = await api('/api/functional/push-test', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'});
    if (!result.configured || !result.sent) { setFeedback(t('push.feedbackFailed'), true); return; }
    if (result.provider_result !== 'accepted') { setFeedback(t('push.feedbackFailed'), true); return; }
    setFeedback(t('push.feedbackAccepted')); setMessage('');
  } catch (error) { setFeedback(t('push.feedbackFailed'), true); }
}

async function saveNotificationPreferences(event) {
  event.preventDefault();
  if (event.currentTarget.dataset.hydrated !== 'true') return;
  const body = {notifications: {}};
  event.currentTarget.querySelectorAll('input[type=checkbox]').forEach(input => { body.notifications[input.name] = input.checked; });
  body.offline_threshold_minutes = Number(event.currentTarget.elements.offline_threshold_minutes.value);
  body.post_charge_reminder_minutes = Number(event.currentTarget.elements.post_charge_reminder_minutes.value);
  body.charging_not_started_minutes = Number(event.currentTarget.elements.charging_not_started_minutes.value);
  body.evening_reminder_soc = Number(event.currentTarget.elements.evening_reminder_soc.value);
  body.evening_reminder_hour = Number(event.currentTarget.elements.evening_reminder_hour.value);
  await api('/api/functional/preferences', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  setMessage(t('message.saved'));
}

async function filterHistory(event) {
  event?.preventDefault();
  const query = new URLSearchParams();
  if ($('historyQuery').value) query.set('q', $('historyQuery').value);
  if ($('historyTarget').value) query.set('target', $('historyTarget').value);
  if ($('historyReason').value) query.set('completion_reason', $('historyReason').value);
  if ($('historyLocation').value) query.set('location', $('historyLocation').value);
  query.set('language', state.language);
  const value = await api(`/api/history?${query}`); renderHistory(value.items, false);
  renderHistoryFilterChips();
  document.querySelector('.filter-detail').open = false;
}

async function saveVehicleModel() {
  const model = $('vehicleModelSelect').value, color = $('vehicleColorSelect').value;
  state.vehiclePick = {model, color, expires: Date.now() + 15000};
  renderLocalVehicleImage('vehicleImage', 'vehicleImageSkeleton', model, color);
  if (state.vehicleSaving) { state.vehicleDirty = true; return; }
  state.vehicleSaving = true;
  let failed = false;
  try {
    do {
      state.vehicleDirty = false;
      const body = {vehicle_model: $('vehicleModelSelect').value, vehicle_color: $('vehicleColorSelect').value};
      try { await api('/api/config/vehicle-model', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)}); }
      catch (_) { failed = true; state.vehicleDirty = false; }
    } while (state.vehicleDirty);
  } finally { state.vehicleSaving = false; }
  if (failed) { state.vehiclePick = null; setMessage(t('message.requestFailed'), true); }
  else { state.vehiclePick = {...state.vehiclePick, expires: Date.now() + 10000}; setMessage(t('message.saved')); }
  try { await loadDashboard(); } catch (_) { /* the next refresh shows the saved state */ }
}

// ---------------------------------------------------------------- own vehicle photo
async function downscaleImage(file, maxSide = 1600) {
  // createImageBitmap and data: URLs both satisfy the page's Content-Security-Policy (blob: images do not).
  let source = null;
  if (window.createImageBitmap) { try { source = await createImageBitmap(file); } catch (_) { source = null; } }
  if (!source) {
    const dataUrl = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
    source = await new Promise((resolve, reject) => { const image = new Image(); image.onload = () => resolve(image); image.onerror = reject; image.src = dataUrl; });
  }
  const width = source.width || source.naturalWidth, height = source.height || source.naturalHeight;
  const scale = Math.min(1, maxSide / Math.max(width, height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
  source.close?.();
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('encode')), 'image/jpeg', 0.88));
}

async function uploadVehiclePhoto(file) {
  try {
    const blob = await downscaleImage(file);
    const response = await fetch('/api/vehicle-photo', {method: 'POST', headers: {'Content-Type': 'application/octet-stream'}, body: blob});
    const value = await response.json();
    if (!response.ok) { const error = new Error('upload'); error.payload = value; throw error; }
    state.customPhoto = value.version || '';
    renderColorOptions($('vehicleModelSelect').value, 'custom');
    $('vehicleColorSelect').value = 'custom';
    await saveVehicleModel();
  } catch (error) { setMessage(errorMessage(error.payload), true); }
}

function setupVehiclePhoto() {
  const input = $('vehiclePhotoInput');
  if (!input) return;
  input.addEventListener('change', async () => { const file = input.files?.[0]; input.value = ''; if (file) await uploadVehiclePhoto(file); });
  $('vehiclePhotoRemove').addEventListener('click', async () => {
    try {
      await api('/api/vehicle-photo/remove', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'});
      state.customPhoto = '';
      renderColorOptions($('vehicleModelSelect').value, '');
      state.vehiclePick = null;
      await loadDashboard();
    } catch (error) { setMessage(errorMessage(error.payload), true); }
  });
}

// ---------------------------------------------------------------- remote access (Tailscale)
function renderRemote(payload) {
  const detected = payload.detected || {};
  const url = payload.effective_url || '';
  updateText($('remoteSummary'), url ? url.replace(/^https:\/\//, '') : t(detected.installed ? 'remote.summaryNone' : 'remote.summaryMissing'));
  let line;
  if (!detected.installed) line = t('remote.statusMissing');
  else if (detected.state === 'connected') line = t('remote.statusConnected');
  else if (detected.state === 'needslogin') line = t('remote.statusLogin');
  else if (detected.state === 'stopped') line = t('remote.statusStopped');
  else line = t('remote.statusOther', {state: detected.state || 'unknown'});
  $('remoteStatus').textContent = line;
  renderRemoteAction(detected, url);
  const steps = document.querySelector('.remote-steps');
  if (steps && !steps.closest('details.remote-howto')) {
    const fold = document.createElement('details'); fold.className = 'remote-howto';
    const label = document.createElement('summary'); label.dataset.i18n = 'remote.stepsTitle'; label.textContent = t('remote.stepsTitle');
    steps.before(fold); fold.append(label, steps);
    // Manual steps are only the fallback for devices without Tailscale; the button does the rest.
    fold.open = !detected.installed;
  }
  if (document.activeElement !== $('remoteUrl')) $('remoteUrl').value = payload.configured_url || '';
  $('remoteUrl').placeholder = (detected.url || '').replace(/^https:\/\//, '') || 'mein-pi.mein-netz.ts.net';
  $('remoteCopy').hidden = !url;
  state.remoteUrl = url;
}

// One button walks the owner through Tailscale: log in, allow HTTPS once if asked, done.
function renderRemoteAction(detected, url) {
  const box = $('remoteAction');
  const stage = !detected.installed ? '' : detected.state !== 'connected' ? 'login' : detected.serving ? 'ready' : 'serve';
  box.hidden = !stage;
  if (!stage) return;
  box.dataset.stage = stage;
  $('remoteActionText').textContent = stage === 'ready' ? t('remote.readyText', {url: url.replace(/^https:\/\//, '')}) : t(stage === 'login' ? 'remote.loginText' : 'remote.serveText');
  $('remoteConnect').hidden = stage === 'ready';
  $('remoteConnect').textContent = t(stage === 'login' ? 'remote.connect' : 'remote.serve');
  if (stage === 'ready' || (stage === 'login' && !detected.auth_url && !state.remoteNext)) { $('remoteNext').hidden = true; state.remoteNext = null; }
  if (stage === 'login' && detected.auth_url) { if (!state.remoteNext) $('remoteMessage').textContent = t('remote.loginHint'); showRemoteNext(detected.auth_url, 'remote.openLogin'); }
}

function showRemoteNext(href, labelKey) {
  state.remoteNext = href;
  $('remoteNext').href = href; $('remoteNext').textContent = t(labelKey); $('remoteNext').hidden = false;
}

async function connectRemote() {
  const button = $('remoteConnect'); button.disabled = true; $('remoteMessage').textContent = t('wizard.checking');
  try {
    const value = await api('/api/remote/connect', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'});
    $('remoteMessage').textContent = value.error_code ? t(`error.${value.error_code}`) : value.next_url ? t(value.needs === 'https' ? 'remote.httpsHint' : 'remote.loginHint') : value.pending ? t('remote.loginPending') : '';
    if (value.next_url) showRemoteNext(value.next_url, value.needs === 'https' ? 'remote.openHttps' : 'remote.openLogin');
    await loadRemote();
    // Keep looking while the owner finishes the login in the other tab.
    clearInterval(connectRemote.timer); let rounds = 0;
    connectRemote.timer = setInterval(async () => {
      await loadRemote();
      if (++rounds > 200 || $('remoteAction').dataset.stage === 'ready') { clearInterval(connectRemote.timer); if ($('remoteAction').dataset.stage === 'ready') $('remoteMessage').textContent = ''; }
    }, 3000);
  } catch (error) { $('remoteMessage').textContent = errorMessage(error.payload); }
  finally { button.disabled = false; }
}

async function loadRemote() {
  try { renderRemote(await api('/api/remote')); } catch (_) { /* optional section */ }
}

function setupRemote() {
  if (!$('remoteForm')) return;
  $('remoteForm').addEventListener('submit', async event => {
    event.preventDefault();
    try {
      renderRemote(await api('/api/config/remote-url', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({url: $('remoteUrl').value})}));
      $('remoteMessage').textContent = t('message.saved');
    } catch (error) { $('remoteMessage').textContent = errorMessage(error.payload); }
  });
  $('remoteConnect').addEventListener('click', connectRemote);
  $('remoteCopy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.remoteUrl || ''); $('remoteMessage').textContent = t('remote.copied'); }
    catch (_) { $('remoteMessage').textContent = state.remoteUrl || ''; }
  });
  loadRemote();
}

// ---------------------------------------------------------------- software updates
function updateMessage(text, isError = false) {
  const node = $('updateMessage');
  node.textContent = text || '';
  node.style.color = isError ? 'var(--bad)' : '';
}

function updateAgo(ts) {
  const seconds = Math.max(0, Date.now() / 1000 - ts);
  if (seconds < 90) return t('updates.checkedJustNow');
  if (seconds < 3600) return t('updates.checkedMinutes', {n: Math.round(seconds / 60)});
  if (seconds < 86400) return t('updates.checkedHours', {n: Math.round(seconds / 3600)});
  return t('updates.checkedDays', {n: Math.round(seconds / 86400)});
}

function setUpdateHero(stateName, title, sub) {
  const hero = $('updateHero');
  if (!hero) return;
  if (hero.dataset.state !== stateName) hero.dataset.state = stateName;
  $('updateHeroTitle').textContent = title;
  $('updateHeroSub').textContent = sub || '';
}

function renderUpdateHero(payload) {
  const available = payload.available;
  if (state.updateChecking) return setUpdateHero('checking', t('updates.heroChecking'), t('updates.heroCheckingSub'));
  if (state.updateInstalling) return setUpdateHero('busy', t('updates.heroInstalling'), t('updates.heroInstallingSub'));
  if (payload.staged_version) return setUpdateHero('busy', t('updates.heroStaged'), t('updates.heroStagedSub'));
  if (!payload.configured) return setUpdateHero('idle', t('updates.heroOff'), '');
  if (available && payload.scheduled_at) {
    const hours = (payload.scheduled_at * 1000 - Date.now()) / 3600000;
    const time = new Date(payload.scheduled_at * 1000).toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit'});
    return setUpdateHero('scheduled', t(hours > 20 ? 'updates.heroScheduledTomorrow' : 'updates.heroScheduled'), t('updates.heroScheduledSub', {version: available.version, time}));
  }
  if (available) return setUpdateHero('available', t('updates.heroAvailable'), t('updates.heroAvailableSub', {version: available.version}));
  if (payload.last_error) return setUpdateHero('error', t('updates.heroError'), t('updates.heroErrorSub'));
  if (!payload.last_check_ts) return setUpdateHero('idle', t('updates.heroNever'), t('updates.heroNeverSub'));
  return setUpdateHero('ok', t('updates.heroCurrent'), t('updates.heroCurrentSub', {version: payload.current_version, when: updateAgo(payload.last_check_ts)}));
}

function renderUpdates(payload) {
  state.updates = payload;
  const available = payload.available;
  const when = payload.last_check_ts ? localTimestamp(new Date(payload.last_check_ts * 1000).toISOString()) : null;
  let summary = t('updates.summaryCurrent', {version: payload.current_version});
  if (available) summary = t('updates.summaryAvailable', {version: available.version});
  updateText($('updatesSummary'), summary);
  renderUpdateHero(payload);
  const lines = [t('updates.current', {version: payload.current_version})];
  if (!payload.configured) lines.push(t('updates.notConfigured'));
  if (payload.held_back) lines.push(t('updates.heldBack'));
  if (payload.notice === 'beta_access_ended') lines.push(t('updates.betaEnded'));
  if (payload.notice === 'beta_unverified') lines.push(t('updates.betaUnverified'));
  $('updateStatus').textContent = lines.join('\n');
  const box = $('updateAvailable');
  box.hidden = !available;
  if (available) {
    $('updateAvailableTitle').textContent = available.downgrade ? t('updates.whatsNewDowngrade', {version: available.version}) : t(available.channel === 'beta' ? 'updates.whatsNewBeta' : 'updates.whatsNew', {version: available.version});
    $('updateSummary').textContent = available.summary || '';
    const list = $('updateNotes'); list.replaceChildren();
    for (const note of available.notes || []) { const item = document.createElement('li'); item.textContent = note; list.append(item); }
  }
  const beta = $('updateBeta');
  beta.checked = payload.channel === 'beta';
  $('updateChannelHelp').textContent = t(beta.checked ? 'updates.betaOnHelp' : 'updates.betaOffHelp');
  // Leaving the beta while running a version newer than stable: the way back, only where the data are known to fit.
  const back = $('updateReturn');
  const offer = payload.channel === 'stable' && (payload.held_back || payload.return_to_stable || payload.downgrade_blocked);
  back.hidden = !offer;
  if (offer) {
    let text = t('updates.returnOffer');
    if (payload.downgrade_blocked) text = t('updates.returnBlocked');
    else if (available?.downgrade) text = t('updates.returnReady', {version: available.version});
    else if (payload.return_to_stable) text = t('updates.returnChecking');
    $('updateReturnText').textContent = text;
    $('updateReturnButton').hidden = Boolean(payload.return_to_stable || payload.downgrade_blocked || available?.downgrade);
  }
  const blockers = payload.install_blockers || [];
  const install = $('updateInstall');
  install.hidden = !available || Boolean(payload.staged_version);
  install.disabled = blockers.length > 0;
  install.textContent = available?.downgrade ? t('updates.installDowngrade', {version: available.version}) : t('updates.install');
  const schedule = $('updateSchedule');
  schedule.hidden = install.hidden;
  schedule.disabled = blockers.some(code => code !== 'vehicle_busy');
  schedule.textContent = t(payload.scheduled_at ? 'updates.scheduleCancel' : 'updates.scheduleTonight');
  $('updateAuto').checked = Boolean(payload.auto_install);
  if (available && blockers.length) updateMessage(t(`updates.blocker.${blockers[0]}`));
  else if (!updateMessage.sticky) updateMessage('');
  document.querySelector('[data-detail="cat-app"]')?.classList.toggle('has-update', Boolean(available));
  refreshSettingsSummaries();
  document.querySelector('.mobile-nav [data-tab="settings"]')?.classList.toggle('has-update', Boolean(available));
}

async function loadUpdates(checkNow = false) {
  try {
    if (checkNow) await api('/api/updates/check', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({force: true})});
    renderUpdates(await api('/api/updates'));
  } catch (_) { /* the update row is optional; the dashboard keeps working without it */ }
}

async function updateAction(path, body, successKey) {
  updateMessage.sticky = true;
  try {
    const value = await api(path, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})});
    renderUpdates(value);
    updateMessage(successKey ? t(successKey) : '');
    return true;
  } catch (error) {
    updateMessage(errorMessage(error.payload), true);
    return false;
  } finally { updateMessage.sticky = false; }
}

function setupUpdates() {
  if (!$('updatePanel')) return;
  $('updateCheck').onclick = async () => {
    const button = $('updateCheck');
    button.disabled = true;
    button.textContent = t('updates.checking');
    state.updateChecking = true;
    if (state.updates) renderUpdateHero(state.updates);
    const started = Date.now();
    const result = updateAction('/api/updates/check', {force: true});
    await new Promise(resolve => setTimeout(resolve, Math.max(0, 1100 - (Date.now() - started))));
    await result;
    state.updateChecking = false;
    if (state.updates) renderUpdateHero(state.updates);
    button.textContent = t('updates.check');
    button.disabled = false;
  };
  $('updateSchedule').onclick = async () => {
    const planned = Boolean(state.updates?.scheduled_at);
    $('updateSchedule').disabled = true;
    await updateAction('/api/updates/schedule', {enabled: !planned}, planned ? 'updates.scheduledCleared' : 'updates.scheduledSet');
  };
  $('updateAuto').onchange = async event => {
    if (!await updateAction('/api/updates/auto', {enabled: event.target.checked})) event.target.checked = !event.target.checked;
  };
  $('updateBeta').onchange = async event => {
    const on = event.target.checked;
    const ok = await updateAction('/api/updates/channel', {channel: on ? 'beta' : 'stable'});
    if (!ok) event.target.checked = !on;
    else await updateAction('/api/updates/check', {force: true});
  };
  $('updateReturnButton').onclick = async () => {
    $('updateReturnButton').disabled = true;
    if (await updateAction('/api/updates/channel', {channel: 'stable', return_to_stable: true})) await updateAction('/api/updates/check', {force: true});
    $('updateReturnButton').disabled = false;
  };
  $('betaForm').addEventListener('submit', async event => {
    event.preventDefault();
    if (await updateAction('/api/updates/beta', {code: $('betaCode').value}, 'updates.joined')) { $('betaCode').value = ''; await updateAction('/api/updates/check', {force: true}); }
  });
  $('updateInstall').onclick = async () => {
    $('updateInstall').disabled = true;
    state.updateInstalling = true;
    if (state.updates) renderUpdateHero(state.updates);
    updateMessage(t('updates.installing'));
    await updateAction('/api/updates/install', {}, 'updates.installStarted');
    state.updateInstalling = false;
    if (state.updates) renderUpdateHero(state.updates);
  };
  loadUpdates(false);
}

async function authenticatedAction(path, successKey) {
  try {
    const value = await api(path, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'});
    setMessage(t(successKey));
    return value;
  } catch (error) { setMessage(errorMessage(error.payload), true); return null; }
}

const detailPages = new Map();
let detailRouting = false;

function setupDetailPages() {
  const settings = $('panel-settings');
  const functional = $('functionalSettings');
  const group = document.createElement('section'); group.className = 'settings-section';
  const label = document.createElement('h3'); label.id='featuresSectionTitle'; label.className = 'settings-section-title'; label.textContent = t('settings.featuresSection');
  const rows = document.createElement('div'); rows.className = 'settings-group'; group.append(label, rows);
  settings.insertBefore(group, $('advancedSettings'));
  const definitions = [['notifications','feature.notifications'],['locations','feature.locations'],['maintenance','feature.maintenance'],['milestones','feature.milestones'],['backup','feature.backup']];
  [...functional.children].forEach((disclosure, index) => {
    const [key, titleKey] = definitions[index]; const title = t(titleKey);
    const summary = disclosure.querySelector('summary');
    const nav = document.createElement('button'); nav.type = 'button'; nav.className = 'settings-nav-row'; nav.dataset.detail = key;
    const copy = summary.querySelector('span'); const chevron = document.createElement('span'); chevron.className = 'nav-chevron'; chevron.setAttribute('aria-hidden','true'); nav.append(copy, chevron); rows.append(nav);
    const page = document.createElement('section'); page.className = 'detail-page'; page.hidden = true; page.id = `detail-${key}`;
    const heading = document.createElement('div'); heading.className = 'detail-heading';
    const back = document.createElement('button'); back.type = 'button'; back.textContent = '←'; back.dataset.i18nAria = 'action.back'; back.setAttribute('aria-label', t('action.back'));
    const h = document.createElement('h2'); h.textContent = title; h.tabIndex = -1; heading.append(back,h); page.append(heading, disclosure.querySelector('section')); settings.append(page);
    detailPages.set(key,{page,nav}); nav.onclick = () => { location.hash = `settings/${key}`; };
    back.onclick = () => { location.hash = 'settings'; };
  });
  functional.remove();
  // Connections and system controls use the same detail-page architecture as
  // the feature pages. Keeping the original form nodes preserves their
  // existing listeners and persistence contracts while removing admin-like
  // inline forms from the root settings feed.
  const moveInlineDetails = (root, mappings) => {
    for (const [key, titleKey] of mappings) {
      const disclosure = [...(root?.querySelectorAll('.settings-detail, .technical-details') || [])].find(node => node.querySelector('strong')?.dataset.i18n === titleKey || node.querySelector(':scope > summary')?.dataset.i18n === titleKey);
      if (!disclosure) continue;
      const navGroup = disclosure.parentElement;
      const summary = disclosure.querySelector('summary');
      const nav = document.createElement('button'); nav.type = 'button'; nav.className = 'settings-nav-row'; nav.dataset.detail = key;
      let copy = summary.querySelector('span');
      if (!copy) {
        copy = document.createElement('span');
        const strong = document.createElement('strong'); strong.textContent = summary.textContent;
        copy.append(strong);
      }
      const chevron = document.createElement('span'); chevron.className = 'nav-chevron'; chevron.setAttribute('aria-hidden','true'); nav.append(copy, chevron); navGroup.append(nav);
      const page = document.createElement('section'); page.className = 'detail-page'; page.hidden = true; page.id = `detail-${key}`;
      const heading = document.createElement('div'); heading.className = 'detail-heading';
      const back = document.createElement('button'); back.type = 'button'; back.className = 'detail-back'; back.textContent = '←'; back.setAttribute('aria-label', t('action.back'));
      const h = document.createElement('h2'); h.textContent = t(titleKey); h.tabIndex = -1; heading.append(back, h);
      page.append(heading);
      // Preserve every content node and its identity, including technicalSummary.
      for (const content of [...disclosure.children]) {
        if (content === summary) continue;
        if (content.tagName === 'FORM') {
          content.classList.add('settings-group');
          content.querySelectorAll('label.check').forEach(label => { label.classList.add('settings-toggle-row'); label.querySelector('input')?.setAttribute('role', 'switch'); });
        }
        page.append(content);
      }
      settings.append(page); detailPages.set(key, {page, nav});
      nav.onclick = () => { location.hash = `settings/${key}`; }; back.onclick = () => { location.hash = 'settings'; };
      disclosure.remove();
    }
  };
  moveInlineDetails($('simpleSettings'), [['zero-cloud','connection.zeroCloud'], ['aivi','aivi.title'], ['abrp','connection.abrp']]);
  moveInlineDetails($('advancedSettings'), [['help','help.title'], ['remote','remote.title'], ['updates','updates.title'], ['diagnostics','diagnostics.title'], ['polling','advanced.polling'], ['system-actions','settings.actions'], ['technical','technical.summary']]);
  // Existing controls remain in their original DOM nodes, retaining state/listeners.
  const about = settings.querySelector('.about-section');
  const aboutGroup = about.querySelector('.about-group');
  const aboutNav = document.createElement('button'); aboutNav.type = 'button'; aboutNav.className = 'settings-nav-row'; aboutNav.dataset.detail = 'about';
  aboutNav.innerHTML = '<span><strong data-i18n="settings.aboutSection">Über Zero Connect</strong><small data-i18n="system.version">Version</small></span><span class="nav-chevron" aria-hidden="true"></span>';
  const aboutSection = about.parentElement.querySelector('.settings-section:last-of-type .settings-group') || about.parentElement.querySelector('.settings-group');
  // Keep About as a small, separate navigation item at the end of Settings.
  about.replaceChildren(aboutNav);
  const aboutPage = document.createElement('section'); aboutPage.className = 'detail-page'; aboutPage.hidden = true; aboutPage.id = 'detail-about';
  const aboutHeading = document.createElement('div'); aboutHeading.className = 'detail-heading';
  const aboutBack = document.createElement('button'); aboutBack.type = 'button'; aboutBack.className = 'detail-back'; aboutBack.textContent = '←'; aboutBack.setAttribute('aria-label', t('action.back'));
  const aboutTitle = document.createElement('h2'); aboutTitle.textContent = t('settings.aboutSection'); aboutTitle.tabIndex = -1; aboutHeading.append(aboutBack, aboutTitle);
  aboutPage.append(aboutHeading, aboutGroup); settings.append(aboutPage); detailPages.set('about', {page: aboutPage, nav: aboutNav});
  aboutNav.onclick = () => { location.hash = 'settings/about'; }; aboutBack.onclick = () => { location.hash = 'settings'; };
  for (const form of [$('maintenanceForm'), $('milestoneForm')]) {
    const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'form-cancel'; cancel.textContent = 'Abbrechen'; cancel.onclick = () => { form.reset(); form.elements.id?.remove(); form.hidden = true; }; form.append(cancel);
  }
  const notifications = $('notificationPreferencesForm');
  notifications.querySelectorAll('input[type=checkbox]').forEach(input => { input.setAttribute('role','switch'); input.closest('label').classList.add('settings-toggle-row'); });
  notifications.querySelector('button[data-i18n="action.save"]')?.remove();
  const hero = document.createElement('div'); hero.className = 'push-hero';
  const title = document.createElement('strong'); title.textContent = t('push.title'); const feedback = document.createElement('p'); feedback.id='pushFeedback'; feedback.className='push-feedback'; feedback.hidden=true; hero.append(title,$('pushStatus'),pushHint(),feedback,$('enablePush'),$('pushTest'),$('disablePush'));
  notifications.before(hero); $('enablePush').classList.add('primary-action'); $('pushTest').classList.add('primary-action'); $('disablePush').classList.add('text-action');
  lockForm(notifications, true);
  const backup = detailPages.get('backup').page.querySelector('.settings-section');
  const [csvLink, jsonLink] = backup.querySelectorAll('a[href*="/api/history/export"]');
  const backupLink = backup.querySelector('a[href="/api/functional/backup"]');
  const restoreInput = $('restoreBackup');
  const row = (title, help, ...controls) => {
    const node = document.createElement('div'); node.className = 'settings-row backup-row';
    const text = document.createElement('div'); const strong = document.createElement('strong'); strong.textContent = title; const small = document.createElement('small'); small.textContent = help; text.append(strong, small);
    const actions = document.createElement('div'); actions.className = 'backup-actions'; actions.append(...controls); node.append(text, actions); return node;
  };
  [csvLink, jsonLink, backupLink].forEach(link => { link.className = 'button secondary'; });
  csvLink.textContent = 'CSV'; jsonLink.textContent = 'JSON'; backupLink.textContent = featureText('Erstellen', 'Create');
  const pick = document.createElement('label'); pick.className = 'button secondary'; pick.append(document.createTextNode(featureText('Datei wählen', 'Choose file')), restoreInput); restoreInput.hidden = true;
  const backupGroup = document.createElement('div'); backupGroup.className = 'settings-group';
  backupGroup.append(
    row(featureText('Ladeverlauf exportieren', 'Export charging history'), featureText('Als Tabelle (CSV) oder vollständig (JSON)', 'As a spreadsheet (CSV) or complete (JSON)'), csvLink, jsonLink),
    row(featureText('Backup erstellen', 'Create backup'), featureText('Sichert App-Daten samt Ladeverlauf, ohne Zugangsdaten', 'Saves app data including charging history, without credentials'), backupLink),
    row(featureText('Backup wiederherstellen', 'Restore backup'), featureText('Ersetzt die aktuellen Daten durch ein Backup', 'Replaces the current data with a backup'), pick),
  );
  backup.replaceChildren(backupGroup);
  for (const [formId, intro] of [['advancedForm', 'settings.pollingIntro'], ['diagnosticsForm', 'settings.diagnosticsIntro']]) {
    const form = $(formId); if (!form || form.dataset.folded) continue;
    const title = form.querySelector('.form-heading h3');
    if (title) { const note = document.createElement('p'); note.className = 'muted'; note.dataset.i18n = intro; note.textContent = t(intro); title.replaceWith(note); }
    const fold = document.createElement('details'); fold.className = 'advanced-fold';
    const label = document.createElement('summary'); label.dataset.i18n = 'settings.adjustValues'; label.textContent = t('settings.adjustValues'); fold.append(label);
    fold.append(...form.querySelectorAll(':scope > label, :scope > button[data-i18n="action.save"]'));
    form.append(fold); form.dataset.folded = '1';
  }
  const milestoneSwitch = $('milestoneForm').querySelector('input[type=checkbox]'); milestoneSwitch.setAttribute('role','switch'); milestoneSwitch.closest('label').classList.add('settings-toggle-row');
  document.querySelector('.history-comparison').addEventListener('toggle', event => { if (event.target.open) populateComparison(); });
  const chips = document.createElement('div'); chips.className = 'filter-chips'; chips.id = 'activeFilterChips'; $('historyFilters').after(chips);
  $('historyQuery').addEventListener('search', filterHistory);
  window.addEventListener('hashchange', () => {
    applyDetailRoute();
    if (location.hash === '#settings' || location.hash.startsWith('#settings/')) void ensureFunctionalSettings().catch(() => null);
  });
  buildSettingsHierarchy();
  applyDetailRoute();
  localizeFunctionalUi();
}

// ---------------------------------------------------------------- settings: two-level structure
const SETTINGS_ICONS = {
  bike: '<circle cx="5.5" cy="17" r="3.5"/><circle cx="18.5" cy="17" r="3.5"/><circle cx="15" cy="5" r="1.2"/><path d="M12 17v-3.5l-3-3 4-3 2 3h2.5M5.5 17 9 10.5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  bell: '<path d="M6 17v-6a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21h4"/>',
  pin: '<path d="M12 21s-6-5.6-6-10.5a6 6 0 0 1 12 0C18 15.4 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.2"/>',
  data: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
  app: '<path d="M12 4v10m0 0-4-4m4 4 4-4M5 19h14"/>',
  help: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.2"/><path d="M6.3 6.3l3.4 3.4M14.3 14.3l3.4 3.4M17.7 6.3l-3.4 3.4M9.7 14.3l-3.4 3.4"/>',
};

function settingsNavRow(key, titleKey, icon) {
  const row = document.createElement('button');
  row.type = 'button'; row.className = 'settings-nav-row has-icon'; row.dataset.detail = key;
  row.innerHTML = `<span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24">${SETTINGS_ICONS[icon]}</svg></span><span><strong data-i18n="${titleKey}"></strong><small id="sum-${key}"></small></span><span class="nav-chevron" aria-hidden="true"></span>`;
  row.querySelector('strong').textContent = t(titleKey);
  row.onclick = () => { location.hash = `settings/${key}`; };
  return row;
}

function buildSettingsHierarchy() {
  const settings = $('panel-settings');
  const nav = key => detailPages.get(key)?.nav;
  const group = nodes => { const box = document.createElement('div'); box.className = 'settings-group'; box.append(...nodes.filter(Boolean)); return box; };
  const section = (nodes, titleKey) => {
    const part = document.createElement('section'); part.className = 'settings-section';
    if (titleKey) { const heading = document.createElement('h3'); heading.className = 'settings-section-title'; heading.dataset.i18n = titleKey; heading.textContent = t(titleKey); part.append(heading); }
    part.append(group(nodes)); return part;
  };
  const modelRow = $('vehicleModelSelect')?.closest('.settings-row');
  const tree = [
    {key: 'cat-motorcycle', title: 'settings.cat.motorcycle', icon: 'bike', parts: [[[modelRow, $('vehicleColorRow'), $('vehiclePhotoRow')]]]},
    {key: 'cat-connections', title: 'settings.cat.connections', icon: 'link', parts: [[[nav('zero-cloud'), nav('aivi'), nav('abrp')]], [[nav('remote')], 'settings.sec.remote']]},
    {key: 'notifications', direct: true},
    {key: 'cat-places', title: 'settings.cat.places', icon: 'pin', parts: [[[nav('locations'), nav('maintenance'), nav('milestones')]]]},
    {key: 'cat-data', title: 'settings.cat.data', icon: 'data', parts: [[[nav('backup'), nav('polling')]]]},
    {key: 'cat-app', title: 'settings.cat.app', icon: 'app', parts: [[[nav('updates')], 'settings.sec.software'], [[document.querySelector('.language-row'), nav('about')], 'settings.sec.general']]},
    {key: 'cat-help', title: 'settings.cat.help', icon: 'help', parts: [[[nav('help')]], [[nav('diagnostics'), nav('system-actions'), nav('technical')]]]},
  ];
  const parentOf = {};
  const rootRows = {};
  for (const entry of tree) {
    if (entry.direct) { rootRows[entry.key] = nav(entry.key); continue; }
    const page = document.createElement('section'); page.className = 'detail-page'; page.hidden = true; page.id = `detail-${entry.key}`;
    const heading = document.createElement('div'); heading.className = 'detail-heading';
    const back = document.createElement('button'); back.type = 'button'; back.className = 'detail-back'; back.textContent = '←'; back.setAttribute('aria-label', t('action.back'));
    const title = document.createElement('h2'); title.dataset.i18n = entry.title; title.textContent = t(entry.title); title.tabIndex = -1;
    heading.append(back, title); page.append(heading);
    for (const [nodes, titleKey] of entry.parts) {
      for (const node of nodes) { if (node?.dataset?.detail) parentOf[node.dataset.detail] = entry.key; }
      page.append(section(nodes, titleKey));
    }
    back.onclick = () => { location.hash = 'settings'; };
    const row = settingsNavRow(entry.key, entry.title, entry.icon);
    settings.append(page); detailPages.set(entry.key, {page, nav: row}); rootRows[entry.key] = row;
  }
  // Item pages go back to their category instead of the root list.
  for (const [item, parent] of Object.entries(parentOf)) {
    const back = detailPages.get(item)?.page.querySelector('.detail-heading button');
    if (back) back.onclick = () => { location.hash = `settings/${parent}`; };
  }
  // The notifications row gets an icon like its siblings.
  const bell = nav('notifications');
  if (bell && !bell.querySelector('.nav-icon')) {
    bell.classList.add('has-icon');
    const icon = document.createElement('span'); icon.className = 'nav-icon'; icon.setAttribute('aria-hidden', 'true');
    icon.innerHTML = `<svg viewBox="0 0 24 24">${SETTINGS_ICONS.bell}</svg>`; bell.prepend(icon);
  }
  // New root: three calm groups.
  for (const old of [...settings.children]) {
    if (old.matches('#simpleSettings, #advancedSettings, .about-section') || old.querySelector?.(':scope > .settings-group > .settings-nav-row, :scope > h3#featuresSectionTitle')) old.remove();
  }
  const root = document.createElement('section'); root.className = 'settings-stack settings-root'; root.id = 'settingsRoot';
  for (const keys of [['cat-motorcycle', 'cat-connections', 'notifications'], ['cat-places', 'cat-data'], ['cat-app', 'cat-help']]) {
    const part = document.createElement('section'); part.className = 'settings-section';
    part.append(group(keys.map(key => rootRows[key]))); root.append(part);
  }
  settings.append(root);
  settings.querySelector('.settings-intro p.muted')?.remove();
  settings.querySelector('.settings-intro .eyebrow')?.remove();
  const aboutRow = nav('about');
  if (aboutRow) { aboutRow.querySelector('strong').textContent = t('settings.aboutSection'); aboutRow.querySelector('small').textContent = state.status?.version ? `${t('system.version')} ${state.status.version}` : t('system.version'); }
  refreshSettingsSummaries();
}

function refreshSettingsSummaries() {
  const set = (key, text) => { const node = $(`sum-${key}`); if (node && node.textContent !== text) node.textContent = text; };
  const vehicle = state.config?.vehicle || {};
  const color = vehicle.color === 'custom' ? t('vehicle.customPhoto') : (vehicle.color ? colorLabel(vehicle.model, vehicle.color) : '');
  set('cat-motorcycle', [vehicle.model || t('vehicle.modelUnknown'), color].filter(Boolean).join(' · '));
  set('cat-connections', t('settings.sum.connections', {cloud: $('zeroSettingsConnection')?.textContent || '–'}));
  set('cat-places', t('settings.sum.places'));
  set('cat-data', t('settings.sum.data'));
  const updates = state.updates;
  set('cat-app', updates ? [t(updates.available ? 'updates.summaryAvailable' : 'updates.summaryCurrent', {version: updates.available?.version || updates.current_version}), t(updates.channel === 'beta' ? 'updates.channelBetaShort' : 'updates.channelStable')].join(' · ') : t('settings.sum.app'));
  set('cat-help', t('settings.sum.help'));
}

function applyDetailRoute() {
  const [tab, key] = location.hash.slice(1).split('/');
  detailRouting = true;
  activateTab(['overview','charging','history','settings'].includes(tab) ? tab : 'overview');
  detailRouting = false;
  const selected = tab === 'settings' ? detailPages.get(key) : null;
  if (!(tab === 'settings' && key === 'locations')) cancelLocationLabelBackfill();
  const settings = $('panel-settings');
  [...settings.children].forEach(child => { child.hidden = child.classList.contains('detail-page') ? child !== selected?.page : Boolean(selected); });
  document.body.classList.toggle('detail-view', Boolean(selected));
  if (selected) { history.replaceState({zeroDetail:true},''); selected.page.querySelector('h2').focus({preventScroll:true}); if (key === 'locations') { backfillChargingLocationLabels(); setTimeout(() => $('chargingLocationsMap')?._leafletMap?.invalidateSize(), 50); } }
  else if (tab === 'settings') { const previous = settings.dataset.lastDetail; detailPages.get(previous)?.nav.focus({preventScroll:true}); }
  settings.dataset.lastDetail = key || '';
  if (tab === 'settings') { if (key === 'updates') void loadUpdates(false); if (key === 'remote') void loadRemote(); }
  window.scrollTo(0,0);
}

async function autoSaveNotifications(event) {
  const form = event.currentTarget; if (form.dataset.hydrated !== 'true') return; const input = event.target; const old = input.type === 'checkbox' ? !input.checked : input.dataset.previousValue ?? '0';
  const eveningHour = form.elements.evening_reminder_hour?.closest('label'); if (eveningHour) eveningHour.hidden = form.elements.evening_reminder_soc.value === '0';
  form.querySelectorAll('input,select').forEach(e => e.disabled = true);
  try { await saveNotificationPreferences({preventDefault(){},currentTarget:form}); form.querySelectorAll('select').forEach(select => { select.dataset.previousValue = select.value; }); }
  catch (error) { if (input.type === 'checkbox') input.checked = old; else input.value = old; setMessage(t('error.preferences'),true); }
  finally { form.querySelectorAll('input,select').forEach(e => e.disabled = e.name === 'target_reached'); }
}

function populateComparison() {
  const selects = [...$('comparisonForm').querySelectorAll('select')];
  selects.forEach((select,index) => { const prior = select.value; select.replaceChildren(); for (const row of state.history || []) { const option = document.createElement('option'); option.value = row.generation; option.textContent = `${row.start_soc ?? '–'} → ${row.end_soc ?? '–'} % · ${localTimestamp(row.started_at_utc)}`; select.append(option); } if ([...select.options].some(o => o.value === prior)) select.value = prior; else select.selectedIndex = Math.min(index, select.options.length-1); });
  $('comparisonForm').querySelector('button').disabled = (state.history || []).length < 2;
}

// Exports leave the app in a standalone iPhone web app (a file preview without a
// way back). Share the file through the system sheet instead; fall back to the
// normal download everywhere else.
function setupShareDownloads() {
  const standalone = (typeof matchMedia === 'function' && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  if (!standalone || typeof navigator.canShare !== 'function' || typeof navigator.share !== 'function') return;
  document.addEventListener('click', async event => {
    const link = event.target.closest?.('a[href^="/api/"]');
    if (!link || !/(export|backup|support)/.test(link.getAttribute('href'))) return;
    event.preventDefault();
    try {
      const response = await fetch(link.href, {credentials: 'same-origin'});
      if (!response.ok) throw new Error(String(response.status));
      const name = /filename="?([^";]+)"?/.exec(response.headers.get('Content-Disposition') || '')?.[1] || 'zero-connect-export';
      const blob = await response.blob();
      const file = new File([blob], name, {type: blob.type || 'application/octet-stream'});
      if (navigator.canShare({files: [file]})) { await navigator.share({files: [file], title: name}); return; }
    } catch (error) {
      if (error?.name === 'AbortError') return;
    }
    location.href = link.href;
  });
}

// Bottom sheet: slides up, follows the finger and can be swiped down or tapped away.
const reducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
function openSheet(dialog) {
  dialog.classList.remove('closing');
  dialog.style.removeProperty('--drag');
  dialog.showModal();
}
function closeSheet(dialog) {
  if (!dialog.open) return;
  if (reducedMotion()) { dialog.close(); return; }
  if (dialog.classList.contains('closing')) return;
  dialog.classList.add('closing');
  const done = event => { if (event.target === dialog) finish(); };
  const finish = () => { dialog.removeEventListener('animationend', done); dialog.classList.remove('closing'); if (dialog.open) dialog.close(); };
  dialog.addEventListener('animationend', done);
  setTimeout(finish, 400);
}
function setupSheet(dialog) {
  let startY = null;
  dialog.addEventListener('cancel', event => { event.preventDefault(); closeSheet(dialog); });
  dialog.addEventListener('click', event => { if (event.target === dialog) closeSheet(dialog); });
  dialog.addEventListener('pointerdown', event => { if (event.pointerType !== 'mouse') { startY = event.clientY; dialog.classList.add('dragging'); } });
  dialog.addEventListener('pointermove', event => {
    if (startY == null) return;
    dialog.style.setProperty('--drag', `${Math.max(0, event.clientY - startY)}px`);
  });
  const end = event => {
    if (startY == null) return;
    const moved = event.clientY - startY;
    startY = null;
    dialog.classList.remove('dragging');
    if (moved > 90) closeSheet(dialog); else dialog.style.removeProperty('--drag');
  };
  dialog.addEventListener('pointerup', end);
  dialog.addEventListener('pointercancel', end);
}

// Pull down at the top of the page to refresh. The page follows the finger
// with growing resistance (no second, native bounce), a ring fills while pulling
// and the page settles back slowly.
function setupPullToRefresh() {
  const MAX = 84, TRIGGER = 120;
  const ring = document.createElement('div');
  ring.className = 'pull-ring';
  ring.innerHTML = '<svg viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="13"/><circle class="pull-arc" cx="18" cy="18" r="13" pathLength="100"/></svg>';
  document.body.append(ring);
  let startY = null, distance = 0;
  const apply = (raw, release = false) => {
    const pull = MAX * (1 - Math.exp(-raw / 150));
    const root = document.documentElement;
    root.classList.toggle('pulling', raw > 0 || release);
    root.classList.toggle('pull-release', release);
    root.style.setProperty('--pull', `${pull}px`);
    ring.style.setProperty('--pull-progress', String(Math.min(1, raw / TRIGGER)));
    ring.style.setProperty('--ring-o', String(Math.max(0, Math.min(1, (pull - 22) / 26))));
    ring.classList.toggle('is-ready', raw >= TRIGGER);
  };
  addEventListener('touchstart', event => { startY = window.scrollY <= 0 && event.touches.length === 1 ? event.touches[0].clientY : null; distance = 0; }, {passive: true});
  addEventListener('touchmove', event => {
    if (startY == null) return;
    distance = Math.max(0, event.touches[0].clientY - startY);
    apply(distance);
  }, {passive: true});
  addEventListener('touchend', () => {
    if (startY == null) return;
    const trigger = distance >= TRIGGER;
    startY = null; distance = 0;
    ring.classList.toggle('is-loading', trigger);
    apply(trigger ? 60 : 0, true);
    const done = () => { ring.classList.remove('is-loading'); apply(0, true); setTimeout(() => document.documentElement.classList.remove('pulling', 'pull-release'), 700); };
    if (trigger) Promise.resolve(loadDashboard({full: false})).finally(() => setTimeout(done, 350));
    else setTimeout(() => document.documentElement.classList.remove('pulling', 'pull-release'), 700);
  }, {passive: true});
}

function activateTab(name, focus = false) {
  if (detailPages.size && !detailRouting) { const desired = name === 'system' ? 'settings' : name; if (location.hash !== `#${desired}`) { location.hash = desired; return; } }
  if (name === 'system') name = 'settings';
  document.querySelectorAll('[role=tab]').forEach(tab => {
    const selected = tab.dataset.tab === name;
    tab.setAttribute('aria-selected', String(selected));
    tab.tabIndex = selected ? 0 : -1;
    if (selected && focus) tab.focus();
  });
  document.querySelectorAll('.tab-panel').forEach(panel => {
    const selected = panel.id === `panel-${name}`;
    panel.hidden = !selected;
    if (selected) {
      panel.classList.remove('view-enter');
      void panel.offsetWidth;
      panel.classList.add('view-enter');
      if (name === 'charging') replayPack();
    }
  });
  document.querySelectorAll('.mobile-nav [data-tab]').forEach(item => {
    const selected = item.dataset.tab === name;
    item.classList.toggle('active', selected);
    if (selected) item.setAttribute('aria-current', 'page');
    else item.removeAttribute('aria-current');
  });
  if (name === 'overview') refreshLocationMapSize();
}

function bindTabs() {
  const tabs = [...document.querySelectorAll('[role=tab]')];
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateTab(tab.dataset.tab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const target = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length;
      activateTab(tabs[target].dataset.tab, true);
    });
  });
  document.querySelectorAll('.mobile-nav [data-tab]').forEach(tab => tab.addEventListener('click', () => {
    activateTab(tab.dataset.tab);
    document.querySelectorAll('.mobile-nav [data-tab]').forEach(item => item.classList.toggle('active', item === tab));
  }));
}

warmStartVehicleImage();

async function start() {
  // Block native submissions immediately, including while translations load.
  document.addEventListener('submit', event => {
    if (event.target.matches(CONFIG_FORMS + ', #notificationPreferencesForm') && event.target.dataset.hydrated !== 'true') event.preventDefault();
  }, true);
  document.querySelectorAll(CONFIG_FORMS + ', #notificationPreferencesForm').forEach(form => lockForm(form, true));
  const environmentBadge = $('environmentBadge');
  if (environmentBadge && /^zero-connect-test(?:\.|$)/i.test(window.location.hostname)) environmentBadge.hidden = false;
  const launchScreen = document.querySelector('.launch-screen');
  if (launchScreen) {
    launchScreen.style.animation = 'none';
    void launchScreen.offsetWidth;
    launchScreen.style.removeProperty('animation');
  }
  document.body.classList.add('app-launching');
  window.setTimeout(() => document.body.classList.remove('app-launching'), 1100);
  [state.translations, state.assets] = await Promise.all([fetch('/assets/i18n.json').then(r => r.json()), fetch('/assets/model-assets.json').then(r => r.json())]);
  state.language = selectedLanguage();
  applyLanguage();
  $('languageSwitch').addEventListener('change', event => { state.language = event.target.value; localStorage.setItem('zero-connect-language', state.language); applyLanguage(); updatePushLanguage(); if (location.hash === '#settings/locations') backfillChargingLocationLabels(); });
  const functionalPanel = $('functionalSettings');
  if (functionalPanel) { $('panel-settings').appendChild(functionalPanel); functionalPanel.hidden = false; buildFunctionalControls(); }
  setupDetailPages();
  bindTabs();
  applyDetailRoute();
  if (window.ResizeObserver) new ResizeObserver(refreshLocationMapSize).observe($('localMap'));
  window.addEventListener('resize', refreshLocationMapSize);
  bindWizard();
  $('donateLink').href = DONATE_URL;
  $('locationForm')?.addEventListener('submit', submitLocation);
  $('maintenanceForm')?.addEventListener('submit', submitMaintenance);
  $('milestoneForm')?.addEventListener('submit', submitMilestone);
  $('comparisonForm')?.addEventListener('submit', compareSessions);
  $('restoreBackup')?.addEventListener('change', event => restoreBackup(event).catch(error => setMessage(errorMessage(error.payload), true)));
  $('enablePush')?.addEventListener('click', () => enablePush().catch(error => setMessage(error.message, true)));
  $('disablePush')?.addEventListener('click', () => disablePush().catch(error => setMessage(errorMessage(error.payload), true)));
  $('pushTest')?.addEventListener('click', () => sendPushTest().catch(error => setMessage(errorMessage(error.payload) || error.message, true)));
  $('showMaintenanceForm')?.addEventListener('click', () => { $('maintenanceForm').hidden = false; $('maintenanceForm').elements.name.focus(); });
  $('showMilestoneForm')?.addEventListener('click', () => { $('milestoneForm').hidden = false; $('milestoneForm').elements.name.focus(); });
  $('historyFilters')?.addEventListener('submit', filterHistory);
  $('historyReset')?.addEventListener('click', () => { $('historyQuery').value = ''; $('historyTarget').value = ''; $('historyReason').value = ''; $('historyLocation').value = ''; filterHistory(); });
  document.querySelectorAll('[data-info]').forEach(button => button.addEventListener('click', () => { $('infoText').textContent = t(button.dataset.info); openSheet($('infoPopover')); }));
  $('closeInfo').addEventListener('click', () => closeSheet($('infoPopover')));
  setupHistorySwitch();
  for (const id of ['closeWhatsNew', 'whatsNewDone']) $(id).addEventListener('click', () => closeSheet($('whatsNew')));
  setupSheet($('whatsNew'));
  setupSheet($('infoPopover'));
  setupPullToRefresh();
  setupShareDownloads();
  setupUpdates();
  setupRemote();
  setupVehiclePhoto();
  $('mapExpand').addEventListener('click', openMapDialog);
  $('closeMap').addEventListener('click', () => closeSheet($('mapDialog')));
  $('mapDialog').addEventListener('cancel', event => { event.preventDefault(); closeSheet($('mapDialog')); });
  $('mapDialog').addEventListener('close', () => $('mapExpand').focus());
  $('recenterVehicle').addEventListener('click', recenterVehicle);
  $('showMyLocation').addEventListener('click', showMyLocation);
  $('fitBothLocations').addEventListener('click', fitBothLocations);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && state.userLocation && Date.now() - state.userLocationCapturedAt > 5 * 60 * 1000) expireUserLocation(); });
  $('releaseNotes')?.addEventListener('toggle', event => { if (event.target.open) loadReleaseNotes(); });
  $('runDoctor').addEventListener('click', () => authenticatedAction('/api/doctor', 'message.doctorDone'));
  $('supportExport').addEventListener('click', async () => {
    const button = $('supportExport');
    button.disabled = true;
    setMessage(t('message.exportLoading'));
    const value = await authenticatedAction('/api/support-export', 'message.exportReady');
    button.disabled = false;
    if (value?.download_url) {
      const link = $('supportDownload');
      link.href = value.download_url;
      link.hidden = false;
    }
  });
  $('restartObserver').addEventListener('click', async () => {
    const button = $('restartObserver');
    button.disabled = true;
    setMessage(t('message.restartLoading'));
    await authenticatedAction('/api/restart', 'message.observerReady');
    button.disabled = false;
  });
  $('reopenWizard').addEventListener('click', async () => {
    try { const value = await api('/api/setup/reopen', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'}); renderWizard(value.setup); setMessage(t('wizard.reopened')); }
    catch (error) { setMessage(errorMessage(error.payload), true); }
  });
  try { if ('serviceWorker' in navigator) await navigator.serviceWorker.register('/sw.js', {scope: '/'}); } catch (_) { /* optional notification channel */ }
  await loadDashboard();
  if (location.hash === '#settings' || location.hash.startsWith('#settings/')) await ensureFunctionalSettings().catch(() => null);
  updatePushLanguage();
  scheduleDashboardRefresh();
}

// The CSV export follows the app language (German: ';' and decimal comma for Excel/Numbers).
document.addEventListener('click', event => {
  const link = event.target.closest?.('a[href*="/api/history/export.csv"]');
  if (link) link.href = `/api/history/export.csv?lang=${encodeURIComponent(state.language || 'de')}`;
}, true);

start().catch(() => setMessage(t('error.generic'), true));
