#!/usr/bin/env bash
set -Eeuo pipefail

PUBLIC_VERSION="1.0.0-beta.7"
INTERNAL_VERSION="3.0.0-alpha.45"
PROJECT_DIR="${HOME}/zero-connect"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VENV="${PROJECT_DIR}/.venv"
BIN_DIR="${HOME}/.local/bin"
SERVICE_DIR="${HOME}/.config/systemd/user"
SERVICE_FILE="${SERVICE_DIR}/zero-observer.service"
WEB_SERVICE_FILE="${SERVICE_DIR}/zero-connect-web.service"
MODE="fresh"
VERBOSE=0
SERVICE_WAS_ACTIVE=0
WEB_SERVICE_WAS_ACTIVE=0
LEGACY_BACKUP=""
UPGRADE_BACKUP=""
SYSTEM_BACKUP=""
INSTALL_MUTATED=0
SYSTEM_MUTATED=0
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
INSTALL_LOG="${HOME}/zero-connect-install-${TIMESTAMP}.log"
INSTALL_COMPLETE_MARKER="${PROJECT_DIR}/.install-complete"

for arg in "$@"; do
  case "${arg}" in
    --appliance) exec "${SCRIPT_DIR}/install_appliance.sh" "$@" ;;
    --upgrade) MODE="upgrade" ;;
    --migrate-legacy) MODE="legacy" ;;
    --verbose) VERBOSE=1 ;;
    -h|--help)
      cat <<'EOF'
Verwendung: ./install.sh [--upgrade|--migrate-legacy] [--verbose]

  ohne Option       frische Installation
  --upgrade         bestehende Zero-Connect-0.9-Installation aktualisieren
  --migrate-legacy  ältere Zero-Connect-v2.x-Installation migrieren
  --verbose         technische Detailausgabe anzeigen
EOF
      exit 0
      ;;
    *) echo "Unbekannte Option: ${arg}" >&2; exit 2 ;;
  esac
done

if [[ "${EUID}" -eq 0 ]]; then
  echo "Bitte als normaler Benutzer installieren, nicht mit sudo/root." >&2
  exit 1
fi

touch "${INSTALL_LOG}"
chmod 600 "${INSTALL_LOG}"
exec 3>>"${INSTALL_LOG}"
printf 'Zero Connect %s / intern %s\nStart: %s\nModus: %s\n\n' \
  "${PUBLIC_VERSION}" "${INTERNAL_VERSION}" "$(date -Is)" "${MODE}" >&3

say() { printf '%s\n' "$*"; }
log() { printf '%s\n' "$*" >&3; }
need_cmd() { command -v "$1" >/dev/null 2>&1; }
step() { say "[$1/5] $2"; }
ok() { say "[✓] $*"; }
warn() { say "[!] $*"; }

valid_upgrade_installation() {
  [[ -f "${PROJECT_DIR}/VERSION.json" && -f "${PROJECT_DIR}/zero_config.json" && -x "${VENV}/bin/python" ]] || return 1
  for required in zero_observer.py zero_connect_cli.py zero_connect_web.py zero_network_helper.py zero_captive_portal.py requirements.txt; do
    [[ -f "${PROJECT_DIR}/${required}" && ! -L "${PROJECT_DIR}/${required}" ]] || return 1
  done
  local installed_beta
  installed_beta="$(python3 - "${PROJECT_DIR}/VERSION.json" "${PROJECT_DIR}/zero_config.json" <<'PY_VALIDATE_INSTALL'
import json, re, sys
try:
    version = json.load(open(sys.argv[1], encoding="utf-8"))
    config = json.load(open(sys.argv[2], encoding="utf-8"))
except (OSError, ValueError, TypeError):
    raise SystemExit(1)
match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-beta\.(\d+))?", str(version.get("public_version", "")))
if not match:
    raise SystemExit(1)
if not isinstance(config, dict) or not isinstance(config.get("setup"), dict):
    raise SystemExit(1)
# Only the 0.9.0 betas up to 27 predate the completion marker; every later version has one.
print(match.group(4) if (match.group(1), match.group(2), match.group(3)) == ("0", "9", "0") and match.group(4) else 999)
PY_VALIDATE_INSTALL
)" || return 1
  if [[ -f "${INSTALL_COMPLETE_MARKER}" ]]; then
    grep -qx 'zero-connect-installation-v1' "${INSTALL_COMPLETE_MARKER}"
    return
  fi
  # Beta 27 and older have no completion marker. Accept only the full set of
  # final service/wrapper evidence, never VERSION.json alone or a step-2 tree.
  (( installed_beta <= 27 )) || return 1
  [[ -f "${SERVICE_FILE}" && -f "${WEB_SERVICE_FILE}" && -x "${BIN_DIR}/zero-connect" ]]
}

run_logged() {
  if [[ "${VERBOSE}" == "1" ]]; then
    "$@" 2>&1 | tee -a "${INSTALL_LOG}"
  else
    "$@" >>"${INSTALL_LOG}" 2>&1
  fi
}

APP_FILES=(
  zero_observer.py zero_status.py zero_setup.py zero_doctor.py zero_connect_cli.py zero_connect_web.py zero_wifi_setup.py zero_network_helper.py zero_captive_portal.py
  zero_diagnostics.py zero_history.py zero_vehicle.py zero_charging.py zero_functional.py aivi_live_test.py zero_paths.py zero_release_notes.py zero_updates.py zero_vehicle_photos.py zero_trips.py zero_remote.py zero_release_verify.py zero_appliance_update.py zero_postboot_verify.py zero_config.json .env VERSION.json
  release_notes.json release-public-key.pub requirements.txt web_assets
)
SYSTEM_FILES=(
  /usr/lib/zero-connect/zero_network_helper.py
  /usr/lib/zero-connect/zero_paths.py
  /usr/lib/zero-connect/zero_captive_portal.py
  /etc/tmpfiles.d/zero-connect.conf
  /etc/dnsmasq.d/zero-connect-setup.conf
  /etc/systemd/system/zero-connect-network.socket
  /etc/systemd/system/zero-connect-network@.service
  /etc/systemd/system/zero-connect-network-watch.service
  /etc/systemd/system/zero-connect-captive-portal.service
  /etc/systemd/system/zero-connect-captive-dns.service
  "/etc/NetworkManager/system-connections/Zero Connect Setup.nmconnection"
)
NETWORK_UNITS=(
  zero-connect-network.socket
  zero-connect-network-watch.service
  zero-connect-captive-dns.service
  zero-connect-captive-portal.service
)
backup_system_files() {
  [[ -n "${SYSTEM_BACKUP}" ]] || return 0
  mkdir -p "${SYSTEM_BACKUP}"
  : > "${SYSTEM_BACKUP}/files"
  for path in "${SYSTEM_FILES[@]}"; do
    local relative="${path#/}"
    if sudo test -e "${path}"; then
      mkdir -p "$(dirname "${SYSTEM_BACKUP}/${relative}")"
      sudo cp -a "${path}" "${SYSTEM_BACKUP}/${relative}"
      printf '%s\n' "${relative}" >> "${SYSTEM_BACKUP}/files"
    fi
  done
  : > "${SYSTEM_BACKUP}/unit-states"
  for unit in "${NETWORK_UNITS[@]}"; do
    local enabled=0 active=0
    sudo systemctl is-enabled --quiet "${unit}" >/dev/null 2>&1 && enabled=1
    sudo systemctl is-active --quiet "${unit}" >/dev/null 2>&1 && active=1
    printf '%s %s %s\n' "${unit}" "${enabled}" "${active}" >> "${SYSTEM_BACKUP}/unit-states"
  done
  if sudo nmcli -t -f NAME connection show --active 2>/dev/null | grep -Fxq "Zero Connect Setup"; then
    : > "${SYSTEM_BACKUP}/hotspot-active"
  fi
}

restore_on_error() {
  local exit_code=$?
  trap - ERR
  set +e
  rm -f "${INSTALL_COMPLETE_MARKER}.tmp" >/dev/null 2>&1 || true
  echo >&2
  echo "[✗] Installation fehlgeschlagen." >&2
  echo "    Details: ${INSTALL_LOG}" >&2
  if [[ "${INSTALL_MUTATED}" == "1" ]]; then
    echo "[↶] Vorheriger Stand wird wiederhergestellt …" >&2
    systemctl --user stop zero-observer.service >/dev/null 2>&1 || true
    systemctl --user stop zero-connect-web.service >/dev/null 2>&1 || true
    if [[ "${MODE}" == "legacy" && -n "${LEGACY_BACKUP}" && -d "${LEGACY_BACKUP}" ]]; then
      rm -rf "${PROJECT_DIR}"
      cp -a "${LEGACY_BACKUP}" "${PROJECT_DIR}" || true
      echo "[✓] Legacy-Installation wiederhergestellt." >&2
    elif [[ "${MODE}" == "upgrade" && -n "${UPGRADE_BACKUP}" && -d "${UPGRADE_BACKUP}" ]]; then
      for rel in "${APP_FILES[@]}"; do
        if [[ -e "${UPGRADE_BACKUP}/project/${rel}" ]]; then
          rm -rf "${PROJECT_DIR:?}/${rel}"
          mkdir -p "$(dirname "${PROJECT_DIR}/${rel}")"
          cp -a "${UPGRADE_BACKUP}/project/${rel}" "${PROJECT_DIR}/${rel}" || true
        else
          rm -rf "${PROJECT_DIR:?}/${rel}" || true
        fi
      done
      rm -rf "${PROJECT_DIR}/tests"
      [[ -d "${UPGRADE_BACKUP}/tests" ]] && cp -a "${UPGRADE_BACKUP}/tests" "${PROJECT_DIR}/tests" || true
      if [[ -f "${UPGRADE_BACKUP}/zero-observer.service" ]]; then
        rm -f "${SERVICE_FILE}" || true
        cp -a "${UPGRADE_BACKUP}/zero-observer.service" "${SERVICE_FILE}" || true
      fi
      rm -f "${WEB_SERVICE_FILE}" || true
      if [[ -f "${UPGRADE_BACKUP}/zero-connect-web.service" ]]; then
        cp -a "${UPGRADE_BACKUP}/zero-connect-web.service" "${WEB_SERVICE_FILE}" || true
      fi
      for wrapper in zero-connect zero-status aivi-live-test; do
        rm -f "${BIN_DIR}/${wrapper}" || true
        if [[ -e "${UPGRADE_BACKUP}/wrapper-${wrapper}" ]]; then
          cp -a "${UPGRADE_BACKUP}/wrapper-${wrapper}" "${BIN_DIR}/${wrapper}" || true
        fi
      done
      echo "[✓] Vorherige Zero-Connect-Version wiederhergestellt." >&2
    elif [[ "${MODE}" == "fresh" ]]; then
      rm -rf "${PROJECT_DIR}" || true
      rm -f "${BIN_DIR}/zero-connect" "${BIN_DIR}/zero-status" "${BIN_DIR}/aivi-live-test" || true
      rm -f "${SERVICE_FILE}" "${WEB_SERVICE_FILE}" || true
    fi
    systemctl --user daemon-reload >/dev/null 2>&1 || true
  fi
  # Packages can be shared and are intentionally never removed. For a fresh
  # install, however, remove only the Zero Connect-owned privileged files so a
  # retry starts from a clean configuration after a partial step 5 failure.
  if [[ "${MODE}" == "fresh" && "${SYSTEM_MUTATED}" == "1" ]]; then
    sudo systemctl disable --now zero-connect-network.socket >/dev/null 2>&1 || true
    sudo systemctl disable --now zero-connect-network-watch.service >/dev/null 2>&1 || true
    sudo systemctl stop zero-connect-captive-portal.service zero-connect-captive-dns.service >/dev/null 2>&1 || true
    sudo nmcli connection delete "Zero Connect Setup" >/dev/null 2>&1 || true
    sudo rm -f "${SYSTEM_FILES[@]}" >/dev/null 2>&1 || true
    sudo rm -f /run/zero-connect/network.lock /run/zero-connect/network-result.json /run/zero-connect/network.sock >/dev/null 2>&1 || true
    sudo rmdir /usr/lib/zero-connect /run/zero-connect >/dev/null 2>&1 || true
    sudo systemctl daemon-reload >/dev/null 2>&1 || true
  elif [[ "${SYSTEM_MUTATED}" == "1" && -n "${SYSTEM_BACKUP}" ]]; then
    sudo systemctl disable --now zero-connect-network.socket >/dev/null 2>&1 || true
    sudo systemctl disable --now zero-connect-network-watch.service >/dev/null 2>&1 || true
    sudo systemctl stop zero-connect-captive-portal.service zero-connect-captive-dns.service >/dev/null 2>&1 || true
    sudo nmcli connection delete "Zero Connect Setup" >/dev/null 2>&1 || true
    for path in "${SYSTEM_FILES[@]}"; do
      relative="${path#/}"
      sudo rm -f "${path}" >/dev/null 2>&1 || true
      if [[ -f "${SYSTEM_BACKUP}/files" ]] && grep -qx "${relative}" "${SYSTEM_BACKUP}/files"; then
        parent_mode=0755
        [[ "${path}" == /etc/NetworkManager/system-connections/* ]] && parent_mode=0700
        sudo install -d -o root -g root -m "${parent_mode}" "$(dirname "${path}")" >/dev/null 2>&1 || true
        sudo cp -a "${SYSTEM_BACKUP}/${relative}" "${path}" >/dev/null 2>&1 || true
      fi
    done
    sudo systemctl daemon-reload >/dev/null 2>&1 || true
    if sudo test -e "/etc/NetworkManager/system-connections/Zero Connect Setup.nmconnection"; then
      sudo nmcli connection load "/etc/NetworkManager/system-connections/Zero Connect Setup.nmconnection" >/dev/null 2>&1 || true
    fi
    if [[ -f "${SYSTEM_BACKUP}/hotspot-active" ]]; then
      sudo nmcli connection up "Zero Connect Setup" >/dev/null 2>&1 || true
    fi
    if [[ -f "${SYSTEM_BACKUP}/unit-states" ]]; then
      while read -r unit enabled active; do
        if [[ "${enabled}" == "1" ]]; then
          sudo systemctl enable "${unit}" >/dev/null 2>&1 || true
        else
          sudo systemctl disable "${unit}" >/dev/null 2>&1 || true
        fi
        if [[ "${active}" == "1" ]]; then
          sudo systemctl start "${unit}" >/dev/null 2>&1 || true
        else
          sudo systemctl stop "${unit}" >/dev/null 2>&1 || true
        fi
      done < "${SYSTEM_BACKUP}/unit-states"
    fi
  fi
  if [[ "${SERVICE_WAS_ACTIVE}" == "1" ]]; then
    systemctl --user start zero-observer.service >/dev/null 2>&1 || true
  fi
  if [[ "${WEB_SERVICE_WAS_ACTIVE}" == "1" ]]; then
    systemctl --user start zero-connect-web.service >/dev/null 2>&1 || true
  fi
  exit "${exit_code}"
}
trap restore_on_error ERR

say ""
say "🏍️  Zero Connect ${PUBLIC_VERSION}"
say "────────────────────────────────────────"
case "${MODE}" in
  fresh) say "Neue Installation" ;;
  upgrade) say "Update einer bestehenden Installation" ;;
  legacy) say "Migration einer älteren v2.x-Installation" ;;
esac
say "Technische Details: ${INSTALL_LOG}"
say ""

step 1 "System prüfen"
if [[ "${MODE}" == "fresh" ]]; then
  if [[ -e "${PROJECT_DIR}/.env" || -e "${PROJECT_DIR}/VERSION.json" ]]; then
    echo "In ${PROJECT_DIR} existiert bereits Zero Connect. Für Updates 'zero-connect update <Bundle>' verwenden." >&2
    exit 1
  fi
  if [[ -d "${PROJECT_DIR}" && -n "$(find "${PROJECT_DIR}" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
    echo "${PROJECT_DIR} ist nicht leer. Installation aus Sicherheitsgründen abgebrochen." >&2
    exit 1
  fi
elif [[ "${MODE}" == "upgrade" ]]; then
  if ! valid_upgrade_installation; then
    echo "Keine bestehende Zero-Connect-0.9-Installation gefunden." >&2
    exit 1
  fi
elif [[ "${MODE}" == "legacy" ]]; then
  if [[ ! -e "${PROJECT_DIR}/.env" || ! -x "${PROJECT_DIR}/.venv/bin/python" || -f "${PROJECT_DIR}/VERSION.json" ]]; then
    echo "Keine verwendbare v2.x-Legacy-Installation gefunden." >&2
    exit 1
  fi
fi

package_installed() {
  dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null | grep -qx 'installed'
}

need_cmd apt-get || { echo "Dieses Debian-/Raspberry-Pi-OS-System benötigt apt-get." >&2; exit 1; }
need_cmd dpkg-query || { echo "Dieses Debian-/Raspberry-Pi-OS-System benötigt dpkg-query." >&2; exit 1; }
MISSING_APT=()
for package in python3 python3-venv ca-certificates network-manager wpasupplicant wireless-regdb iptables dnsmasq-base; do
  package_installed "${package}" || MISSING_APT+=("${package}")
done
if ((${#MISSING_APT[@]})); then
  need_cmd sudo || { echo "Fehlende Systempakete (${MISSING_APT[*]}) und sudo ist nicht verfügbar." >&2; exit 1; }
  run_logged sudo -v || { echo "sudo-Autorisierung für erforderliche Systempakete fehlgeschlagen." >&2; exit 1; }
  warn "Fehlende Systempakete werden installiert: ${MISSING_APT[*]}"
  if ! run_logged sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${MISSING_APT[@]}"; then
    warn "Paketindex wird aktualisiert und die Installation einmal wiederholt."
    run_logged sudo apt-get update
    run_logged sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${MISSING_APT[@]}"
  fi
fi
for package in python3 python3-venv ca-certificates network-manager wpasupplicant wireless-regdb iptables dnsmasq-base; do
  package_installed "${package}" || { echo "Erforderliches Paket fehlt nach Installation: ${package}" >&2; exit 1; }
done
for command in python3 nmcli systemctl systemd-tmpfiles loginctl id; do
  need_cmd "${command}" || { echo "Erforderlicher Systembefehl fehlt nach Paketprüfung: ${command}" >&2; exit 1; }
done
DNSMASQ_CHECK_ROOT="${ZERO_CONNECT_TEST_ROOT:-}"
[[ -z "${DNSMASQ_CHECK_ROOT}" || "${DNSMASQ_CHECK_ROOT}" == /* ]] || { echo "Ungültiger Test-Systempfad." >&2; exit 1; }
[[ -x "${DNSMASQ_CHECK_ROOT}/usr/sbin/dnsmasq" ]] || { echo "dnsmasq-base stellt /usr/sbin/dnsmasq nicht bereit." >&2; exit 1; }
INSTALL_USER="$(id -un)" || { echo "Installationsbenutzer konnte nicht ermittelt werden." >&2; exit 1; }
INSTALL_GROUP="$(id -gn)" || { echo "Primäre Gruppe des Installationsbenutzers konnte nicht ermittelt werden." >&2; exit 1; }
PYTHON_VERSION="$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')"
python3 - <<'PY' || { echo "Python >= 3.10 erforderlich." >&2; exit 1; }
import sys
raise SystemExit(0 if sys.version_info >= (3, 10) else 1)
PY

if [[ ! -f "${SCRIPT_DIR}/MANIFEST.sha256" ]]; then
  echo "Bundle unvollständig: MANIFEST.sha256 fehlt." >&2
  exit 1
fi
run_logged python3 - "${SCRIPT_DIR}" <<'PY'
import hashlib, re, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
manifest = root / "MANIFEST.sha256"
expected = {}
for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
    if not line.strip():
        continue
    match = re.fullmatch(r"([0-9a-fA-F]{64})  (.+)", line)
    if not match:
        raise SystemExit(f"Ungültige MANIFEST-Zeile {number}")
    rel = match.group(2)
    path = Path(rel)
    if path.is_absolute() or ".." in path.parts or rel == "MANIFEST.sha256":
        raise SystemExit(f"Unsicherer MANIFEST-Pfad: {rel}")
    expected[rel] = match.group(1).lower()
actual = {
    str(path.relative_to(root))
    for path in root.rglob("*")
    if path.is_file() and path.name != "MANIFEST.sha256" and "__pycache__" not in path.parts
}
if actual != set(expected):
    raise SystemExit("Bundle-Inhalt stimmt nicht mit MANIFEST.sha256 überein")
for rel, wanted in expected.items():
    path = root / rel
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != wanted:
        raise SystemExit(f"Prüfsumme stimmt nicht: {rel}")
PY

REQUIRED=(
  zero_observer.py zero_status.py zero_setup.py zero_doctor.py zero_connect_cli.py zero_connect_web.py zero_wifi_setup.py zero_network_helper.py zero_captive_portal.py
  zero_diagnostics.py zero_history.py zero_vehicle.py zero_charging.py zero_functional.py aivi_live_test.py zero_paths.py zero_release_notes.py zero_updates.py zero_vehicle_photos.py zero_trips.py zero_remote.py zero_release_verify.py zero_appliance_update.py zero_postboot_verify.py zero_config.json requirements.txt VERSION.json
  release_notes.json release-public-key.pub tests/fixtures/charge_65.jsonl tests/fixtures/charge_100_20260814.jsonl
  tests/fixtures/charge_100_20260815_sleep.jsonl
  tests/fixtures/charge_target90_then_100_20260824.jsonl
  web_assets/index.html web_assets/app.css web_assets/app.js web_assets/sw.js web_assets/i18n.json
  web_assets/manifest.webmanifest web_assets/icons/zero-connect-final-96.png
  web_assets/icons/zero-connect-final-180.png web_assets/icons/zero-connect-final-192.png
  web_assets/icons/zero-connect-final-512.png
  web_assets/icons/zero-connect-home-96.png web_assets/icons/zero-connect-home-180.png
  web_assets/icons/zero-connect-home-192.png web_assets/icons/zero-connect-home-512.png
  web_assets/model-assets.json web_assets/vehicle-sources.json web_assets/vendor/leaflet/LICENSE web_assets/vendor/leaflet/leaflet.css web_assets/vendor/leaflet/leaflet.js web_assets/vehicles/fallback.svg
  web_assets/vehicles/sport.svg web_assets/vehicles/naked.svg
  web_assets/vehicles/dual-sport.svg

)
for file in "${REQUIRED[@]}"; do
  [[ -f "${SCRIPT_DIR}/${file}" ]] || { echo "Bundle unvollständig: ${file} fehlt." >&2; exit 1; }
done
ok "Python ${PYTHON_VERSION} · Bundle vollständig"

step 2 "Sichern und installieren"
LEGACY_LABEL=""
if [[ "${MODE}" == "legacy" && -f "${PROJECT_DIR}/zero_config.json" ]]; then
  LEGACY_LABEL="$(python3 - "${PROJECT_DIR}/zero_config.json" <<'PY'
import json, sys
try:
    print(str(json.load(open(sys.argv[1], encoding='utf-8')).get('vehicle_label', '')).strip(), end='')
except Exception:
    pass
PY
)"
fi

if [[ "$(systemctl --user is-active zero-observer.service 2>/dev/null || true)" == "active" ]]; then
  SERVICE_WAS_ACTIVE=1
  run_logged systemctl --user stop zero-observer.service
fi
if [[ "$(systemctl --user is-active zero-connect-web.service 2>/dev/null || true)" == "active" ]]; then
  WEB_SERVICE_WAS_ACTIVE=1
  run_logged systemctl --user stop zero-connect-web.service
fi

if [[ "${MODE}" == "legacy" ]]; then
  LEGACY_BACKUP="${HOME}/zero-connect-legacy-backup-${TIMESTAMP}"
  SYSTEM_BACKUP="${LEGACY_BACKUP}/system"
  cp -a "${PROJECT_DIR}" "${LEGACY_BACKUP}"
  rm -rf "${PROJECT_DIR}"
  mkdir -p "${PROJECT_DIR}/data"
  [[ -f "${LEGACY_BACKUP}/.env" ]] && install -m 600 "${LEGACY_BACKUP}/.env" "${PROJECT_DIR}/.env"
  [[ -d "${LEGACY_BACKUP}/data" ]] && cp -a "${LEGACY_BACKUP}/data/." "${PROJECT_DIR}/data/" 2>/dev/null || true
  log "Legacy backup: ${LEGACY_BACKUP}"
elif [[ "${MODE}" == "upgrade" ]]; then
  UPGRADE_BACKUP="${PROJECT_DIR}/backups/pre-${PUBLIC_VERSION}-${TIMESTAMP}"
  SYSTEM_BACKUP="${UPGRADE_BACKUP}/system"
  mkdir -p "${UPGRADE_BACKUP}/project"
  for rel in "${APP_FILES[@]}"; do
    if [[ -e "${PROJECT_DIR}/${rel}" ]]; then
      mkdir -p "$(dirname "${UPGRADE_BACKUP}/project/${rel}")"
      cp -a "${PROJECT_DIR}/${rel}" "${UPGRADE_BACKUP}/project/${rel}"
    fi
  done
  [[ -d "${PROJECT_DIR}/tests" ]] && cp -a "${PROJECT_DIR}/tests" "${UPGRADE_BACKUP}/tests"
  [[ -f "${SERVICE_FILE}" ]] && cp -a "${SERVICE_FILE}" "${UPGRADE_BACKUP}/zero-observer.service"
  [[ -f "${WEB_SERVICE_FILE}" ]] && cp -a "${WEB_SERVICE_FILE}" "${UPGRADE_BACKUP}/zero-connect-web.service"
  for wrapper in zero-connect zero-status aivi-live-test; do
    [[ -f "${BIN_DIR}/${wrapper}" ]] && cp -a "${BIN_DIR}/${wrapper}" "${UPGRADE_BACKUP}/wrapper-${wrapper}"
  done
  log "Upgrade backup: ${UPGRADE_BACKUP}"
fi
INSTALL_MUTATED=1
if [[ "${MODE}" != "fresh" ]]; then
  backup_system_files
  sudo systemctl stop zero-connect-network.socket zero-connect-network-watch.service || { echo "Netzwerkdienste konnten für das Update nicht angehalten werden." >&2; exit 1; }
  sudo systemctl stop zero-connect-captive-portal.service zero-connect-captive-dns.service || true
  sudo rm -f /run/zero-connect/network-result.json >/dev/null 2>&1 || true
fi

mkdir -p "${PROJECT_DIR}" "${PROJECT_DIR}/data" "${PROJECT_DIR}/tests/fixtures" "${BIN_DIR}" "${SERVICE_DIR}"
for dir in logs polls events sessions; do
  mkdir -p "${PROJECT_DIR}/data/${dir}"
  chmod 700 "${PROJECT_DIR}/data/${dir}"
done
chmod 700 "${PROJECT_DIR}/data"

for file in zero_observer.py zero_status.py zero_setup.py zero_doctor.py zero_connect_cli.py zero_connect_web.py zero_wifi_setup.py zero_network_helper.py zero_captive_portal.py zero_diagnostics.py zero_history.py zero_vehicle.py zero_charging.py zero_functional.py aivi_live_test.py zero_paths.py zero_release_notes.py zero_updates.py zero_vehicle_photos.py zero_trips.py zero_remote.py zero_release_verify.py zero_appliance_update.py zero_postboot_verify.py; do
  install -m 755 "${SCRIPT_DIR}/${file}" "${PROJECT_DIR}/${file}"
done
install -m 644 "${SCRIPT_DIR}/requirements.txt" "${PROJECT_DIR}/requirements.txt"
install -m 644 "${SCRIPT_DIR}/release_notes.json" "${PROJECT_DIR}/release_notes.json"
install -m 644 "${SCRIPT_DIR}/release-public-key.pub" "${PROJECT_DIR}/release-public-key.pub"
install -m 644 "${SCRIPT_DIR}/VERSION.json" "${PROJECT_DIR}/VERSION.json"
rm -rf "${PROJECT_DIR:?}/web_assets"
mkdir -p "${PROJECT_DIR}/web_assets"
cp -a "${SCRIPT_DIR}/web_assets/." "${PROJECT_DIR}/web_assets/"
find "${PROJECT_DIR}/web_assets" -type d -exec chmod 755 {} +
find "${PROJECT_DIR}/web_assets" -type f -exec chmod 644 {} +
for fixture in charge_65.jsonl charge_100_20260814.jsonl charge_100_20260815_sleep.jsonl charge_target90_then_100_20260824.jsonl; do
  install -m 600 "${SCRIPT_DIR}/tests/fixtures/${fixture}" "${PROJECT_DIR}/tests/fixtures/${fixture}"
done
if [[ "${MODE}" != "upgrade" ]]; then
  install -m 600 "${SCRIPT_DIR}/zero_config.json" "${PROJECT_DIR}/zero_config.json"
fi

if [[ ! -x "${VENV}/bin/python" ]]; then
  run_logged python3 -m venv "${VENV}"
fi
run_logged "${VENV}/bin/python" -m pip install --disable-pip-version-check -q -r "${PROJECT_DIR}/requirements.txt"
ok "Programmdateien installiert · Backup vorhanden"

step 3 "Selbsttest"
run_logged "${VENV}/bin/python" -m py_compile \
  "${PROJECT_DIR}/zero_observer.py" "${PROJECT_DIR}/zero_status.py" "${PROJECT_DIR}/zero_setup.py" \
  "${PROJECT_DIR}/zero_doctor.py" "${PROJECT_DIR}/zero_connect_cli.py" \
  "${PROJECT_DIR}/zero_diagnostics.py" "${PROJECT_DIR}/zero_history.py" "${PROJECT_DIR}/zero_vehicle.py" "${PROJECT_DIR}/zero_charging.py" "${PROJECT_DIR}/zero_functional.py" "${PROJECT_DIR}/zero_paths.py" "${PROJECT_DIR}/zero_release_notes.py" "${PROJECT_DIR}/zero_updates.py" "${PROJECT_DIR}/zero_vehicle_photos.py" "${PROJECT_DIR}/zero_trips.py" "${PROJECT_DIR}/zero_remote.py" "${PROJECT_DIR}/zero_release_verify.py" "${PROJECT_DIR}/zero_appliance_update.py" "${PROJECT_DIR}/zero_postboot_verify.py" "${PROJECT_DIR}/zero_connect_web.py" "${PROJECT_DIR}/zero_wifi_setup.py" "${PROJECT_DIR}/zero_network_helper.py" "${PROJECT_DIR}/zero_captive_portal.py" "${PROJECT_DIR}/aivi_live_test.py"
run_logged "${VENV}/bin/python" "${PROJECT_DIR}/zero_observer.py" --self-test
ok "Syntax und Regressionstests bestanden"

step 4 "Konfiguration vorbereiten"
if [[ "${MODE}" == "upgrade" ]]; then
  run_logged "${VENV}/bin/python" - <<'PY'
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path.home() / 'zero-connect'))
import zero_observer
p = Path.home() / 'zero-connect/zero_config.json'
cfg = zero_observer.load_config(p)
tmp = p.with_suffix('.json.tmp')
tmp.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
tmp.chmod(0o600)
tmp.replace(p)
p.chmod(0o600)
PY
  [[ ! -e "${PROJECT_DIR}/.env" ]] || chmod 600 "${PROJECT_DIR}/.env"
  chmod 600 "${PROJECT_DIR}/zero_config.json"
  ok "Bestehende Konfiguration aktualisiert · Zugangsdaten erhalten"
elif [[ "${MODE}" == "legacy" ]]; then
  export LEGACY_LABEL
  run_logged "${VENV}/bin/python" - <<'PY'
import json, os
from pathlib import Path
from dotenv import dotenv_values
import sys
p = Path.home() / 'zero-connect'
sys.path.insert(0, str(p))
import zero_observer
env = {str(k): str(v or '') for k, v in dotenv_values(p / '.env').items()}
config = zero_observer.load_config(p / 'zero_config.json')
label = os.environ.get('LEGACY_LABEL', '').strip()
if label:
    config['vehicle_label'] = label
has_aivi = bool(env.get('AIVI_API_TOKEN') and env.get('AIVI_ACTIVITY_SLUG'))
config['aivi']['enabled'] = has_aivi
if env.get('AIVI_ACTIVITY_SLUG'):
    config['aivi']['activity_slug'] = env['AIVI_ACTIVITY_SLUG']
config['abrp']['enabled'] = bool(env.get('ABRP_TOKEN') and env.get('ABRP_API_KEY'))
(p / 'zero_config.json').write_text(json.dumps(config, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
(p / 'zero_config.json').chmod(0o600)
(p / '.env').chmod(0o600)
PY
  say "Legacy-Konfiguration wird einmal durch den neuen Assistenten geführt."
  "${VENV}/bin/python" "${PROJECT_DIR}/zero_setup.py" --section all 2>&1 | tee -a "${INSTALL_LOG}"
else
  run_logged "${VENV}/bin/python" "${PROJECT_DIR}/zero_setup.py" --prepare-first-run
fi
if [[ "${MODE}" == "fresh" ]]; then
  ok "Ersteinrichtung bereit · Web-UI führt durch die Konfiguration"
else
  ok "Konfiguration bereit"
fi

step 5 "Dienst einrichten und starten"
cat > "${SERVICE_FILE}" <<'EOF_SERVICE'
[Unit]
Description=Zero Connect Motorcycle Cloud Observer
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
WorkingDirectory=%h/zero-connect
ExecStart=%h/zero-connect/.venv/bin/python %h/zero-connect/zero_observer.py
Restart=on-failure
RestartSec=15
TimeoutStopSec=20

[Install]
WantedBy=default.target
EOF_SERVICE

cat > "${WEB_SERVICE_FILE}" <<'EOF_WEB_SERVICE'
[Unit]
Description=Zero Connect Local Web UI
Wants=network-online.target
After=network-online.target zero-observer.service

[Service]
Type=simple
WorkingDirectory=%h/zero-connect
ExecStart=%h/zero-connect/.venv/bin/python %h/zero-connect/zero_connect_web.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
EOF_WEB_SERVICE

# Local admin PIN for write actions in the web UI.
if [[ ! -s "${PROJECT_DIR}/data/web_admin_pin" ]]; then
  PIN_VALUE="$(python3 - <<'PY_PIN'
import secrets
print(f"{secrets.randbelow(1_000_000):06d}")
PY_PIN
)"
  printf '%s\n' "${PIN_VALUE}" > "${PROJECT_DIR}/data/web_admin_pin"
fi
chmod 600 "${PROJECT_DIR}/data/web_admin_pin"

# Root-owned network boundary.  The web process receives only a group-readable
# Unix socket; all NetworkManager and captive-portal actions stay in fixed
# system units and the helper accepts a closed JSON action set.
if ! need_cmd sudo; then
  echo "sudo wird für die sichere WLAN-Ersteinrichtung benötigt." >&2; exit 1
fi
run_logged sudo -v || { echo "sudo-Autorisierung für die Netzwerkdienste fehlgeschlagen." >&2; exit 1; }
sudo systemctl enable --now NetworkManager.service || { echo "NetworkManager konnte nicht aktiviert werden." >&2; exit 1; }
sudo systemctl is-active --quiet NetworkManager.service || { echo "NetworkManager ist nicht aktiv." >&2; exit 1; }
WIFI_DEVICE="$(LC_ALL=C nmcli -t -e no -f DEVICE,TYPE,STATE device status | awk -F: '$2 == "wifi" && $3 != "unmanaged" { print $1; exit }')"
if [[ -z "${WIFI_DEVICE}" ]]; then
  echo "Kein von NetworkManager verwaltetes WLAN-Gerät verfügbar; Setup-Hotspot kann nicht eingerichtet werden." >&2
  exit 1
fi
if [[ ! "${WIFI_DEVICE}" =~ ^[A-Za-z0-9_.:-]{1,15}$ ]]; then
  echo "NetworkManager meldet einen ungültigen WLAN-Gerätenamen; Installation wird sicher abgebrochen." >&2
  exit 1
fi
# Debian minimal images do not necessarily ship optional configuration
# directories. Create every directory this privileged path writes to before
# writing a configuration; ownership and modes are explicit and repeatable.
SYSTEM_MUTATED=1
sudo install -d -o root -g root -m 0755 /etc/dnsmasq.d /etc/systemd/system /etc/tmpfiles.d /usr/lib/zero-connect
sudo install -d -o root -g root -m 0700 /etc/NetworkManager/system-connections
sudo install -D -o root -g root -m 0755 "${PROJECT_DIR}/zero_network_helper.py" /usr/lib/zero-connect/zero_network_helper.py
sudo install -D -o root -g root -m 0644 "${PROJECT_DIR}/zero_paths.py" /usr/lib/zero-connect/zero_paths.py
sudo install -D -o root -g root -m 0755 "${PROJECT_DIR}/zero_captive_portal.py" /usr/lib/zero-connect/zero_captive_portal.py
sudo install -d -o root -g "${INSTALL_GROUP}" -m 0710 /run/zero-connect
printf 'd /run/zero-connect 0710 root %s -\n' "${INSTALL_GROUP}" | sudo tee /etc/tmpfiles.d/zero-connect.conf >/dev/null
sudo systemd-tmpfiles --create /etc/tmpfiles.d/zero-connect.conf
sudo tee /etc/systemd/system/zero-connect-network.socket >/dev/null <<EOF_NETWORK_SOCKET
[Unit]
Description=Zero Connect restricted network IPC socket
[Socket]
ListenStream=/run/zero-connect/network.sock
Accept=true
SocketMode=0660
SocketUser=root
SocketGroup=${INSTALL_GROUP}
RemoveOnStop=true
[Install]
WantedBy=sockets.target
EOF_NETWORK_SOCKET
sudo tee /etc/systemd/system/zero-connect-network@.service >/dev/null <<EOF_NETWORK_SERVICE
[Unit]
Description=Zero Connect restricted NetworkManager helper
After=NetworkManager.service
CollectMode=inactive-or-failed
PartOf=zero-connect-network.socket
[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/lib/zero-connect/zero_network_helper.py --project-dir ${PROJECT_DIR} --wifi-device ${WIFI_DEVICE}
StandardInput=socket
StandardOutput=socket
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=read-only
ProtectSystem=strict
ReadWritePaths=/etc/NetworkManager/system-connections /run/zero-connect
EOF_NETWORK_SERVICE
sudo tee /etc/systemd/system/zero-connect-network-watch.service >/dev/null <<EOF_NETWORK_WATCH
[Unit]
Description=Zero Connect first-run network recovery watcher
Wants=NetworkManager.service
After=NetworkManager.service zero-connect-network.socket
[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/lib/zero-connect/zero_network_helper.py --watch --project-dir ${PROJECT_DIR} --wifi-device ${WIFI_DEVICE}
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=read-only
ProtectSystem=strict
ReadWritePaths=/etc/NetworkManager/system-connections /run/zero-connect
[Install]
WantedBy=multi-user.target
EOF_NETWORK_WATCH
sudo tee /etc/systemd/system/zero-connect-captive-portal.service >/dev/null <<'EOF_PORTAL_SERVICE'
[Unit]
Description=Zero Connect setup captive portal
After=NetworkManager.service
StartLimitIntervalSec=0
[Service]
Type=simple
User=root
ExecStart=/usr/lib/zero-connect/zero_captive_portal.py --host 10.42.0.1 --port 80
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
EOF_PORTAL_SERVICE
sudo tee /etc/dnsmasq.d/zero-connect-setup.conf >/dev/null <<EOF_DNS
port=53
bind-dynamic
interface=${WIFI_DEVICE}
except-interface=lo
listen-address=10.42.0.1
dhcp-authoritative
dhcp-range=10.42.0.10,10.42.0.100,255.255.255.0,12h
dhcp-option=option:router,10.42.0.1
dhcp-option=option:dns-server,10.42.0.1
dhcp-leasefile=/run/zero-connect/dnsmasq/dnsmasq.leases
pid-file=/run/zero-connect/dnsmasq/dnsmasq.pid
no-resolv
no-hosts
local=/#/
address=/#/10.42.0.1
EOF_DNS
sudo tee /etc/systemd/system/zero-connect-captive-dns.service >/dev/null <<'EOF_DNS_SERVICE'
[Unit]
Description=Zero Connect setup captive DNS
After=NetworkManager.service
StartLimitIntervalSec=0
[Service]
Type=simple
ExecStart=/usr/sbin/dnsmasq --keep-in-foreground --conf-file=/etc/dnsmasq.d/zero-connect-setup.conf
Restart=on-failure
RestartSec=5
TimeoutStopSec=15
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
RuntimeDirectory=zero-connect/dnsmasq
RuntimeDirectoryMode=0750
ReadWritePaths=/run/zero-connect/dnsmasq
EOF_DNS_SERVICE
sudo systemctl daemon-reload
sudo systemctl enable --now zero-connect-network.socket
sudo systemctl enable --now zero-connect-network-watch.service

rm -f "${BIN_DIR}/zero-connect" "${BIN_DIR}/zero-status" "${BIN_DIR}/aivi-live-test"
cat > "${BIN_DIR}/zero-connect" <<EOF_BIN
#!/usr/bin/env bash
exec "${VENV}/bin/python" "${PROJECT_DIR}/zero_connect_cli.py" "\$@"
EOF_BIN
cat > "${BIN_DIR}/zero-status" <<EOF_BIN
#!/usr/bin/env bash
exec "${VENV}/bin/python" "${PROJECT_DIR}/zero_connect_cli.py" status "\$@"
EOF_BIN
cat > "${BIN_DIR}/aivi-live-test" <<EOF_BIN
#!/usr/bin/env bash
exec "${VENV}/bin/python" "${PROJECT_DIR}/aivi_live_test.py" "\$@"
EOF_BIN
chmod 755 "${BIN_DIR}/zero-connect" "${BIN_DIR}/zero-status" "${BIN_DIR}/aivi-live-test"

run_logged "${VENV}/bin/python" -m py_compile "${PROJECT_DIR}/zero_connect_cli.py" "${PROJECT_DIR}/zero_connect_web.py" "${PROJECT_DIR}/zero_wifi_setup.py" "${PROJECT_DIR}/zero_network_helper.py" "${PROJECT_DIR}/zero_captive_portal.py" "${PROJECT_DIR}/aivi_live_test.py"
if [[ ! -f "${PROJECT_DIR}/aivi_live_test.py" ]] || grep -q '^exec .*aivi_live_test.py' "${PROJECT_DIR}/aivi_live_test.py"; then
  echo "Aivi-Testskript wurde bei der Wrapper-Installation beschädigt." >&2
  exit 1
fi
run_logged systemctl --user daemon-reload
if need_cmd sudo; then
  sudo loginctl enable-linger "${INSTALL_USER}" >>"${INSTALL_LOG}" 2>&1 || warn "Linger konnte nicht automatisch aktiviert werden."
fi
run_logged systemctl --user enable --now zero-observer.service
run_logged systemctl --user enable --now zero-connect-web.service
sleep 3
if [[ "$(systemctl --user is-active zero-observer.service || true)" != "active" ]]; then
  systemctl --user status zero-observer.service -l --no-pager >>"${INSTALL_LOG}" 2>&1 || true
  echo "Observer konnte nicht gestartet werden." >&2
  exit 1
fi
if [[ "$(systemctl --user is-active zero-connect-web.service || true)" != "active" ]]; then
  systemctl --user status zero-connect-web.service -l --no-pager >>"${INSTALL_LOG}" 2>&1 || true
  echo "Web-UI konnte nicht gestartet werden." >&2
  exit 1
fi
printf '%s\n' 'zero-connect-installation-v1' > "${INSTALL_COMPLETE_MARKER}.tmp"
chmod 600 "${INSTALL_COMPLETE_MARKER}.tmp"
mv -f "${INSTALL_COMPLETE_MARKER}.tmp" "${INSTALL_COMPLETE_MARKER}"
SERVICE_WAS_ACTIVE=0
WEB_SERVICE_WAS_ACTIVE=0
INSTALL_MUTATED=0
ok "Observer und Web-UI aktiv · Autostart eingerichtet"

if [[ ":${PATH}:" != *":${BIN_DIR}:"* ]]; then
  warn "${BIN_DIR} ist in dieser Shell noch nicht im PATH; nach Neuanmeldung automatisch verfügbar."
fi

say ""
say "[✓] Zero Connect ${PUBLIC_VERSION} ist bereit."
say "    status:  zero-connect status"
say "    prüfen:  zero-connect doctor"
say "    Web-UI:  zero-connect web"
say "    details: ${INSTALL_LOG}"
[[ "${MODE}" == "legacy" ]] && say "    Legacy-Backup: ${LEGACY_BACKUP}"
say ""
"${VENV}/bin/python" "${PROJECT_DIR}/zero_status.py" || true
