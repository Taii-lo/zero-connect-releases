#!/usr/bin/env python3
"""Persistent diagnostics summary and privacy-aware export for Zero Connect."""

from __future__ import annotations

import argparse
import copy
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import tarfile
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import zero_observer as observer

from zero_paths import PATHS
PROJECT_DIR = PATHS.program_dir
DATA_DIR = PATHS.data_dir
PUBLIC_VERSION = "1.0.0-beta.12"
INTERNAL_VERSION = "3.0.0-alpha.45"
SERVICE_STATUS_TIMEOUT_SECONDS = 10
SAFE_STATUS_FIELDS = (
    "datetime_utc", "datetime_actual", "soc", "charging", "chargecomplete",
    "pluggedin", "chargingtimeleft", "velocity", "mileage", "gps_valid",
    "ignition", "logic_state", "reason",
)
LOCATION_STATUS_FIELDS = (
    "latitude", "longitude", "lat", "lon", "lng", "altitude", "address",
    "heading", "unitnumber", "unit_number", "vin", "VIN", "vehiclevin",
    "vehicle_label", "name",
)
SAFE_RUNTIME_FIELDS = (
    "version", "initialized", "charge_session_generation", "charge_phase",
    "charge_state_confidence", "charge_completion_source", "session_active",
    "session_started_epoch", "session_start_soc", "session_target_reached_epoch",
    "session_completed_epoch", "session_ended_epoch", "session_terminal",
    "session_terminal_contact_epoch", "session_balancing_started_epoch",
    "target_soc", "target_source", "target_notified", "complete_notified",
    "session_end_notified", "session_end_reason", "shutdown_zero_pulse_observed",
    "shutdown_zero_pulse_epoch", "shutdown_zero_pulse_generation",
    "last_poll_success_epoch", "last_contact_epoch", "last_measurement_epoch",
    "last_live_activity_success_epoch", "last_live_activity_action",
    "live_activity_real_update_count", "live_activity_intermediate_update_count",
    "aivi_consecutive_errors", "aivi_next_retry_epoch", "three_phase_active_kind",
    "last_abrp_success_epoch", "last_abrp_send_epoch", "abrp_consecutive_errors",
    "abrp_next_retry_epoch", "last_diagnostics_cleanup_epoch",
)
SAFE_POLL_FIELDS = (
    "fetched_at_utc", "fresh", "raw_changed", "valid_changed", "soc_accepted",
    "soc_note", "phase_before", "phase_after", "state_events",
    "session_generation", "session_active", "target_soc", "target_source",
    "confidence", "completion_source",
)
SAFE_TIME_FIELDS = (
    "measurement", "actual", "contact", "measurement_age_seconds",
    "contact_age_seconds",
)
SAFE_EVENT_FIELDS = (
    "recorded_at_utc", "event_type", "phase", "session_generation",
    "session_active", "target_soc", "target_source", "confidence",
    "completion_source", "soc", "charging", "chargecomplete", "pluggedin",
    "chargingtimeleft", "vehicle_time", "contact_time",
)
SAFE_EVENT_DETAIL_FIELDS = (
    "raw_soc", "from_phase", "to_phase", "action", "display",
)
SAFE_SESSION_FIELDS = (
    "recorded_at_utc", "record_type", "generation", "started_at_utc",
    "target_reached_at_utc", "ended_at_utc", "duration_seconds", "start_soc",
    "target_soc", "end_soc", "terminal_event", "completion_source", "confidence",
    "target_source", "shutdown_zero_pulse",
    "shutdown_zero_pulse_at_utc",
)
SAFE_CONFIG_FIELDS: dict[str, tuple[str, ...]] = {
    "freshness": ("max_contact_age_seconds", "future_tolerance_seconds"),
    "polling": (
        "charging_seconds", "recent_seconds", "idle_seconds",
        "recent_window_seconds", "error_initial_seconds", "error_max_seconds",
    ),
    "abrp": ("enabled", "min_interval_seconds", "error_initial_seconds", "error_max_seconds"),
    "charging": (
        "interruption_confirmation_polls", "full_target_fallback_soc",
        "full_target_requires_zero_minutes", "complete_after_target_when_idle",
    ),
    "diagnostics": (
        "retention_days", "cleanup_interval_hours", "persistent_text_log",
        "poll_history", "event_history", "export_default_days", "max_size_mib",
    ),
    "aivi": (
        "enabled", "request_timeout_seconds", "error_initial_seconds",
        "error_max_seconds", "finalize_delay_seconds", "mode",
        "complete_summary_seconds", "balancing_update_seconds",
    ),
    "web": ("enabled", "port"),
}
SAFE_BALANCING_FIELDS = (
    "enabled", "timeout_seconds", "confirmation_polls", "require_full_soc",
    "require_zero_minutes",
)


def human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TiB"


def directory_size(path: Path) -> int:
    if not path.exists():
        return 0
    total = 0
    for item in path.rglob("*"):
        try:
            if item.is_file() and not item.is_symlink():
                total += item.stat().st_size
        except OSError:
            pass
    return total


def count_lines(paths: list[Path]) -> int:
    count = 0
    for path in paths:
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                count += sum(1 for _ in handle)
        except OSError:
            pass
    return count


def count_session_records(paths: list[Path]) -> int:
    count = 0
    for path in paths:
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    try:
                        record = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(record, dict) and record.get("record_type", "session") != "evidence_update":
                        count += 1
        except OSError:
            pass
    return count


def select_fields(value: Any, fields: tuple[str, ...]) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    return {key: copy.deepcopy(value[key]) for key in fields if key in value}


def safe_config_export(value: Any, include_location: bool) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    result = select_fields(value, ("schema_version", "request_timeout_seconds"))
    if "vehicle_label" in value:
        result["vehicle_label"] = (
            copy.deepcopy(value["vehicle_label"]) if include_location else "<redacted>"
        )
    for section, fields in SAFE_CONFIG_FIELDS.items():
        selected = select_fields(value.get(section), fields)
        if selected:
            result[section] = selected
    charging = result.get("charging")
    source_charging = value.get("charging")
    if isinstance(charging, dict) and isinstance(source_charging, dict):
        balancing = select_fields(
            source_charging.get("balancing_sleep_completion"), SAFE_BALANCING_FIELDS
        )
        if balancing:
            charging["balancing_sleep_completion"] = balancing
    return result


def safe_status_export(value: Any, include_location: bool) -> dict[str, Any]:
    fields = SAFE_STATUS_FIELDS + (LOCATION_STATUS_FIELDS if include_location else ())
    return select_fields(value, fields)


def safe_version_export(value: Any) -> dict[str, Any]:
    return select_fields(value, ("public_version", "internal_version", "schema_version"))


def safe_runtime_export(value: Any) -> dict[str, Any]:
    return select_fields(value, SAFE_RUNTIME_FIELDS)


def safe_poll_export(value: Any, include_location: bool) -> dict[str, Any]:
    result = select_fields(value, SAFE_POLL_FIELDS)
    if not isinstance(value, dict):
        return result
    times = select_fields(value.get("time"), SAFE_TIME_FIELDS)
    if times:
        result["time"] = times
    for key in ("raw_status", "valid_status", "status"):
        status = safe_status_export(value.get(key), include_location)
        if status:
            result[key] = status
    return result


def safe_event_export(value: Any, include_location: bool) -> dict[str, Any]:
    result = select_fields(value, SAFE_EVENT_FIELDS)
    if not isinstance(value, dict):
        return result
    details = select_fields(value.get("details"), SAFE_EVENT_DETAIL_FIELDS)
    if details:
        result["details"] = details
    status = safe_status_export(value.get("status"), include_location)
    if status:
        result["status"] = status
    return result


def safe_session_export(value: Any, include_location: bool) -> dict[str, Any]:
    result = select_fields(value, SAFE_SESSION_FIELDS)
    if isinstance(value, dict) and "vehicle_label" in value:
        result["vehicle_label"] = (
            copy.deepcopy(value["vehicle_label"]) if include_location else "<redacted>"
        )
    return result


def safe_json_value(value: Any, kind: str, include_location: bool) -> dict[str, Any]:
    exporters = {
        "config": lambda item: safe_config_export(item, include_location),
        "status": lambda item: safe_status_export(item, include_location),
        "runtime": safe_runtime_export,
        "version": safe_version_export,
        "poll": lambda item: safe_poll_export(item, include_location),
        "event": lambda item: safe_event_export(item, include_location),
        "session": lambda item: safe_session_export(item, include_location),
        "change": lambda item: safe_poll_export(item, include_location),
    }
    return exporters[kind](value)


def write_safe_json(
    source: Path,
    target: Path,
    kind: str,
    include_location: bool,
) -> None:
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            safe_json_value(value, kind, include_location),
            indent=2,
            ensure_ascii=False,
        ) + "\n",
        encoding="utf-8",
    )
    target.chmod(0o600)


def parse_record_time(record: dict[str, Any]) -> datetime | None:
    for key in ("fetched_at_utc", "recorded_at_utc"):
        value = record.get(key)
        if not value:
            continue
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return None


def filter_jsonl(
    source: Path,
    target: Path,
    cutoff: datetime,
    include_location: bool,
    kind: str,
) -> int:
    if not source.exists():
        return 0
    target.parent.mkdir(parents=True, exist_ok=True)
    kept = 0
    with source.open("r", encoding="utf-8", errors="replace") as src, target.open(
        "w", encoding="utf-8"
    ) as dst:
        for line in src:
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except ValueError:
                continue
            stamp = parse_record_time(record) if isinstance(record, dict) else None
            if stamp is not None and stamp.astimezone(timezone.utc) < cutoff:
                continue
            dst.write(
                json.dumps(
                    safe_json_value(record, kind, include_location),
                    ensure_ascii=False,
                ) + "\n"
            )
            kept += 1
    target.chmod(0o600)
    if kept == 0:
        target.unlink(missing_ok=True)
    return kept


def copy_recent_text_logs(
    target_dir: Path,
    cutoff: datetime,
) -> int:
    source_dir = DATA_DIR / "logs"
    if not source_dir.exists():
        return 0
    copied = 0
    target_dir.mkdir(parents=True, exist_ok=True)
    cutoff_epoch = cutoff.timestamp()
    for source in source_dir.glob("observer.log*"):
        try:
            # Current log must always be included; rotations are selected by mtime.
            if source.name != "observer.log" and source.stat().st_mtime < cutoff_epoch:
                continue
            target = target_dir / source.name
            target.write_text(
                "Raw log content omitted for privacy.\n"
                f"Source: {source.name}\n"
                f"Size: {source.stat().st_size} bytes\n"
                f"Modified UTC: {datetime.fromtimestamp(source.stat().st_mtime, timezone.utc).isoformat()}\n",
                encoding="utf-8",
            )
            target.chmod(0o600)
            copied += 1
        except OSError:
            pass
    return copied


# ---- what a friend's problem report needs: device health, update and network state, redacted error lines
LOG_SEVERITY = re.compile(r"fehler|fehlgeschlagen|error|warn|exception|traceback|failed|timeout|zeitüberschreitung|abgelehnt|denied|refused|unreachable|nicht erreichbar|neustart|restart|retry|erneut", re.IGNORECASE)
LOG_PRIVATE_TOPICS = re.compile(r"standort|ladeort|adresse|address|location|place|gps|koordinat|lat\b|lon\b|vin\b|fahrgestell|e-?mail|passwort|password|token|ssid|wlan-name", re.IGNORECASE)
LOG_REDACTIONS = (
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "<mail>"),
    (re.compile(r"https?://\S+"), "<url>"),
    (re.compile(r"\b(?:[0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}\b"), "<mac>"),
    (re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b"), "<ip>"),
    (re.compile(r"\b(?:[0-9a-fA-F]{1,4}:){3,7}[0-9a-fA-F]{1,4}\b"), "<ip>"),
    (re.compile(r"[-+]?\d{1,3}\.\d{4,}"), "<zahl>"),
    (re.compile(r"\b[A-HJ-NPR-Z0-9]{17}\b"), "<kennung>"),
    (re.compile(r"\b[A-Za-z0-9+/_=-]{28,}\b"), "<geheim>"),
    (re.compile(r"\b[\w-]+\.local\b"), "<host>"),
)
LOG_MAX_LINES = 300
LOG_MAX_LINE_CHARS = 240


def redact_log_line(line: str) -> str:
    """One log line with everything that could identify the person, the place, the network or the vehicle removed."""
    for pattern, replacement in LOG_REDACTIONS:
        line = pattern.sub(replacement, line)
    return line.strip()[:LOG_MAX_LINE_CHARS]


def important_log_lines(lines: list[str], limit: int = LOG_MAX_LINES) -> list[str]:
    """Warnings and errors only, never lines about places, accounts or secrets; the newest `limit` of them, redacted."""
    kept = [redact_log_line(line) for line in lines
            if line.strip() and LOG_SEVERITY.search(line) and not LOG_PRIVATE_TOPICS.search(line)]
    return kept[-limit:]


def read_tail_lines(path: Path, max_bytes: int = 2_000_000) -> list[str]:
    try:
        with path.open("rb") as handle:
            handle.seek(0, os.SEEK_END)
            handle.seek(max(0, handle.tell() - max_bytes))
            return handle.read().decode("utf-8", errors="replace").splitlines()
    except OSError:
        return []


def journal_report(units: tuple[str, ...], runner=subprocess.run) -> tuple[list[str] | None, str]:
    """Warnings and errors of the Zero Connect services from the journal, and why they are missing where they are."""
    command = ["journalctl", "--no-pager", "-o", "cat", "-p", "warning", "-n", "300", "--since", "-2 days"]
    for unit in units:
        command += ["-u", unit]
    try:
        result = runner(command, capture_output=True, text=True, check=False, timeout=45)
    except subprocess.TimeoutExpired:
        return None, "Zeitüberschreitung (45 s)"
    except (OSError, subprocess.SubprocessError) as exc:
        return None, f"nicht ausführbar ({type(exc).__name__})"
    if result.returncode != 0:
        first = (getattr(result, "stderr", "") or "").strip().splitlines()[:1]
        return None, f"Rückgabewert {result.returncode}" + (": " + redact_log_line(first[0]) if first else "")
    return result.stdout.splitlines(), ""


def journal_lines(units: tuple[str, ...], runner=subprocess.run) -> list[str] | None:
    return journal_report(units, runner)[0]


def read_first_line(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace").replace("\x00", "").strip().splitlines()[0]
    except (OSError, IndexError):
        return "unbekannt"


def meminfo_mib() -> dict[str, int]:
    values: dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            name, _, rest = line.partition(":")
            if name in ("MemTotal", "MemAvailable", "SwapTotal", "SwapFree"):
                values[name] = int(rest.split()[0]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return values


def throttled_text(runner=subprocess.run) -> str:
    """Undervoltage and overheating flags of the Raspberry Pi; a weak power supply is the most common cause of odd behaviour."""
    value: int | None = None
    try:
        out = runner(["vcgencmd", "get_throttled"], capture_output=True, text=True, check=False, timeout=5).stdout.strip()
        value = int(out.split("=")[1], 16)
    except (OSError, subprocess.SubprocessError, IndexError, ValueError):
        for path in sorted(Path("/sys/devices/platform").glob("**/get_throttled"))[:1]:  # the kernel offers the same flags without a device permission
            try:
                value = int(path.read_text(encoding="utf-8").strip(), 16)
            except (OSError, ValueError):
                pass
    if value is None:  # newer kernels offer only the undervoltage alarm, as a hardware monitor
        for name_file in sorted(Path("/sys/class/hwmon").glob("hwmon*/name")):
            try:
                if name_file.read_text(encoding="utf-8").strip() != "rpi_volt":
                    continue
                alarm = int((name_file.parent / "in0_lcrit_alarm").read_text(encoding="utf-8").strip())
                return "Unterspannung jetzt" if alarm else "keine Unterspannung gemeldet (nur diese Angabe lesbar)"
            except (OSError, ValueError):
                continue
        return "unbekannt (vcgencmd, Kernel-Datei und Spannungswächter nicht lesbar)"
    flags = {0: "Unterspannung jetzt", 1: "Takt gedrosselt jetzt", 2: "Leistung gedrosselt jetzt", 3: "Übertemperatur jetzt",
             16: "Unterspannung seit Start", 17: "Takt gedrosselt seit Start", 18: "Leistung gedrosselt seit Start", 19: "Übertemperatur seit Start"}
    active = [text for bit, text in flags.items() if value >> bit & 1]
    return f"0x{value:x} " + (", ".join(active) if active else "keine Auffälligkeiten")


def network_text(runner=subprocess.run) -> str:
    """Kinds and states of the network devices, never names or addresses."""
    try:
        out = runner(["nmcli", "-t", "-f", "TYPE,STATE", "device", "status"], capture_output=True, text=True, check=False, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return "nicht lesbar"
    rows = [line for line in out.splitlines() if line.split(":")[0] in ("wifi", "ethernet")]
    return "; ".join(rows) or "keine Netzwerkgeräte gemeldet"


def health_text(include_location: bool) -> str:
    memory = meminfo_mib()
    try:
        uptime_hours = float(Path("/proc/uptime").read_text(encoding="utf-8").split()[0]) / 3600
    except (OSError, ValueError, IndexError):
        uptime_hours = -1
    try:
        temperature = f"{int(Path('/sys/class/thermal/thermal_zone0/temp').read_text(encoding='utf-8')) / 1000:.1f} °C"
    except (OSError, ValueError):
        temperature = "unbekannt"
    lines = [
        f"Gerät: {read_first_line('/proc/device-tree/model')}",
        f"Betriebssystem: {next((l.split('=', 1)[1].strip(chr(34)) for l in Path('/etc/os-release').read_text(encoding='utf-8').splitlines() if l.startswith('PRETTY_NAME=')), 'unbekannt') if Path('/etc/os-release').is_file() else 'unbekannt'}",
        f"Kernel: {platform.release()}",
        f"Laufzeit seit Start: {uptime_hours:.1f} Stunden",
        f"Arbeitsspeicher: {memory.get('MemAvailable', '?')} von {memory.get('MemTotal', '?')} MiB frei",
        f"Auslagerung: {memory.get('SwapFree', '?')} von {memory.get('SwapTotal', '?')} MiB frei",
        f"Prozessor: {temperature}, Last {' '.join(f'{v:.2f}' for v in os.getloadavg())}",
        f"Stromversorgung: {throttled_text()}",
        f"Netzwerk: {network_text()}",
        f"Seitenaufrufe: {page_loads_text().strip()}",
    ]
    return "\n".join(lines) + "\n"


def page_loads_text(runner=subprocess.run) -> str:
    """How often the app page itself was fetched lately: many loads for few taps would mean the page reloads by itself."""
    try:
        result = runner(["journalctl", "--no-pager", "-o", "cat", "-u", "zero-connect-web.service", "--since", "-3 hours"],
                        capture_output=True, text=True, check=False, timeout=45)
    except (OSError, subprocess.SubprocessError) as exc:
        return f"nicht lesbar ({type(exc).__name__})\n"
    if result.returncode != 0:
        return f"nicht lesbar (Rückgabewert {result.returncode})\n"
    lines = result.stdout.splitlines()
    page = sum(1 for line in lines if '"GET / HTTP' in line or '"GET /?' in line)
    script = sum(1 for line in lines if '"GET /assets/app.js' in line)
    api = sum(1 for line in lines if '"GET /api/' in line or '"POST /api/' in line)
    return f"Startseite: {page}, app.js: {script}, API-Aufrufe: {api} (letzte 3 Stunden)\n"


def update_text() -> str:
    """Where the software update stands: versions, channel, last error; nothing that identifies the person."""
    try:
        import zero_updates as updates
        status = updates.status()
    except Exception as exc:  # the report must still be produced
        return f"Update-Status nicht lesbar: {type(exc).__name__}\n"
    available = status.get("available") or {}
    keys = ("current_version", "channel", "configured", "last_error", "held_back", "notice", "staged_version", "return_to_stable", "auto_install")
    lines = [f"{key}: {status.get(key)}" for key in keys]
    lines.append(f"available_version: {available.get('version')}")
    lines.append(f"install_blockers: {', '.join(status.get('install_blockers') or []) or 'keine'}")
    last = status.get("last_check_ts") or 0
    lines.append("last_check_utc: " + (datetime.fromtimestamp(last, timezone.utc).isoformat() if last else "nie"))
    return "\n".join(lines) + "\n"


def setup_text(config: dict[str, Any]) -> str:
    setup = config.get("setup") if isinstance(config.get("setup"), dict) else {}
    return "\n".join(f"{key}: {setup.get(key)}" for key in ("completed", "step") if key in setup) + "\n"


def service_text() -> str:
    command = PATHS.service_command("status", "zero-observer.service", "--no-pager", "-l")
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=SERVICE_STATUS_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return (
            "systemctl --user status zero-observer.service\n"
            "Command result: timed out\n"
            "Service reported active: unknown\n"
            "Raw service output omitted for privacy.\n"
        )
    except OSError:
        return (
            "systemctl --user status zero-observer.service\n"
            "Command result: unavailable\n"
            "Service reported active: unknown\n"
            "Raw service output omitted for privacy.\n"
        )
    active = result.returncode == 0
    return (
        "systemctl --user status zero-observer.service\n"
        f"Command exit code: {result.returncode}\n"
        f"Service reported active: {str(active).lower()}\n"
        "Raw service output omitted for privacy.\n"
    )


def system_text(include_location: bool) -> str:
    disk = shutil.disk_usage(PROJECT_DIR)
    lines = [
        f"Zero Connect: {PUBLIC_VERSION} (intern v{INTERNAL_VERSION})",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        f"Hostname: {socket.gethostname() if include_location else '<redacted>'}",
        f"Platform: {platform.system()}",
        f"Python: {platform.python_version()}",
        f"Architecture: {platform.machine()}",
        f"Disk total: {human_size(disk.total)}",
        f"Disk used: {human_size(disk.used)}",
        f"Disk free: {human_size(disk.free)}",
    ]
    return "\n".join(lines) + "\n"


def summary() -> int:
    config = observer.load_config()
    diag = config.get("diagnostics", {})
    polls = sorted((DATA_DIR / "polls").glob("poll-*.jsonl")) if (DATA_DIR / "polls").exists() else []
    events = sorted((DATA_DIR / "events").glob("event-*.jsonl")) if (DATA_DIR / "events").exists() else []
    sessions = sorted((DATA_DIR / "sessions").glob("session-*.jsonl")) if (DATA_DIR / "sessions").exists() else []
    logs = sorted((DATA_DIR / "logs").glob("observer.log*")) if (DATA_DIR / "logs").exists() else []
    print(f"🔎 Zero Connect Diagnose · {PUBLIC_VERSION}")
    print("────────────────────────────────────────")
    print(f"Aufbewahrung:       {int(diag.get('retention_days', 180))} Tage · max. {int(diag.get('max_size_mib', 2048))} MiB")
    print(f"Poll-Tagesdateien:  {len(polls)} · {count_lines(polls)} Datensätze")
    print(f"Event-Tagesdateien: {len(events)} · {count_lines(events)} Datensätze")
    print(f"Ladesitzungen:      {len(sessions)} Tagesdateien · {count_session_records(sessions)} Sitzungen")
    print(f"Textlogs:           {len(logs)}")
    print(f"Diagnosedaten:      {human_size(directory_size(DATA_DIR))}")
    disk = shutil.disk_usage(PROJECT_DIR)
    print(f"Freier Speicher:    {human_size(disk.free)}")
    if polls:
        print(f"Poll-Zeitraum:      {polls[0].stem.removeprefix('poll-')} bis {polls[-1].stem.removeprefix('poll-')}")
    print("Export:             zero-connect export-logs")
    print("                    (Standort/Kennung standardmäßig geschwärzt)")
    return 0


def export(days: int, output: str | None, include_location: bool) -> int:
    config = observer.load_config()
    if days < 1:
        raise SystemExit("--days muss mindestens 1 sein.")
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    stamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    output_path = (
        Path(output).expanduser().resolve()
        if output
        else (DATA_DIR / "exports" if PATHS.mode == "appliance" else Path.home()) / f"zero-connect-diagnostics-{stamp}.tar.gz"
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    state_sources = (
        (PROJECT_DIR / "VERSION.json", "version"),
        (PATHS.config_file, "config"),
        (DATA_DIR / "runtime_state_v2.json", "runtime"),
        (DATA_DIR / "last_valid_transmit.json", "status"),
        (DATA_DIR / "last_raw_transmit.json", "status"),
    )

    # Appliance services run with ProtectSystem=strict. The system /tmp is
    # therefore not guaranteed writable inside the service sandbox; DATA_DIR
    # is the declared writable state path and is already created above.
    with tempfile.TemporaryDirectory(
        prefix="zero-connect-diagnostics-", dir=str(DATA_DIR)
    ) as temp:
        root = Path(temp) / f"zero-connect-diagnostics-{stamp}"
        root.mkdir(parents=True)
        (root / "system.txt").write_text(
            system_text(include_location),
            encoding="utf-8",
        )
        (root / "service.txt").write_text(
            service_text(),
            encoding="utf-8",
        )
        (root / "health.txt").write_text(health_text(include_location), encoding="utf-8")
        (root / "update.txt").write_text(update_text(), encoding="utf-8")
        (root / "setup.txt").write_text(setup_text(config), encoding="utf-8")
        journal, journal_problem = journal_report(("zero-connect-web.service", "zero-observer.service", "zero-connect-network-watch.service", "zero-connect-update.service"))
        (root / "logs").mkdir(exist_ok=True)
        (root / "logs" / "journal-important.txt").write_text(
            (f"Journal nicht lesbar: {journal_problem}\n" if journal is None
             else ("\n".join(important_log_lines(journal)) or "Keine Warnungen oder Fehler gefunden.") + "\n"), encoding="utf-8")
        (root / "logs" / "observer-important.txt").write_text(
            ("\n".join(important_log_lines(read_tail_lines(DATA_DIR / "logs" / "observer.log"))) or "Keine Warnungen oder Fehler gefunden.") + "\n", encoding="utf-8")
        (root / "privacy.txt").write_text(
            (
                "Location and vehicle identifiers are INCLUDED by explicit request.\n"
                if include_location
                else "Location, address, integration identifiers, vehicle identifiers and local system identity were omitted or redacted.\n"
            )
            + "Structured data uses explicit safe-field allowlists; secrets and unknown fields are omitted.\n"
            + "Raw text logs are never exported. logs/*-important.txt holds only warning and error lines, redacted (addresses, mail, URLs, coordinates, identifiers),\n"
            + "without any line about places, accounts or secrets.\n"
            + "The .env secrets file is never exported.\n",
            encoding="utf-8",
        )

        for source, kind in state_sources:
            if source.exists():
                write_safe_json(
                    source,
                    root / "state" / source.name,
                    kind,
                    include_location,
                )

        # Daily detailed histories.
        for directory_name, prefix, kind in (
            ("polls", "poll-", "poll"),
            ("events", "event-", "event"),
            ("sessions", "session-", "session"),
        ):
            source_dir = DATA_DIR / directory_name
            if not source_dir.exists():
                continue
            for source in sorted(source_dir.glob(f"{prefix}*.jsonl")):
                filter_jsonl(
                    source,
                    root / directory_name / source.name,
                    cutoff,
                    include_location,
                    kind,
                )

        # Legacy/change-only histories remain valuable for migrations and long-running systems.
        for name in ("zero_raw_changes_v2.jsonl", "zero_valid_changes_v2.jsonl"):
            filter_jsonl(
                DATA_DIR / name,
                root / "history" / name,
                cutoff,
                include_location,
                "change",
            )

        copy_recent_text_logs(root / "logs", cutoff)

        # Save the effective non-secret configuration used for interpreting diagnostics.
        effective = safe_config_export(config, include_location)
        effective_path = root / "effective_config.json"
        effective_path.write_text(
            json.dumps(effective, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        effective_path.chmod(0o600)

        with tarfile.open(output_path, "w:gz") as tf:
            tf.add(root, arcname=root.name)

    os.chmod(output_path, 0o600)
    print(f"Diagnosepaket erstellt: {output_path}")
    print(f"Zeitraum: letzte {days} Tage")
    if include_location:
        print("Datenschutz: Standort/Fahrzeugkennung enthalten (--include-location).")
    else:
        print("Datenschutz: Standort, Kennungen und lokale Systemidentität geschwärzt; .env nicht enthalten.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Zero Connect Diagnosedaten")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("summary", help="lokale Diagnose-/Speichernutzung anzeigen")
    exp = sub.add_parser("export", help="Support-Diagnosepaket erzeugen")
    exp.add_argument("--days", type=int, default=None, help="Anzahl Tage (Standard aus Konfiguration)")
    exp.add_argument("--output", help="optionaler Ausgabepfad für .tar.gz")
    exp.add_argument(
        "--include-location",
        action="store_true",
        help="Standort, Adresse und Fahrzeugkennung ausnahmsweise im Export belassen",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.command == "summary":
        raise SystemExit(summary())
    if args.command == "export":
        config = observer.load_config()
        default_days = int(config.get("diagnostics", {}).get("export_default_days", 7))
        raise SystemExit(export(args.days or default_days, args.output, args.include_location))


if __name__ == "__main__":
    main()
