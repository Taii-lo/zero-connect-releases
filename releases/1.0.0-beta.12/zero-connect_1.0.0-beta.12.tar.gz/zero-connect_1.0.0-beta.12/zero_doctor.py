#!/usr/bin/env python3
"""Read-only health diagnostics for Zero Connect."""

from __future__ import annotations

import json
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import requests
from dotenv import dotenv_values

import zero_observer as observer
from zero_paths import PATHS

PROJECT_DIR = PATHS.program_dir
ENV_FILE = PATHS.secrets_file
CONFIG_FILE = PATHS.config_file
STATE_FILE = PATHS.data_dir / "runtime_state_v2.json"
PUBLIC_VERSION = "1.0.0-beta.12"


def service_active(name: str = "zero-observer.service") -> bool:
    result = subprocess.run(
        PATHS.service_command("is-active", name),
        capture_output=True,
        text=True,
        check=False,
    )
    return result.stdout.strip() == "active"


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


class Report:
    def __init__(self) -> None:
        self.errors = 0
        self.warnings = 0

    def ok(self, label: str, text: str) -> None:
        print(f"[✓] {label:<15} {text}")

    def warn(self, label: str, text: str) -> None:
        self.warnings += 1
        print(f"[!] {label:<15} {text}")

    def error(self, label: str, text: str) -> None:
        self.errors += 1
        print(f"[✗] {label:<15} {text}")

    def off(self, label: str, text: str = "deaktiviert") -> None:
        print(f"[-] {label:<15} {text}")


def main() -> None:
    report = Report()
    print()
    print(f"🩺 Zero Connect Doctor · {PUBLIC_VERSION}")
    print("──────────────────────────────────────")

    if sys.version_info >= (3, 10):
        report.ok("Python", sys.version.split()[0])
    else:
        report.error("Python", f"{sys.version.split()[0]} · mindestens 3.10 erforderlich")

    env_exists = ENV_FILE.is_file()
    if not env_exists:
        report.error(".env", "Datei fehlt")
    else:
        mode = stat.S_IMODE(ENV_FILE.stat().st_mode)
        if mode == 0o600:
            report.ok(".env", "600")
        else:
            report.error(".env", f"unsichere Rechte {mode:o} · erwartet 600")

    try:
        config = observer.load_config(CONFIG_FILE)
        report.ok("Konfiguration", f"gültig · Schema {int(config.get('schema_version', 0))}")
    except Exception as error:
        config = observer.DEFAULT_CONFIG
        report.error("Konfiguration", str(error))

    active = service_active("zero-observer.service")
    if active:
        report.ok("Observer", "aktiv")
    else:
        report.error("Observer", "inaktiv")

    env = (
        {str(k): str(v or "") for k, v in dotenv_values(ENV_FILE).items()}
        if env_exists
        else {}
    )
    user = env.get("ZERO_CLOUD_USER", "")
    password = env.get("ZERO_CLOUD_PASSWORD", "")
    selected_unit = env.get("ZERO_UNIT_NUMBER", "")

    if not user or not password:
        report.error("Zero Cloud", "Zugangsdaten fehlen")
    else:
        try:
            session = requests.Session()
            vehicles = observer.request_zero(
                session,
                "get_units",
                user,
                password,
                float(config["request_timeout_seconds"]),
            )
            if not isinstance(vehicles, list):
                raise RuntimeError("unerwartete Fahrzeugliste")
            vehicle = observer.select_account_vehicle(vehicles, selected_unit)
            report.ok("Zero Cloud", f"verbunden · {observer.vehicle_display_label(vehicle)}")
            transmissions = observer.request_zero(
                session,
                "get_last_transmit",
                user,
                password,
                float(config["request_timeout_seconds"]),
                unitnumber=str(vehicle["unitnumber"]),
            )
            if isinstance(transmissions, list) and transmissions and isinstance(transmissions[0], dict):
                status = transmissions[0]
                soc = observer.to_float_or_none(status.get("soc"))
                info = observer.status_time_info(status, config, time.time())
                age = float(info.get("contact_age_seconds", float("inf")))
                max_age = float(config.get("freshness", {}).get("max_contact_age_seconds", 900))
                suffix = f" · SoC {soc:.0f} %" if soc is not None else ""
                if age <= max_age:
                    report.ok("Fahrzeugdaten", f"aktuell{suffix}")
                else:
                    minutes = int(age // 60) if age != float("inf") else 0
                    report.warn("Fahrzeugdaten", f"abrufbar, aber veraltet · {minutes} min{suffix}")
            else:
                report.warn("Fahrzeugdaten", "derzeit kein Datensatz")
        except Exception as error:
            report.error("Zero Cloud", str(error))

    state = load_json(STATE_FILE)

    if bool(config.get("aivi", {}).get("enabled", False)):
        configured = bool(env.get("AIVI_API_TOKEN") and env.get("AIVI_ACTIVITY_SLUG"))
        last_ok = float(state.get("last_live_activity_success_epoch", 0.0) or 0.0) > 0
        error = str(state.get("last_live_activity_error", "") or "").strip()
        if not configured:
            report.error("Aivi", "aktiviert, Zugangsdaten fehlen")
        elif error:
            report.warn("Aivi", f"letzter Fehler: {error}")
        else:
            mode = str(config.get("aivi", {}).get("mode", "single_progress"))
            if mode == "single_progress":
                detail = "Single Progress"
            elif mode == "three_phase":
                detail = "Dreiphasenmodus"
            else:
                detail = "Legacy-Progress"
            suffix = (
                "bereits erfolgreich verwendet"
                if last_ok
                else "noch kein produktiver Vorgang"
            )
            report.ok("Aivi", f"{detail} · {suffix}")
    else:
        report.off("Aivi")

    data_dir = PATHS.data_dir
    required_dirs = [
        data_dir,
        data_dir / "logs",
        data_dir / "polls",
        data_dir / "events",
        data_dir / "sessions",
    ]
    bad_dirs: list[str] = []
    for directory in required_dirs:
        if not directory.exists():
            bad_dirs.append(directory.name)
            continue
        try:
            if stat.S_IMODE(directory.stat().st_mode) != 0o700:
                bad_dirs.append(f"{directory.name}:Rechte")
        except OSError:
            bad_dirs.append(directory.name)
    persistent_log = data_dir / "logs" / "observer.log"
    log_required = active and bool(config.get("diagnostics", {}).get("persistent_text_log", True))
    if log_required and not persistent_log.exists():
        bad_dirs.append("observer.log")
    disk = shutil.disk_usage(PATHS.data_dir)
    free_gib = disk.free / (1024 ** 3)
    retention_days = int(config.get("diagnostics", {}).get("retention_days", 180))
    max_size = int(config.get("diagnostics", {}).get("max_size_mib", 2048))
    diag_error = str(state.get("last_diagnostics_error", "") or "").strip()
    if bad_dirs:
        report.warn("Diagnose", "prüfen: " + ", ".join(bad_dirs))
    elif diag_error:
        report.warn("Diagnose", diag_error)
    else:
        report.ok("Diagnose", f"persistent · {retention_days} Tage / max. {max_size} MiB · {free_gib:.1f} GiB frei")

    if bool(config.get("web", {}).get("enabled", True)):
        if service_active("zero-connect-web.service"):
            report.ok("Web UI", f"aktiv · Port {int(config.get('web', {}).get('port', 8080))}")
        else:
            report.warn("Web UI", "Dienst inaktiv")
    else:
        report.off("Web UI")

    if bool(config.get("abrp", {}).get("enabled", False)):
        configured = bool(env.get("ABRP_TOKEN") and env.get("ABRP_API_KEY"))
        last_ok = float(state.get("last_abrp_success_epoch", 0.0) or 0.0) > 0
        error = str(state.get("last_abrp_error", "") or "").strip()
        if not configured:
            report.error("ABRP", "aktiviert, Zugangsdaten fehlen")
        elif error:
            report.warn("ABRP", f"letzter Fehler: {error}")
        elif last_ok:
            report.ok("ABRP", "bereits erfolgreich verwendet")
        else:
            report.ok("ABRP", "konfiguriert · wartet auf ersten Datensatz")
    else:
        report.off("ABRP")

    print("──────────────────────────────────────")
    if report.errors:
        warn_label = "Warnung" if report.warnings == 1 else "Warnungen"
        error_label = "Fehler" if report.errors != 1 else "Fehler"
        print(f"Ergebnis: {report.errors} {error_label} · {report.warnings} {warn_label}.")
        raise SystemExit(1)
    if report.warnings:
        label = "Warnung" if report.warnings == 1 else "Warnungen"
        print(f"Ergebnis: Kernsystem betriebsbereit · {report.warnings} {label}.")
    else:
        print("Ergebnis: Kernsystem betriebsbereit · keine Warnungen.")
    print()


if __name__ == "__main__":
    main()
